export interface ProductIds {
  [key: string]: Array<string>
}

export interface ProductsIds {
  productIds: ProductIds,
  keys: Array<string>,
}

export type MagnoliaType = string;

export interface MagnoliaObject {
  [key: string]: string | string[];
}
export interface MagnoliaDto {
  [key: string]: string | string[] | MagnoliaObject;
}
export interface MagnoliaData {
  data: MagnoliaDto;
  productIds: ProductsIds;
  templateName: string;
}
export interface BaseMeasure {
  '@name': string;
  '@path': string;
  '@id': string;
  '@nodeType': string;
  translation: string;
  unitPriceBaseMeasure: string;
  containerSizeLimit: string;
  '@nodes': Array<string>;
}
export interface PriceFormat {
  '@name': string;
  '@path': string;
  '@id': string;
  '@nodeType': string;
  ccy: string;
  showDecimalZero: string;
  thousandSeperator: string;
  noOfDigit: string;
  currencyPlacement: string;
  decimalPoint: string;
  isVatIncluded: string;
  vatIncludedMessage: string;
  baseMeasure: BaseMeasure;
  '@nodes': Array<string>;
}
