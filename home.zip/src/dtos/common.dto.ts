/** Generic response from CommerceTools */
export interface CtResponse<T> {
  statusCode: number;
  body: T;
}

export interface MagnoliaInfo {
  url: string;
  isPreview: boolean;
  marketPath: string;
}

export interface CommonResponse {
  [x: string]: string | any | unknown | undefined; // NOSONAR
}

export interface NotificationsRequestDto {
  sessionKey: string;
  customerKey: string;
  ticket?: string;
  productKey?: string;
  variantKey?: string;
}

export interface VariantAttribute {
  name: string;
  value: any; // NOSONAR
}
