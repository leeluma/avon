import {
  Attribute, LocalizedString, Product, ProductCatalogData, ProductData, ProductVariant, ProductVariantAvailability,
  InventoryEntry,
} from '@commercetools/platform-sdk';

export interface FieldRaw {
  name: string;
  value: any; // NOSONAR
}
export interface FieldType {
  name: string;
  id: any; // NOSONAR
}

export interface CustomFields {
  type: FieldType;
  customFieldsRaw: FieldRaw[];
}

export interface GraphQLInventoryEntry extends Omit<InventoryEntry, 'custom'> {
  custom: CustomFields;
}

export interface AttributesDto{
  variantType: string;
  variantValue: string;
  shortDescription: string;
  brandId: string;
  brandName: string;
  finishedStockCode: string;
  specialMessage: string;
  ContentFillMeasure: string;
  ContentFill: string;
  maxPurchasableQty: number;
  ratingCount: number;
  reviewCount: number;
  inStock: boolean;
  nonRepListPrice: string;
  nonRepSalePrice: string;
  isDiscontinued: boolean;
}

export interface ProductAttributesDto{
  contentFill: string;
  contentFillMeasure: string;
  description: string | LocalizedString;
  galleryImageUrl: string;
  thumbnailImageUrl: string;
  inStock: boolean;
  productMassDetails: string;
  maxPurchasableQty: number;
  metaKeywords: string;
  new: string;
  productSpecialMessage: string;
  ratingCount: number;
  reviewCount: number;
  title: string | LocalizedString;
  url: string;
  vatIncludedMsg: string;
  productKey?: string;
}

export interface AssetsDto{
  url: string;
  assetType?: string;
  sequence: number;
}

export interface Channel{
  key: string;
}

export interface GraphQLVariantAvailability extends Omit<ProductVariantAvailability,
  'id' > {
  id: string;
}
export interface ChannelAvailability{
  channel: Channel;
  availability: GraphQLVariantAvailability;
  id?: string;
}
export interface AvailabilityResults{
  results: ChannelAvailability[];
}
export interface VariantAvailability{
  channels: AvailabilityResults;
}
export interface AvailabilityDto{
  stockQty?: number;
  isAvailable?: boolean;
  isLimitedStock?: boolean;
}

export interface BadgesDto {
  topRight: string;
  topLeft: string;
}

export interface VariantDto{
  id: number;
  key?: string;
  sku?: string;
  listPrice: number,
  sellPrice: number,
  formattedListPrice: string,
  formattedSellPrice: string,
  vatMessage: string,
  unitPrice: string,
  attributes?: AttributesDto;
  badges: BadgesDto;
  availability: AvailabilityDto;
  assets: AssetsDto[];
}

export interface BreadcrumbDto {
  key: string;
  parentKey: string;
  displayName: string;
  url: string;
}

export interface CategoryDto {
  id: string;
  slug: string;
}

export interface ProductDto {
  id: string;
  key: string;
  name: string;
  description: string;
  metaDescription?: string;
  metaKeywords?: string;
  metaTitle?: string;
  isLive: boolean;
  masterVariant: VariantDto;
  variants: VariantDto[];
  categories: CategoryDto[];
  breadcrumb: BreadcrumbDto[];
  searchKeywords: string;
}

export interface BadgeNode {
  priority?: string;
  type?: string;
  text?: string;
  side?: string;
}

export interface LooseObject {
  [key: string]: string
}

export interface MultiProductDto {
  id: string;
  key: string | undefined;
  name: string | LooseObject;
  description: string | LooseObject | undefined;
  metaDescription?: string | LooseObject;
  metaKeywords?: string | LooseObject;
  metaTitle?: string | LooseObject;
  isLive: boolean;
  masterVariant?: VariantDto;
  variants?: VariantDto[];
  attributes: ProductAttributesDto;
}

export interface ImageDto {
  url: string;
  label: string;
  width: number;
  height: number;
}

export interface OffersDto {
  key: string;
  displayName: string;
  url: string;
  description: string;
}

export interface LineItemDto {
  lineItemId: string;
  productId: string;
  productKey?: string;
  name: string;
  skuCode?: string;
  images: ImageDto[];
  listPrice: number,
  sellPrice: number,
  formattedListPrice: string,
  formattedSellPrice: string,
  vatMessage: string,
  unitPrice: string,
  quantity: number;
  modifiedTimeStamp?: string;
  sequenceNumber: number;
  maxPurchasableQty: number;
  availableQuantity:number;
  hexCode: string;
  variantType: string;
  variantValue: string;
  offers: OffersDto[];
}
export interface ShippingAddressDto {
  id: string;
  title: string;
  salutation: string;
  firstName: string;
  lastName: string;
  streetName: string;
  streetNumber: string;
  additionalStreetInfo: string;
  postalCode: string;
  city: string;
  state: string;
  region: string;
  country: string;
  company: string;
  department: string;
  building: string;
  apartment: string;
  p0Box: string;
  phone: string;
  mobile: string;
  email: string;
  fax: string;
  additionalAddressInfo: string;
  externalId: string;
  key: string;
}

export interface LineItemsAddProductDto {
  productKey : string,
  sku : string,
  quantity : number,
}

export interface AddToCartRequestDto {
  cartId: string;
  customerId: string;
  lineItems: LineItemsAddProductDto;
}

export interface GraphQLVariant extends Omit<ProductVariant,
  'availability' > {
  availability: VariantAvailability;
  attributesRaw: Attribute[];
}
export interface GraphQLProductData extends Omit<ProductData,
  'masterVariant' | 'variants' > {
  masterVariant: GraphQLVariant;
  variants: GraphQLVariant[];
}
export interface GraphQLProductCatalogData extends Omit<ProductCatalogData,
  'current' > {
  current: GraphQLProductData;
}
export interface GraphQLProduct extends Omit<Product,
  'masterData' > {
  masterData: GraphQLProductCatalogData;
}
