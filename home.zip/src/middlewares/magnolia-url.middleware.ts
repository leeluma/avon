import { NextFunction, Request, Response } from 'express';
import { config } from '../config/config';
import { getMarketPath } from '../lib/utils';
import { MagnoliaInfo } from '../dtos/common.dto';

export const magnoliaUrlMiddleware = (req: Request, res: Response, next: NextFunction): void => {
  const { market } = res.locals;
  const { country } = market;
  const magnolia: MagnoliaInfo = {
    url: config.magnoliaBasePath as string,
    isPreview: false,
    marketPath: country.toLocaleLowerCase(),
  };

  const previewValue = req.query.isPreview ? (req.query.isPreview as string).toLowerCase() : false;
  if (previewValue === 'true') {
    magnolia.url = config.previewMagnoliaBasePath as string;
    magnolia.isPreview = true;
    const path = req.query.path ? req.query.path as string : '';
    const isGlobal = path ? (path.includes('Global')) : false;
    if (isGlobal) {
      const pathContext = path.split(',');
      magnolia.marketPath = getMarketPath(pathContext);// ['Global','CEE'], ['Global','en_US','CEE']
    }
  }

  res.locals.magnolia = magnolia;
  next();
};
