import axios from 'axios';
import {
  NextFunction, Request, Response,
} from 'express';
import { logger } from '../lib';
import { MAGNOLIA } from '../common/constant';

export enum LogStatus {
  NONE,
  TRACE,
  INFO,
  ERROR
}

export interface LogConfig{
  apptusLogStatus: LogStatus
}

export const apptusLogConfig = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  if (logger.isDebugEnabled()) {
    const url = `${process.env.MAGNOLIA_BASE_PATH}${MAGNOLIA.logSetting}`;
    axios(url).then((response) => {
      const { apptusLogStatus } = response?.data || LogStatus.NONE;
      res.locals.logConfig = {
        apptusLogStatus: Number(apptusLogStatus),
      };
    })
      .catch((err) => {
        logger.error(`Unable to fetch aptus log status from magnolia because: ${err.stack}`);
        res.locals.logConfig = {
          apptusLogStatus: LogStatus.NONE,
        };
      });
  } else {
    res.locals.logConfig = {
      apptusLogStatus: LogStatus.NONE,
    };
    next();
  }
};
