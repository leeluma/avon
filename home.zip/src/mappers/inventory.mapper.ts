import { GraphQLProduct } from '../dtos/product.dto';

export default class InventoryMapper {
  /**
   * Method to get all products inventories ids
   * @param products
   * @param channelKey
   * @returns
   */
  public getInventoriesId(
    products: GraphQLProduct[],
    channelKey: string,
  ): string {
    const inventoryIds = products.map((product) => {
      return this.getProductInventoriesIds(product, channelKey);
    });
    const ids = inventoryIds.filter((id) => id !== '');
    return ids.length > 0 ? ids.toString() : '';
  }

  /**
   * Method to get product all inventories id
   * @param product
   * @param channelKey
   * @returns
   */
  private getProductInventoriesIds(product:GraphQLProduct, channelKey: string): string {
    const { masterVariant, variants } = product.masterData.current;
    const channels = masterVariant.availability.channels?.results;
    const stockDetail = channels?.find((channel) => channel.channel.key === channelKey);
    const inventoryIds: string[] = [];
    variants.forEach((variant) => {
      const invChannels = variant.availability.channels?.results;
      const stockDetails = invChannels?.find((channel) => channel.channel.key === channelKey);
      if (stockDetails?.availability.id) {
        inventoryIds.push(stockDetails.availability.id);
      }
    });
    if (stockDetail !== undefined) {
      inventoryIds.push(stockDetail.availability.id);
    }
    return inventoryIds.length > 0 ? inventoryIds.map((id) => `"${id}"`).toString() : '';
  }
}
