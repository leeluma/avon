import { MultiProductDto } from '../dtos/product.dto';
import {
  MagnoliaData, ProductsIds, ProductIds,
} from '../dtos/magnolia.dto';
import { CommonResponse } from '../dtos';

export default class MagnoliaMapper {
  /**
   * Data mapping related to products carousel
   * @param magnoliaData
   * @returns magnolia data with carousel products ids
   */
  public pageData = (magnoliaData:CommonResponse): MagnoliaData => {
    const mainNodes = magnoliaData.main['@nodes'];
    const productIds = this.getCarouselProductIds(magnoliaData.main, mainNodes);
    return {
      data: magnoliaData,
      productIds,
      templateName: magnoliaData['mgnl:template'] as string,
    };
  };

  /**
   * Read products ids from magnolia carousel data
   * @param data magnolia response data
   * @param nodes main content nodes
   * @returns
   */
  private getCarouselProductIds(data: CommonResponse, nodes:Array<string>):ProductsIds {
    let productIds:ProductIds = {};
    const keys:Array<string> = [];
    nodes.forEach((key) => {
      const mainNode = data[key];
      if ('ProductCarousel' in mainNode) {
        const carouselNode = mainNode.ProductCarousel['@nodes'];
        const productsIds = carouselNode.map((carouselKey) => {
          const product = JSON.parse(mainNode.ProductCarousel[carouselKey].product);
          return product.productId;
        });
        productIds = {
          ...productIds,
          [key]: productsIds,
        };
        keys.push(key);
      }
    });
    return { productIds, keys };
  }

  /**
   * Append carousel products list in magnolia response with carousel data
   * @param data
   * @param nodes
   * @param productList
   * @returns
   */
  public appendProductList(
    data: CommonResponse,
    nodes:ProductsIds,
    productList:MultiProductDto[] | undefined | CommonResponse,
  ):CommonResponse {
    const magnoliaData = data;
    const { productIds, keys } = nodes;
    keys.forEach((key) => {
      const ids = productIds[key];
      const productJson = productList?.filter((product) => {
        return ids.find((id) => product.id === id);
      });
      magnoliaData[key] = {
        ...magnoliaData[key],
        productsList: productJson,
      };
    });
    return magnoliaData;
  }
}
