import { Price } from '@commercetools/platform-sdk';
import {
  AssetsDto, VariantDto, ChannelAvailability,
  AvailabilityDto, MultiProductDto, ProductAttributesDto, GraphQLVariant, GraphQLProduct, GraphQLInventoryEntry,
} from '../dtos/product.dto';
import { PriceFormat } from '../dtos/magnolia.dto';
import {
  ATTRIBUTE_NAMES, ATTRIBUTE_VALUES, DEFAULT_INVENTORY,
} from '../common/constant';
import { MarketInfo } from '../middlewares';
import { CommonResponse } from '../dtos';
import { Product } from '../lib/product';

export interface ProdutcMapperConfig {
  product: Product;
}

export default class ProductMapper {
  private readonly product: Product;

  constructor(config: ProdutcMapperConfig) {
    this.product = config.product;
  }

  /**
   * Maps variant images to product DTO
   * @param images - variant images
   * @returns
   */
  private readonly varImgToDTO = (variant: GraphQLVariant): AssetsDto[] => {
    const { images } = variant;
    const attribute = variant.attributesRaw;
    let assetsDto: AssetsDto[] = [];
    if ((typeof images !== 'undefined') && (images.length > 0)) {
      assetsDto = images.map((img, index) => {
        const assetDto: AssetsDto = {
          url: img.url,
          assetType: img.label,
          sequence: index,
        };
        return assetDto;
      });
    }
    /**
     * check for Gallery Video Attribute
     */
    const videoGallery = attribute?.find((value) => value.name === ATTRIBUTE_NAMES.galleryVideo);
    if ((typeof videoGallery !== 'undefined') && (videoGallery.value.length > 0)) {
      const videos:AssetsDto[] = videoGallery.value.map((video, index) => {
        return {
          url: video,
          assetType: ATTRIBUTE_VALUES.assetType,
          sequence: index,
        };
      });
      /**
       * merging images and Video attributes
       */
      assetsDto = [...assetsDto, ...videos];
    }
    return assetsDto;
  };

  /**
   * Maps child variant fields to product DTO
   * @param variants - all variant details of other variants
   * @param locale
   * @returns - All child Variants DTO
   */
  private readonly variantsToDto = (
    variants: GraphQLVariant[] | CommonResponse,
    locale:string,
    channelKey: string,
    priceFormat: PriceFormat,
    inventoryData: GraphQLInventoryEntry[],
  ): VariantDto[] => {
    if (variants?.length !== 0) {
      const variantDetails = variants.map((variant) => {
        const {
          sellPrice,
          listPrice,
          sellPriceCT,
          listPriceCT,
        } = this.checkChannel(variant.prices ?? []);
        const channels = variant.availability.channels?.results;
        const availabilities:AvailabilityDto = this.getStockDetails(channels, channelKey, inventoryData);
        const productAttr = this.product.prodAttrToDTO(variant.attributesRaw, locale);
        if (!productAttr?.isDiscontinued) {
          const variantDto: VariantDto = {
            id: Number(variant.id),
            key: variant.key,
            sku: variant.sku,
            sellPrice: Number(sellPrice),
            listPrice: Number(listPrice),
            formattedListPrice: this.product.magnoliaPriceFormatter(listPriceCT, priceFormat),
            formattedSellPrice: this.product.magnoliaPriceFormatter(sellPriceCT, priceFormat),
            vatMessage: (priceFormat.isVatIncluded === 'true') ? priceFormat.vatIncludedMessage : '',
            unitPrice: this.product.getUnitPrice(variant.attributesRaw, Number(sellPriceCT), priceFormat),
            availability: availabilities,
            assets: this.varImgToDTO(variant),
            attributes: {
              ...productAttr,
              inStock: availabilities.isAvailable ?? false,
              nonRepListPrice: listPrice,
              nonRepSalePrice: sellPrice,
            },
            badges: this.product.getBadgeDetails(variant.attributesRaw, sellPriceCT, listPriceCT, locale),
          };
          return variantDto;
        }
        return null;
      });
      return variantDetails.filter((n) => n);
    }
    return [];
  };

  /**
   * Check variant prices have channel price
   * @param prices variants prices
   * @returns
   */
  private readonly checkChannel = (prices: Price[]) => {
    const priceWithoutChannel = prices.find((attribute) => (attribute.channel === undefined
      || attribute.channel === null));
    const [firstPrice] = prices;
    return this.checkDiscount(priceWithoutChannel ?? firstPrice);
  };

  /**
   * Check if product price have discount property then return sell price after applied promotion
   * if discount property not available then return empty object
   * @param price  - All price details including promotional prices
   * @returns - sellPrice and isPromotionApplied
   */
  private readonly checkDiscount = (price: Price) => {
    if (price?.discounted !== undefined && price?.discounted !== null) {
      return {
        sellPrice: this.product.priceConverter(price.discounted.value.centAmount, price.discounted.value.fractionDigits),
        listPrice: this.product.priceConverter(price.value.centAmount, price.value.fractionDigits),
        sellPriceCT: price.discounted.value.centAmount,
        listPriceCT: price.value.centAmount,
        isPromotionApplied: true,
      };
    }
    return {
      sellPrice: this.product.priceConverter(price.value.centAmount, price.value.fractionDigits),
      listPrice: this.product.priceConverter(price.value.centAmount, price.value.fractionDigits),
      sellPriceCT: price.value.centAmount,
      listPriceCT: price.value.centAmount,
      isPromotionApplied: false,
    };
  };

  /**
  * get product stock details
  */
  private readonly getStockDetails = (
    channels: ChannelAvailability[],
    channelKey: string,
    inventoryData: GraphQLInventoryEntry[],
  ): AvailabilityDto => {
    if (channels.length === 0) {
      return DEFAULT_INVENTORY;
    }
    const stockDetails = channels?.find((channel) => channel.channel.key === channelKey);
    const inventory = inventoryData?.find((inv) => inv.id === stockDetails?.availability.id);
    let limitedStock = false;
    if (inventory !== undefined && inventory.custom !== null) {
      inventory.custom.customFieldsRaw.forEach((field) => {
        if (field.name === 'isLowAvailability') {
          limitedStock = field.value;
        }
      });
    }

    return {
      stockQty: stockDetails?.availability.availableQuantity,
      isAvailable: stockDetails?.availability.isOnStock,
      isLimitedStock: limitedStock,
    };
  };

  /**
   * Map multiple products
   * @param products - products array
   * @param locale - Locale of market
   * @returns - desired multi product response
   */
  public multiProductMap = (
    products:GraphQLProduct[],
    market: MarketInfo,
    channelKey: string,
    priceFormat: PriceFormat,
    inventoryData: GraphQLInventoryEntry[],
  ): MultiProductDto[] | CommonResponse => {
    const results: MultiProductDto[] | CommonResponse = products.map((product) => {
      return this.productMapping(product, market, channelKey, priceFormat, inventoryData);
    });
    return results;
  };

  /**
   * Maps product data for multiple products
   * @param product - main method to map product details
   * @param locale
   * @returns
   */
  public productMapping = (
    product: GraphQLProduct,
    market: MarketInfo,
    channelKey: string,
    priceFormat: PriceFormat,
    inventoryData: GraphQLInventoryEntry[],
  ): MultiProductDto | CommonResponse => {
    const masterVariant = this.variantsToDto(
      product?.masterData?.current?.masterVariant ? [product?.masterData?.current?.masterVariant] : [],
      market.locale, channelKey,
      priceFormat, inventoryData,
    );
    const variants = this.variantsToDto(product.masterData.current.variants, market.locale, channelKey,
      priceFormat, inventoryData);
    if (variants?.length === 0 && masterVariant?.length === 0) {
      return [];
    }
    const stockData = variants.find((record) => record.availability.isAvailable === true);
    let isOnStock = false;
    if (stockData !== undefined) {
      isOnStock = true;
    }
    const masterData = masterVariant.length > 0 ? masterVariant[0] : undefined;
    const productDto: MultiProductDto = {
      id: product.id,
      key: product?.key,
      name: product?.masterData?.current?.name,
      description: product?.masterData?.current?.description,
      metaTitle: product?.masterData?.current?.metaTitle ?? '',
      metaDescription: product?.masterData?.current?.metaDescription ?? '',
      isLive: true,
      masterVariant: masterData,
      variants,
      attributes: this.getProductAttributes(masterData as VariantDto, product, market, isOnStock),
    };
    return productDto;
  };

  /**
   * Product level attributes data
   * @param variant variant data
   * @param product product data
   * @returns
   */
  private readonly getProductAttributes = (
    variant:VariantDto,
    product:GraphQLProduct,
    market: MarketInfo,
    variantInStock: boolean,
  ):ProductAttributesDto => {
    const galleryImage = variant?.assets?.find((asset) => asset.assetType === 'Gallery');
    const thumbnailImage = variant?.assets?.find((asset) => asset.assetType === 'Thumbnail');
    const slug = product.masterData.current?.slug ?? '';
    const isOnStock = variant?.availability?.isAvailable ?? variantInStock;
    const attributes:ProductAttributesDto = {
      contentFill: variant?.attributes?.ContentFill ?? '',
      contentFillMeasure: variant?.attributes?.ContentFillMeasure ?? '',
      description: product.masterData.current?.description ?? '',
      galleryImageUrl: galleryImage?.url ?? '',
      thumbnailImageUrl: thumbnailImage?.url ?? '',
      inStock: isOnStock,
      productMassDetails: variant?.unitPrice,
      maxPurchasableQty: variant?.attributes?.maxPurchasableQty ?? 0,
      metaKeywords: this.product.getAllKeywords(product.masterData.current.searchKeywords, market.locale),
      new: '',
      productSpecialMessage: variant?.attributes?.specialMessage ?? '',
      ratingCount: variant?.attributes?.ratingCount ?? 0,
      reviewCount: variant?.attributes?.reviewCount ?? 0,
      title: product.masterData.current.name,
      url: slug ? `/${market.country.toLocaleLowerCase()}/p/${slug}` : '',
      vatIncludedMsg: variant?.vatMessage,
      productKey: product.key,
    };
    return attributes;
  };
}
