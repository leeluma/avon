import { readFile } from 'fs/promises';

const loadAsync = async (fileName: string): Promise<string> =>
  (await readFile(`${__dirname}/../graphql/${fileName}.graphql`, 'utf-8'))
    .toString();

export const graphql = {
  getProducts: loadAsync('get-products'),
  getInventories: loadAsync('get-inventories'),
};
