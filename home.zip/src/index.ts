import { Router } from 'express';
import { CtClient, Common, Product } from './lib';
import { LeapApp, LeapAppConfig } from './app/leap.app';

import {
  CartsController, NotificationsController, StaticPageController,
  HomeController, ProductController, DefaultController,
}
  from './controller';

import {
  CartsDao, ProductDao, MagnoliaDao, DefaultDao, NotificationsDao, InventoryDao,
} from './daos';

import {
  CartsService, ProductService, MagnoliaService, NotificationsService, DefaultService,
} from './services';

import MagnoliaMapper from './mappers/magnolia.mapper';
import { config } from './config/config';
import { graphql } from './graphql';
import ProductMapper from './mappers/product.mapper';
import InventoryMapper from './mappers/inventory.mapper';
import {
  CartsRouter, StaticPageRouter, NotificationsRouter, HomeRouter, ProductRouter, DefaultRouter,
}
  from './routes';

/* Build configuration */
const {
  projectName, projectVersion, apiContextPath, apiVersion, port, magnoliaBasePath, previewMagnoliaBasePath,
} = config;
if (!projectName) {
  throw new Error('The "name" field in package.json is mandatory!');
}

if (!projectVersion) {
  throw new Error('The "version" field in package.json is mandatory!');
}

if (!apiContextPath) {
  throw new Error('The "API_CONTEXT_PATH" environment variable is mandatory! (suggested value: api)');
}
if (!apiVersion) {
  throw new Error('The "API_VERSION" environment variable is mandatory! (suggested value: v1)');
}
if (!port) {
  throw new Error('The "API_PORT" environment variable is missing or not a valid number! (suggested value: 3000)');
}
const beOrderUrl = process.env.LEAP_BE_ORDER;
if (!beOrderUrl) {
  throw new Error('The "LEAP_BE_ORDER" environment variable is mandatory!');
}

if (!magnoliaBasePath) {
  throw new Error('The "MAGNOLIA_BASE_PATH" environment variable is mandatory!');
}

if (!previewMagnoliaBasePath) {
  throw new Error('The "PREVIEW_MAGNOLIA_BASE_PATH" environment variable is mandatory!');
}
const apptusEsalesMarket = process.env.APPTUS_ESALES_MARKET;
if (!apptusEsalesMarket) {
  throw new Error('The "APPTUS_ESALES_MARKET" environment variable is missing');
}

const apptusBaseUrl = process.env.APPTUS_BASE_URL;
if (!apptusBaseUrl) {
  throw new Error('The "APPTUS_BASE_URL" environment variable is missing');
}

const apptusClusterId = process.env.APPTUS_CLUSTER_ID;
if (!apptusClusterId) {
  throw new Error('The "APPTUS_CLUSTER_ID" environment variable is missing');
}

const appConfig: LeapAppConfig = {
  projectName,
  projectVersion,
  apiContextPath,
  apiVersion,
  port,
};

/* Initialize dependencies */
const common = new Common();
const product = new Product();
const notificationsDao = new NotificationsDao({
  common,
  apptusBaseUrl,
  apptusClusterId,
  apptusEsalesMarket,
});
const ctClient = new CtClient(process.env as any);
const productDao = new ProductDao({
  ctClient,
  graphql,
  beOrderUrl,
});
const productMapper = new ProductMapper({ product });
const magnoliaMapper = new MagnoliaMapper();
const inventoryMapper = new InventoryMapper();

const cartsDao = new CartsDao({ beOrderUrl });
const magnoliaDao = new MagnoliaDao();
const inventoryDao = new InventoryDao({ ctClient, graphql });
const defaultDao = new DefaultDao({ ctClient });
// services
const productService = new ProductService({
  productDao, productMapper, inventoryMapper, inventoryDao,
});
const cartsService = new CartsService({ cartsDao });
const magnoliaService = new MagnoliaService({
  magnoliaDao, magnoliaMapper, productService,
});
const notificationsService = new NotificationsService({ notificationsDao });
const defaultService = new DefaultService({ defaultDao });

// controllers
const cartsController = new CartsController({ cartsService });
const productController = new ProductController({ productService });
const homeController = new HomeController({ productService, magnoliaService });
const staticPageController = new StaticPageController({ magnoliaService });
const notificationsController = new NotificationsController({ notificationsService });
const defaultController = new DefaultController({ defaultService });

// routers
const productRouter = new ProductRouter({ productController, Router });
const homeRouter = new HomeRouter({ homeController, Router });
const staticPageRouter = new StaticPageRouter({ staticPageController, Router });
const cartsRouter = new CartsRouter({ Router, cartsController });
const defaultRouter = new DefaultRouter({ defaultController, Router });
const notificationsRouter = new NotificationsRouter({ Router, notificationsController });

/* Start app */

const leapApp = new LeapApp(appConfig);
leapApp.bootstrap();
leapApp.mount('/', defaultRouter.buildExpressRouter());
leapApp.mount('/products', productRouter.buildExpressRouter());
leapApp.mount('/home', homeRouter.buildExpressRouter());
leapApp.mount('/static', staticPageRouter.buildExpressRouter());
leapApp.mount('/notifications', notificationsRouter.buildExpressRouter());
leapApp.mount('/carts', cartsRouter.buildExpressRouter());
leapApp.listen();
