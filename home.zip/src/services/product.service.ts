import { MultiProductDto, AddToCartResponseDto, CommonResponse } from '../dtos';
import { PriceFormat } from '../dtos/magnolia.dto';
import { ProductDao, InventoryDao } from '../daos';
import ProductMapper from '../mappers/product.mapper';
import InventoryMapper from '../mappers/inventory.mapper';
import { MarketInfo } from '../middlewares';

interface ProductServiceConfig {
  productDao: ProductDao;
  inventoryDao: InventoryDao;
  productMapper: ProductMapper;
  inventoryMapper: InventoryMapper;
}

/**
 * `ProductService` for business logic `Product Detail Page`
 */
export class ProductService {
  private readonly productDao: ProductDao;

  private readonly inventoryDao: InventoryDao;

  private readonly productMapper: ProductMapper;

  private readonly inventoryMapper: InventoryMapper;

  /**
   * Constructor for `ProductService` class
   * @param config injects dependencies into the object
   */
  constructor(config: ProductServiceConfig) {
    this.productDao = config.productDao;
    this.inventoryDao = config.inventoryDao;
    this.productMapper = config.productMapper;
    this.inventoryMapper = config.inventoryMapper;
  }

  /**
   * Get multiple products data from CT
   * @param market - MarketInfo
   * @param productIds - Product Ids
   * @returns Multiple Products Response
   */
  public async getProductByIds(
    market: MarketInfo,
    productIds: Array<string>,
    channelKey: string,
    priceFormat: PriceFormat,
  ): Promise<MultiProductDto[] | CommonResponse | undefined> {
    const productsIds = productIds.length > 0 ? productIds.map((id) => `"${id}"`).toString() : '';
    const result = await this.productDao.fetchProducts(market, productsIds);
    const resultData = result?.data?.products ?? undefined;

    if (
      resultData === undefined
      || result.data?.products?.results?.length === 0
    ) {
      return undefined;
    }
    const inventoriesIds = this.inventoryMapper.getInventoriesId(resultData.results, channelKey);
    let inventoryData;
    if (inventoriesIds !== undefined && inventoriesIds.length > 0) {
      inventoryData = await this.inventoryDao.fetchInventoryDetail(market, inventoriesIds);
    }
    return this.productMapper.multiProductMap(
      resultData.results,
      market,
      channelKey,
      priceFormat,
      inventoryData,
    );
  }

  /**
   * Add products to cart
   * @param market - MarketInfo
   * @param customerId - Customer Id
   * @param cartId - cart Id
   * @param sku - Sku
   * @param quantity - Quantity
   * @param productKey - Product key
   * @returns Cart response from order
   */
  public async addProductToCart(
    market: MarketInfo,
    customerId: string,
    cartId: string,
    sku: string,
    quantity: number,
    productKey: string,
  ): Promise<AddToCartResponseDto> {
    return this.productDao.addProductToCart(
      market,
      customerId,
      cartId,
      sku,
      quantity,
      productKey,
    );
  }
}
