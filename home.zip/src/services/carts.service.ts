import { AddToCartResponseDto } from '../dtos';
import { MarketInfo } from '../middlewares';
import { CartsDao } from '../daos';

export interface CartsServiceConfig {
  cartsDao: CartsDao;
}
export interface CartsInfo {
  market: MarketInfo,
  channelKey: string | undefined,
  customerId: string,
  anonymousId: string | undefined,
  cartId: string,
  sku: string,
  quantity: number,
  productKey: string,
}

/**
 * Service for managing Carts
 */
export class CartsService {
  private readonly cartsDao: CartsDao;

  /**
   * Constructor for `CartsService` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: CartsServiceConfig) {
    this.cartsDao = config.cartsDao;
  }

  public async addProductToCart(
    cartsInfo: CartsInfo,
  ): Promise<AddToCartResponseDto> {
    return this.cartsDao.addProductToCart(cartsInfo);
  }
}
