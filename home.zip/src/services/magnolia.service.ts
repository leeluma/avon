import { MultiProductDto } from '../dtos/product.dto';
import { ProductIds, PriceFormat, MagnoliaDto } from '../dtos/magnolia.dto';
import { MagnoliaDao } from '../daos/magnolia.dao';
import MagnoliaMapper from '../mappers/magnolia.mapper';
import { MarketInfo } from '../middlewares';
import { ProductService } from './product.service';
import { MagnoliaInfo } from '../dtos/common.dto';
import { CommonResponse } from '../dtos';

interface MagnoliaServiceConfig {
  magnoliaDao: MagnoliaDao;
  magnoliaMapper: MagnoliaMapper;
  productService: ProductService;
}

/**
 * `MagnoliaService` for business logic Magnolia data
 */
export class MagnoliaService {
  private readonly magnoliaDao: MagnoliaDao;

  private readonly magnoliaMapper: MagnoliaMapper;

  private readonly productService: ProductService;

  /**
   * Constructor for `MagnoliaService` class
   * @param config injects dependencies into the object
   */
  constructor(config: MagnoliaServiceConfig) {
    this.magnoliaDao = config.magnoliaDao;
    this.magnoliaMapper = config.magnoliaMapper;
    this.productService = config.productService;
  }

  /**
   * Get multiple products data from CT
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   * @param channelKey - channel key
   * @returns Multiple Products Response
   */
  public async getPageData(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
    channelKey: string | undefined,
  ): Promise<CommonResponse | undefined> {
    const [globalSettings, magnoliaResponse] = await Promise.all([
      this.magnoliaDao.getGlobalSettings(market, magnolia.url),
      this.magnoliaDao.getHomeDataFromMagnolia(market, magnolia),
    ]);
    let warehouseKey;
    warehouseKey = channelKey;
    if (channelKey === undefined) {
      const warehouseResult = globalSettings.warehouseSettings;
      warehouseKey = warehouseResult.defaultWarehouse;
    }
    const magnoliaData = this.magnoliaMapper.pageData(magnoliaResponse);
    const { productIds, keys } = magnoliaData.productIds;
    let productList: MultiProductDto[] | CommonResponse | undefined;
    if (Object.keys(productIds).length > 0) {
      productList = await this.getProductsList(market, productIds, keys, warehouseKey, globalSettings.priceFormat);
    }
    const mainData = this.magnoliaMapper.appendProductList(magnoliaResponse.main, magnoliaData.productIds, productList);
    return {
      ...magnoliaData,
      main: mainData,
    };
  }

  public async getTemplateData(
    templateName: string,
    magnolia: MagnoliaInfo,
  ): Promise<MagnoliaDto> {
    return this.magnoliaDao.getTemplateDataFromMagnolia(templateName, magnolia);
  }

  /**
   * Get products list from CT through product services
   * @param market MarketInfo
   * @param productIds Products ids
   * @param keys Products Keys
   * @param channelKey Warehouse key
   * @param priceFormat Global price format
   * @returns return the list of products
   */
  public async getProductsList(
    market:MarketInfo,
    productIds:ProductIds,
    keys:Array<string>,
    channelKey: string,
    priceFormat: PriceFormat,
  ):Promise<MultiProductDto[] | CommonResponse | undefined> {
    let ids:Array<string> = [];
    keys.forEach((key) => {
      ids = [...ids, ...productIds[key]];
    });
    return this.productService.getProductByIds(market, ids, channelKey, priceFormat);
  }

  /**
   * Get magnolia static page data
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   * @param pagePath - Magnolia static page path url
   * @returns Page data from Magnolia
   */
  public async getStaticPageData(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
    pagePath: string,
  ): Promise<MagnoliaDto | undefined> {
    const staticPageResponse = await this.magnoliaDao.getStaticPageDataFromMagnolia(market, magnolia, pagePath);
    return {
      ...staticPageResponse,
    };
  }

  /**
   * Get magnolia global settings data
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   * @returns Global settings data from Magnolia
   */
  public async getGlobalSettings(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ): Promise<CommonResponse> {
    const globalSettings = await this.magnoliaDao.getGlobalSettings(market, magnolia.url);
    return {
      ...globalSettings,
    };
  }
}
