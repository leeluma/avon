import { MarketInfo } from '../middlewares';
import { NotificationsDao } from '../daos/notification.dao';
import { NotificationsRequestDto } from '../dtos';

export interface NotificationsServiceConfig {
  notificationsDao: NotificationsDao;
}

export interface NotificationsParams {
  sessionKey: string,
  customerKey: string,
  ticket?: string,
  productKey?:string,
  variantKey?: string,
  }

/**
 * Service for managing notifications
 */
export class NotificationsService {
  private readonly notificationsDao: NotificationsDao;

  constructor(config: NotificationsServiceConfig) {
    this.notificationsDao = config.notificationsDao;
  }

  /**
   * create a notification for a add to cart
   * @param market - MarketInfo
   * @param productId - Product id
   * @returns ProductResponseDto
   * @throws ApiError 400
   */
  public async addToCart(
    market: MarketInfo,
    params: NotificationsRequestDto,
  ): Promise<boolean> {
    return this.notificationsDao.cartNotifications(market, params);
  }

  /**
   * create a notification for a product
   * @param market - MarketInfo
   * @param productId - Product id
   * @returns ProductResponseDto
   * @throws ApiError 400
   */
  public async product(
    market: MarketInfo,
    params: NotificationsRequestDto,
  ): Promise<boolean> {
    return this.notificationsDao.esaleNotifications(market, params);
  }
}
