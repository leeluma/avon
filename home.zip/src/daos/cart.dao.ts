import axios, { AxiosRequestConfig } from 'axios';
import { ApiError, logger } from '../lib';
import { MarketInfo } from '../middlewares';
import { AddToCartResponseDto } from '../dtos';
import { RESPONSE_KEY } from '../common/constant';

export interface CartsDaoConfig {
  beOrderUrl: string;
}
export interface CartsData {
  market: MarketInfo,
  channelKey: string | undefined,
  customerId: string,
  anonymousId: string | undefined,
  cartId: string,
  sku: string,
  quantity: number,
  productKey: string,
}

/**
 * `CartsDao` data access class for Carts
 */
export class CartsDao {
  private readonly beOrderUrl: string;

  /**
   * Constructor for `CartsDao` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: CartsDaoConfig) {
    this.beOrderUrl = config.beOrderUrl;
  }

  public async addProductToCart(
    cartData: CartsData,
  ): Promise<AddToCartResponseDto> {
    const {
      market, channelKey, customerId, anonymousId, cartId, sku, quantity, productKey,
    } = cartData;
    const axiosConfig: AxiosRequestConfig = {
      method: 'post' as const,
      url: `${this.beOrderUrl.replace('{{MARKET}}', market.localeAndCountry)}/carts`,
      headers: {
        'Content-Type': RESPONSE_KEY.applicationJson,
        Accepts: RESPONSE_KEY.applicationJson,
      },
      data: {
        anonymousId,
        customerId,
        channelKey,
        cartId,
        lineItems: { sku, quantity, productKey },
      },
    };

    try {
      const response = await axios(axiosConfig);

      return response.data.data;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`LEAP BE ORDER returned error: ${err}`);

      if (!err.response) {
        throw err;
      }

      throw new ApiError(err.response.status, err.response.data?.errors);
    }
  }
}
