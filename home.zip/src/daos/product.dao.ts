import axios, { AxiosRequestConfig } from 'axios';
import { ClientResponse, GraphQLResponse } from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import { axiosOptions } from '../lib/axios-options';
import { logger, ApiError, CtClient } from '../lib';
import { MarketInfo } from '../middlewares';
import { AddToCartResponseDto } from '../dtos';
import { graphql } from '../graphql';

interface CtProductDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
  beOrderUrl: string;
}

/**
 * `CtProductDao` data access class for CommerceTools `Product`
 */
export class ProductDao {
  private readonly ctClient: CtClient;

  private readonly beOrderUrl: string;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `ProductDao` class
   * @param config injects dependencies into the object
   */
  constructor(config: CtProductDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
    this.beOrderUrl = config.beOrderUrl;
  }

  /**
   * Fetch products data based on provided ids using GraphQL
   * @param market - Market info
   * @param productIds - multiple product ids as comma separated
   * @returns - product details
   */
  public async fetchProducts(
    market: MarketInfo,
    productIds: string,
  ): Promise<GraphQLResponse> {
    const body = {
      query: await this.graphql.getProducts,
      variables: {
        where: `id in (${productIds})`,
        locale: market.locale,
      },
    };

    let ctResponse: ClientResponse<GraphQLResponse>;

    try {
      ctResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body })
        .execute();
      if (ctResponse.body?.data === null && ctResponse.body?.errors?.length !== undefined) {
        throw new ApiError(
          HttpStatusCodes.BAD_REQUEST,
          'Malformed parameter: UUID string is invalid',
        );
      }
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
        + ` GraphQL returned: ${JSON.stringify(err.body?.errors)}.`);
      throw err;
    }
    return ctResponse.body;
  }

  public async addProductToCart(
    market: MarketInfo,
    customerId: string,
    cartId: string,
    sku: string,
    quantity: number,
    productKey: string,
  ): Promise<AddToCartResponseDto> {
    const applicationType = 'application/json';
    const axiosConfig: AxiosRequestConfig = {
      ...axiosOptions,
      method: 'post' as const,
      url: `${this.beOrderUrl.replace('{{MARKET}}', market.localeAndCountry)}/carts`,
      headers: {
        'Content-Type': applicationType,
        Accepts: applicationType,
      },
      data: {
        customerId,
        cartId,
        lineItems: { sku, quantity, productKey },
      },
    };
    try {
      const response = await axios(axiosConfig);
      return response?.data?.data;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`LEAP BE ORDER returned error: ${err}`);
      if (!err.response) {
        throw err;
      } else {
        throw new ApiError(err.response.status, err.response.data?.errors);
      }
    }
  }
}
