import { MarketInfo } from '../middlewares';
import { logger, CtClient, ApiError } from '../lib';
import { AnonymousFlowDto, CommonResponse } from '../dtos';

export interface DefaultDaoConfig {
  ctClient: CtClient;
}

/**
 * `DefaultDao` data access class for CommerceTools `Default`
 */
export class DefaultDao {
  private readonly ctClient: CtClient;

  /**
   * Constructor for `DefaultDraftDto` class
   * @param config injects dependencies into the object
   */
  constructor(config: DefaultDaoConfig) {
    this.ctClient = config.ctClient;
  }

  /** Create anonymous session
   * @param market - MarketInfo
   * @param anonymousId - anonymousId
   */
  public async createAnonymousSession(
    market: MarketInfo,
    anonymousId: string,
  ): Promise<AnonymousFlowDto> {
    try {
      return await this.ctClient.getAuthClient(market.country)
        .anonymousFlow(anonymousId);
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to create anonymous session from CT because:\n${error}`);
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, error.errors);
      }
      throw error;
    }
  }

  /**
   * Get result from Commerce Tool
   * @param market - MarketInfo
   * @param params - Params
   * @returns result
   */
  public async refreshToken(
    market: MarketInfo,
    params: CommonResponse | string,
  ): Promise<CommonResponse> {
    try {
      return await this.ctClient.getAuthClient(market.country).refreshTokenFlow(params);
    } catch (error: any) { // NOSONAR
      logger.error(`Failed to generate refreshToken from Commerce Tool because:\n${error}`);
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, error.errors);
      }
      throw error;
    }
  }
}
