import axios from 'axios';
import HttpStatusCodes from 'http-status-codes';
import { axiosOptions } from '../lib/axios-options';
import { MarketInfo } from '../middlewares';
import { MAGNOLIA_URI } from '../common/constant';
import { MagnoliaDto } from '../dtos/magnolia.dto';
import { CommonResponse } from '../dtos';
import { MagnoliaInfo } from '../dtos/common.dto';
import { ApiError } from '../lib';

const country = '{{country}}';
/**
 * `MagnoliaDao` data access class for Magnolia
 */
export class MagnoliaDao {
  /**
   * Get Home page data From Magnolia
   * @param market - MarketInfo
   * @returns Return home data from Magnolia
   */
  public async getHomeDataFromMagnolia(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ) : Promise<CommonResponse> {
    const queryParam = `lang=${market.locale}-${market.country}`;
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: `${magnolia.url}${MAGNOLIA_URI.home}${magnolia.marketPath}?${queryParam}`,
    };

    try {
      const page = await axios(config);
      return page.data;
    } catch (error:any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch home data from Magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get Home template data from Magnolia
   * @param templateName magnolia template name
   * @returns return Home template data from Magnolia
   */
  public async getTemplateDataFromMagnolia(
    templateName: string,
    magnolia: MagnoliaInfo,
  ) : Promise<MagnoliaDto> {
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: `${magnolia.url}${MAGNOLIA_URI.template}${templateName}`,
    };
    try {
      const howToLook = await axios(config);
      return howToLook.data;
    } catch (error:any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch home template data from Magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get static page data from Magnolia
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   * @param pagePath - Magnolia static page path url
   * @returns Page data from Magnolia
   */
  public async getStaticPageDataFromMagnolia(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
    pagePath: string,
  ) : Promise<MagnoliaDto> {
    const queryParam = `lang=${market.locale}-${market.country}`;
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: `${magnolia.url}${MAGNOLIA_URI.home}${magnolia.marketPath}/pages/${pagePath}?${queryParam}`,
    };
    try {
      const page = await axios(config);
      return page.data;
    } catch (error:any) { // NOSONAR
      if (error?.response
        && (error?.response?.status === HttpStatusCodes.NOT_FOUND
           || error?.response?.status === HttpStatusCodes.INTERNAL_SERVER_ERROR)
      ) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, 'Page not found.');
      }
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch static page data from Magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get warehouse data
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   */
  public async getDefaultWarehouse(
    market: MarketInfo,
    magnoliaBasePath: string,
  ) : Promise<MagnoliaDto> {
    try {
      let wareHouseSettingUrl = `${magnoliaBasePath}${MAGNOLIA_URI.wareHouseSetting}?lang=${market.localeAndCountry}`;
      wareHouseSettingUrl = wareHouseSettingUrl.replace(country, `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: wareHouseSettingUrl,
      };
      const result = await axios(config);
      return result.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch warehouse data from magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get price format data
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   */
  public async getPriceFormat(
    market: MarketInfo,
    magnoliaBasePath: string,
  ) : Promise<MagnoliaDto> {
    try {
      let priceFormatUrl = `${magnoliaBasePath}${MAGNOLIA_URI.priceFormat}?lang=${market.localeAndCountry}`;
      priceFormatUrl = priceFormatUrl.replace(country, `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: priceFormatUrl,
      };
      const result = await axios(config);
      return result.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch price format data from magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get global settings data
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   */
  public async getGlobalSettings(
    market: MarketInfo,
    magnoliaBasePath: string,
  ) : Promise<CommonResponse> {
    try {
      let globalSettingsUrl = `${magnoliaBasePath}${MAGNOLIA_URI.globalSettings}?lang=${market.localeAndCountry}`;
      globalSettingsUrl = globalSettingsUrl.replace(country, `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: globalSettingsUrl,
      };
      const result = await axios(config);
      return result.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch global settings data from magnolia, because: ${error.stack}`);
    }
  }
}
