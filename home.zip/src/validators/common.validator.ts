import {
  body, header, oneOf, param,
} from 'express-validator';

export const validateId = [
  param('id')
    .exists({ checkNull: true, checkFalsy: true })
    .isUUID()
    .withMessage('validationError.idMustExistAndValidUuid'),
];

export const validateNotifications = [
  header('sessionKey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  header('customerKey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  oneOf([
    [
      body('productKey').notEmpty().withMessage('common.notEmpty'),
      body('variantKey').notEmpty().withMessage('common.notEmpty'),
    ],
    body('ticket').notEmpty().withMessage('common.notEmpty'),
  ]),
];
