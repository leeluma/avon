import { body } from 'express-validator';

export const validateCustomerLoginRequestBody = [
  body('email').notEmpty().isEmail().withMessage('internet.email'),
  body('password').notEmpty().isLength({ min: 6, max: 18 }).withMessage('internet.password'),
];
