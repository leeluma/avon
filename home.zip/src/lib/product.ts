import { Attribute } from '@commercetools/platform-sdk';
import { PriceFormat } from '../dtos/magnolia.dto';
import {
  AttributesDto, BadgeNode, BadgesDto, CommonResponse,
} from '../dtos';
import {
  ATTRIBUTE_NAMES, ATTRIBUTE_VALUES, BADGE_NAMES, BADGE_VALUES, MEASUREMENT, ATTRIBUTE_TYPES,
} from '../common/constant';

export class Product {
  /**
   *
   * @param sellPrice : discounted price
   * @param listPrice : actual price
   * @returns discount in percentage
   */
  public getPriceDiff(sellPrice:number, listPrice:number): number {
    const numberHundred = 100;
    const numberTwo = 2;
    let productDiff = 0;
    if (listPrice > sellPrice) {
      productDiff = numberHundred * Math.abs((listPrice - sellPrice) / ((listPrice + sellPrice) / numberTwo));
    }
    return Math.floor(productDiff);
  }

  /**
  * Get Formatted Magnolia Price
  * @param price - List of prices
  * @param priceFormat - Magnolia Price Format
  * @returns Magnolia Formatted Price
  */
  public magnoliaPriceFormatter = (price: number, priceFormat: PriceFormat): string => {
    let calculatedPrice = '';
    const numberTen = 10;
    const currency: string = priceFormat.ccy;
    const showDecimalZero = Boolean(priceFormat.showDecimalZero ?? false);
    const noOfDigitAtLast = Number(priceFormat.noOfDigit ?? 0);
    const decimalPoint: string = priceFormat.decimalPoint ?? '.';
    const thousandSeparator: string = priceFormat.thousandSeperator ?? '';
    const currencyPlacement: string = priceFormat.currencyPlacement ?? 'after';
    const lastDigitNo: number = numberTen ** noOfDigitAtLast;
    const sellPrice = (price / lastDigitNo).toFixed(noOfDigitAtLast);
    const parts = sellPrice.toString().split('.');
    const calculation = parts[1] ? decimalPoint + parts[1] : '';
    const returnPrice = showDecimalZero === true ? (parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator)
    + calculation) : parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator);
    calculatedPrice = (currencyPlacement === 'before')
      ? `${currency} ${returnPrice}` : `${returnPrice} ${currency}`;
    return calculatedPrice;
  };

  /**
   * function to convert number to decimal in given fraction
   * @param amount - Given amount
   * @param fraction - Given fraction
   * @returns
   */
  public readonly priceConverter = (amount:number, fraction:number) => {
    const numberTen = 10;
    return (amount / (numberTen ** fraction)).toFixed(fraction);
  };

  /**
   * for getting comma separated Search Keywords string of products
   */
  public readonly getAllKeywords = (searchKey, locale: string): string => {
    let keywords;
    if (typeof searchKey !== undefined && searchKey?.length > 0) {
      const searchKeywords = searchKey?.find((searchKeyword) => searchKeyword.locale === locale);
      keywords = typeof searchKeywords !== undefined
        ? searchKeywords.searchKeywords?.map((keyword) => keyword.text).toString() : '';
    }
    return keywords ?? '';
  };

  /**
   *
   * @param obj : array of object
   * @returns get highest priority in array of objects
   */
  public getMaxPriority(obj:CommonResponse) {
    let maxPriority: BadgeNode = {};
    if (obj.length > 0) {
      maxPriority = obj.reduce((prev, current) => {
        return (prev.priority > current.priority) ? prev : current;
      });
    }
    return maxPriority;
  }

  private readonly mapBadgeDetails = (getBadgeObject, locale, sellPrice, listPrice) => {
    const returnObj = { topRight: '', topLeft: '' };
    const badgeEmptyObj = {
      type: '', text: '', side: '', priority: '',
    };
    const badgeValObj = {
      type: '', text: '', side: '', priority: '',
    };
    const getLeft: Array<string> = [];
    const getRight: Array<string> = [];
    const wrapper = {};
    let priceDiff: number;
    getBadgeObject.value.map((entry, index) => {
      entry.map((badges) => {
        if (typeof badges.value[locale] !== 'undefined') {
          badgeValObj.text = badges.value[locale];
        } else if (badges.name === BADGE_NAMES.side) {
          badgeValObj.side = badges.value.key;
        } else if (badges.name === BADGE_NAMES.type) {
          badgeValObj.type = badges.value.key;
        } else if (badges.name === BADGE_NAMES.priority) {
          badgeValObj.priority = badges.value;
        }
        return badgeValObj;
      });
      wrapper[index] = { ...badgeValObj };
      if (wrapper[index].side === BADGE_VALUES.topLeft) {
        if (wrapper[index].type === BADGE_VALUES.discount) {
          priceDiff = this.getPriceDiff(sellPrice, listPrice);
          if (priceDiff > 0) {
            wrapper[index].text = `- ${priceDiff} %`;
          } else {
            wrapper[index] = badgeEmptyObj;
          }
        }
        getLeft.push(wrapper[index]);
      } else if (wrapper[index].side === BADGE_VALUES.topRight) {
        getRight.push(wrapper[index]);
      }
      return wrapper;
    });
    const maxLeft = this.getMaxPriority(getLeft);
    const maxRight = this.getMaxPriority(getRight);
    returnObj.topRight = maxRight?.text ?? '';
    returnObj.topLeft = maxLeft?.text ?? '';
    return returnObj;
  };

  /**
   *
   * @param attributes
   * @param locale
   * @returns badges with respective value in it
   */
  public readonly getBadgeDetails = (attributes:Attribute[], sellPrice, listPrice, locale: string):BadgesDto => {
    let returnObj = { topRight: '', topLeft: '' };
    const getBadgeObject = attributes?.find((value) => value.name === ATTRIBUTE_NAMES.badges);
    if ((typeof getBadgeObject !== 'undefined') && (ATTRIBUTE_VALUES.attributeValue in getBadgeObject)) {
      returnObj = this.mapBadgeDetails(getBadgeObject, locale, sellPrice, listPrice);
    }
    return returnObj;
  };

  /**
   * @param attributes all variant attributes
   * @param sellPrice : variant sell price after discount
   * @param priceFormat :global price format
   * @returns : string with unit price measurement
   */
  public readonly getUnitPrice = (
    attributes:Attribute[] | undefined,
    sellPrice:number,
    priceFormat: PriceFormat,
  ):string => {
    let allBaseNodes;
    let measuredValue;
    let result = '';
    let formattedPrice;
    const unitFillMeasureObj = attributes?.find((attribute) => attribute.name === ATTRIBUTE_NAMES.contentFillMeasurement);
    const unitFillValueObj = attributes?.find((attribute) => attribute.name === ATTRIBUTE_NAMES.contentFill);
    const allNodes: CommonResponse = {};
    const unitFillMeasure = unitFillMeasureObj?.value?.key || '';
    const unitFillValue = unitFillValueObj?.value || 0;

    if (Object.keys(priceFormat).length > 0 && unitFillMeasure !== '' && unitFillValue !== 0) {
      // normalizing unit price json response
      if (MEASUREMENT.baseMeasure in priceFormat && MEASUREMENT.nodes in priceFormat.baseMeasure) {
        allBaseNodes = priceFormat.baseMeasure[MEASUREMENT.nodes];
        allBaseNodes?.forEach((key) => {
          const nodeKey = priceFormat.baseMeasure[key]?.unitType;
          allNodes[nodeKey] = priceFormat.baseMeasure[key];
          return allNodes;
        });
      }
      // get Unit Price Measurement details
      if (unitFillMeasure in allNodes && unitFillValue > allNodes[unitFillMeasure]?.containerSizeLimit) {
        measuredValue = sellPrice * (allNodes[unitFillMeasure].unitPriceBaseMeasure / unitFillValue);
        formattedPrice = this.magnoliaPriceFormatter(Math.round(measuredValue), priceFormat);
        result = `${formattedPrice} per ${allNodes[unitFillMeasure].unitPriceBaseMeasure}`
            + `${allNodes[unitFillMeasure].translation}`;
      }
    }
    return result;
  };

  private readonly attrVal = (val: CommonResponse, locale: string): CommonResponse => {
    if ((typeof val) in ATTRIBUTE_TYPES) {
      return val;
    }
    return locale in val ? val[locale] : val.key;
  };

  /**
   * Maps attribute to product DTO
   * @param attributes - all variants attribute
   * @param locale - locale of market
   * @returns
   */
  public prodAttrToDTO = (attributes: Attribute[], locale: string): AttributesDto => {
    const attributesDto: CommonResponse = attributes?.filter(
      ({ name }) => name !== 'startDate' && name !== 'endDate',
    )
      .reduce(
        (obj, item) => Object.assign(obj,
          { [item.name]: this.attrVal(item.value, locale) }),
        {},
      );
    return attributesDto as AttributesDto;
  };
}
