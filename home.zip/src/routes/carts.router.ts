import { Router } from 'express';
import { validateRequestSchema } from '../middlewares';
import { CartsController } from '../controller';
import { wrapJsonApiController } from '../lib';
import { validateAddToCart } from '../validators';

export interface CartsRouterConfig {
  cartsController: CartsController;
  Router: typeof Router;
}

/**
 * `CartsRouter` for all the routes related to `/carts`
 */
export class CartsRouter {
  private readonly cartsController: CartsController;

  private readonly Router: typeof Router;

  constructor(config: CartsRouterConfig) {
    this.cartsController = config.cartsController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();
    /**
    * @swagger
    * components:
    *   schemas:
    *     HttpResponseProductsDto:
    *      type: object
    *      properties:
    *        status:
    *          $ref: '#/components/schemas/Status'
    *        data:
    *          $ref: '#/components/schemas/MultiProductDto'
    *     Status:
    *      type: object
    *      properties:
    *        statusCode:
    *          type: integer
    *          format: int32
    *          example: 200
    *        msg:
    *          type: string
    *          example: OK
    *        timestamp:
    *          type: string
    *          example: 2022-01-24T08:15:49.618Z
    *     CartRequest:
    *        type: object
    *        properties:
    *         cartId:
    *           type: string
    *           example: "5f70b373-5b91-410b-a16f-19c26332c459"
    *         customerId:
    *           type: string
    *           example: "5f70b373-5b91-410b-a16f-19c26332c459"
    *         anonymousId:
    *           type: string
    *           example: "5f70b373-5b91-410b-a16f-19c26332c459"
    *         lineItems:
    *           type: object
    *           properties:
    *             productKey:
    *               type: string
    *               example: "92327"
    *             sku:
    *               type: string
    *               example: "1324194"
    *             quantity:
    *               type: integer
    *               example: 1
    *     CartResponse:
    *       type: object
    *       properties:
    *         status:
    *           type: object
    *           properties:
    *             statusCode:
    *               type: integer
    *               format: int32
    *               example: 200
    *             message:
    *               type: string
    *               example: OK
    *             timestamp:
    *               type: string
    *               example: 2021-12-31T07:32:43.751Z
    *         data:
    *           type: object
    *           properties:
    *             id:
    *               type: string
    *               example: 796c0b39-0a6b-4930-a987-a762149a71d8
    *             version:
    *               type: integer
    *               format: int32
    *               example: 17
    *             totalRetailPriceAmount:
    *               type: string
    *               example: 35.16
    *             totalInvoiceAmount:
    *               type: string
    *               example: 35.16
    *             customerId:
    *               type: integer
    *               format: int32
    *               example: 0
    *             lineItems:
    *               type: array
    *               items:
    *                 type: object
    *                 properties:
    *                   lineItemId:
    *                     type: string
    *                     example: 8f6dbef7-6590-4d07-bdab-51a858907970
    *                   productId:
    *                     type: string
    *                     example: 12ad8823-ce25-4978-b8c1-cd9504898c46
    *                   name:
    *                     type: string
    *                     example: Mini-apă de parfum Far Away Glamour
    *                   skuCode:
    *                     type: string
    *                     example: 77567-9161866660405752600
    *                   images:
    *                     type: array
    *                     items:
    *                       type: object
    *                       properties:
    *                         label:
    *                           type: string
    *                           example: Gallery
    *                         url:
    *                           type: string
    *                           example: https://www.avon.ro/assets/ro-RO/images/product/prod_1200539_1_613x613.jpg
    *                         width:
    *                           type: integer
    *                           format: int32
    *                           example: 613
    *                         height:
    *                           type: integer
    *                           format: int32
    *                           example: 613
    *                   listPriceAmount:
    *                     type: string
    *                     example: 17.58
    *                   unitPriceAmount:
    *                     type: string
    *                     example: 17.58
    *                   quantity:
    *                     type: integer
    *                     format: int32
    *                     example: 2
    *                   modifiedTimeStamp:
    *                     type: string
    *                     example: 2021-12-28T07:49:54.341Z
    *                   sequenceNumber:
    *                     type: integer
    *                     format: int32
    *                     example: 0
    *                   maxPurchasableQty:
    *                     type: integer
    *                     format: int32
    *                     example: 10
    *                   availableQuantity:
    *                     type: integer
    *                     format: int32
    *                     example: 12
    *             promotion:
    *               type: object
    *               properties:
    *                 promotionId:
    *                   type: string
    *                   example: 032295d2-ed3a-48c5-9f07-3f2e15d384a9
    *                 promotionCode:
    *                   type: string
    *                   example: discount
    *                 promotionAmount:
    *                   type: integer
    *                   format: int32
    *                   example: 0
    *                 promotionDescription:
    *                   type: string
    *                   example: This is a test discount which is applied on cart if total is less than 10 RON
    * */
    /**
     * @swagger
     * /{locale}-{market}/carts:
     *   post:
     *     summary: Add product to cart
     *     tags: [Cart]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *           type: string
     *         required: true
     *         description: language
     *       - in: path
     *         name: market
     *         schema:
     *           type: string
     *         required: true
     *         description: Market
     *     requestBody:
     *       content:
     *         'application/json:':
     *          schema:
     *            $ref: '#/components/schemas/CartRequest'
     *     responses:
     *       "400":
     *         description: default response
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *       "500":
     *         description: default response
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *       "404":
     *         description: default response
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *       "200":
     *         description: add to cart response
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CartResponse'
     */
    router.post(
      '/',
      validateAddToCart,
      validateRequestSchema,
      wrapJsonApiController(
        this.cartsController.addProductToCart.bind(this.cartsController),
      ),
    );

    return router;
  }
}
