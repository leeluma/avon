import { Router } from 'express';
import {
  validateAddToCart,
} from '../validations/common.validation';
import { validateRequestSchema } from '../middlewares/validate-request-schema';
import { ProductController } from '../controller/product.controller';
import { wrapJsonApiController } from '../lib';

interface ProductRouterConfig {
  productController: ProductController;
  Router: typeof Router;
}

/**
 * `ProductRouter` for all the routes related to `/product`
 */
export class ProductRouter {
  private readonly productController: ProductController;

  private readonly Router: typeof Router;

  constructor(config: ProductRouterConfig) {
    this.productController = config.productController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
    * @swagger
    * /{locale}-{market}/products/addProductToCart:
    *   post:
    *     summary: Add Line Item to cart
    *     tags: [Product]
    *     parameters:
    *       - in: path
    *         name: language
    *         schema:
    *           type: string
    *         required: true
    *         description: language
    *       - in: path
    *         name: market
    *         schema:
    *           type: string
    *         required: true
    *         description: Market
    *     requestBody:
    *       content:
    *         application/json:
    *          schema:
    *            $ref: '#/components/schemas/CartRequest'
    *     responses:
    *       "400":
    *         description: default response
    *         content:
    *           application/json:
    *             schema:
    *               type: object
    *       "500":
    *         description: default response
    *         content:
    *           application/json:
    *             schema:
    *               type: object
    *       "404":
    *         description: default response
    *         content:
    *           application/json:
    *             schema:
    *               type: object
    *       "200":
    *         description: add to cart response
    *         content:
    *           application/json:
    *             schema:
    *               $ref: '#/components/schemas/CartResponse'
    */
    router.post(
      '/addProductToCart',
      validateAddToCart,
      validateRequestSchema,
      wrapJsonApiController(
        this.productController.addProductToCart.bind(this.productController),
      ),
    );
    return router;
  }
}
