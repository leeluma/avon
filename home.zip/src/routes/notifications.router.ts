import { Router } from 'express';
import { validateRequestSchema } from '../middlewares';
import { NotificationsController } from '../controller/notifications.controller';
import { wrapJsonApiController } from '../lib';
import { validateNotifications } from '../validators';

export interface NotificationsRouterConfig {
  notificationsController: NotificationsController;
  Router: typeof Router;
}

/**
 * `NotificationsRouter` for all the routes related to `/notifications`
 */
export class NotificationsRouter {
  private readonly notificationsController: NotificationsController;

  private readonly Router: typeof Router;

  constructor(config: NotificationsRouterConfig) {
    this.notificationsController = config.notificationsController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();
    /**
    * @swagger
    * components:
    *   schemas:
    *     HttpResponseNotificationDto:
    *      type: object
    *      properties:
    *        status:
    *          $ref: '#/components/schemas/Status'
    *        data:
    *          type: boolean
    *          example: true
    *     Status:
    *      type: object
    *      properties:
    *        statusCode:
    *          type: integer
    *          format: int32
    *          example: 200
    *        msg:
    *          type: string
    *          example: OK
    *        timestamp:
    *          type: string
    *          example: 2022-01-24T08:15:49.618Z
    *     NotificationRequest:
    *      type: object
    *      properties:
    *        ticket:
    *          type: string
    *          example: Oy9wcm9kMTlfQVZPTlNIT1BfUk8tUk87T0JKRUNUSVZFJDtOT05FOk5PTkU7NzI7
    *        productKey:
    *          type: string
    *          example: 41615
    *        variantKey:
    *          type: string
    *          example: 41615-776909111144637448
    * */

    /**
     * @swagger
     * /{locale}-{market}/notifications/product:
     *   post:
     *     summary: Add apptus notification for product esale and cart non-esale products
     *     tags: [Notifications]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: market
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: header
     *         name: sessionkey
     *         schema:
     *            type: string
     *            default: uuid
     *         required: true
     *       - in: header
     *         name: customerKey
     *         schema:
     *            type: string
     *            default: uuid
     *         required: true
     *     requestBody:
     *      description: if token is available then other are optional else required.
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/NotificationRequest'
     *     responses:
     *       200:
     *         description: default response
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/HttpResponseNotificationDto'
     *       404:
     *         description: The product was not found
     *       400:
     *         description: Bad request
     */

    router.post(
      '/product',
      validateNotifications,
      validateRequestSchema,
      wrapJsonApiController(
        this.notificationsController.product.bind(this.notificationsController),
      ),
    );
    /**
     * @swagger
     * /{locale}-{market}/notifications/adding-to-cart:
     *   post:
     *     summary: Add apptus notification for cart esale and cart non-esale products
     *     tags: [Notifications]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: market
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: header
     *         name: sessionkey
     *         schema:
     *            type: string
     *            default: uuid
     *         required: true
     *       - in: header
     *         name: customerKey
     *         schema:
     *            type: string
     *            default: uuid
     *         required: true
     *     requestBody:
     *      description: if token is available then other are optional else required.
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/NotificationRequest'
     *     responses:
     *       200:
     *         description: default response
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/HttpResponseNotificationDto'
     *       404:
     *         description: The product was not found
     *       400:
     *         description: Bad request
     */
    router.post(
      '/adding-to-cart',
      validateNotifications,
      validateRequestSchema,
      wrapJsonApiController(
        this.notificationsController.addToCart.bind(this.notificationsController),
      ),
    );
    return router;
  }
}
