import { Router } from 'express';
import { StaticPageController } from '../controller/static-page.controller';
import { wrapJsonApiController } from '../lib';
import { validateRequestSchema } from '../middlewares';
import { magnoliaUrlMiddleware } from '../middlewares/magnolia-url.middleware';
import { validatePageParams } from '../validations/common.validation';

interface StaticPageRouterConfig {
    staticPageController: StaticPageController;
  Router: typeof Router;
}

/**
 * `StaticPageRouter` for all the routes related to `/staticPage`
 */
export class StaticPageRouter {
  private readonly staticPageController: StaticPageController;

  private readonly Router: typeof Router;

  constructor(config: StaticPageRouterConfig) {
    this.staticPageController = config.staticPageController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /{language}-{market}/static/:
     *   get:
     *     summary: Get the static page data for particular language and market
     *     operationId: getStaticPageData
     *     tags: [Static]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *           type: string
     *         required: true
     *         description: The language
     *         example: ro
     *       - in: path
     *         name: market
     *         schema:
     *           type: string
     *         required: true
     *         description: The market
     *         example: Ro
     *       - in: query
     *         name: isPreview
     *         enum: [true, false]
     *         default: false
     *         description: The preview
     *         required: false
     *       - in: query
     *         name: path
     *         description: The page path
     *         required: true
     *         example: support
     *     responses:
     *       200:
     *         description: home response
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/HttpResponseProductsDto'
     *       404:
     *         description: home data not found
     */
    router.get('/',
      validatePageParams,
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.staticPageController.getStaticPageData.bind(this.staticPageController),
      ));

    return router;
  }
}
