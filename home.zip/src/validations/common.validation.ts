import { body, query, header } from 'express-validator';

const commonNotEmpty = 'common.notEmpty';
const lineItemsQuantity = 'lineItems.quantity';
const validateProductIds = [
  body('ids')
    .exists({ checkNull: true, checkFalsy: true })
    .isArray()
    .withMessage('Ids must exists and contain a valid uuid.'),
];
const validateAddToCart = [
  body('cartId')
    .optional({ checkFalsy: true })
    .isUUID()
    .withMessage('datatype.uuid'),

  body('lineItems.sku')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage(commonNotEmpty),

  body(lineItemsQuantity)
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage(commonNotEmpty),

  body(lineItemsQuantity)
    .if(body(lineItemsQuantity).notEmpty())
    .isInt({ min: 1, max: 2000 })
    .withMessage('common.integer'),
];

const validatePageParams = [
  query('isPreview')
    .optional({ checkFalsy: true })
    .isBoolean()
    .withMessage('isPreview must be true or false'),
  query('path')
    .exists({ checkNull: true })
    .isString()
    .withMessage('Path name must exists and a valid string'),
];

const validateRefreshToken = [
  header('refreshtoken').notEmpty().withMessage(commonNotEmpty),
];

export {
  validateProductIds,
  validateAddToCart,
  validatePageParams,
  validateRefreshToken,
};
