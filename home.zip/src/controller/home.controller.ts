import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { ProductService, MagnoliaService } from '../services';
import { MarketInfo } from '../middlewares';
import { MultiProductDto } from '../dtos/product.dto';
import { ApiError, JsonApiResponseEntity } from '../lib';
import { MagnoliaInfo } from '../dtos';

interface HomeControllerConfig {
  productService: ProductService;
  magnoliaService: MagnoliaService;
}

/**
 * `ProductController` representing `product`
 */
export class HomeController {
  private readonly productService: ProductService;

  private readonly magnoliaService: MagnoliaService;

  /**
   * Constructor for `ProductController` class
   * @param config injects dependencies into the object
   */
  constructor(config: HomeControllerConfig) {
    this.productService = config.productService;
    this.magnoliaService = config.magnoliaService;
  }

  /**
   * Get multiple products by product Ids
   * @param req - Express request object
   * @param res - Express response object
   * @returns Promise
   */
  public async fetchData(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<MultiProductDto[]>> {
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;
    const { channelkey } = req.headers;
    const [magnoliaPageData, globalSettings] = await Promise.all([
      this.magnoliaService.getPageData(market, magnolia, channelkey as string | undefined),
      this.magnoliaService.getGlobalSettings(market, magnolia),
    ]);
    let magnoliaTemplateData = {};
    if (magnolia.isPreview && magnoliaPageData !== undefined) {
      magnoliaTemplateData = await this.magnoliaService.getTemplateData(magnoliaPageData.templateName, magnolia);
    }

    const responseData = {
      ...magnoliaPageData?.data,
      globalSettings,
      templateDefinition: magnoliaTemplateData,
    };

    if (magnoliaPageData?.data === undefined) {
      throw new ApiError(
        HttpStatusCodes.NOT_FOUND,
        'Magnolia data not found.',
      );
    }

    return {
      statusCode: HttpStatusCodes.OK,
      body: responseData,
    };
  }
}
