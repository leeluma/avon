import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { MagnoliaService } from '../services/magnolia.service';
import { MarketInfo } from '../middlewares';
import { JsonApiResponseEntity } from '../lib';
import { CommonResponse, MagnoliaInfo } from '../dtos/common.dto';

interface StaticPageControllerConfig {
  magnoliaService: MagnoliaService;
}

/**
 * `ProductController` representing `product`
 */
export class StaticPageController {
  private readonly magnoliaService: MagnoliaService;

  /**
   * Constructor for `ProductController` class
   * @param config injects dependencies into the object
   */
  constructor(config: StaticPageControllerConfig) {
    this.magnoliaService = config.magnoliaService;
  }

  /**
   * Get multiple products by product Ids
   * @param req - Express request object
   * @param res - Express response object
   * @returns Promise
   */
  public async getStaticPageData(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<CommonResponse>> {
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;
    const pagePath = req.query.page as string;
    const staticPageData = await this.magnoliaService.getStaticPageData(market, magnolia, pagePath);
    let magnoliaTemplateData = {};
    if (magnolia.isPreview && staticPageData !== undefined) {
      magnoliaTemplateData = await this.magnoliaService.getTemplateData(staticPageData['mgnl:template'] as string, magnolia);
    }
    const magnoliaResponse = await this.magnoliaService.getGlobalSettings(market, magnolia);
    delete magnoliaResponse.fieldValidators;
    delete magnoliaResponse.addressSettings;
    const responseData = {
      ...staticPageData,
      globalSettings: magnoliaResponse,
      templateDefinition: magnoliaTemplateData,
    };
    return {
      statusCode: HttpStatusCodes.OK,
      body: responseData,
    };
  }
}
