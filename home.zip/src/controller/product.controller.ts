import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { ProductService } from '../services/product.service';
import { MarketInfo } from '../middlewares';
import { AddToCartResponseDto } from '../dtos';
import { JsonApiResponseEntity } from '../lib';

interface ProductControllerConfig {
  productService: ProductService;
}

/**
 * `ProductController` representing `product`
 */
export class ProductController {
  private readonly productService: ProductService;

  /**
   * Constructor for `ProductController` class
   * @param config injects dependencies into the object
   */
  constructor(config: ProductControllerConfig) {
    this.productService = config.productService;
  }

  /**
   * Add product to the Cart from home page
   * @param req - Express request object
   * @param res - Express response object
   * @returns Promise
   */
  public async addProductToCart(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<AddToCartResponseDto>> {
    const market = res.locals.market as MarketInfo;
    const { customerId, cartId } = req.body;
    const { sku, quantity, productKey } = req.body.lineItems;
    const cart = await this.productService.addProductToCart(
      market,
      customerId,
      cartId,
      sku,
      quantity,
      productKey,
    );
    return {
      statusCode: HttpStatusCodes.OK,
      body: cart,
    };
  }
}
