export const ATTRIBUTE_NAMES = {
  config: 'config',
  galleryVideo: 'galleryVideo',
  badges: 'badges',
  contentFillMeasurement: 'ContentFillMeasure',
  contentFill: 'ContentFill',
  availability: 'availability',
};

export const ATTRIBUTE_VALUES = {
  attributeValue: 'value',
  availabilitySku: 'skuCode',
  assetType: 'Video Gallery',
};

export const BADGE_NAMES = {
  type: 'type',
  text: 'text',
  side: 'side',
  priority: 'priority',
};

export const BADGE_VALUES = {
  discount: 'DISCOUNT',
  bestSeller: 'BESTSELLER',
  typeNew: 'NEW',
  topLeft: 'TOP-LEFT',
  topRight: 'TOP-RIGHT',
};

export const MEASUREMENT = {
  baseMeasure: 'baseMeasure',
  nodes: '@nodes',
};

export const DEFAULT_INVENTORY = {
  stockQty: 999,
  isAvailable: true,
};

export const ATTRIBUTE_TYPES = {
  boolean: 'boolean',
  string: 'string',
  number: 'number',
  date: 'date',
};

export const CATEGORY_LEVEL = {
  parent: 'root',
};

export const QUERY_EXPAND = {
  findOne: 'masterData.current.categories[*].ancestors[*]',
  findProducts: 'masterData.current.categories[*]',
};

export enum MAGNOLIA_URI {
    home = '.rest/delivery/pages/v1/',
    template = '.rest/template-definitions/v1/',
    wareHouseSetting = '.rest/delivery/global-settings/{{country}}/settings/warehouseSettings',
    priceFormat = '.rest/delivery/global-settings/{{country}}/settings/priceFormat',
    globalSettings = '.rest/delivery/global-settings/{{country}}/settings',
}
export const APPTUS = {
  search: 'panels/product-list-page?',
  searchPage: 'panels/search-page/search-result-zone?',
  esales: 'notifications/click',
  nonEsales: 'notifications/non-esales-click',
  esaleAddToCart: 'notifications/adding-to-cart',
  nonEsaleAddToCart: 'notifications/adding-to-cart',
};

export const MAGNOLIA = {
  category: '/c',
  search: '/s',
  pageData: '.rest/delivery/pages/v1/',
  logSetting: '.rest/delivery/pages/v1/ro/apptusSetting',
  categorySearch: '.rest/delivery/ecommerce-categories?q=',
  templatePath: '.rest/template-definitions/v1/',
};
export const URI = {
  apptus: {
    esaleAddToCart: 'notifications/adding-to-cart',
    nonEsaleAddToCart: 'notifications/non-esales-adding-to-cart',
    esales: 'notifications/click',
    nonEsales: 'notifications/non-esales-click',
  },
};

export const RESPONSE_KEY = {
  applicationJson: 'application/json',
};
