import faker from '@faker-js/faker';
import ProductMapper from '../../src/mappers/product.mapper';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubCtProductDto, stubGlobalSettings,
} from '../__stubs__';
import { ProductDto, BadgeNode } from '../../src/dtos/product.dto';
import {
  ATTRIBUTE_NAMES, ATTRIBUTE_VALUES, BADGE_NAMES, BADGE_VALUES,
} from '../../src/common/constant';
import { Product } from '../../src/lib/product';

describe('ProductMapper', () => {
  let productMapper: ProductMapper;
  let productDto: ProductDto;
  let product: Product;

  let market: MarketInfo;
  const nameValue = {
    name: faker.datatype.string(),
    value: faker.datatype.string(),
  };
  const url = faker.datatype.string();
  const label = faker.datatype.string();
  const priceFormatterData = 'RON 3.54';
  const attributesRaw = [
    {
      name: 'galleryVideo',
      value: [
        url,
      ],
    },
    {
      name: faker.datatype.string(),
      value: {
        key: faker.datatype.string(),
        label: faker.datatype.string(),
      },
    },
    nameValue,
    {
      name: 'startDate',
      value: faker.datatype.datetime(),
    },
    {
      name: 'endDate',
      value: faker.datatype.datetime(),
    },
    nameValue,
    nameValue,
    {
      name: ATTRIBUTE_NAMES.contentFillMeasurement,
      value: {
        key: 'g',
        label: faker.datatype.string(),
      },
    },
    {
      name: ATTRIBUTE_NAMES.contentFill,
      value: faker.datatype.number(),
    },
    {
      name: ATTRIBUTE_NAMES.badges,
      value: [
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.typeNew,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: 'NOU',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topRight,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.9,
          },
        ],
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.discount,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: '20%',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topLeft,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.2,
          },
        ],
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.bestSeller,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: 'Best Seller',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topRight,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.1,
          },
        ],
      ],
    },
    {
      name: ATTRIBUTE_NAMES.config,
      value: [
        [
          {
            name: 'quantity',
            value: 1,
          },
          {
            name: 'setComponent',
            value: {
              typeId: 'product',
              id: faker.datatype.uuid(),
            },
          },
          {
            name: 'lineNumber',
            value: faker.datatype.number(),
          },
          {
            name: ATTRIBUTE_VALUES.availabilitySku,
            value: faker.datatype.uuid(),
          },
        ],
        [
          {
            name: 'quantity',
            value: 1,
          },
          {
            name: 'setComponent',
            value: {
              typeId: 'product',
              id: faker.datatype.uuid(),
            },
          },
          {
            name: 'lineNumber',
            value: faker.datatype.number(),
          },
          {
            name: ATTRIBUTE_VALUES.availabilitySku,
            value: faker.datatype.uuid(),
          },
        ],
      ],
    },
    {
      name: faker.datatype.string(),
      value: faker.datatype.boolean(),
    },
  ];

  const availability = {
    channels: {
      results: [
        {
          channel: {
            key: faker.datatype.string(),
          },
          availability: {
            isOnStock: faker.datatype.boolean(),
            availableQuantity: faker.datatype.number(),
          },
        },
        {
          channel: {
            key: faker.datatype.string(),
          },
          availability: {
            isOnStock: faker.datatype.boolean(),
            availableQuantity: faker.datatype.number(),
          },
        },
      ],
    },
    noChannel: {
      stockQty: faker.datatype.number(),
      isAvailable: faker.datatype.boolean(),
    },
  };

  const masterVariant = {
    id: faker.datatype.number(),
    sku: faker.datatype.string(),
    key: faker.datatype.string(),
    sellPrice: faker.datatype.number(),
    listPrice: faker.datatype.number(),
    formatedListPrice: faker.datatype.string(),
    formatedSellPrice: faker.datatype.string(),
    vatMessage: faker.datatype.string(),
    availability,
    assets: [{
      url: faker.datatype.string(),
      assetType: faker.datatype.string(),
      sequence: faker.datatype.number(),
    }],
    prices: [
      {
        value: {
          type: faker.datatype.string(),
          currencyCode: faker.datatype.string(),
          centAmount: faker.datatype.number(),
          fractionDigits: faker.datatype.number(2),
        },
        id: faker.datatype.uuid(),
        channel: {
          typeId: faker.datatype.string(),
          id: faker.datatype.uuid(),
        },
        discounted: {
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.string(),
            fractionDigits: faker.datatype.number(2),
          },
          discount: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
        },
      },
      {
        value: {
          type: faker.datatype.string(),
          currencyCode: faker.datatype.string(),
          centAmount: faker.datatype.number(),
          fractionDigits: faker.datatype.number(2),
        },
        id: faker.datatype.uuid(),
        discounted: {
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.string(),
            fractionDigits: faker.datatype.number(2),
          },
          discount: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
        },
      },
    ],
    images: [
      /* {
        url,
        label: label,
        dimensions: {
          w: faker.datatype.number(),
          h: faker.datatype.number(),
        },
      }, */
      {
        url,
        label,
        dimensions: {
          w: faker.datatype.number(),
          h: faker.datatype.number(),
        },
      },
    ],
    attributesRaw,
  };

  const price = {
    sellPrice: faker.datatype.number(),
    listPrice: faker.datatype.number(),
  };

  let globalSettings;
  let maxPriority: BadgeNode;
  beforeEach(() => {
    market = stubMarket();
    productDto = stubCtProductDto(market);
    globalSettings = stubGlobalSettings();
    maxPriority = {
      priority: '0.7',
      type: BADGE_VALUES.discount,
      text: '- 16 %',
      side: BADGE_VALUES.topLeft,
    };
    product = {
      getPriceDiff: jest.fn().mockReturnValueOnce(price),
      priceConverter: jest.fn().mockReturnValueOnce(undefined),
      prodAttrToDTO: jest.fn().mockReturnValueOnce(undefined),
      getAllKeywords: jest.fn().mockReturnValueOnce(undefined),
      getUnitPrice: jest.fn().mockReturnValueOnce(undefined),
      getMaxPriority: jest.fn().mockReturnValueOnce(maxPriority),
      getBadgeDetails: jest.fn().mockReturnValueOnce({ topRight: '', topLeft: '' }),
      magnoliaPriceFormatter: jest.fn().mockReturnValueOnce(priceFormatterData),
    } as any;

    productMapper = new ProductMapper({ product });
  });

  //   varImgToDTO

  test('varImgToDTO', () => {
    /* Setup */
    const videLabel = 'Video Gallery';
    const variantImageStubRes = [
      {
        url,
        assetType: label,
        sequence: 0,
      },
      {
        url,
        assetType: videLabel,
        sequence: 0,
      },
    ];

    /* Execute */
    const result = (productMapper as any).varImgToDTO(masterVariant);
    /* Verify */
    expect(result).toEqual(variantImageStubRes);
  });

  test('variantsToDto', () => {
    /* Setup */
    const channelKey = faker.datatype.string();
    const varientExpected = [{
      id: Number(masterVariant.id),
      key: masterVariant.key,
      sku: masterVariant.sku,
    }];
    (product.getMaxPriority) = jest.fn().mockReturnValueOnce(maxPriority);
    (product.magnoliaPriceFormatter) = jest.fn().mockReturnValueOnce(priceFormatterData);
    /* Execute */
    const result = (productMapper as any).variantsToDto([masterVariant],
      market.locale, channelKey, globalSettings.priceFormat);

    /* Verify */
    expect(result).toMatchObject(varientExpected);
  });

  test('getStockDetails', () => {
    /* Setup */
    const channelKey = faker.datatype.string();
    const stockDetails = [
      {
        channel: {
          key: faker.datatype.string(),
        },
        availability: {
          isOnStock: faker.datatype.boolean(),
          availableQuantity: faker.datatype.number(),
        },
      },
      {
        channel: {
          key: channelKey,
        },
        availability: {
          isOnStock: faker.datatype.boolean(),
          availableQuantity: faker.datatype.number(),
        },
      },
    ];
    const inventoryData = [{
      id: faker.datatype.uuid(),
      sku: faker.datatype.string(),
      custom: null,
    }];

    const stockData = stockDetails?.find((channel) => channel.channel.key === channelKey);
    const stockDetailsExpected = {
      stockQty: stockData?.availability.availableQuantity,
      isAvailable: stockData?.availability.isOnStock,
      isLimitedStock: false,
    };
    /* Execute */
    const result = (productMapper as any).getStockDetails(stockDetails, channelKey, inventoryData);

    /* Verify */
    expect(result).toEqual(stockDetailsExpected);
  });

  test('getStockDetails with limitedStock', () => {
    /* Setup */
    const channelKey = faker.datatype.string();
    const inventoryId = faker.datatype.uuid();
    const stockDetails = [
      {
        channel: {
          key: faker.datatype.string(),
        },
        availability: {
          isOnStock: faker.datatype.boolean(),
          availableQuantity: faker.datatype.number(),
        },
      },
      {
        channel: {
          key: channelKey,
        },
        availability: {
          isOnStock: faker.datatype.boolean(),
          availableQuantity: faker.datatype.number(),
          id: inventoryId,
        },
      },
    ];
    const inventoryData = [{
      id: inventoryId,
      sku: faker.datatype.string(),
      custom: {
        customFieldsRaw: [
          {
            value: true,
            name: 'isLowAvailability',
          },
        ],
      },
    }];

    const stockData = stockDetails?.find((channel) => channel.channel.key === channelKey);
    const stockDetailsExpected = {
      stockQty: stockData?.availability.availableQuantity,
      isAvailable: stockData?.availability.isOnStock,
      isLimitedStock: true,
    };
    /* Execute */
    const result = (productMapper as any).getStockDetails(stockDetails, channelKey, inventoryData);

    /* Verify */
    expect(result).toEqual(stockDetailsExpected);
  });

  test('getStockDetails undefined', () => {
    /* Setup */
    const channelKey = faker.datatype.string();
    const stockDetails = [];
    const stockDetailsExpected = {
      stockQty: 999,
      isAvailable: true,
    };
    /* Execute */
    const result = (productMapper as any).getStockDetails(stockDetails, channelKey);

    /* Verify */
    expect(result).toEqual(stockDetailsExpected);
  });

  describe('check for only channel price', () => {
    const masterVariantonlyChannel = {
      id: faker.datatype.number(),
      sku: faker.datatype.string(),
      key: faker.datatype.string(),
      sellPrice: faker.datatype.number(),
      listPrice: faker.datatype.number(),
      formatedListPrice: faker.datatype.string(),
      formatedSellPrice: faker.datatype.string(),
      vatMessage: faker.datatype.string(),
      availability,
      assets: [{
        url: faker.datatype.string(),
        assetType: faker.datatype.string(),
        sequence: faker.datatype.number(),
      }],
      prices: [
        {
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.number(),
            fractionDigits: 2,
          },
          id: faker.datatype.uuid(),
          channel: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
          discounted: {
            value: {
              type: faker.datatype.string(),
              currencyCode: faker.datatype.string(),
              centAmount: faker.datatype.string(),
              fractionDigits: 2,
            },
            discount: {
              typeId: faker.datatype.string(),
              id: faker.datatype.uuid(),
            },
          },
        },
      ],
      images: [
        {
          url: faker.datatype.string(),
          label: faker.datatype.string(),
          dimensions: {
            w: faker.datatype.number(),
            h: faker.datatype.number(),
          },
        },
      ],
      attributesRaw,
    };

    test('variantsToDto with isDiscontinued false', () => {
      (product.prodAttrToDTO) = jest.fn().mockReturnValueOnce({ isDiscontinued: true });
      /* Execute */
      const result = (productMapper as any).variantsToDto([masterVariant], market.locale);
      /* Verify */
      expect(result).toEqual([]);
    });

    test('variantsToDto with empty data', () => {
      attributesRaw[10] = {
        name: 'isDiscontinued',
        value: true,
      };
      /* Execute */
      const result = (productMapper as any).variantsToDto([], market.locale);

      /* Verify */
      expect(result).toStrictEqual([]);
    });

    test('variantsToDto with only channel price', () => {
      attributesRaw[10] = {
        name: 'isDiscontinued',
        value: false,
      };
      /* Setup */
      const channelKey = faker.datatype.string();
      const varientExpected = [{
        id: Number(masterVariantonlyChannel.id),
        key: masterVariantonlyChannel.key,
        sku: masterVariantonlyChannel.sku,
      }];
      (product.magnoliaPriceFormatter) = jest.fn().mockReturnValueOnce(priceFormatterData);
      /* Execute */
      const result = (productMapper as any).variantsToDto([masterVariantonlyChannel],
        market.locale, channelKey, globalSettings.priceFormat);

      /* Verify */
      expect(result).toMatchObject(varientExpected);
    });

    test('productMapping', () => {
      /* Setup */
      const channelKey = faker.datatype.string();
      const products = {
        id: productDto.id,
        key: productDto.key,
        masterData: {
          current: {
            name: {
              [market.locale]: faker.datatype.string(),
            },
            description: {
              [market.locale]: faker.lorem.words(),
            },
            masterVariant,
            variants: [masterVariant],
          },
        },
      };

      const inventoryData: any = [
        {
          id: faker.datatype.uuid(),
          sku: faker.datatype.string(),
          custom: {
            customFieldsRaw: [
              {
                value: true,
                name: 'isLowAvailability',
              },
            ],
          },
        },
        {
          id: faker.datatype.uuid(),
          sku: faker.datatype.string(),
          custom: null,
        },
      ];
      (product.getMaxPriority) = jest.fn().mockReturnValueOnce(maxPriority);
      (product.magnoliaPriceFormatter) = jest.fn().mockReturnValueOnce(priceFormatterData);
      /* Execute */
      const result = productMapper.productMapping(
        products as any, market, channelKey, globalSettings.priceFormat, inventoryData,
      );
      expect(result.id).toBe(products.id);
      expect(result.key).toBe(products.key);
    });

    test('empty variant and mastervarint', () => {
      /* Setup */
      const channelKey = faker.datatype.string();
      const productReq = {
        id: productDto.id,
        key: productDto.key,
        masterData: {
          current: {
            variants: [],
          },
        },
      };
      const inventoryData: any = [
        {
          id: faker.datatype.uuid(),
          sku: faker.datatype.string(),
          custom: {
            customFieldsRaw: [
              {
                value: true,
                name: 'isLowAvailability',
              },
            ],
          },
        },
        {
          id: faker.datatype.uuid(),
          sku: faker.datatype.string(),
          custom: null,
        },
      ];
      /* Execute */
      const result = productMapper.productMapping(
        productReq as any, market, channelKey, globalSettings.priceFormat, inventoryData,
      );
      /* Verify */
      expect(result).toEqual([]);
    });

    test('multiProductMap', () => {
      /* Setup */
      const channelKey = faker.datatype.string();
      const products = [
        {
          id: productDto.id,
          key: productDto.key,
          masterData: {
            current: {
              name: {
                [market.locale]: faker.datatype.string(),
              },
              description: {
                [market.locale]: faker.lorem.words(),
              },
              masterVariant,
              variants: [masterVariant],
            },
          },
        },
        {
          id: productDto.id,
          key: productDto.key,
          masterData: {
            current: {
              name: {
                [market.locale]: faker.datatype.string(),
              },
              description: {
                [market.locale]: faker.lorem.words(),
              },
              masterVariant,
              variants: [masterVariant],
            },
          },
        },
      ];

      (product.magnoliaPriceFormatter) = jest.fn().mockReturnValueOnce(priceFormatterData);
      /* Execute */
      const result = (productMapper as any).multiProductMap(products, market.locale, channelKey, globalSettings.priceFormat);

      /* Verify */
      expect(result[0].id).toBe(products[0].id);
      expect(result[0].key).toBe(products[0].key);
      expect(result[1].id).toBe(products[1].id);
      expect(result[1].key).toBe(products[1].key);
    });

    test('checkDiscount mapper', () => {
      /* Setup */
      const prices = {
        id: faker.datatype.uuid(),
        value: {
          type: 'centPrecision',
          currencyCode: 'RON',
          centAmount: faker.datatype.number(),
          fractionDigits: 2,
        },
        discounted: {
          value: {
            type: 'centPrecision',
            currencyCode: 'RON',
            centAmount: faker.datatype.number(),
            fractionDigits: 2,
          },
          discount: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
        },
      };
      const expectedRes = true;
      /* Execute */
      const result = (productMapper as any).checkDiscount(prices);

      /* Verify */
      expect(result.isPromotionApplied).toBe(expectedRes);
    });

    test('check if no discounted price mapper', () => {
      /* Setup */
      const prices = {
        id: faker.datatype.uuid(),
        value: {
          type: 'centPrecision',
          currencyCode: 'RON',
          centAmount: faker.datatype.number(),
          fractionDigits: 2,
        },
      };
      const expectedRes = false;
      /* Execute */
      const result = (productMapper as any).checkDiscount(prices);

      /* Verify */
      expect(result.isPromotionApplied).toBe(expectedRes);
    });
  });
});
