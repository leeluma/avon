import faker from '@faker-js/faker';
import MagnoliaMapper from '../../src/mappers/magnolia.mapper';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubCtProductDto, stubMagnoliaHome, stubMagnoliaData,
} from '../__stubs__';
import { ProductDto } from '../../src/dtos/product.dto';
import {
  ATTRIBUTE_NAMES, ATTRIBUTE_VALUES, BADGE_NAMES, BADGE_VALUES,
} from '../../src/common/constant';
import Mock = jest.Mock;

describe('MagnoliaMapper', () => {
  let magnoliaMapper: MagnoliaMapper;
  let productDto: ProductDto;

  let market: MarketInfo;
  const nameValue = {
    name: faker.datatype.string(),
    value: faker.datatype.string(),
  };
  const url = faker.datatype.string();
  const label = faker.datatype.string();
  const attributesRaw = [
    {
      name: 'galleryVideo',
      value: [
        url,
      ],
    },
    {
      name: faker.datatype.string(),
      value: {
        key: faker.datatype.string(),
        label: faker.datatype.string(),
      },
    },
    nameValue,
    {
      name: 'startDate',
      value: faker.datatype.datetime(),
    },
    {
      name: 'endDate',
      value: faker.datatype.datetime(),
    },
    nameValue,
    nameValue,
    {
      name: ATTRIBUTE_NAMES.contentFillMeasurement,
      value: {
        key: 'g',
        label: faker.datatype.string(),
      },
    },
    {
      name: ATTRIBUTE_NAMES.contentFill,
      value: faker.datatype.number(),
    },
    {
      name: ATTRIBUTE_NAMES.badges,
      value: [
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.typeNew,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: 'NOU',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topRight,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.9,
          },
        ],
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.discount,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: '20%',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topLeft,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.2,
          },
        ],
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.bestSeller,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: 'Best Seller',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topRight,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.1,
          },
        ],
      ],
    },
    {
      name: ATTRIBUTE_NAMES.config,
      value: [
        [
          {
            name: 'quantity',
            value: 1,
          },
          {
            name: 'setComponent',
            value: {
              typeId: 'product',
              id: faker.datatype.uuid(),
            },
          },
          {
            name: 'lineNumber',
            value: faker.datatype.number(),
          },
          {
            name: ATTRIBUTE_VALUES.availabilitySku,
            value: faker.datatype.uuid(),
          },
        ],
        [
          {
            name: 'quantity',
            value: 1,
          },
          {
            name: 'setComponent',
            value: {
              typeId: 'product',
              id: faker.datatype.uuid(),
            },
          },
          {
            name: 'lineNumber',
            value: faker.datatype.number(),
          },
          {
            name: ATTRIBUTE_VALUES.availabilitySku,
            value: faker.datatype.uuid(),
          },
        ],
      ],
    },
    {
      name: faker.datatype.string(),
      value: faker.datatype.boolean(),
    },
  ];

  const availability = {
    channels: {
      results: [
        {
          channel: {
            key: faker.datatype.string(),
          },
          availability: {
            isOnStock: faker.datatype.boolean(),
            availableQuantity: faker.datatype.number(),
          },
        },
        {
          channel: {
            key: faker.datatype.string(),
          },
          availability: {
            isOnStock: faker.datatype.boolean(),
            availableQuantity: faker.datatype.number(),
          },
        },
      ],
    },
    noChannel: {
      stockQty: faker.datatype.number(),
      isAvailable: faker.datatype.boolean(),
    },
  };

  const masterVariant = {
    id: faker.datatype.number(),
    sku: faker.datatype.string(),
    key: faker.datatype.string(),
    sellPrice: faker.datatype.number(),
    listPrice: faker.datatype.number(),
    formatedListPrice: faker.datatype.string(),
    formatedSellPrice: faker.datatype.string(),
    vatMessage: faker.datatype.string(),
    availability,
    assets: [{
      url: faker.datatype.string(),
      assetType: faker.datatype.string(),
      sequence: faker.datatype.number(),
    }],
    prices: [
      {
        value: {
          type: faker.datatype.string(),
          currencyCode: faker.datatype.string(),
          centAmount: faker.datatype.number(),
          fractionDigits: faker.datatype.number(2),
        },
        id: faker.datatype.uuid(),
        channel: {
          typeId: faker.datatype.string(),
          id: faker.datatype.uuid(),
        },
        discounted: {
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.string(),
            fractionDigits: faker.datatype.number(2),
          },
          discount: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
        },
      },
      {
        value: {
          type: faker.datatype.string(),
          currencyCode: faker.datatype.string(),
          centAmount: faker.datatype.number(),
          fractionDigits: faker.datatype.number(2),
        },
        id: faker.datatype.uuid(),
        discounted: {
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.string(),
            fractionDigits: faker.datatype.number(2),
          },
          discount: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
        },
      },
    ],
    images: [
      {
        url,
        label,
        dimensions: {
          w: faker.datatype.number(),
          h: faker.datatype.number(),
        },
      },
    ],
    attributesRaw,
  };

  let magnoliaData;
  let magnoliaHome;
  beforeEach(() => {
    market = stubMarket();
    productDto = stubCtProductDto(market);
    magnoliaHome = stubMagnoliaHome();
    magnoliaData = stubMagnoliaData();

    magnoliaMapper = new MagnoliaMapper();
  });

  describe('check for only channel price', () => {
    test('pageData', () => {
      /* Setup */
      (magnoliaMapper as any).getCarouselProductIds = jest.fn();
      ((magnoliaMapper as any).getCarouselProductIds as Mock).mockReturnValue(magnoliaData.productIds);
      /* Execute */
      const result = (magnoliaMapper as any).pageData(magnoliaHome);

      /* Verify */
      expect(result).toHaveProperty('productIds');
      expect((magnoliaMapper as any).getCarouselProductIds).toHaveBeenCalledTimes(1);
    });

    test('getCarouselProductIds', () => {
      /* Setup */
      const mainNodes = magnoliaHome.main['@nodes'];
      /* Execute */
      const result = (magnoliaMapper as any).getCarouselProductIds(magnoliaHome.main, mainNodes);

      /* Verify */
      expect(result).toHaveProperty('productIds');
      expect(result).toHaveProperty('keys');
      expect(mainNodes.length).toBe(1);
    });

    test('getCarouselProductIds without ProductCarousel node', () => {
      /* Setup */
      const mainNodes = magnoliaHome.main['@nodes'];
      const { main } = magnoliaHome;
      delete main['01'].ProductCarousel;
      const matchObj = {};
      /* Execute */
      const result = (magnoliaMapper as any).getCarouselProductIds(main, mainNodes);

      /* Verify */
      expect(result.productIds).toMatchObject(matchObj);
      expect(result.keys).toBeDefined();
    });

    test('appendProductList', () => {
      /* Setup */
      const key = '01';
      const mainNodes = {
        keys: [key],
        productIds: {
          [key]: [productDto.id],
        },
      };

      const product = [{
        id: productDto.id,
        key: productDto.key,
        masterData: {
          current: {
            name: {
              [market.locale]: faker.datatype.string(),
            },
            description: {
              [market.locale]: faker.lorem.words(),
            },
            masterVariant,
            variants: [masterVariant],
          },
        },
      }];
      /* Execute */
      const result = (magnoliaMapper as any).appendProductList(magnoliaHome, mainNodes, product);

      /* Verify */
      expect(result[key]).toHaveProperty('productsList');
    });
  });
});
