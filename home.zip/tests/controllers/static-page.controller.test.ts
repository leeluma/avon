import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
// eslint-disable-next-line import/no-extraneous-dependencies
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubMagnoliaData, stubMagnoliaHome, stubMagnoliaInfo, stubGlobalSettings,
} from '../__stubs__';
import { StaticPageController } from '../../src/controller';

import { MagnoliaService } from '../../src/services';
import { MagnoliaData } from '../../src/dtos';

import Mock = jest.Mock;

describe('LeapApp', () => {
  /* System Under Test */
  let staticPageController: StaticPageController;

  /* Dependencies */
  let magnoliaService: MagnoliaService;
  let market: MarketInfo;
  let magnolia: MagnoliaInfo;
  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    magnoliaService = {} as any;

    /* SUT */
    staticPageController = new StaticPageController({ magnoliaService });
  });

  /**
   * Unit test case for getStaticPageData
   */
  describe('getStaticPageData()', () => {
    let magnoliaData: MagnoliaData;
    let magnoliaHome: any;
    let magnoliaGlobalSetting: any;

    beforeEach(() => {
      magnoliaService.getStaticPageData = jest.fn();
      magnoliaService.getTemplateData = jest.fn();
      magnoliaService.getGlobalSettings = jest.fn();
      res.locals.magnolia = magnolia;
      magnoliaData = stubMagnoliaData();
      magnoliaHome = stubMagnoliaHome();
      magnoliaGlobalSetting = stubGlobalSettings();
    });

    test('fetches data from magnoliaService', async () => {
      /* Prepare */
      (magnoliaService.getStaticPageData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);
      (magnoliaService.getGlobalSettings as Mock).mockReturnValueOnce(magnoliaGlobalSetting);

      /* Execute */
      const result = await staticPageController.getStaticPageData(req, res);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaService.getStaticPageData).toHaveBeenCalledTimes(1);
    });

    test('fetches data from magnoliaService if isPreview is true', async () => {
      /* Prepare */
      res.locals.magnolia.isPreview = true;
      (magnoliaService.getStaticPageData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(stubMagnoliaHome);
      (magnoliaService.getGlobalSettings as Mock).mockReturnValueOnce(magnoliaGlobalSetting);

      /* Execute */
      const result = await staticPageController.getStaticPageData(req, res);

      /* Verify */
      expect(result.statusCode).toBe(HttpStatusCodes.OK);
      expect(result.body.data).toBeTruthy();
      expect(magnoliaService.getTemplateData).toHaveBeenCalledWith(magnoliaData['mgnl:template'] as string, magnolia);
      expect(magnoliaService.getStaticPageData).toHaveReturnedWith(magnoliaData);
    });

    test('returns empty template if not preview', async () => {
    /* Prepare */
      const staticData = { staticField: faker.datatype.uuid() };
      (magnoliaService.getStaticPageData as Mock).mockReturnValueOnce(staticData);
      magnolia.isPreview = false;
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);
      (magnoliaService.getGlobalSettings as Mock).mockReturnValueOnce(magnoliaGlobalSetting);

      /* Execute */
      await staticPageController.getStaticPageData(req, res);

      /* Verify */
      expect(magnoliaService.getTemplateData).not.toHaveBeenCalled();
    });

    test('returns template from magnolia if preview', async () => {
    /* Prepare */
      const staticData = { staticField: faker.datatype.uuid() };
      (magnoliaService.getStaticPageData as Mock).mockReturnValueOnce(staticData);
      magnolia.isPreview = true;
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);
      (magnoliaService.getGlobalSettings as Mock).mockReturnValueOnce(magnoliaGlobalSetting);

      /* Execute */
      await staticPageController.getStaticPageData(req, res);

      /* Verify */
      expect(magnoliaService.getTemplateData).toHaveBeenCalledTimes(1);
      expect(magnoliaService.getTemplateData).toHaveBeenNthCalledWith(
        1,
        staticData['mgnl:template'],
        magnolia,
      );
    });
  });
});
