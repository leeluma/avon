import { Request, Response } from 'express';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes,
} from '../__stubs__';
import { ProductController } from '../../src/controller/product.controller';
import { ProductService } from '../../src/services';

import Mock = jest.Mock;
import { AddToCartRequestDto, AddToCartResponseDto } from '../../src/dtos';

import { stubAddProductToCartRequestDto, stubAddProductToCartResponseDto } from '../__stubs__/addproducttocart.dto.stub';

describe('LeapApp', () => {
  /* System Under Test */
  let productController: ProductController;

  /* Dependencies */
  let productService: ProductService;
  let market: MarketInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    productService = {} as any;

    /* SUT */
    productController = new ProductController({ productService });
  });

  describe('addProductsToCart', () => {
    let addProductToCartDtoRequest:AddToCartRequestDto;
    let addProductToCartResponseDto:AddToCartResponseDto;

    beforeEach(() => {
      productService.addProductToCart = jest.fn();
      addProductToCartDtoRequest = stubAddProductToCartRequestDto(market);
      addProductToCartResponseDto = stubAddProductToCartResponseDto(market);
      const { customerId, cartId, lineItems } = addProductToCartDtoRequest;
      req.body.customerId = customerId;
      req.body.cartId = cartId;
      req.body.lineItems = lineItems;
    });

    test('check request data', async () => {
      /* Prepare */
      (productService.addProductToCart as Mock).mockReturnValueOnce(addProductToCartResponseDto);

      /* Execute */
      await productController.addProductToCart(req, res);

      /* Verify */
      expect(productService.addProductToCart).toHaveBeenCalledTimes(1);
      expect(productService.addProductToCart).toHaveBeenNthCalledWith(1,
        market,
        addProductToCartDtoRequest.customerId,
        addProductToCartDtoRequest.cartId,
        addProductToCartDtoRequest?.lineItems?.sku,
        addProductToCartDtoRequest?.lineItems?.quantity,
        addProductToCartDtoRequest?.lineItems?.productKey);
    });

    test('check addProductToCart output from order', async () => {
      /* Prepare */
      (productService.addProductToCart as Mock).mockReturnValueOnce(addProductToCartResponseDto);

      /* Execute */
      const response = await productController.addProductToCart(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: addProductToCartResponseDto,
      });
    });
  });
});
