import faker from '@faker-js/faker';
import HttpStatusCodes from 'http-status-codes';
import { Request, Response } from 'express';
import { MarketInfo } from '../../src/middlewares';
import { CartsController } from '../../src/controller';
import { CartsService } from '../../src/services';
import { stubMarket, stubExpressReq, stubExpressRes } from '../__stubs__';
import { AddToCartResponseDto } from '../../src/dtos';
import Mock = jest.Mock;

describe('CartsController', () => {
  /* System Under Test */
  let cartsController: CartsController;

  /* Dependencies */
  let cartsService: CartsService;
  let market: MarketInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();
    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    cartsService = {} as any;

    cartsController = new CartsController({ cartsService });
  });

  describe('addProductToCart()', () => {
    let customerId: string;
    let channelKey: string;
    let anonymousId: string;
    let cartId: string;
    let sku: string;
    let quantity: number;
    let productKey: string;

    beforeEach(() => {
      cartsService.addProductToCart = jest.fn();

      customerId = faker.datatype.uuid();
      cartId = faker.datatype.uuid();
      sku = faker.datatype.uuid();
      quantity = faker.datatype.number();
      productKey = faker.datatype.uuid();
      req.headers = {
        channelKey,
      };
      req.body = {
        anonymousId,
        channelKey,
        customerId,
        cartId,
        lineItems: { sku, quantity, productKey },
      };
    });

    test('calls cartService with request parameters', async () => {
      const data = {
        market,
        channelKey,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
      };
      /* Execute */
      await cartsController.addProductToCart(req, res);

      /* Verify */
      expect(cartsService.addProductToCart).toHaveBeenCalledTimes(1);
      expect(cartsService.addProductToCart).toHaveBeenNthCalledWith(
        1,
        data,
      );
    });

    test('returns the result from the cartService', async () => {
      /* Prepare */
      const addToCartResponseDto = { id: faker.datatype.uuid() } as AddToCartResponseDto;
      (cartsService.addProductToCart as Mock).mockReturnValueOnce(addToCartResponseDto);

      /* Execute */
      const result = await cartsController.addProductToCart(req, res);

      /* Verify */
      expect(result).toStrictEqual({
        body: addToCartResponseDto,
        statusCode: HttpStatusCodes.OK,
      });
    });
  });
});
