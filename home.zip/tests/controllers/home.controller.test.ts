import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { MarketInfo } from '../../src/middlewares';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubMagnoliaData, stubMagnoliaHome, stubMagnoliaInfo,
} from '../__stubs__';
import { HomeController } from '../../src/controller';

import { MagnoliaService, ProductService } from '../../src/services';
import { MagnoliaData } from '../../src/dtos';

import Mock = jest.Mock;

import { ApiError } from '../../src/lib';

describe('LeapApp', () => {
  /* System Under Test */
  let homeController: HomeController;

  /* Dependencies */
  let productService: ProductService;
  let magnoliaService: MagnoliaService;
  let market: MarketInfo;
  let magnolia: MagnoliaInfo;
  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    productService = {} as any;
    magnoliaService = {} as any;

    /* SUT */
    homeController = new HomeController({ productService, magnoliaService });
  });

  /**
   * Unit test case for fetchData
   */
  describe('fetchData()', () => {
    let magnoliaData: MagnoliaData;

    beforeEach(() => {
      magnoliaService.getPageData = jest.fn();
      magnoliaService.getTemplateData = jest.fn();
      magnoliaService.getGlobalSettings = jest.fn();
      res.locals.magnolia = magnolia;
      magnoliaData = stubMagnoliaData();
      /* req.body.ids = multiProductDto.id; */
    });

    test('fetches data from productService for is Preview true', async () => {
      /* Prepare */
      magnolia.isPreview = true;
      (magnoliaService.getPageData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(stubMagnoliaHome);

      /* Execute */
      const result = await homeController.fetchData(req, res);

      /* Verify */
      expect(result).toBeTruthy();
      expect(result.statusCode).toBe(HttpStatusCodes.OK);
      expect(magnoliaService.getPageData).toHaveBeenCalledTimes(1);
      expect(magnoliaService.getTemplateData).toHaveBeenCalledWith(magnoliaData.templateName, magnolia);
    });

    test('throw an ApiError(NOT_FOUND) if products does not exist', async () => {
      // Prepare
      (magnoliaService.getPageData as Mock).mockReturnValueOnce({ data: undefined });
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(stubMagnoliaHome);
      const expectedErrors = new ApiError(404, 'Magnolia data not found.');

      // Execute
      await expect(() => homeController.fetchData(req, res))
        .rejects.toThrow(expectedErrors);
    });
  });
});
