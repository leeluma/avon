Object.assign(process.env, {
  LOG_LEVEL: 'trace',
});
