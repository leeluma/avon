import { Router } from 'express';
import { ProductRouter } from '../../src/routes/product.routes';
import { ProductController } from '../../src/controller/product.controller';
import { validateAddToCart } from '../../src/validations/common.validation';
import { validateRequestSchema } from '../../src/middlewares/validate-request-schema';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks/express-validator.mock').default);

describe('ProductRouter', () => {
  let productController: ProductController;
  let productRouter: ProductRouter;
  let mockRouter: Router;

  beforeEach(() => {
    productController = {
      fetchProducts: jest.fn(),
      addProductToCart: jest.fn(),
    } as any;

    mockRouter = {
      post: jest.fn(() => mockRouter),
    } as any;

    productRouter = new ProductRouter({
      productController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = productRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      productRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenCalledTimes(1);
    });

    /**
     * Test case to add product to cart
     */
    test('add product to cart POST / routes', () => {
      productRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenNthCalledWith(1,
        '/addProductToCart',
        validateAddToCart,
        validateRequestSchema,
        expect.any(Function));
    });
  });
});
