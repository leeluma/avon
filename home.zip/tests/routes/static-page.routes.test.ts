import { Router } from 'express';
import { StaticPageRouter } from '../../src/routes';
import { StaticPageController } from '../../src/controller';
import { validateRequestSchema } from '../../src/middlewares/validate-request-schema';
import { magnoliaUrlMiddleware } from '../../src/middlewares/magnolia-url.middleware';
import { validatePageParams } from '../../src/validations/common.validation';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks/express-validator.mock').default);

describe('StaticPageRouter', () => {
  let staticPageController: StaticPageController;
  let staticPageRouter: StaticPageRouter;
  let mockRouter: Router;

  beforeEach(() => {
    staticPageController = {
      getStaticPageData: jest.fn(),
    } as any;

    mockRouter = {
      post: jest.fn(() => mockRouter),
      get: jest.fn(() => mockRouter),
    } as any;

    staticPageRouter = new StaticPageRouter({
      staticPageController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = staticPageRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      staticPageRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(1);
    });

    /**
     * Test case for the route to get static page data
     */
    test('configures the static page routes', () => {
      staticPageRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenNthCalledWith(1,
        '/',
        validatePageParams,
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function));
    });
  });
});
