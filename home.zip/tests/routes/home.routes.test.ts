import { Router } from 'express';
import { HomeRouter } from '../../src/routes/home.routes';
import { HomeController } from '../../src/controller/home.controller';
import { validateRequestSchema } from '../../src/middlewares/validate-request-schema';
import { magnoliaUrlMiddleware } from '../../src/middlewares/magnolia-url.middleware';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks/express-validator.mock').default);

describe('HomeRouter', () => {
  let homeController: HomeController;
  let homeRouter: HomeRouter;
  let mockRouter: Router;

  beforeEach(() => {
    homeController = {
      fetchData: jest.fn(),
    } as any;

    mockRouter = {
      post: jest.fn(() => mockRouter),
      get: jest.fn(() => mockRouter),
    } as any;

    homeRouter = new HomeRouter({
      homeController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = homeRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      homeRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(1);
    });

    /**
     * Test case for the route to get Home page data
     */
    test('configures the Home routes', () => {
      homeRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenNthCalledWith(1,
        '/',
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function));
    });
  });
});
