import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import {
  stubMarket, stubMagnoliaData, stubCtMultiProductDto, stubMagnoliaInfo, stubMagnoliaHome, stubGlobalSettings,
} from '../__stubs__';

import { ProductDao, MagnoliaDao } from '../../src/daos';

import { ProductService, MagnoliaService } from '../../src/services';
import Mock = jest.Mock;
import { MultiProductDto } from '../../src/dtos/product.dto';
import MagnoliaMapper from '../../src/mappers/magnolia.mapper';
import { MagnoliaData } from '../../src/dtos/magnolia.dto';

describe('LeapApp', () => {
  /* System Under Test */
  let magnoliaService: MagnoliaService;
  let productService: ProductService;

  /* Dependencies */
  let magnoliaDao: MagnoliaDao;
  let magnoliaMapper: MagnoliaMapper;
  let productDao: ProductDao;
  let market: MarketInfo;
  let magnolia: MagnoliaInfo;
  let globalSettings;
  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();
    globalSettings = stubGlobalSettings();

    /* Dependencies */
    magnoliaDao = {} as any;
    productDao = {
      getProductByIds: jest.fn(),
    } as any;
    magnoliaMapper = {
      pageData: jest.fn(),
      appendProductList: jest.fn(),
    } as any;
    productService = {} as any;

    /* SUT */
    magnoliaService = new MagnoliaService({ magnoliaDao, magnoliaMapper, productService });
  });

  /**
   * Unit test case for getByIds function of product service
   */
  describe('getPageData()', () => {
    let multiProductDto: MultiProductDto;
    let magnoliaData: MagnoliaData;
    const channelKey = faker.datatype.string();
    beforeEach(() => {
      magnoliaDao.getHomeDataFromMagnolia = jest.fn();
      magnoliaDao.getDefaultWarehouse = jest.fn();
      magnoliaDao.getGlobalSettings = jest.fn();
      magnoliaDao.getTemplateDataFromMagnolia = jest.fn();
      magnoliaDao.getStaticPageDataFromMagnolia = jest.fn();
      productDao.fetchProducts = jest.fn();
      productService.getProductByIds = jest.fn();
      multiProductDto = stubCtMultiProductDto(market);
      magnoliaData = stubMagnoliaData();
    });

    test('fetches Home data from Magnolia and CT', async () => {
      /* Prepare */
      (magnoliaDao.getHomeDataFromMagnolia as Mock).mockReturnValueOnce(stubMagnoliaHome);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(stubMagnoliaHome);
      (magnoliaMapper.pageData as Mock).mockReturnValue(magnoliaData);
      (productService.getProductByIds as Mock).mockReturnValue(multiProductDto);
      /* Execute */
      const result = await magnoliaService.getPageData(market, magnolia, channelKey);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaDao.getHomeDataFromMagnolia).toHaveBeenCalledTimes(1);
    });

    test('if channelKey is undefind', async () => {
      /* Prepare */
      const defaultWarehouse = {
        isSingleWarehouse: faker.datatype.boolean(),
        defaultWarehouse: faker.datatype.string(),
      };
      (magnoliaDao.getHomeDataFromMagnolia as Mock).mockReturnValueOnce(stubMagnoliaHome);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (magnoliaDao.getDefaultWarehouse as Mock).mockReturnValueOnce(defaultWarehouse);
      (magnoliaMapper.pageData as Mock).mockReturnValue(magnoliaData);
      (productService.getProductByIds as Mock).mockReturnValue(multiProductDto);
      /* Execute */
      const result = await magnoliaService.getPageData(market, magnolia, undefined);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaDao.getHomeDataFromMagnolia).toHaveBeenCalledTimes(1);
    });

    test('getProductsList', async () => {
      /* Prepare */
      const { productIds, keys } = magnoliaData.productIds;
      (productService.getProductByIds as Mock).mockReturnValue(multiProductDto);
      /* Execute */
      const result = await magnoliaService.getProductsList(market, productIds, keys, channelKey, globalSettings.priceFormat);

      /* Verify */
      expect(result).toBeTruthy();
      expect(productService.getProductByIds).toHaveBeenCalledTimes(1);
    });

    test('if productIds is undefined', async () => {
      /* Prepare */
      const defaultWarehouse = {
        isSingleWarehouse: faker.datatype.boolean(),
        defaultWarehouse: faker.datatype.string(),
      };
      const pageData = {
        ...magnoliaData,
        productIds: {
          productIds: {},
          keys: null,
        },
      };
      magnoliaService.getProductsList = jest.fn();
      (magnoliaDao.getHomeDataFromMagnolia as Mock).mockReturnValueOnce(stubMagnoliaHome);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (magnoliaDao.getDefaultWarehouse as Mock).mockReturnValueOnce(defaultWarehouse);
      (magnoliaMapper.pageData as Mock).mockReturnValue(pageData);
      (productService.getProductByIds as Mock).mockReturnValue(multiProductDto);
      /* Execute */
      const result = await magnoliaService.getPageData(market, magnolia, undefined);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaDao.getHomeDataFromMagnolia).toHaveBeenCalledTimes(1);
      expect(magnoliaService.getProductsList).not.toHaveBeenCalled();
    });

    test('fetches template data from Magnolia', async () => {
      /* Prepare */
      const templateName = faker.datatype.string();
      const magnoliaBasePath = faker.datatype.string();
      (magnoliaDao.getTemplateDataFromMagnolia as Mock).mockReturnValueOnce(stubMagnoliaHome);

      /* Execute */
      const result = await magnoliaService.getTemplateData(templateName, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaDao.getTemplateDataFromMagnolia).toHaveBeenCalledTimes(1);
    });

    test('Get magnolia static page data', async () => {
      /* Prepare */
      const pagePath = faker.datatype.string();
      (magnoliaDao.getStaticPageDataFromMagnolia as Mock).mockReturnValueOnce(stubMagnoliaHome);

      /* Execute */
      const result = await magnoliaService.getStaticPageData(market, magnolia, pagePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaDao.getStaticPageDataFromMagnolia).toHaveBeenCalledTimes(1);
    });
    test('fetches global settings from Magnolia', async () => {
      /* Prepare */
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(stubMagnoliaHome);
      /* Execute */
      const result = await magnoliaService.getGlobalSettings(market, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaDao.getGlobalSettings).toHaveBeenCalledTimes(1);
    });
  });
});
