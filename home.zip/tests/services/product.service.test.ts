// eslint-disable-next-line import/no-extraneous-dependencies
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubCtProductDto, stubCtMultiProductDto, stubGlobalSettings,
} from '../__stubs__';
import { ProductDao, InventoryDao } from '../../src/daos';
import { ProductService } from '../../src/services';
import Mock = jest.Mock;
import { MultiProductDto, AddToCartRequestDto, AddToCartResponseDto } from '../../src/dtos';
import ProductMapper from '../../src/mappers/product.mapper';
import InventoryMapper from '../../src/mappers/inventory.mapper';
import { stubAddProductToCartRequestDto, stubAddProductToCartResponseDto } from '../__stubs__/addproducttocart.dto.stub';

describe('LeapApp', () => {
  /* System Under Test */
  let productService: ProductService;

  /* Dependencies */
  let productDao: ProductDao;
  let inventoryDao: InventoryDao;
  let productMapper: ProductMapper;
  let inventoryMapper: InventoryMapper;
  let market: MarketInfo;
  beforeEach(() => {
    market = stubMarket();

    /* Dependencies */
    productDao = {} as any;
    inventoryDao = {} as any;
    productMapper = {
      multiProductMap: jest.fn(),
      productMapping: jest.fn(),
    } as any;
    inventoryMapper = {
      getInventoriesId: jest.fn(),
    } as any;

    /* SUT */
    productService = new ProductService({
      productDao, productMapper, inventoryMapper, inventoryDao,
    });
  });

  /**
   * Unit test case for getByIds function of product service
   */
  describe('getProductByIds()', () => {
    let multiProductDto: MultiProductDto;
    let globalSettings;
    const channelKey = faker.datatype.string();
    beforeEach(() => {
      productDao.fetchProducts = jest.fn();
      inventoryDao.fetchInventoryDetail = jest.fn();
      multiProductDto = stubCtMultiProductDto(market);
      globalSettings = stubGlobalSettings();
    });

    test('fetches data from productDao', async () => {
      /* Prepare */
      (productDao.fetchProducts as Mock).mockReturnValueOnce(stubCtMultiProductDto);
      (productMapper.multiProductMap as Mock).mockReturnValue(multiProductDto);
      const productIds = [multiProductDto.id];
      /* Execute */
      expect(productIds.length).toBeGreaterThan(0);
      await productService.getProductByIds(market, productIds, channelKey, globalSettings.priceFormat);

      /* Verify */
      expect(productDao.fetchProducts).toHaveBeenCalledTimes(1);
    });

    test('maps CtProductDto to multiProductDto', async () => {
      const mockData = {
        data: {
          products: {
            results: [
              stubCtProductDto,
            ],
          },
        },
      };
      const inventoryData = [
        {
          id: faker.datatype.uuid(),
          sku: faker.datatype.string(),
          custom: {
            customFieldsRaw: [
              {
                value: true,
                name: 'isLowAvailability',
              },
            ],
          },
        },
        {
          id: faker.datatype.uuid(),
          sku: faker.datatype.string(),
          custom: null,
        },
      ];
      /* Prepare */
      (productDao.fetchProducts as Mock).mockReturnValueOnce(mockData);
      (inventoryMapper.getInventoriesId as Mock).mockReturnValueOnce(`"${faker.datatype.uuid()}"`);
      (inventoryDao.fetchInventoryDetail as Mock).mockReturnValueOnce(inventoryData);
      (productMapper.multiProductMap as Mock).mockReturnValueOnce(multiProductDto);
      (productMapper.productMapping as Mock).mockReturnValueOnce(multiProductDto);

      /* Execute */
      await productService.getProductByIds(market, [multiProductDto.id], channelKey, globalSettings.priceFormat);

      /* Verify */
      expect(productMapper.multiProductMap).toHaveBeenCalledTimes(1);
      expect(productMapper.multiProductMap).toHaveBeenNthCalledWith(1,
        mockData.data.products.results, market, channelKey, globalSettings.priceFormat, inventoryData);
    });

    test('returns the productDto from mapper', async () => {
      /* Prepare */
      const mockData = {
        data: {
          products: {
            results: [
              stubCtProductDto,
            ],
          },
        },
      };
      (productDao.fetchProducts as Mock).mockReturnValueOnce(mockData);
      (productMapper.multiProductMap as Mock).mockReturnValueOnce(multiProductDto);
      (inventoryMapper.getInventoriesId as Mock).mockReturnValueOnce(undefined);

      /* Execute */
      const response = await productService.getProductByIds(market, [multiProductDto.id], channelKey, globalSettings.priceFormat);
      /* Verify */
      expect(response).toBe(multiProductDto);
    });

    test('returns undefined if the product does not exist', async () => {
      /* Prepare */
      (productDao.fetchProducts as Mock).mockReturnValueOnce(undefined);
      (productMapper.multiProductMap as Mock).mockReturnValueOnce(multiProductDto);

      /* Execute */
      const response = await productService.getProductByIds(market, [multiProductDto.id], channelKey, globalSettings.priceFormat);

      /* Verify */
      expect(response).toBeUndefined();
      expect(productMapper.multiProductMap).not.toHaveBeenCalled();
    });
  });

  /**
   * Unit test case for addProductToCart function of product service
   */
  describe('addProductToCart()', () => {
    let addProductToCartDtoRequest:AddToCartRequestDto;
    let addProductToCartResponseDto:AddToCartResponseDto;
    beforeEach(() => {
      productDao.addProductToCart = jest.fn();
      addProductToCartDtoRequest = stubAddProductToCartRequestDto(market);
      addProductToCartResponseDto = stubAddProductToCartResponseDto(market);
    });

    test('fetches data from productDao', async () => {
      /* Prepare */
      (productDao.addProductToCart as Mock).mockReturnValueOnce(addProductToCartResponseDto);

      /* Execute */
      await productService.addProductToCart(
        market,
        addProductToCartDtoRequest.customerId,
        addProductToCartDtoRequest.cartId,
        addProductToCartDtoRequest?.lineItems?.sku,
        addProductToCartDtoRequest?.lineItems?.quantity,
        addProductToCartDtoRequest?.lineItems?.productKey,
      );

      /* Verify */
      expect(productDao.addProductToCart).toHaveBeenCalledTimes(1);
    });
  });
});
