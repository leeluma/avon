import faker from '@faker-js/faker';
import { Cart } from '@commercetools/platform-sdk';
import axios from 'axios';
import HttpStatusCodes from 'http-status-codes';
import { MarketInfo } from '../../src/middlewares';
import { CartsDao } from '../../src/daos';
import { stubMarket } from '../__stubs__';
import { ApiError } from '../../src/lib';
import Mock = jest.Mock;

jest.mock('axios');

describe('CartsDao', () => {
  let cartsDao: CartsDao;

  let market: MarketInfo;
  let beOrderUrl: string;

  beforeEach(() => {
    market = stubMarket();
    beOrderUrl = 'https://url/{{MARKET}}';

    cartsDao = new CartsDao({ beOrderUrl });
  });

  describe('addProductToCart()', () => {
    let customerId: string;
    let anonymousId: string;
    let channelKey: string;
    let cartId: string;
    let sku: string;
    let quantity: number;
    let productKey: string;

    let cart: Cart;

    beforeEach(() => {
      customerId = faker.datatype.uuid();
      cartId = faker.datatype.uuid();
      sku = faker.datatype.uuid();
      quantity = faker.datatype.number();
      productKey = faker.datatype.uuid();
      anonymousId = faker.datatype.uuid();
      channelKey = 'DC-RO';
      cart = { id: faker.datatype.uuid() } as Cart;
    });

    test('builds axiosConfig', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockReturnValueOnce({ data: { data: cart } });

      /* Execute */
      const data = {
        market,
        channelKey,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
      };
      await cartsDao.addProductToCart(data);

      /* Verify */
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(
        1,
        {
          method: 'post',
          url: `https://url/${market.locale}-${market.country}/carts`,
          headers: {
            'Content-Type': 'application/json',
            Accepts: 'application/json',
          },
          data: {
            anonymousId,
            customerId,
            channelKey,
            cartId,
            lineItems: { sku, quantity, productKey },
          },
        },
      );
    });

    test('returns data from leap-be-order', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockReturnValueOnce({ data: { data: cart } });

      /* Execute */
      const data = {
        market,
        channelKey,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
      };
      const response = await cartsDao.addProductToCart(data);

      /* Verify */
      expect(response).toBe(cart);
    });

    test('rethrows connection errors', async () => {
      const connectionError = new Error('something went wrong');
      (axios as unknown as Mock).mockRejectedValueOnce(connectionError);
      const data = {
        market,
        channelKey,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
      };
      const response = () => cartsDao.addProductToCart(data);

      await expect(response).rejects.toThrow(connectionError);
    });

    test('returns leap-be-order errors', async () => {
      const beOrderError = Object.assign(
        new Error('something went wrong'),
        {
          response: {
            status: HttpStatusCodes.NOT_FOUND,
            data: { errors: ['sku not found'] },
          },
        },
      );
      (axios as unknown as Mock).mockRejectedValueOnce(beOrderError);
      const data = {
        market,
        channelKey,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
      };
      const response = () => cartsDao.addProductToCart(data);

      await expect(response).rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, ['sku not found']),
      );
    });
  });
});
