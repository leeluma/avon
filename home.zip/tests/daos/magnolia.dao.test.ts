import faker from '@faker-js/faker';
import axios from 'axios';
import { Request } from 'express';
import { axiosOptions } from '../../src/lib/axios-options';
import { MarketInfo } from '../../src/middlewares';
import { stubMarket, stubExpressReq, stubMagnoliaInfo } from '../__stubs__';
import Mock = jest.Mock;
import { MagnoliaDao } from '../../src/daos/magnolia.dao';
import { MAGNOLIA_URI } from '../../src/common/constant';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import { ApiError } from '../../src/lib';

jest.mock('axios');

describe('Magnolia Dao testing Suit', () => {
  let magnoliaDao: MagnoliaDao;
  let market: MarketInfo;
  const templateName = faker.datatype.string();

  let req: Request;
  let magnoliaBasePath: string;
  let magnolia: MagnoliaInfo;
  const mockResponse = {
    data: {
      name: faker.datatype.string(),
      path: faker.datatype.string(),
      id: faker.datatype.uuid(),
      nodeType: faker.datatype.string(),
      title: faker.datatype.string(),
      facebook: {
        name: faker.datatype.string(),
        path: faker.datatype.string(),
      },
      twitter: {
        name: faker.datatype.string(),
        path: faker.datatype.string(),
      },
    },
  };

  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();
    magnoliaBasePath = faker.internet.url();
    /* Stubs */
    req = stubExpressReq();

    magnoliaDao = new MagnoliaDao();
  });

  // Unite test case for getHomeDataFromMagnolia() method
  describe('getHomeDataFromMagnolia()', () => {
    test('returns magnolia response body', async () => {
      /* Prepare */
      const queryParam = `lang=${market.locale}-${market.country}`;
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: `${magnolia.url}${MAGNOLIA_URI.home}${magnolia.marketPath}?${queryParam}`,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getHomeDataFromMagnolia(market, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(1, config);
    });

    test('Failed to fetch magnolia data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getHomeDataFromMagnolia(market, magnolia));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch home data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getTemplateDataFromMagnolia()', () => {
    test('returns magnolia template response body', async () => {
      /* Prepare */
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: `${magnolia.url}${MAGNOLIA_URI.template}${templateName}`,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getTemplateDataFromMagnolia(templateName, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(1, config);
    });

    test('Failed to fetch magnolia template data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getTemplateDataFromMagnolia(templateName, magnolia));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch home template data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getStaticPageDataFromMagnolia()', () => {
    const pagePath = faker.datatype.string();
    test('returns magnolia template response body', async () => {
      /* Prepare */
      const queryParam = `lang=${market.locale}-${market.country}`;
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: `${magnolia.url}${MAGNOLIA_URI.home}${magnolia.marketPath}/pages/${pagePath}?${queryParam}`,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getStaticPageDataFromMagnolia(market, magnolia, pagePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(1, config);
    });

    test('Failed to fetch magnolia template data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getStaticPageDataFromMagnolia(market, magnolia, pagePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch static page data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('rethrows magnolia errors as ApiError', async () => {
      /* Prepare */
      const err = new Error('magnolia error');
      Object.assign(err, {
        response: {
          status: 404,
          data: { message: 'The page was not found.' },
        },
      });
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const result = () => magnoliaDao.getStaticPageDataFromMagnolia(market, magnolia, pagePath);

      /* Verify */
      await expect(result).rejects.toThrow(new ApiError(404, 'Page not found.'));
    });

    test('rethrows magnolia errors as ApiError 500', async () => {
      /* Prepare */
      const err = new Error('magnolia error');
      Object.assign(err, {
        response: {
          status: 500,
          data: { message: 'The page was not found.' },
        },
      });
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const result = () => magnoliaDao.getStaticPageDataFromMagnolia(market, magnolia, pagePath);

      /* Verify */
      await expect(result).rejects.toThrow(new ApiError(500, 'Page not found.'));
    });
  });

  describe('getDefaultWarehouse()', () => {
    test('returns magnolia default warehouse response body', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getDefaultWarehouse(market, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia default warehouse data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getDefaultWarehouse(market, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch warehouse data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getPriceFormat()', () => {
    test('returns magnolia price format response body', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getPriceFormat(market, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia price format data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getPriceFormat(market, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch price format data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getGlobalSettings()', () => {
    test('returns magnolia global setting response body', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getGlobalSettings(market, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia global setting data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getGlobalSettings(market, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch global settings data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
});
