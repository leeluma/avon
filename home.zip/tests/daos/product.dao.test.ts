import faker from '@faker-js/faker';
import { Product } from '@commercetools/platform-sdk';
import axios from 'axios';
import { CtClient, ApiError } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import { graphql } from '../../src/graphql';
import { stubCtProductDto, stubMarket, stubCtMultiProductDto } from '../__stubs__';
import Mock = jest.Mock;
import { ProductDao } from '../../src/daos';
import { stubCtClient } from '../__stubs__/ct-client.stub';
import {
  ProductDto, MultiProductDto, AddToCartRequestDto,
  AddToCartResponseDto,
} from '../../src/dtos';
import {
  stubAddProductToCartRequestDto,
  stubAddProductToCartResponseDto,
} from '../__stubs__/addproducttocart.dto.stub';
import { axiosOptions } from '../../src/lib/axios-options';

jest.mock('axios');

describe('Product Detail Dao testing Suit', () => {
  let productDao: ProductDao;

  let productDto: ProductDto;
  let multiProductDto: MultiProductDto;
  let product: Product;

  let ctClient: CtClient;
  let gql: typeof graphql;
  let market: MarketInfo;
  let post: Mock;
  let withId: Mock;
  let get: Mock;
  let execute: Mock;
  let beOrderUrl: string;

  beforeEach(() => {
    market = stubMarket();
    beOrderUrl = faker.datatype.string();
    productDto = stubCtProductDto(market);
    multiProductDto = stubCtMultiProductDto(market);

    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    ctClient = stubCtClient(market.country, {
      products: jest.fn().mockReturnValueOnce({ withId, get }),
      graphql: jest.fn().mockReturnValueOnce({ get, post }),
      inventory: jest.fn().mockReturnValueOnce({ get }),
    });

    gql = {
      getProducts: Promise.resolve('query () { product {} }'),
      getInventories: Promise.resolve('query () { inventoryEntries {} }'),
    };

    productDao = new ProductDao({ ctClient, graphql: gql, beOrderUrl });
  });

  /**
   * Unit test case for fetchProduct function of product.dao
   */
  describe('fetchProducts()', () => {
    let ctResponse: any;
    beforeEach(() => {
      multiProductDto = stubCtMultiProductDto(market, { id: faker.datatype.uuid() });
      ctResponse = {
        body: {
          data: {
            products: {
              results: [product],
            },
          },
        },
      };
    });

    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      const expectedBody = {
        query: 'query () { product {} }',
        variables: {
          where: `id in ("${multiProductDto.id}")`,
          locale: market.locale,
        },
      };
      execute.mockReturnValueOnce(ctResponse);

      /* Execute */
      await productDao.fetchProducts(market, `"${multiProductDto.id}"`);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: expectedBody },
      );
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await productDao.fetchProducts(market, `"${multiProductDto.id}"`);

      expect(result).toBe(ctResponse.body);
    });

    test('returns the result data NULL from the GraphQL server', async () => {
      const ctResponses = {
        body: {
          data: null,
          errors: {
            error: 'Malformed parameter: UUID string is invalid',
          },
        },
      };
      execute.mockReturnValueOnce(ctResponses);

      const result = await productDao.fetchProducts(market, `"${multiProductDto.id}"`);

      expect(result.data).toBeNull();
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {};
      execute.mockRejectedValueOnce(err);

      const result = productDao.fetchProducts(market, `"${multiProductDto.id}"`);

      await expect(result).rejects.toThrow(err);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);
      /* Execute */
      const result = expect(() => productDao.fetchProducts(market, multiProductDto.id));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('re-throws ApiError ctClient errors', async () => {
      /* Prepare */
      const errBody = {
        body: {
          data: null,
          errors: ['msg'],
        },
      };

      execute.mockReturnValueOnce(errBody);
      /* Execute */
      const call = () => productDao.fetchProducts(market, multiProductDto.id);

      /* Verify */
      await expect(call).rejects.toThrow(
        new ApiError(400, 'Malformed parameter: UUID string is invalid'),
      );
    });
  });

  describe('addProductToCart()', () => {
    let addProductToCartDtoRequest: AddToCartRequestDto;
    let addProductToCartResponseDto: AddToCartResponseDto;
    let customerId; let cartId; let sku; let quantity; let productKey;
    beforeEach(() => {
      addProductToCartDtoRequest = stubAddProductToCartRequestDto(market);
      addProductToCartResponseDto = stubAddProductToCartResponseDto(market);
      customerId = addProductToCartDtoRequest?.customerId;
      cartId = addProductToCartDtoRequest?.cartId;
      sku = addProductToCartDtoRequest?.lineItems?.sku;
      quantity = addProductToCartDtoRequest?.lineItems?.quantity;
      productKey = addProductToCartDtoRequest?.lineItems?.productKey;
    });
    test('check the response of response addProductToCart()', async () => {
      /* Prepare */
      const axiosConfig = {
        ...axiosOptions,
        method: 'post' as const,
        url: `${beOrderUrl}/carts`,
        headers: {
          'Content-Type': 'application/json',
          Accepts: 'application/json',
        },
        data: {
          customerId,
          cartId,
          lineItems: { sku, quantity, productKey },
        },
      };
      (axios as unknown as Mock).mockResolvedValueOnce(addProductToCartResponseDto);

      /* Execute */
      const result = await productDao.addProductToCart(market, customerId, cartId, sku, quantity, productKey);
      /* Verify */
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(
        1,
        axiosConfig,
      );
      expect(result).toBe(undefined);
    });

    test('Failed to get the response of addProductToCart()', async () => {
      const err = new Error('LEAP BE ORDER returned error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => productDao.addProductToCart(market, customerId, cartId, sku, quantity, productKey));
      /* Verify */
      await response.rejects.toThrow(
        new Error('LEAP BE ORDER returned error'),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to get the response of addProductToCart() ApiError', async () => {
      const err = { response: { status: 500, data: { errors: 'Server error' } } };
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      /* Execute */
      const call = () => productDao.addProductToCart(market, customerId, cartId, sku, quantity, productKey);

      /* Verify */
      await expect(call).rejects.toThrow(
        new ApiError(err.response.status, err.response.data?.errors),
      );
    });
  });
});
