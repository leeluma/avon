import faker from '@faker-js/faker';

export const stubCategory = (
  config: Partial<any> = {},
): any => {
  return {
    typeId: 'category',
    id: faker.datatype.string(),
    obj: {
      id: faker.datatype.string(),
      key: faker.datatype.string(),
      name: {
        en: faker.datatype.string(),
      },
      slug: {
        en: faker.datatype.string(),
      },
      description: {
        en: faker.datatype.string(),
      },
      ancestors: [],
      parent: {
        typeId: 'category',
        id: faker.datatype.string(),
      },
    },
    ...config,
  };
};
