// eslint-disable-next-line import/no-extraneous-dependencies
import faker from '@faker-js/faker';
import { AddToCartRequestDto, AddToCartResponseDto } from '../../src/dtos';
import { MarketInfo } from '../../src/middlewares';

export const stubAddProductToCartResponseDto = (
  market: MarketInfo,
  config: Partial<AddToCartResponseDto> = {},
): any => {
  return {
    id: faker.datatype.string(),
    version: faker.datatype.number(),
    totalRetailPriceAmount: faker.datatype.string(),
    totalTaxAmount: faker.datatype.number(),
    totalAdjustmentAmount: faker.datatype.number(),
    totalInvoicedAmount: faker.datatype.string(),
    customerId: faker.datatype.string(),
    anonymousId: faker.datatype.string(),
    lineItems: [{
      lineItemId: faker.datatype.string(),
      productId: faker.datatype.string(),
      productKey: faker.datatype.string(),
      name: faker.datatype.string(),
      skuCode: faker.datatype.uuid(),
      images: [{
        url: faker.datatype.string(),
        label: faker.datatype.string(),
        width: faker.datatype.number(),
        height: faker.datatype.number(),
      }],
      listPrice: faker.datatype.number(),
      sellPrice: faker.datatype.number(),
      formattedListPrice: faker.datatype.string(),
      formattedSellPrice: faker.datatype.string(),
      vatMessage: faker.datatype.string(),
      unitPrice: faker.datatype.string(),
      quantity: faker.datatype.number(),
      modifiedTimeStamp: faker.datatype.string(),
      sequenceNumber: faker.datatype.number(),
      maxPurchasableQty: faker.datatype.number(),
      availableQuantity: faker.datatype.number(),
      variantType: faker.datatype.string(),
      variantValue: faker.datatype.string(),
      hexCode: faker.datatype.string(),
      offers: [
        {
          key: faker.datatype.string(),
          displayName: faker.datatype.string(),
          url: faker.datatype.string(),
          description: faker.datatype.string(),
        },
      ],
    }],
    shippingAddress: {
      id: faker.datatype.string(),
      title: faker.datatype.string(),
      salutation: faker.datatype.string(),
      firstName: faker.datatype.string(),
      lastName: faker.datatype.string(),
      streetName: faker.datatype.string(),
      streetNumber: faker.datatype.string(),
      additionalStreetInfo: faker.datatype.string(),
      postalCode: faker.datatype.string(),
      city: faker.datatype.string(),
      state: faker.datatype.string(),
      region: faker.datatype.string(),
      country: faker.datatype.string(),
      company: faker.datatype.string(),
      department: faker.datatype.string(),
      building: faker.datatype.string(),
      apartment: faker.datatype.string(),
      p0Box: faker.datatype.string(),
      phone: faker.datatype.string(),
      mobile: faker.datatype.string(),
      email: faker.datatype.string(),
      fax: faker.datatype.string(),
      additionalAddressInfo: faker.datatype.string(),
      externalId: faker.datatype.string(),
      key: faker.datatype.string(),
    },
    ...config,
  };
};
export const stubAddProductToCartRequestDto = (
  market: MarketInfo,
  config: Partial<AddToCartRequestDto> = {},
): AddToCartRequestDto => {
  return {
    cartId: faker.datatype.string(),
    customerId: faker.datatype.string(),
    lineItems: {
      productKey: faker.datatype.string(),
      sku: faker.datatype.string(),
      quantity: faker.datatype.number(),
    },
    ...config,
  };
};
