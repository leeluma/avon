import faker from '@faker-js/faker';

export const stubMagnoliaHome = (
  config: Partial<any> = {},
): any => {
  const product = {
    definitionName: faker.datatype.string(),
    connectionName: faker.datatype.string(),
    categoryId: faker.datatype.uuid(),
    productId: faker.datatype.uuid(),
  };

  return {
    '@name': faker.datatype.string(),
    '@path': faker.datatype.string(),
    '@id': faker.datatype.uuid(),
    '@nodeType': faker.datatype.string(),
    'mgnl:template': faker.datatype.string(),
    'mgnl:created': faker.datatype.string(),
    title: faker.datatype.string(),
    main: {
      '01': {
        '@name': faker.datatype.string(),
        '@path': faker.datatype.string(),
        '@id': faker.datatype.uuid(),
        ProductCarousel: {
          '@name': faker.datatype.string(),
          '@path': faker.datatype.string(),
          '@id': faker.datatype.uuid(),
          ProductCarousel0: {
            '@name': faker.datatype.string(),
            '@path': faker.datatype.string(),
            '@id': faker.datatype.uuid(),
            product: JSON.stringify(product),
          },
          '@nodes': [
            'ProductCarousel0',
          ],
        },
        '@nodes': [
          'ProductCarousel',
        ],
      },
      '@nodes': [
        '01',
      ],
    },
    ...config,
  };
};
