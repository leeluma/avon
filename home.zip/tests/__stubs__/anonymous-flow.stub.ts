import faker from '@faker-js/faker';
import { AnonymousFlowResponseDto } from '../../src/dtos';

export const stubAnonymousFlowResponseDto = (
  config: Partial<AnonymousFlowResponseDto> = {},
): AnonymousFlowResponseDto => {
  return {
    accessToken: faker.datatype.string(),
    expiresIn: faker.datatype.number(),
    anonymousId: faker.datatype.uuid(),
    refreshToken: faker.datatype.uuid(),
    ...config,
  };
};
