import faker from '@faker-js/faker';
import { AttributesDto } from '../../src/dtos/product.dto';

export const stubAttributeFields = (
  config: Partial<AttributesDto> = {},
): AttributesDto => {
  return {
    variantType: faker.datatype.string(),
    variantValue: faker.datatype.string(),
    shortDescription: faker.datatype.string(),
    brandId: faker.datatype.string(),
    brandName: faker.datatype.string(),
    finishedStockCode: faker.datatype.string(),
    specialMessage: faker.datatype.string(),
    ContentFillMeasure: faker.datatype.string(),
    ContentFill: faker.datatype.string(),
    maxPurchasableQty: faker.datatype.number(),
    ratingCount: faker.datatype.number(),
    reviewCount: faker.datatype.number(),
    inStock: faker.datatype.boolean(),
    nonRepListPrice: faker.datatype.string(),
    nonRepSalePrice: faker.datatype.string(),
    isDiscontinued: faker.datatype.boolean(),
    ...config,
  };
};
