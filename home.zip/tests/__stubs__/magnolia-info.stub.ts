import faker from '@faker-js/faker';
import { MagnoliaInfo } from '../../src/dtos/common.dto';

export const stubMagnoliaInfo = (
  config: Partial<MagnoliaInfo> = {},
): MagnoliaInfo => {
  const url = faker.internet.url();
  const isPreview = faker.datatype.boolean();
  const marketPath = faker.datatype.string();

  return {
    url,
    isPreview,
    marketPath,
    ...config,
  };
};
