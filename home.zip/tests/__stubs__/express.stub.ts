import { Request, Response } from 'express';
import { MarketInfo } from '../../src/middlewares';

export const stubExpressReq = (
  config: Partial<Request> = {},
): Request => {
  return {
    headers: {},
    body: {},
    params: {},
    query: {},
    ...config,
  } as any;
};

export const stubExpressRes = (
  market: MarketInfo,
  config: Partial<Response> = {},
): Response => {
  const res: any = {
    statusCode: 999,
    headers: {},
    body: undefined,
    locals: { market },
  } as any;

  return { ...res, ...config };
};
