import faker from '@faker-js/faker';
import { MagnoliaData, ProductIds, ProductsIds } from '../../src/dtos/magnolia.dto';
import { stubMagnoliaHome } from './magnolia-home.stub';

export const stubMagnoliaData = (
  config: Partial<MagnoliaData> = {},
): MagnoliaData => {
  const key = faker.datatype.string();
  const pid = faker.datatype.uuid();
  const productIds:ProductIds = {
    [key]: [pid],
  };
  const productsIds:ProductsIds = {
    productIds,
    keys: [key],
  };
  return {
    data: stubMagnoliaHome(),
    productIds: productsIds,
    templateName: faker.datatype.string(),
    ...config,
  };
};
