import { CustomerSignin } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import { CtClientRequestBuilder } from '../../src/lib';

export const stubCustomerLoginRequestDto = (
  config: Partial<CustomerSignin> = {},
): CustomerSignin => {
  return {
    email: faker.internet.email(),
    password: faker.internet.password(),
    ...config,
  };
};

export const stubCtCustomerClient = (
  expectedCountry: string,
  requestBuilderConfig: Partial<CtClientRequestBuilder> = {},
): CtClientRequestBuilder => {
  return {
    getClient: (country) => {
      expect(country).toEqual(expectedCountry);
      return {
        ...requestBuilderConfig,
      };
    },
    getAuthClient: (country) => {
      expect(country).toEqual(expectedCountry);
      return {
        ...requestBuilderConfig,
      };
    },
  } as any;
};
