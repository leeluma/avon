import faker from '@faker-js/faker';
import { ProductAttributesDto } from '../../src/dtos/product.dto';

export const stubProductAttributeFields = (
  config: Partial<ProductAttributesDto> = {},
): ProductAttributesDto => {
  return {
    contentFill: faker.datatype.string(),
    contentFillMeasure: faker.datatype.string(),
    description: faker.datatype.string(),
    galleryImageUrl: faker.datatype.string(),
    thumbnailImageUrl: faker.datatype.string(),
    inStock: faker.datatype.boolean(),
    productMassDetails: faker.datatype.string(),
    maxPurchasableQty: faker.datatype.number(),
    metaKeywords: faker.datatype.string(),
    ratingCount: faker.datatype.number(),
    reviewCount: faker.datatype.number(),
    new: faker.datatype.string(),
    productSpecialMessage: faker.datatype.string(),
    title: faker.datatype.string(),
    url: faker.datatype.string(),
    vatIncludedMsg: faker.datatype.string(),
    productKey: faker.datatype.string(),
    ...config,
  };
};
