import faker from '@faker-js/faker';
import { AssetsDto } from '../../src/dtos/product.dto';

export const stubAssetsFields = (
  config: Partial<AssetsDto> = {},
): AssetsDto => {
  return {
    url: faker.internet.url(),
    assetType: faker.datatype.string(),
    sequence: faker.datatype.number(),
    ...config,
  };
};
