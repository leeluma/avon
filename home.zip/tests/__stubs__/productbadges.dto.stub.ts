import faker from '@faker-js/faker';
import { BadgesDto } from '../../src/dtos/product.dto';

export const stubBadgesFields = (
  config: Partial<BadgesDto> = {},
): BadgesDto => {
  return {
    topRight: faker.random.words(),
    topLeft: faker.random.words(),
    ...config,
  };
};
