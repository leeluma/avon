# leap-bff-footer

This service implements APIs for the footer component.

# Repo Owner

HCL

# Prerequisites

- None

# Installation

```shell
npm install
npm run build
```

Configure the `.env` file according to the sample below in this readme.

```shell
npm start
```

# Sample .env file

```
API_CONTEXT_PATH='api'
API_VERSION=v1
API_PORT=3000

NODE_ENV=development
LOG_LEVEL=trace

MAGNOLIA_BASE_PATH=https://magnolia-author.leap-dev.aws.avon.com/

```

## Development Checklist

1. Update Swagger specs
2. Update Postman collection
3. Write Unit Test cases
4. Run stryker mutation testing
5. Write required validation
6. Run npm audit and see no security issues
7. All eslint issue mitigated
8. Write jsdoc comments on each method, class, constant etc.
9. API should not take more than 1.5 second 
