import { MagnoliaInfo, SettingsResponseDto } from '../dtos';
import { SettingsDao } from '../daos';
import { MarketInfo } from '../middlewares';
import { Common } from '../lib';

export interface SettingsServiceConfig {
  settingsDao: SettingsDao;
  common: Common;
}

/**
 * Service for managing Settings
 */
export class SettingsService {
  private readonly settingsDao: SettingsDao;

  private readonly common: Common;

  /**
   * Constructor for `SettingsService` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: SettingsServiceConfig) {
    this.settingsDao = config.settingsDao;
    this.common = config.common;
  }

  /**
   * Get Footer Settings from Magnolia
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   * @returns SettingResponseDto
   */
  public async index(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ): Promise<SettingsResponseDto> {
    const response = await this.settingsDao.index(market, magnolia);
    return magnolia.ispreview ? response : this.common.filterPreviewFields(response);
  }
}
