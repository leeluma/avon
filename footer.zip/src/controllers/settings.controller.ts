import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { SettingsService } from '../services';
import { JsonApiResponseEntity } from '../lib';
import { MagnoliaInfo, SettingsResponseDto } from '../dtos';
import { MarketInfo } from '../middlewares';

export interface SettingsControllerConfig {
  settingsService: SettingsService;
}

/**
 * Service for managing Settings
 */
export class SettingsController {
  private readonly settingsService: SettingsService;

  /**
   * Constructor for `SettingsController` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: SettingsControllerConfig) {
    this.settingsService = config.settingsService;
  }

  /**
   * returns magnolia footer config
   * @param request - Express request object
   * @param response - Express response object
   * @returns Settings
   */
  public async index(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<SettingsResponseDto>> {
    const market = response.locals.market as MarketInfo;
    const magnolia = response.locals.magnolia as MagnoliaInfo;
    const settings = await this.settingsService.index(market, magnolia);

    return {
      statusCode: HttpStatusCodes.OK,
      body: settings,
    };
  }
}
