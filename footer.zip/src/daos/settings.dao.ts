import axios from 'axios';
import { MagnoliaInfo, SettingsResponseDto } from '../dtos';
import { axiosOptions, MagnoliaUri } from '../lib';
import { MarketInfo } from '../middlewares';

export interface SearchDaoConfig {
  magnoliaBasePath: string;
}
/**
 * `SettingsDao` data access class for getting footer settings from magnolia
 */
export class SettingsDao {
  private readonly magnoliaBasePath;

  /**
   * Constructor for `SettingsDao` class
   * @param config Injects dependencies into the object
   */
  constructor(config: SearchDaoConfig) {
    this.magnoliaBasePath = config.magnoliaBasePath;
  }

  /**
   * Get Footer settings from magnolia
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   */
  public async index(
    market: MarketInfo,
    magnolia:MagnoliaInfo,
  ): Promise<SettingsResponseDto> {
    try {
      const uri = MagnoliaUri.FooterSetting.replace('{{country}}', market.country.toLowerCase());
      const url = `${magnolia.url}${uri}`;
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url,
      };
      const result = await axios(config);
      return result.data;
    } catch (err: any) {
      throw new Error(`Failed to fetch settings from magnolia, because: ${err.stack}`);
    }
  }
}
