import { Router } from 'express';
import { LeapApp, LeapAppConfig } from './app/leap.app';
import { SettingsDao } from './daos';
import { SettingsRouter } from './routers';
import { SettingsController } from './controllers';
import { SettingsService } from './services';
import { Common } from './lib';

/* Build configuration */

const projectName = process.env.npm_package_name;
if (!projectName) {
  throw new Error('The "name" field in package.json is mandatory!');
}

const projectVersion = process.env.npm_package_version;
if (!projectVersion) {
  throw new Error('The "version" field in package.json is mandatory!');
}

const apiContextPath = process.env.API_CONTEXT_PATH;
if (!apiContextPath) {
  throw new Error('The "API_CONTEXT_PATH" environment variable is mandatory! (suggested value: api)');
}
const apiVersion = process.env.API_VERSION;
if (!apiVersion) {
  throw new Error('The "API_VERSION" environment variable is mandatory! (suggested value: v1)');
}
const port = parseInt(process.env.API_PORT || '0', 10);
if (!port) {
  throw new Error('The "API_PORT" environment variable is missing or not a valid number! (suggested value: 3000)');
}
const magnoliaBasePath = process.env.MAGNOLIA_BASE_PATH;
if (!magnoliaBasePath) {
  throw new Error('The "MAGNOLIA_BASE_PATH" environment variable is missing.');
}

const appConfig: LeapAppConfig = {
  projectName,
  projectVersion,
  apiContextPath,
  apiVersion,
  port,
};

/* Initialize dependencies */
const common = new Common();

const settingsDao = new SettingsDao({ magnoliaBasePath });

const settingsService = new SettingsService({ settingsDao, common });

const settingsController = new SettingsController({ settingsService });

const settingsRouter = new SettingsRouter({ Router, settingsController });

/* Start app */

const leapApp = new LeapApp(appConfig);
leapApp.bootstrap().then(() => {
  leapApp.mount('/settings', settingsRouter.buildExpressRouter());
  leapApp.listen();
});
