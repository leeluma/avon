import { Router } from 'express';
import { magnoliaUrlMiddleware, validateRequestSchema } from '../middlewares';
import { SettingsController } from '../controllers';
import { wrapJsonApiController } from '../lib';

export interface SettingsRouterConfig {
  settingsController: SettingsController;
  Router: typeof Router;
}

/**
 * `SettingsRouter` for all the routes related to `/settings`
 */
export class SettingsRouter {
  private readonly settingsController: SettingsController;

  private readonly Router: typeof Router;

  constructor(config: SettingsRouterConfig) {
    this.settingsController = config.settingsController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /footer/v1/{locale}-{country}/settings:
     *   get:
     *     summary: Get Footer Settings
     *     tags: [Settings]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: header
     *         name: isPreview
     *         schema:
     *            type: boolean
     *            default: true
     *     responses:
     *       200:
     *         description: Get Footer Settings
     *       404:
     *         description: Something went wrong.
    */
    router.get(
      '/',
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.settingsController.index.bind(this.settingsController),
      ),
    );

    return router;
  }
}
