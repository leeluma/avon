export interface SettingsResponseDto {
  [key: string]: string | SettingsResponseDto | string[];
}
