export interface MagnoliaInfo {
  url: string;
  ispreview: boolean;
}
