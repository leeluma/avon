import { NextFunction, Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { ApiError } from '../lib';

export interface MarketInfo {
  country: string;
  locale: string;
  localeAndCountry: string;
  store: string;
  storeAndLocaleAndCountry: string;
}

export const marketParserMiddleware = (
  req: Request,
  res: Response,
  next: NextFunction,
): void => {
  const { locale, country } = req.params;
  if (!locale || !country) {
    throw new ApiError(HttpStatusCodes.BAD_REQUEST, `The market "${locale}-${country}" is invalid.`);
  }

  res.locals.market = {
    locale: locale.toLocaleLowerCase(),
    country: country.toLocaleUpperCase(),
  };

  // TODO Validate that this market exists, otherwise throw ApiError(400)

  next();
};
