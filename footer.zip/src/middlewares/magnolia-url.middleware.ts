import { NextFunction, Request, Response } from 'express';
import { config } from '../config';
import { MagnoliaInfo } from '../dtos';

export const magnoliaUrlMiddleware = (
  request: Request,
  response: Response,
  next: NextFunction,
): void => {
  const magnolia: MagnoliaInfo = {
    url: config.magnoliaBasePath as string,
    ispreview: false,
  };

  const previewValue = request.headers.ispreview ? (request.headers.ispreview as string).toLowerCase() : false;
  if (previewValue === 'true') {
    magnolia.url = config.previewMagnoliaBasePath as string;
    magnolia.ispreview = true;
  }

  response.locals.magnolia = magnolia;
  next();
};
