import { NextFunction, Request, Response } from 'express';
import i18next from 'i18next';

export const switchLangMiddleware = async (
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  const { locale } = req.params;
  i18next.changeLanguage(locale);
  next();
};
