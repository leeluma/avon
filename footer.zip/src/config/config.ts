import dotenv from 'dotenv';

dotenv.config();
export const config = {
  env: process.env.NODE_ENV,
  apiUrl: process.env.API_CONTEXT_PATH,
  port: parseInt(process.env.API_PORT || '0', 10),
  projectName: process.env.npm_package_name,
  projectVersion: process.env.npm_package_version,
  apiContextPath: process.env.API_CONTEXT_PATH,
  apiVersion: process.env.API_VERSION,
  magnoliaBasePath: process.env.MAGNOLIA_BASE_PATH,
  previewMagnoliaBasePath: process.env.PREVIEW_MAGNOLIA_BASE_PATH,
  ctRO: {
    projectKey: process.env.CT_PROJECT_KEY_RO,
    clientId: process.env.CT_CLIENT_ID_RO,
    clientSecret: process.env.CT_CLIENT_SECRET_RO,
  },
  ctPH: {
    projectKey: process.env.CT_PROJECT_KEY_PH,
    clientId: process.env.CT_CLIENT_ID_PH,
    clientSecret: process.env.CT_CLIENT_SECRET_PH,
  },
  ctMarkets: process.env.CT_ACTIVE_MARKETS,
  ctApiEndpoint: process.env.CT_API_ENDPOINT,
  ctAuthEndpoint: process.env.CT_AUTH_ENDPOINT,
  beOrderUrl: process.env.LEAP_BE_ORDER,
  apptusClusterId: process.env.APPTUS_CLUSTER_ID,
  apptusBaseUrl: process.env.APPTUS_BASE_URL,
  apptusEsalesMarket: process.env.APPTUS_ESALES_MARKET,

};
