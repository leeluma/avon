export class Common {
  /**
   * Remove fields beginning with '@'
   * @param data - Header data
   */
  public filterPreviewFields = (data: any) => {
    return Object.fromEntries(
      Object.entries(data)
        .filter(([k]) => !k.startsWith('@'))
        .map(([k, v]) => {
          if (typeof v === 'object' && v !== null) {
            return [k, this.filterPreviewFields(v)];
          }
          return [k, v];
        }),
    );
  };
}
