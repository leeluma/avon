export enum MagnoliaUri {
    FooterSetting = '.rest/delivery/footer/{{country}}/setting',
}
