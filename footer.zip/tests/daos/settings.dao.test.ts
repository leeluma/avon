import axios from 'axios';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { stubMagnoliaInfo, stubMarket } from '../__stubs__';
import Mock = jest.Mock;
import { SettingsDao } from '../../src/daos';
import { MagnoliaInfo } from '../../src/dtos';

jest.mock('axios');

describe('SettingsDao', () => {
  let settingsDao: SettingsDao;
  let magnoliaInfo: MagnoliaInfo;
  let market: MarketInfo;

  beforeEach(() => {
    market = stubMarket();
    magnoliaInfo = stubMagnoliaInfo();
    settingsDao = {} as any;
  });

  describe('index()', () => {
    let magnoliaBasePath: string;
    beforeEach(() => {
      magnoliaBasePath = faker.internet.url();
      settingsDao = new SettingsDao({ magnoliaBasePath });
    });

    test('mocking axios', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce({});
      /* Execute */
      await (settingsDao).index(market, magnoliaInfo);
      /* Verify */
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch settings from magnolia', async () => {
      /* Prepare */
      const err = {
        stack: 'some error',
      };
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (settingsDao).index(market, magnoliaInfo));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch settings from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
});
