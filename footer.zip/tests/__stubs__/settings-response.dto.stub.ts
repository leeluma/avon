import faker from '@faker-js/faker';
import { SettingsResponseDto } from '../../src/dtos';

export const stubSettingsResponseDto = (
  config: Partial<SettingsResponseDto> = {},
): SettingsResponseDto => {
  return {
    '@name': faker.datatype.string(),
    '@path': faker.datatype.string(),
    '@id': faker.datatype.uuid(),
  };
};
