import { MarketInfo } from '../../src/middlewares';
import { SettingsDao } from '../../src/daos';
import { stubMagnoliaInfo, stubMarket } from '../__stubs__';
import { SettingsService } from '../../src/services';
import Mock = jest.Mock;
import { MagnoliaInfo, SettingsResponseDto } from '../../src/dtos';
import { Common } from '../../src/lib';

describe('SettingsService', () => {
  /* System Under Test */
  let settingsService: SettingsService;

  /* Dependencies */
  let settingsDao: SettingsDao;
  let market: MarketInfo;
  let settingsDto: SettingsResponseDto;
  let magnoliaInfo: MagnoliaInfo;
  let common: Common;

  beforeEach(() => {
    market = stubMarket();
    magnoliaInfo = stubMagnoliaInfo();

    settingsDao = {} as any;
    common = {
      filterPreviewFields: jest.fn(),
    } as any;

    /* SUT */
    settingsService = new SettingsService({ settingsDao, common });
  });

  describe('index()', () => {
    beforeEach(() => {
      settingsDao.index = jest.fn();
    });

    test('reads the products from settingDao with magnolia preview true', async () => {
      /* Prepare */
      (settingsDao.index as Mock).mockReturnValueOnce(settingsDto);

      /* Execute */
      await settingsService.index(market, magnoliaInfo);

      /* Verify */
      expect(settingsDao.index).toHaveBeenCalledTimes(1);

      /* Verify */
      expect(common.filterPreviewFields).toHaveBeenCalledTimes(1);
    });

    test('reads the products from settingDao with magnolia preview false', async () => {
      /* Prepare */
      magnoliaInfo.ispreview = true;
      (settingsDao.index as Mock).mockReturnValueOnce(settingsDto);

      /* Execute */
      await settingsService.index(market, magnoliaInfo);

      /* Verify */
      expect(settingsDao.index).toHaveBeenCalledTimes(1);

      /* Verify */
      expect(common.filterPreviewFields).not.toHaveBeenCalledTimes(1);
    });
  });
});
