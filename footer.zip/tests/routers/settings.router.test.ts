import { Router } from 'express';
import { SettingsController } from '../../src/controllers';
import { magnoliaUrlMiddleware, validateRequestSchema } from '../../src/middlewares';
import { SettingsRouter } from '../../src/routers';

describe('CustomerRouter', () => {
  let settingsController: SettingsController;
  let settingsRouter: SettingsRouter;
  let mockRouter: Router;

  beforeEach(() => {
    settingsController = {
      index: jest.fn(),
    } as any;

    mockRouter = {
      get: jest.fn(() => mockRouter),
      post: jest.fn(() => mockRouter),
      put: jest.fn(() => mockRouter),
      delete: jest.fn(() => mockRouter),
    } as any;

    settingsRouter = new SettingsRouter({
      settingsController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = settingsRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      settingsRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(1);
    });

    test('configures the GET / route', () => {
      settingsRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/',
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
  });
});
