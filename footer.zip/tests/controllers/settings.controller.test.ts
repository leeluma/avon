import { Request, Response } from 'express';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubSettingsResponseDto,
} from '../__stubs__';
import { SettingsController } from '../../src/controllers';
import { SettingsService } from '../../src/services';

import Mock = jest.Mock;

describe('SettingsController', () => {
  /* System Under Test */
  let settingsController: SettingsController;

  /* Dependencies */
  let settingsService: SettingsService;
  let market: MarketInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    settingsService = {} as any;

    /* SUT */
    settingsController = new SettingsController({ settingsService });
  });

  describe('settings methods', () => {
    describe('index', () => {
      beforeEach(() => {
        settingsService.index = jest.fn();
      });

      test('forwards request parameters to service', async () => {
        /* Execute */
        await settingsController.index(req, res);

        /* Verify */
        expect(settingsService.index).toHaveBeenCalledTimes(1);
      });

      test('returns settings from service', async () => {
        /* Prepare */
        const settingsResponseDto = [stubSettingsResponseDto()];
        (settingsService.index as Mock).mockReturnValueOnce(settingsResponseDto);

        /* Execute */
        const result = await settingsController.index(req, res);

        /* Verify */
        expect(result).toEqual({
          statusCode: 200,
          body: settingsResponseDto,
        });
      });
    });
  });
});
