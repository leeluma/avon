import {config} from '../src/config';

Object.assign(config, {
  LOG_LEVEL: 'trace',
});
