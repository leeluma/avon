import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';

import { OffersController } from '../../src/controllers';
import { OffersService } from '../../src/services';

import Mock = jest.Mock;
import {
  stubMarket, stubExpressReq, stubExpressRes, stubMagnoliaInfo,
} from '../__stubs__';
import { MagnoliaInfo } from '../../src/dtos';

describe('OfferConroller', () => {
  /* System Under Test */
  let offersController: OffersController;

  /* Dependencies */
  let offersService: OffersService;
  let market: MarketInfo;
  let magnoliaInfo: MagnoliaInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();
    magnoliaInfo = stubMagnoliaInfo();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    offersService = {} as any;

    offersController = new OffersController({ offersService });
  });

  describe('offer methods', () => {
    beforeEach(() => {
      offersService.index = jest.fn();
      req.headers.channelKey = 'DC-RO';
      req.headers.sessionKey = faker.datatype.string();
      req.headers.customerKey = faker.datatype.string();
      req.headers.page = faker.datatype.string();
      req.headers.ispreview = 'true';
      req.query.offerFacet = faker.datatype.string();
      req.query.sortBy = faker.datatype.string();
      offersService.detail = jest.fn();
      req.query.windowFirst = faker.datatype.string();
      req.query.windowLast = faker.datatype.string();
      req.query.selectedCategory = faker.datatype.string();
      req.query.sortBy = faker.datatype.string();
      req.query.windowFirstRecommendations = faker.datatype.string();
      req.query.windowLastRecommendations = faker.datatype.string();
      req.query.maxFacets = faker.datatype.string();
      req.query.facets = faker.datatype.string();
      req.query.page = faker.datatype.string();
      req.query.rootCategory = faker.datatype.string();
      req.query.maxProducts = faker.datatype.string();
      req.query.depth = faker.datatype.string();
      req.query.filter = faker.datatype.string();
      req.headers.channelkey = faker.datatype.string();

      // req.headers.ispage = 'false';
    });
    describe('index()', () => {
      test('calls offers with request parameters', async () => {
        /* Prepare */
        (offersService.index as Mock).mockReturnValueOnce({ data: 'offers' });
        res.locals.magnolia = magnoliaInfo;
        /* Execute */
        await offersController.index(req, res);
        const {
          channelkey, sessionkey, customerkey, page,
        } = req.headers;
        const isPage = req.headers.ispage === 'false';
        const { sortBy, offerFacet } = req.query;
        const params = {
          channelkey, sessionkey, customerkey, isPage, sortBy, page, offerFacet,
        };
        /* Verify */
        expect(offersService.index).toHaveBeenCalledTimes(1);
        expect(offersService.index).toHaveBeenNthCalledWith(
          1,
          market,
          params,
          magnoliaInfo,
        );
      });
    });
    describe('detail()', () => {
      test('calls product with request parameters', async () => {
        /* Prepare */
        (offersService.detail as Mock).mockReturnValueOnce({ data: 'productList' });
        res.locals.magnolia = magnoliaInfo;

        /* Execute */
        await offersController.detail(req, res);
        const { channelkey, customerkey, sessionkey } = req.headers;
        const isPage = req.headers.ispage === 'true';
        const queryPrams = {
          windowFirst: req.query.windowFirst,
          windowLast: req.query.windowLast,
          selectedCategory: req.query.selectedCategory,
          sortBy: req.query.sortBy,
          windowFirstRecommendations: req.query.windowFirstRecommendations,
          windowLastRecommendations: req.query.windowLastRecommendations,
          maxFacets: req.query.maxFacets,
          rootCategory: req.query.rootCategory,
          maxProducts: req.query.maxProducts,
          depth: req.query.depth,
          filter: req.query.filter,
          page: req.query.page,
          channelkey,
          facets: req.query.facets,
          isPage,
          customerKey: customerkey,
          sessionKey: sessionkey,
        };

        /* Verify */
        expect(offersService.detail).toHaveBeenCalledTimes(1);
        expect(offersService.detail).toHaveBeenNthCalledWith(
          1,
          market,
          queryPrams,
          magnoliaInfo,
        );
      });
    });
  });
});
