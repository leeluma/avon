import { Request, Response } from 'express';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubAnonymousFlowResponseDto,
} from '../__stubs__';
import { DefaultController } from '../../src/controllers';
import { DefaultService } from '../../src/services';

import Mock = jest.Mock;
import { AnonymousFlowResponseDto } from '../../src/dtos';
// eslint-disable-next-line import/order
import faker from '@faker-js/faker';

describe('DefaultController', () => {
  /* System Under Test */
  let defaultController: DefaultController;

  /* Dependencies */
  let defaultService: DefaultService;
  let market: MarketInfo;

  /* Stubs */
  let request: Request;
  let response: Response;

  beforeEach(() => {
    market = stubMarket();

    /* Stubs */
    request = stubExpressReq();
    response = stubExpressRes(market);

    /* Dependencies */
    defaultService = {

    } as any;

    /* SUT */
    defaultController = new DefaultController({ defaultService });
  });

  describe('Default controller', () => {
    describe('createAnonymousSession()', () => {
      let anonymousFlowResponseDto: AnonymousFlowResponseDto;
      beforeEach(() => {
        defaultService.createAnonymousSession = jest.fn();
        anonymousFlowResponseDto = stubAnonymousFlowResponseDto();
      });

      test('forward request payload to createAnonymousSession service', async () => {
        await defaultController.createAnonymousSession(request, response);
        expect(defaultService.createAnonymousSession).toHaveBeenCalledTimes(1);
        expect(defaultService.createAnonymousSession).toHaveBeenNthCalledWith(
          1,
          market,
        );
      });

      test('return createAnonymousSession Response from Service', async () => {
        (defaultService.createAnonymousSession as Mock).mockReturnValueOnce(anonymousFlowResponseDto);
        const resultData = await defaultController.createAnonymousSession(request, response);
        expect(resultData.statusCode).toEqual(200);
      });
    });

    describe('refreshToken()', () => {
      test('reads request parameters', async () => {
      /* Prepare */
        const refreshtoken = faker.datatype.string();

        request.headers = { refreshtoken };
        (defaultService.refreshToken as Mock) = jest.fn();

        /* Execute */
        await defaultController.refreshToken(request, response);

        /* Verify */
        expect(defaultService.refreshToken).toHaveBeenCalledTimes(1);
        expect(defaultService.refreshToken).toHaveBeenNthCalledWith(
          1,
          market,
          refreshtoken,
        );
      });
    });
  });
});
