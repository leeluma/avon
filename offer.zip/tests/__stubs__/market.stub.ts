import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';

export const stubMarket = (
  config: Partial<MarketInfo> = {},
): MarketInfo => {
  const store = faker.random.word();
  const locale = faker.random.locale();
  const country = faker.address.countryCode();

  return {
    country,
    locale,
    localeAndCountry: `${locale}-${country}`,
    store,
    storeAndLocaleAndCountry: `${store}_${locale}-${country}`,
    ...config,
  };
};
