import faker from '@faker-js/faker';
import { ApiError, CtClient } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubCtCustomerClient, stubAnonymousFlowResponseDto,
} from '../__stubs__';
import Mock = jest.Mock;
import { DefaultDao } from '../../src/daos';

describe('DefaultDao', () => {
  let defaultDao: DefaultDao;
  let ctClient: CtClient;
  let market: MarketInfo;
  let execute: Mock;
  let post: Mock;
  let anonymousFlow: Mock;
  let passwordToken: Mock;
  let refreshTokenFlow: Mock;

  beforeEach(() => {
    market = stubMarket();
    execute = jest.fn();
    post = jest.fn().mockReturnValueOnce({ execute });
    anonymousFlow = jest.fn();
    refreshTokenFlow = jest.fn();
    passwordToken = jest.fn().mockReturnValueOnce({ post });
    ctClient = stubCtCustomerClient(market.country, {
      anonymousFlow,
      refreshTokenFlow,
    });

    defaultDao = new DefaultDao({ ctClient });
  });

  describe('createAnonymousSession()', () => {
    const anonymousId = faker.datatype.uuid();
    test('queries ctClient with anonymousId', async () => {
      /* Execute */
      await defaultDao.createAnonymousSession(market, anonymousId);

      /* Verify */
      expect(anonymousFlow).toHaveBeenCalledTimes(1);
      expect(anonymousFlow).toHaveBeenNthCalledWith(
        1,
        anonymousId,
      );
    });

    test('returns response from CT', async () => {
      /* Execute */
      const anonymousFlowResDto = stubAnonymousFlowResponseDto();
      anonymousFlow.mockReturnValueOnce(anonymousFlowResDto);

      const response = await defaultDao.createAnonymousSession(market, anonymousId);

      /* Verify */
      expect(response).toBe(anonymousFlowResDto);
    });

    test('forwards CT errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.uuid());
      anonymousFlow.mockRejectedValueOnce(err);

      /* Execute */
      const createAnonymousSession = () => defaultDao.createAnonymousSession(market, anonymousId);

      /* Verify */
      await expect(createAnonymousSession).rejects.toThrow(err);
    });

    test('re-throws non-500  ctClient errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 500,
        status: {
          statusCode: 500,
          msg: faker.datatype.string(),
          timestamp: faker.datatype.datetime(),
        },
        errors: [
          {
            msg: faker.datatype.string(),
          },
        ],
      };

      anonymousFlow.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => defaultDao.createAnonymousSession(market, anonymousId));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  describe('refreshToken()', () => {
    const params = faker.datatype.string();
    test('queries ctClient with refreshToken', async () => {
      await defaultDao.refreshToken(market, params);
      /* Verify */
      expect(refreshTokenFlow).toHaveBeenCalledTimes(1);
      expect(refreshTokenFlow).toHaveBeenNthCalledWith(
        1,
        params,
      );
    });

    test('returns response from CT', async () => {
      /* Execute */
      refreshTokenFlow.mockReturnValueOnce({ access_token: faker.datatype.string() });

      const response = await defaultDao.refreshToken(market, params);

      /* Verify */
      expect(response).toBeTruthy();
    });

    test('returns undefined if CtClient throws 404', async () => {
      /* Prepare */
      const err = { statusCode: 404, errors: 'Not found' };
      refreshTokenFlow.mockRejectedValueOnce(err);

      /* Execute */
      const call = () => defaultDao.refreshToken(market, params);

      /* Verify */
      await expect(call).rejects.toThrow(
        new ApiError(err.statusCode, err.errors),
      );
    });

    test('forwards CT errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.string());
      refreshTokenFlow.mockRejectedValueOnce(err);

      /* Execute */
      const refreshToken = () => defaultDao.refreshToken(market, params);

      /* Verify */
      await expect(refreshToken).rejects.toThrow(err);
    });
    test('re-throws non-500  ctClient errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 500,
      };

      refreshTokenFlow.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => defaultDao.refreshToken(market, params));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });
});
