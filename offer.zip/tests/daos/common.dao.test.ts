import axios from 'axios';
import faker from '@faker-js/faker';
import Mock = jest.Mock;
import { CommonDao } from '../../src/daos';

jest.mock('axios');

describe('CommonDao', () => {
  let commonDao: CommonDao;
  let offerPageUrl: string;

  beforeEach(() => {
    commonDao = {} as any;
    offerPageUrl = faker.internet.url();
  });

  describe('getResult()', () => {
    beforeEach(() => {
      commonDao = new CommonDao();
    });

    test('mocking axios', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce({});
      /* Execute */
      await (commonDao).getResult(offerPageUrl);
      /* Verify */
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch offer from magnolia', async () => {
      /* Prepare */
      const err = {
        stack: 'some error',
      };
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (commonDao).getResult(offerPageUrl));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch offer , because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
});
