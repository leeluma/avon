import { Router } from 'express';
import { OffersRouter } from '../../src/routers';
import { OffersController } from '../../src/controllers';
import { offerValidator, validateCategory } from '../../src/validators';
import { magnoliaUrlMiddleware, validateRequestSchema } from '../../src/middlewares';

describe('offerRouter', () => {
  let offersController: OffersController;
  let offersRouter: OffersRouter;
  let mockRouter: Router;

  beforeEach(() => {
    offersController = {
      index: jest.fn(),
      detail: jest.fn(),
    } as any;

    mockRouter = {
      get: jest.fn(() => mockRouter),
    } as any;

    offersRouter = new OffersRouter({
      offersController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter() for offer', () => {
    test('returns the express router', () => {
      const response = offersRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      offersRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(2);
    });

    test('configures the GET / route', () => {
      offersRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/',
        offerValidator,
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
    test('configures the GET /detail route', () => {
      offersRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        2,
        '/detail',
        validateCategory,
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
  });
});
