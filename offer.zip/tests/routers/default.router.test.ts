import { Router } from 'express';
import { DefaultRouter } from '../../src/routers';
import { DefaultController } from '../../src/controllers';
import { validateRequestSchema } from '../../src/middlewares';
import { validateRefreshToken } from '../../src/validators';

describe('defaultRouter', () => {
  let defaultController: DefaultController;
  let defaultRouter: DefaultRouter;
  let mockRouter: Router;

  beforeEach(() => {
    defaultController = {
      createAnonymousSession: jest.fn(),
      refreshToken: jest.fn(),
    } as any;

    mockRouter = {
      post: jest.fn(() => mockRouter),
    } as any;

    defaultRouter = new DefaultRouter({
      defaultController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter() for Default', () => {
    test('returns the express router', () => {
      const response = defaultRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      defaultRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenCalledTimes(2);
    });
    test('configures the POST /adding-to-cart route', () => {
      defaultRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        1,
        '/anonymous',
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the POST /refresh-token route', () => {
      defaultRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        2,
        '/refresh-token',
        validateRefreshToken,
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
