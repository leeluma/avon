import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { NotificationsDao } from '../../src/daos';
import { NotificationsService } from '../../src/services';
import Mock = jest.Mock;
import { stubMarket } from '../__stubs__';

describe('NotificationService', () => {
  /* System Under Test */
  let notificationsService: NotificationsService;

  /* Dependencies */
  let notificationsDao: NotificationsDao;
  let market: MarketInfo;
  let params;

  beforeEach(() => {
    market = stubMarket();
    notificationsDao = {
      esaleNotifications: jest.fn(),
      cartNotifications: jest.fn(),
    } as any;
    notificationsService = new NotificationsService({ notificationsDao });
    params = {
      sessionKey: faker.datatype.uuid(),
      customerKey: faker.datatype.uuid(),
      ticket: faker.datatype.uuid(),
      productKey: undefined,
      variantKey: undefined,
    };
  });

  describe('product()', () => {
    test('return true if notification updated', async () => {
      /* Prepare */
      (notificationsDao.esaleNotifications as Mock).mockReturnValueOnce(true);

      /* Execute */
      await notificationsService.product(market, params);

      /* Verify */
      expect(notificationsDao.esaleNotifications).toHaveBeenCalledTimes(1);
    });
  });

  describe('addToCart()', () => {
    test('return true if notification updated in addding to cart', async () => {
      /* Prepare */
      (notificationsDao.cartNotifications as Mock).mockReturnValueOnce(true);

      /* Execute */
      await notificationsService.addToCart(market, params);

      /* Verify */
      expect(notificationsDao.cartNotifications).toHaveBeenCalledTimes(1);
    });
  });
});
