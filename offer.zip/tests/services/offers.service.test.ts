import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { CommonDao } from '../../src/daos';
import {
  stubExpressReq, stubExpressRes, stubMagnoliaInfo, stubMarket,
} from '../__stubs__';
import { OffersService } from '../../src/services';
import Mock = jest.Mock;
import { MagnoliaInfo } from '../../src/dtos';
import { Common } from '../../src/lib';

describe('OfferServices', () => {
  /* System Under Test */

  /* Dependencies */
  let common: Common;
  let commonDao: CommonDao;
  let apptusEsalesMarket: string;
  let market: MarketInfo;
  let magnoliaInfo: MagnoliaInfo;
  let offersService: OffersService;
  let apptusBaseUrl: string;
  let apptusClusterId: string;
  /* Stubs */
  let req: Request;
  let res: Response;
  let convertUnderScoreToCamelCase: Mock;
  let request: Request;
  let response: Response;
  let magnoliaBasePath: string;

  beforeEach(() => {
    market = stubMarket();
    /* Stubs */
    request = stubExpressReq();
    response = stubExpressRes(market);
    magnoliaInfo = stubMagnoliaInfo();
    commonDao = {} as any;
    common = {} as any;
    apptusBaseUrl = faker.internet.url();
    apptusClusterId = faker.datatype.string();

    /* SUT */
    offersService = new OffersService({
      common, commonDao, apptusBaseUrl, apptusClusterId, apptusEsalesMarket, magnoliaBasePath,
    });
  });

  describe('index()', () => {
    beforeEach(() => {
      commonDao.getResult = jest.fn();
      common.queryString = jest.fn();
      request.headers.channelKey = 'DC-RO';
      request.headers.sessionkey = faker.datatype.string();
      request.headers.customerkey = faker.datatype.string();
      request.headers.page = '1';
      request.query.sortBy = faker.datatype.string();
      common.convertUnderScoreToCamelCase = jest.fn();
    });

    test('reads the offer data from common dao case page=1', async () => {
      const {
        channelkey, sessionkey, customerkey, page,
      } = request.headers;
      const isPage = request.headers.ispage === 'false';
      const { sortBy } = request.query;
      const params = {
        channelkey, sessionkey, customerkey, isPage, sortBy, page,
      };
      /* Prepare */
      (commonDao.getResult as Mock).mockReturnValueOnce({

        categoryNavigation: [
          {
            categoryTree: {
              subcategories: [
                {
                  attributes: {

                    offer_facet: [
                      'PRODUSE PENTRU CASĂ',
                      'Advance Techniques',
                    ],
                    type: [
                      'Offer',
                    ],
                  },
                },

              ],
            },
          },
        ],

      });
      (commonDao.getResult as Mock).mockReturnValueOnce({
        offersPerPage: 2,
        'mgnl:template': 'spa-lm:pages/offers',
      });

      /* Execute */
      await offersService.index(market, params, magnoliaInfo);

      /* Verify */
      expect(commonDao.getResult).toHaveBeenCalledTimes(4);
    });
    test('reads the offer data from common dao case page=1, isPage=true and offerFacet', async () => {
      request.query.offerFacet = 'Offer|PRODUSE PENTRU CASĂ';
      const {
        channelkey, sessionkey, customerkey, page,
      } = request.headers;
      const isPage = true;
      const ispreview = request.headers.ispreview === 'true';
      const { sortBy, offerFacet } = request.query;
      const params = {
        channelkey, sessionkey, customerkey, isPage, sortBy, page, offerFacet, ispreview,
      };
      /* Prepare */
      (commonDao.getResult as Mock).mockReturnValueOnce({

        categoryNavigation: [
          {
            categoryTree: {
              subcategories: [
                {
                  attributes: {

                    offer_facet: [
                      'PRODUSE PENTRU CASĂ',
                      'Advance Techniques',
                    ],
                    type: [
                      'Offer',
                    ],
                  },
                },

              ],
            },
          },
        ],

      });
      (commonDao.getResult as Mock).mockReturnValueOnce({
        offersPerPage: 2,
        'mgnl:template': 'spa-lm:pages/offers',
      });

      /* Execute */
      await offersService.index(market, params, magnoliaInfo);

      /* Verify */
      expect(commonDao.getResult).toHaveBeenCalledTimes(3);
    });
    test('reads isPage=true, ispreview=false and marketpath =a', async () => {
      request.query.offerFacet = 'Offer|PRODUSE PENTRU CASĂ';
      const {
        channelkey, sessionkey, customerkey, page,
      } = request.headers;
      const isPage = true;
      const ispreview = request.headers.ispreview === 'false';
      const { sortBy, offerFacet } = request.query;
      const params = {
        channelkey, sessionkey, customerkey, isPage, sortBy, page, offerFacet, ispreview,
      };
      /* Prepare */
      (commonDao.getResult as Mock).mockReturnValueOnce({

        categoryNavigation: [
          {
            categoryTree: {
              subcategories: [
                {
                  attributes: {

                    offer_facet: [
                      'PRODUSE PENTRU CASĂ',
                      'Advance Techniques',
                    ],
                    type: [
                      'Offer',
                    ],
                  },
                },

              ],
            },
          },
        ],

      });
      (commonDao.getResult as Mock).mockReturnValueOnce({
        offersPerPage: 2,
        'mgnl:template': 'spa-lm:pages/offers',
      });
      magnoliaInfo.ispreview = false;
      magnoliaInfo.marketPath = 'a';

      /* Execute */
      await offersService.index(market, params, magnoliaInfo);

      /* Verify */
      expect(commonDao.getResult).toHaveBeenCalledTimes(3);
    });
    test('reads isPage=true, ispreview=true and marketpath =a', async () => {
      request.query.offerFacet = 'Offer|PRODUSE PENTRU CASĂ';
      const {
        channelkey, sessionkey, customerkey, page,
      } = request.headers;
      const isPage = true;
      const ispreview = request.headers.ispreview === 'true';
      const { sortBy, offerFacet } = request.query;
      const params = {
        channelkey, sessionkey, customerkey, isPage, sortBy, page, offerFacet, ispreview,
      };
      /* Prepare */
      (commonDao.getResult as Mock).mockReturnValueOnce({

        categoryNavigation: [
          {
            categoryTree: {
              subcategories: [
                {
                  attributes: {

                    offer_facet: [
                      'PRODUSE PENTRU CASĂ',
                      'Advance Techniques',
                    ],
                    type: [
                      'Offer',
                    ],
                  },
                },

              ],
            },
          },
        ],

      });
      (commonDao.getResult as Mock).mockReturnValueOnce({
        offersPerPage: 2,
        'mgnl:template': 'spa-lm:pages/offers',
      });
      magnoliaInfo.ispreview = true;
      magnoliaInfo.marketPath = 'a';

      /* Execute */
      await offersService.index(market, params, magnoliaInfo);

      /* Verify */
      expect(commonDao.getResult).toHaveBeenCalledTimes(3);
    });
    test('reads the offer data from common dao case page=1, isPage=true and offerPerPage=undefined', async () => {
      request.query.offerFacet = 'Offer|PRODUSE PENTRU CASĂ';
      const {
        channelkey, sessionkey, customerkey,
      } = request.headers;
      const page = undefined;
      const isPage = true;
      const ispreview = request.headers.ispreview === 'true';
      const { sortBy, offerFacet } = request.query;
      const params = {
        channelkey, sessionkey, customerkey, isPage, sortBy, page, offerFacet, ispreview,
      };
      /* Prepare */
      (commonDao.getResult as Mock).mockReturnValueOnce({

        categoryNavigation: [
          {
            categoryTree: {
              subcategories: [
                {
                  attributes: {

                    offer_facet: [
                      'PRODUSE PENTRU CASĂ',
                      'Advance Techniques',
                    ],
                    type: [
                      'Offer',
                    ],
                  },
                },

              ],
            },
          },
        ],

      });
      (commonDao.getResult as Mock).mockReturnValueOnce({
        offersPerPage: undefined,
        'mgnl:template': 'spa-lm:pages/offers',
      });

      /* Execute */
      await offersService.index(market, params, magnoliaInfo);

      /* Verify */
      expect(commonDao.getResult).toHaveBeenCalledTimes(3);
    });
  });
  describe('details()', () => {
    beforeEach(() => {
      commonDao.getResult = jest.fn();
      common.queryString = jest.fn();
      request.headers.channelKey = 'DC-RO';
      request.headers.sessionkey = faker.datatype.string();
      request.headers.customerkey = faker.datatype.string();
      request.headers.page = '1';
      request.query.sortBy = faker.datatype.string();
      common.convertUnderScoreToCamelCase = jest.fn();
      common.updateApptusResponse = jest.fn();
    });
    test('reads the categories from offerDao', async () => {
      const {
        channelkey, sessionkey, customerkey, page,
      } = request.headers;
      const isPage = request.headers.ispage === 'true';
      const { sortBy } = request.query;
      const queryParams = {
        channelkey, sessionkey, customerkey, isPage, sortBy, page,
      };
      /* Prepare */
      (commonDao.getResult as Mock).mockReturnValueOnce({
        offersPerPage: 2,
        'mgnl:template': 'spa-lm:pages/offers-details',

      });
      (commonDao.getResult as Mock).mockReturnValueOnce({

        '@name': 'settings',
        '@path': '/ro/settings',
        '@id': 'dfee041c-6a0b-4e0e-b3f1-b6b88e8befb4',
        '@nodeType': 'mgnl:content',
        text: '9878422',
        name: 'settings',
        warehouseSettings: {
          '@name': 'warehouseSettings',
          '@path': '/ro/settings/warehouseSettings',
          '@id': 'ad6c21e6-d8d3-46c8-8435-8c5cf45c7f0c',
          '@nodeType': 'mgnl:contentNode',
          defaultWarehouse: 'DC-RO',
          isSingleWarehouse: 'true',
          '@nodes': [],
        },
        priceFormat: [Object],
        thirdPartySettings: [Object],
        socialMediaSettings: [Object],
        fieldValidators: [Object],
        addressSettings: [Object],
        buttonTexts: [Object],
        linkTexts: [Object],
        generalSettings: [Object],
        '@nodes': [Array],

      });
      /* Execute */
      (commonDao.getResult as Mock).mockReturnValueOnce({
        productListWithCount: [{
          name: 'product-list',
          products: [
            {
              attributes: {
                inStock: false,
              },
              variants: [
                {
                  attributes: {
                    availability: [

                      // eslint-disable-next-line max-len
                      '{"DC-RO":{"in_stock":true,"available_quantity":5026,"channel_id":"9653f17c-352f-4fe9-a5b8-8351ad861896"}}',

                    ],
                  },
                },
              ],
            },
          ],
          facets: [
            {
              name: 'facets',
              facetList: [
                {
                  attribute: 'non_rep_sale_price',
                  isRange: true,
                  range: {
                    min: '24.2',
                    max: '27.5',
                    minSelected: '24.2',
                    maxSelected: '27.5',
                  },
                  ccy: 'RON',
                  currencyPlacement: 'before',
                },
              ],
            },
          ],

        }],
      });
      await offersService.detail(market, queryParams, magnoliaInfo);
      /* Verify */
      expect(commonDao.getResult).toHaveBeenCalledTimes(4);
    });
    test('reads the categories from offerDao if isPage=true', async () => {
      const {
        channelkey, sessionkey, customerkey, page,
      } = request.headers;
      const isPage = true;
      const { sortBy } = request.query;
      const queryParams = {
        channelkey, sessionkey, customerkey, isPage, sortBy, page,
      };
      /* Prepare */
      (commonDao.getResult as Mock).mockReturnValueOnce({
        offersPerPage: 2,
        'mgnl:template': 'spa-lm:pages/offers-details',

      });
      (commonDao.getResult as Mock).mockReturnValueOnce({
        results: [
          {
            '@name': 'settings',
            '@path': '/ro/settings',
            '@id': 'dfee041c-6a0b-4e0e-b3f1-b6b88e8befb4',
            '@nodeType': 'mgnl:content',
            text: '9878422',
            name: 'settings',
            warehouseSettings: {
              '@name': 'warehouseSettings',
              '@path': '/ro/settings/warehouseSettings',
              '@id': 'ad6c21e6-d8d3-46c8-8435-8c5cf45c7f0c',
              '@nodeType': 'mgnl:contentNode',
              defaultWarehouse: 'DC-RO',
              isSingleWarehouse: 'true',
              '@nodes': [],
            },
            priceFormat: [Object],
            thirdPartySettings: [Object],
            socialMediaSettings: [Object],
            fieldValidators: [Object],
            addressSettings: [Object],
            buttonTexts: [Object],
            linkTexts: [Object],
            generalSettings: [Object],
            '@nodes': [Array],
          },
        ],
      });
      /* Execute */
      (commonDao.getResult as Mock).mockReturnValueOnce({
        productListWithCount: [{
          name: 'product-list',
          products: [
            {
              attributes: {
                inStock: false,
              },
              variants: [
                {
                  attributes: {
                    availability: [

                      // eslint-disable-next-line max-len
                      '{"DC-RO":{"in_stock":true,"available_quantity":5026,"channel_id":"9653f17c-352f-4fe9-a5b8-8351ad861896"}}',

                    ],
                  },
                },
              ],
            },
          ],

        }],
        facets: [
          {
            name: 'facets',
            facetList: [
              {
                attribute: 'non_rep_sale_price',
                isRange: true,
                range: {
                  min: '24.2',
                  max: '27.5',
                  minSelected: '24.2',
                  maxSelected: '27.5',
                },
                ccy: 'RON',
                currencyPlacement: 'before',
              },
            ],
          },
        ],
      });
      await offersService.detail(market, queryParams, magnoliaInfo);
      /* Verify */
      expect(commonDao.getResult).toHaveBeenCalledTimes(3);
    });
    test('reads the categories from productsDao when isPage=true', async () => {
      /* Prepare */
      const {
        channelkey, sessionkey, customerkey, page,
      } = request.headers;
      const isPage = request.headers.ispage === 'false';
      const { sortBy } = request.query;
      const queryPrams = {
        channelkey, sessionkey, customerkey, isPage, sortBy, page,
      };

      (commonDao.getResult as Mock).mockReturnValueOnce({
        offersPerPage: 2,
        'mgnl:template': 'spa-lm:pages/offers-details',
      });
      (commonDao.getResult as Mock).mockReturnValueOnce({
        results: [
          {
            '@name': 'settings',
            '@path': '/ro/settings',
            '@id': 'dfee041c-6a0b-4e0e-b3f1-b6b88e8befb4',
            '@nodeType': 'mgnl:content',
            text: '9878422',
            name: 'settings',
            warehouseSettings: {
              '@name': 'warehouseSettings',
              '@path': '/ro/settings/warehouseSettings',
              '@id': 'ad6c21e6-d8d3-46c8-8435-8c5cf45c7f0c',
              '@nodeType': 'mgnl:contentNode',
              defaultWarehouse: 'DC-RO',
              isSingleWarehouse: 'true',
              '@nodes': [],
            },
            priceFormat: [Object],
            thirdPartySettings: [Object],
            socialMediaSettings: [Object],
            fieldValidators: [Object],
            addressSettings: [Object],
            buttonTexts: [Object],
            linkTexts: [Object],
            generalSettings: [Object],
            '@nodes': [Array],
          },
        ],
      });
      /* Execute */
      (commonDao.getResult as Mock).mockReturnValueOnce({
        productListWithCount: [{
          name: 'product-list',
          products: [
            {
              attributes: {
                inStock: false,
              },
              variants: [
                {
                  attributes: {
                    availability: [

                      // eslint-disable-next-line max-len
                      '{"DC-RO":{"in_stock":true,"available_quantity":5026,"channel_id":"9653f17c-352f-4fe9-a5b8-8351ad861896"}}',

                    ],
                  },
                },
              ],
            },
          ],

        }],
        facets: [
          {
            name: 'facets',
            facetList: [
              {
                attribute: 'non_rep_sale_price',
                isRange: true,
                range: {
                  min: '24.2',
                  max: '27.5',
                  minSelected: '24.2',
                  maxSelected: '27.5',
                },
                ccy: 'RON',
                currencyPlacement: 'before',
              },
            ],
          },
        ],
      });
      await offersService.detail(market, queryPrams, magnoliaInfo);
      /* Verify */
      expect(commonDao.getResult).toHaveBeenCalledTimes(4);
    });
    test('reads the categories from productsDao when isPage=true and ispreview=false', async () => {
      const {
        channelkey, sessionkey, customerkey, page,
      } = request.headers;
      const isPage = request.headers.ispage === 'true';
      const { sortBy } = request.query;
      const queryPrams = {
        channelkey, sessionkey, customerkey, isPage, sortBy, page,
      };
      magnoliaInfo.ispreview = false;
      magnoliaInfo.marketPath = 'a';

      (commonDao.getResult as Mock).mockReturnValueOnce({
        offersPerPage: 2,
        'mgnl:template': 'spa-lm:pages/offers-details',
      });
      (commonDao.getResult as Mock).mockReturnValueOnce({
        results: [
          {
            '@name': 'settings',
            '@path': '/ro/settings',
            '@id': 'dfee041c-6a0b-4e0e-b3f1-b6b88e8befb4',
            '@nodeType': 'mgnl:content',
            text: '9878422',
            name: 'settings',
            warehouseSettings: {
              '@name': 'warehouseSettings',
              '@path': '/ro/settings/warehouseSettings',
              '@id': 'ad6c21e6-d8d3-46c8-8435-8c5cf45c7f0c',
              '@nodeType': 'mgnl:contentNode',
              defaultWarehouse: 'DC-RO',
              isSingleWarehouse: 'true',
              '@nodes': [],
            },
            priceFormat: [Object],
            thirdPartySettings: [Object],
            socialMediaSettings: [Object],
            fieldValidators: [Object],
            addressSettings: [Object],
            buttonTexts: [Object],
            linkTexts: [Object],
            generalSettings: [Object],
            '@nodes': [Array],
          },
        ],
      });
      /* Execute */
      (commonDao.getResult as Mock).mockReturnValueOnce({
        productListWithCount: [{
          name: 'product-list',
          products: [
            {
              attributes: {
                inStock: false,
              },
              variants: [
                {
                  attributes: {
                    availability: [

                      // eslint-disable-next-line max-len
                      '{"DC-RO":{"in_stock":true,"available_quantity":5026,"channel_id":"9653f17c-352f-4fe9-a5b8-8351ad861896"}}',

                    ],
                  },
                },
              ],
            },
          ],

        }],
        facets: [
          {
            name: 'facets',
            facetList: [
              {
                attribute: 'non_rep_sale_price',
                isRange: true,
                range: {
                  min: '24.2',
                  max: '27.5',
                  minSelected: '24.2',
                  maxSelected: '27.5',
                },
                ccy: 'RON',
                currencyPlacement: 'before',
              },
            ],
          },
        ],
      });
      await offersService.detail(market, queryPrams, magnoliaInfo);
      /* Verify */
      expect(commonDao.getResult).toHaveBeenCalledTimes(3);
    });
    test('reads the categories from Dao when isPage=true and ispreview=false, channelKey=undefined', async () => {
      const {
        sessionkey, customerkey, page,
      } = request.headers;
      const isPage = request.headers.ispage === 'true';
      const { sortBy } = request.query;
      const channelkey = undefined;
      const queryPrams = {
        channelkey, sessionkey, customerkey, isPage, sortBy, page,
      };
      magnoliaInfo.ispreview = false;
      magnoliaInfo.marketPath = 'a';

      (commonDao.getResult as Mock).mockReturnValueOnce({
        offersPerPage: 2,
        'mgnl:template': 'spa-lm:pages/offers-details',
      });
      (commonDao.getResult as Mock).mockReturnValueOnce({
        results: [
          {
            '@name': 'settings',
            '@path': '/ro/settings',
            '@id': 'dfee041c-6a0b-4e0e-b3f1-b6b88e8befb4',
            '@nodeType': 'mgnl:content',
            text: '9878422',
            name: 'settings',
            warehouseSettings: {
              '@name': 'warehouseSettings',
              '@path': '/ro/settings/warehouseSettings',
              '@id': 'ad6c21e6-d8d3-46c8-8435-8c5cf45c7f0c',
              '@nodeType': 'mgnl:contentNode',
              defaultWarehouse: 'DC-RO',
              isSingleWarehouse: 'true',
              '@nodes': [],
            },
            priceFormat: [Object],
            thirdPartySettings: [Object],
            socialMediaSettings: [Object],
            fieldValidators: [Object],
            addressSettings: [Object],
            buttonTexts: [Object],
            linkTexts: [Object],
            generalSettings: [Object],
            '@nodes': [Array],
          },
        ],
      });
      /* Execute */
      (commonDao.getResult as Mock).mockReturnValueOnce({
        productListWithCount: [{
          name: 'product-list',
          products: [
            {
              attributes: {
                inStock: false,
              },
              variants: [
                {
                  attributes: {
                    availability: [

                      // eslint-disable-next-line max-len
                      '{"DC":{"in_stock":true,"available_quantity":5026,"channel_id":"9653f17c-352f-4fe9-a5b8-8351ad861896"}}',

                    ],
                  },
                },
              ],
            },
          ],

        }],
        facets: [
          {
            name: 'facets',
            facetList: [
              {
                attribute: 'non_rep_sale_price',
                isRange: true,
                range: {
                  min: '24.2',
                  max: '27.5',
                  minSelected: '24.2',
                  maxSelected: '27.5',
                },
                ccy: 'RON',
                currencyPlacement: 'before',
              },
            ],
          },
        ],
      });
      await offersService.detail(market, queryPrams, magnoliaInfo);
      /* Verify */
      expect(commonDao.getResult).toHaveBeenCalledTimes(3);
    });
    test('reads the categories from Dao when page=undefined and ispreview=false, channelKey=undefined', async () => {
      const {
        sessionkey, customerkey,
      } = request.headers;
      const isPage = request.headers.ispage === 'true';
      const { sortBy } = request.query;
      const channelkey = undefined;
      const page = undefined;
      const queryPrams = {
        channelkey, sessionkey, customerkey, isPage, sortBy, page,
      };
      magnoliaInfo.ispreview = false;
      magnoliaInfo.marketPath = 'a';

      (commonDao.getResult as Mock).mockReturnValueOnce({
        offersPerPage: 2,
        'mgnl:template': 'spa-lm:pages/offers-details',
      });
      (commonDao.getResult as Mock).mockReturnValueOnce({
        results: [
          {
            '@name': 'settings',
            '@path': '/ro/settings',
            '@id': 'dfee041c-6a0b-4e0e-b3f1-b6b88e8befb4',
            '@nodeType': 'mgnl:content',
            text: '9878422',
            name: 'settings',
            warehouseSettings: {
              '@name': 'warehouseSettings',
              '@path': '/ro/settings/warehouseSettings',
              '@id': 'ad6c21e6-d8d3-46c8-8435-8c5cf45c7f0c',
              '@nodeType': 'mgnl:contentNode',
              defaultWarehouse: 'DC-RO',
              isSingleWarehouse: 'true',
              '@nodes': [],
            },
            priceFormat: [Object],
            thirdPartySettings: [Object],
            socialMediaSettings: [Object],
            fieldValidators: [Object],
            addressSettings: [Object],
            buttonTexts: [Object],
            linkTexts: [Object],
            generalSettings: [Object],
            '@nodes': [Array],
          },
        ],
      });
      /* Execute */
      (commonDao.getResult as Mock).mockReturnValueOnce({
        productListWithCount: [{
          name: 'product-list',
          products: [
            {
              attributes: {
                inStock: false,
              },
              variants: [
                {
                  attributes: {
                    availability: [

                      // eslint-disable-next-line max-len
                      '{"DC":{"in_stock":true,"available_quantity":5026,"channel_id":"9653f17c-352f-4fe9-a5b8-8351ad861896"}}',

                    ],
                  },
                },
              ],
            },
          ],

        }],
        facets: [
          {
            name: 'facets',
            facetList: [
              {
                attribute: 'non_rep_sale_price',
                isRange: true,
                range: {
                  min: '24.2',
                  max: '27.5',
                  minSelected: '24.2',
                  maxSelected: '27.5',
                },
                ccy: 'RON',
                currencyPlacement: 'before',
              },
            ],
          },
        ],
      });
      await offersService.detail(market, queryPrams, magnoliaInfo);
      /* Verify */
      expect(commonDao.getResult).toHaveBeenCalledTimes(3);
    });
  });
});
