import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { DefaultDao } from '../../src/daos/default.dao';
import { DefaultService } from '../../src/services';
import {
  stubAnonymousFlowResponseDto,
  stubMarket,
} from '../__stubs__';
import {
  AnonymousFlowResponseDto,
} from '../../src/dtos';
import Mock = jest.Mock;

describe('NotificationService', () => {
  /* System Under Test */
  let defaultService: DefaultService;

  /* Dependencies */
  let defaultDao: DefaultDao;
  let market: MarketInfo;
  let params: string;
  beforeEach(() => {
    market = stubMarket();
    defaultDao = {
      createAnonymousSession: jest.fn(),
      refreshToken: jest.fn(),
    } as any;
    defaultService = new DefaultService({ defaultDao });
    params = faker.datatype.string();
  });

  describe('createAnonymousSession()', () => {
    let anonymousFlowResDto: AnonymousFlowResponseDto;

    beforeEach(() => {
      defaultDao.createAnonymousSession = jest.fn();
      anonymousFlowResDto = stubAnonymousFlowResponseDto();
    });

    test('reads the anonymous session data from defaultDao', async () => {
      /* Prepare */

      (defaultDao.createAnonymousSession as Mock).mockReturnValueOnce(anonymousFlowResDto);

      /* Execute */
      await defaultService.createAnonymousSession(market);

      /* Verify */
      expect(defaultDao.createAnonymousSession).toHaveBeenCalledTimes(1);
      expect(defaultDao.createAnonymousSession).toBeTruthy();
    });
  });

  describe('refreshToken()', () => {
    test('call refreshToken method', async () => {
    /* Prepare */
      (defaultDao.refreshToken as Mock)
        .mockReturnValueOnce({ access_token: faker.datatype.string() });

      /* Execute */
      await defaultService.refreshToken(market, params);

      /* Verify */
      expect(defaultDao.refreshToken).toHaveBeenCalledTimes(1);
      expect(defaultDao.refreshToken).toHaveBeenNthCalledWith(
        1,
        market,
        params,
      );
    });
  });
});
