## NOTE
to run offer API on Commerce Tool there will be offer category as root and all offer belongs to this category.
Offer category key's value will always 'offer'.

# leap-bff-offer

This service implements APIs for the offer mfe.

# Repo Owner

HCL

# Prerequisites

- None

# Installation

```shell
npm install
npm run build
```

Configure the `.env` file according to the sample below in this readme.

```shell
npm start
```

# Sample .env file

```
# Common config
npm_package_name=leap-bff-offer
npm_package_version=1.0.0
API_CONTEXT_PATH='offer'
API_VERSION=v1
API_PORT=3001
NODE_ENV=development
LOG_LEVEL=trace
CT_ACTIVE_MARKETS=["RO"]
CT_PROJECT_KEY_RO=avonshop-ct-ro-dev
CT_CLIENT_ID_RO=XXXXXXXXXXXXXXXXX
CT_CLIENT_SECRET_RO=XXXXXXXXXXXXX
CT_MAX_RETRIES=2
CT_RETRY_DELAY=300
CT_RETRY_MAX_DELAY=1000
CT_RETRY_ON_ABORT=true
CT_TIMEOUT=2000
CT_CONCURRENCY=20
CT_API_ENDPOINT=https://api.europe-west1.gcp.commercetools.com
CT_AUTH_ENDPOINT=https://auth.europe-west1.gcp.commercetools.com

APPTUS_CLUSTER_ID=XXXXXXXX
APPTUS_BASE_URL=https://{{CLUSTER_ID}}.api.esales.apptus.cloud/api/v2/
APPTUS_ESALES_MARKET=AVONSHOP_
NODE_TLS_REJECT_UNAUTHORIZED=0
MAGNOLIA_BASE_PATH=https://magnolia-author.leap-dev.aws.avon.com/
PREVIEW_MAGNOLIA_BASE_PATH=https://magnolia-author.leap-dev.aws.avon.com/
# Magnolia config
MAGNOLIA_BASE_PATH=https://magnolia-author.leap-dev.aws.avon.com/
```

## Development Checklist

1. Update Swagger specs
2. Update Postman collection
3. Write Unit Test cases
4. Run stryker mutation testing
5. Write required validation
6. Run npm audit and see no security issues
7. All eslint issue mitigated
8. Write jsdoc comments on each method, class, constant etc.
9. API should not take more than 1.5 second 
