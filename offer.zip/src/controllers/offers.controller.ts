import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { OffersService } from '../services';
import { JsonApiResponseEntity } from '../lib';
import { MarketInfo } from '../middlewares';
import { CommonResponse, MagnoliaInfo } from '../dtos';
import { ApptusRequest } from '../dtos/apptus-request.dto';

export interface OffersControllerConfig {
  offersService: OffersService;
}

/**
 * Service for managing Offers
 */
export class OffersController {
  private readonly offersService: OffersService;

  /**
   * Constructor for `OffersController` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: OffersControllerConfig) {
    this.offersService = config.offersService;
  }

  /**
   * returns magnolia offer config
   * @param request - Express request object
   * @param response - Express response object
   * @returns Offers
   */
  public async index(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<CommonResponse>> {
    const market = response.locals.market as MarketInfo;
    const magnolia = response.locals.magnolia as MagnoliaInfo;
    const { sortBy, offerFacet } = request.query;
    const {
      channelkey, sessionkey, customerkey, page,
    } = request.headers;

    const isPage: boolean = request.headers.ispage === 'false';
    const params = {
      channelkey, sessionkey, customerkey, isPage, sortBy, page, offerFacet,
    };
    const apptusResponse = await this.offersService.index(market, params, magnolia);

    return {
      statusCode: HttpStatusCodes.OK,
      body: apptusResponse,
    };
  }

  /**
   * Get offer details
   * @param request - Express request object
   * @param response - Express response object
   * @returns Categories if it was found
   */
  public async detail(
    request: Request,
    response: Response,
  ):Promise<JsonApiResponseEntity<CommonResponse>> {
    const {
      sessionkey,
      customerkey,
    } = request.headers;
    const market = response.locals.market as MarketInfo;
    const magnolia = response.locals.magnolia as MagnoliaInfo;
    const { channelkey } = request.headers;
    const isPage: boolean = request.headers.ispage === 'false';
    const {
      windowFirst,
      windowLast,
      selectedCategory,
      sortBy,
      windowFirstRecommendations,
      windowLastRecommendations,
      maxFacets,
      rootCategory,
      maxProducts,
      filter,
      depth,
      facets,
      page,
    }: ApptusRequest = request.query;

    const params = {
      windowFirst,
      windowLast,
      selectedCategory,
      sortBy,
      windowFirstRecommendations,
      windowLastRecommendations,
      maxFacets,
      rootCategory,
      maxProducts,
      filter,
      depth,
      facets,
      page,
      sessionKey: sessionkey,
      customerKey: customerkey,
      isPage,
      channelkey,

    };

    const apptusResponse = await this.offersService.detail(market, params, magnolia);
    return {
      statusCode: HttpStatusCodes.OK,
      body: apptusResponse,
    };
  }
}
