import {
  body, oneOf, header,
} from 'express-validator';

export const validateNotifications = [
  header('sessionkey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  header('customerkey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  oneOf([
    [
      body('productKey').notEmpty().withMessage('common.notEmpty'),
      body('variantKey').notEmpty().withMessage('common.notEmpty'),
    ],
    body('ticket').notEmpty().withMessage('common.notEmpty'),
  ]),
];
