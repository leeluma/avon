import {
  query, header,
} from 'express-validator';

export const offerValidator = [
  header('sessionkey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  header('customerkey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  query('page').optional().isInt().withMessage('common.integer'),
];

export const validateCategory = [
  header('sessionkey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  header('customerkey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  query('page').optional().isInt().withMessage('common.integer'),
  query('rootCategory').notEmpty().withMessage('common.notEmpty'),
  query('selectedCategory').optional().isString().withMessage('common.string'),
  query('filter').optional().isString().withMessage('common.string'),
  query('maxProducts').optional().isInt().withMessage('common.integer'),
  query('maxFacets').optional().isInt().withMessage('common.integer'),
  query('sortBy').optional().isString().withMessage('common.string'),
  query('windowFirstRecommendations').optional().isInt().withMessage('common.integer'),
  query('windowLastRecommendations').optional().isInt().withMessage('common.integer'),
  query('depth').optional().isInt().withMessage('common.integer'),
];
