import { param } from 'express-validator';

export const validateId = param('id').isUUID().withMessage('datatype.uuid');
