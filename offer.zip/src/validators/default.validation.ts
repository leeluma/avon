import {
  header,
} from 'express-validator';

export const validateRefreshToken = [
  header('refreshtoken').notEmpty().withMessage('common.notEmpty'),
];
