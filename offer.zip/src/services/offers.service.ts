import { CommonDao } from '../daos';
import { MarketInfo } from '../middlewares';
import {
  Common, PAGINATION, URI,
} from '../lib';
import { CommonResponse, MagnoliaInfo } from '../dtos';

import { config as configuration } from '../config';
import { MAGNOLIA_URI } from '../common/constant';

const country = '{{country}}';
const productListing = 'product-list';

const {
  apptusMaxFacets, apptusWindowFirstRecommendations,
  apptusWindowLastRecommendations, apptusMaxProducts,
} = configuration;

export interface OffersServiceConfig {
  common: Common;
  commonDao: CommonDao;
  apptusBaseUrl: string;
  apptusClusterId: string;
  apptusEsalesMarket: string;
  magnoliaBasePath: string;

}

/**
 * Service for managing Offers
 */
export class OffersService {
  private readonly common: Common;

  private readonly commonDao: CommonDao;

  private readonly apptusBaseUrl: string;

  private readonly apptusClusterId: string;

  private readonly apptusEsalesMarket: string;

  private readonly magnoliaBasePath: string;

  private readonly marketPath = 3;

  private readonly factes = 'facets';

  /**
   * Constructor for `OffersService` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: OffersServiceConfig) {
    this.common = config.common;
    this.commonDao = config.commonDao;
    this.apptusBaseUrl = config.apptusBaseUrl;
    this.apptusClusterId = config.apptusClusterId;
    this.apptusEsalesMarket = config.apptusEsalesMarket;
    this.magnoliaBasePath = config.magnoliaBasePath;
  }

  /**
   * Filter offer subcategory
   * @param apptusData
   */
  public offerPaginationData(subcategories, pageNo, offerPerPage) {
    const perPage = offerPerPage || PAGINATION.apptus.offerPerPage;
    const page = pageNo || PAGINATION.apptus.page;
    const startIndex = (page - 1) * perPage;
    const endIndex = page * perPage;

    return subcategories.splice(startIndex, endIndex);
  }

  /**
   * Filter offer subcategory based on facet
   * @param apptusData
   */
  public offerSubcategoryByFacet(subcategories, offerFacet) {
    const filteredData : CommonResponse = [];
    const facet = offerFacet.split('|');
    facet.forEach((value) => {
      const filter = subcategories.filter((data) => {
        return (data.attributes.offer_facet?.some((v) => {
          const vs = v.replace(/["']/g, '');
          const val = value.replace(/["']/g, '');
          return (vs === val);
        }));
      });
      filteredData.push(filter);
    });
    const flatData = filteredData.flat(1);
    return [
      ...new Map(flatData.map((item) => [item.key, item])).values(),
    ];
  }

  /**
   * Filter offer facet data
   * @param subcategories
   */
  public offerFacetData(subcategories) {
    const offerSet : CommonResponse = [];
    subcategories.forEach((datas) => {
      /* istanbul ignore else */
      if (datas.attributes.offer_facet?.length > 0) {
        offerSet.push(datas.attributes.offer_facet);
      }
    });
    const object = offerSet.flat(1).reduce((acc, value) => ({
      ...acc,
      [value]: (acc[value] || 0) + 1,
    }), []);
    return Object.entries(object).map(([k, v]) => ({ [k]: v }));
  }

  /**
   * Get Offers from Magnolia
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   * @returns offerResponse
   */
  public async index(
    market: MarketInfo,
    params,
    magnolia: MagnoliaInfo,
  ): Promise<CommonResponse> {
    const apptusQueryParams = {
      'esales.market': `${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}`,
      'esales.customerKey': params.customerkey,
      'esales.sessionKey': params.sessionkey,
      category_tree: `${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}`,
      category_filter: configuration.categoryFilter,
      root_category: `categories_${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}:
      '${configuration.rootCategory}'`,
      sort_by: params.sortBy,
      locale: `${market.locale}-${market.country}`,
    };
    const searchParams = this.common.queryString(apptusQueryParams);

    const getOfferUrl = `${this.apptusBaseUrl
      .replace(URI.tokens.clusterId, this.apptusClusterId)}${URI.apptus.getOffer}${searchParams}`;
    let globalSettingPageUrl;
    const offerPageUrl = `${magnolia.url}${URI.magnolia.pageData}`.replace(country, `${magnolia.marketPath}`);
    const queryParam = `lang=${market.locale}-${market.country}`;
    globalSettingPageUrl = `${offerPageUrl}?${queryParam}`;
    /* istanbul ignore else */
    if (magnolia.ispreview === false || magnolia.marketPath.length < this.marketPath) {
      globalSettingPageUrl = `${offerPageUrl}${URI.magnolia.getOffer}?${queryParam}`;
    }
    let globalSettingsUrl = `${this.magnoliaBasePath}${MAGNOLIA_URI.globalSettings}`;
    globalSettingsUrl = globalSettingsUrl
      .replace(country, `${market.country.toLocaleLowerCase()}`);

    const [getApptusOffer, getMagnoliaOfferResult, magnoliaResponse] = await Promise.all([
      this.commonDao.getResult(getOfferUrl),
      this.commonDao.getResult(globalSettingPageUrl),
      this.commonDao.getResult(globalSettingsUrl),

    ]);
    let offerSubcategories = getApptusOffer?.categoryNavigation[0].categoryTree.subcategories;
    /* istanbul ignore else */
    if (params.offerFacet) {
      offerSubcategories = this.offerSubcategoryByFacet(offerSubcategories, params.offerFacet);
    }
    const offerFacet = this.offerFacetData(offerSubcategories);

    delete magnoliaResponse?.addressSettings; // NOSONAR
    delete magnoliaResponse?.fieldValidators; // NOSONAR
    const offerPerPage = getMagnoliaOfferResult?.offersPerPage;
    const filterOfferData = this.offerPaginationData(offerSubcategories, params.page, offerPerPage);
    const offerResult = this.updateOfferResponse(filterOfferData);
    /* istanbul ignore else */
    if (params.isPage === true) {
      return { offers: offerResult, facet: offerFacet, globalSettings: magnoliaResponse };
    }
    let templateDefinition;
    /* istanbul ignore else */
    if (magnolia.ispreview && getMagnoliaOfferResult[`${URI.magnolia.getmgnlTemplate}`]) {
      const templateName = getMagnoliaOfferResult[`${URI.magnolia.getmgnlTemplate}`];
      const getOfferTemplateUrl = `${this.magnoliaBasePath}${URI.magnolia.templatePath}${templateName}`;
      templateDefinition = await this.commonDao
        .getResult(getOfferTemplateUrl);
    }
    return {

      ...getMagnoliaOfferResult,
      templateDefinition,
      offers: offerResult,
      facet: offerFacet,
      globalSettings: magnoliaResponse,
    };
  }

  /**
   * Get Offers from Magnolia
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   * @returns offerResponse
   */
  public async detail(
    market: MarketInfo,
    params,
    magnolia: MagnoliaInfo,
  ): Promise<CommonResponse> {
    const {
      channelkey, isPage,
    } = params;
    let availabilityCheck = channelkey;
    let singleWarehouse;
    let defaultWarehouse;
    let globalSettingPageUrl;
    let ccy;
    let currencyPlacement;
    const queryParam = `lang=${market.locale}-${market.country}`;
    const perPageUrl = `${magnolia.url}${URI.magnolia.pageData}`.replace(country, `${magnolia.marketPath}`);

    globalSettingPageUrl = `${perPageUrl}?${queryParam}`;
    /* istanbul ignore else */
    if (magnolia.ispreview === false || magnolia.marketPath.length < this.marketPath) {
      globalSettingPageUrl = `${perPageUrl}${URI.magnolia.offerDetail}?${queryParam}`;
    }
    let globalSettingsUrl = `${this.magnoliaBasePath}${MAGNOLIA_URI.globalSettings}`;
    globalSettingsUrl = globalSettingsUrl
      .replace(country, `${market.country.toLocaleLowerCase()}`);
    const [getMagnoliapageData, magnoliaResponse] = await Promise.all([
      this.commonDao.getResult(globalSettingPageUrl),
      this.commonDao.getResult(globalSettingsUrl),
    ]);

    // eslint-disable-next-line no-prototype-builtins
    if (magnoliaResponse.hasOwnProperty('warehouseSettings')) {
      singleWarehouse = magnoliaResponse.warehouseSettings.isSingleWarehouse;
      defaultWarehouse = magnoliaResponse.warehouseSettings.defaultWarehouse;
      ccy = magnoliaResponse.priceFormat?.ccy;
      currencyPlacement = magnoliaResponse.priceFormat?.currencyPlacement;
    }
    const productsPerPage = getMagnoliapageData?.offersPerPage;

    const queryParams = { productsPerPage, ...params };
    const apptusQueryParams = this.apptusQueryParams(queryParams, market);
    const searchParams = this.common.queryString(apptusQueryParams);
    const offerDetailUrl = `${this.apptusBaseUrl
      .replace(URI.tokens.clusterId, this.apptusClusterId)}${URI.apptus.offerDetail}${searchParams}`;

    const apptusData = await this.commonDao.getResult(offerDetailUrl);
    const facetItems = apptusData.facets?.find((item) => item.name === this.factes);
    /* istanbul ignore else */
    if (facetItems?.facetList) {
      this.facetData(facetItems, { ccy, currencyPlacement });
    }
    this.common.updateApptusResponse(apptusData);
    /* istanbul ignore else */
    if (!channelkey && singleWarehouse === 'true') {
      availabilityCheck = defaultWarehouse;
    }

    this.updateProductAvailability(apptusData, availabilityCheck);
    delete magnoliaResponse?.addressSettings; // NOSONAR
    delete magnoliaResponse?.fieldValidators;// NOSONAR
    const productListWithCount = apptusData.productListWithCount.find((tt) => tt.name === productListing);
    /* istanbul ignore else */
    if (productListWithCount?.products) {
      productListWithCount.products.map((ctProduct) => {
        const limitedStock = ctProduct?.variants?.every((variant) =>
          variant?.attributes?.availability?.limited_stock === true);

        // eslint-disable-next-line no-param-reassign
        ctProduct.limited_stock = limitedStock;
        return {
          ...ctProduct,
          variants: limitedStock,
        };
      }).filter((product) => product.variants?.length);
    }
    if (isPage) {
      return { productList: { ...apptusData }, globalSettings: magnoliaResponse };
    }
    let templateDefinition;
    /* istanbul ignore else */
    if (magnolia.ispreview && getMagnoliapageData[`${URI.magnolia.getmgnlTemplate}`]) {
      const templateName = getMagnoliapageData[`${URI.magnolia.getmgnlTemplate}`];
      const getOfferDetailTemplateUrl = `${this.magnoliaBasePath}${URI.magnolia.templatePath}${templateName}`;

      templateDefinition = await this.commonDao
        .getResult(getOfferDetailTemplateUrl);
    }
    return {
      ...getMagnoliapageData,
      templateDefinition,
      productList: { ...apptusData },
      singleWarehouse,
      defaultWarehouse,
      globalSettings: magnoliaResponse,
    };
  }

  /**
   *
   * @param facetsData Object
   * @param priceFormat Object
   * @returns
   */
  private facetData(facetsData, priceFormat) {
    const { ccy, currencyPlacement } = priceFormat;
    return facetsData.facetList?.map((facetsItems) => {
      const facetItem = facetsItems;
      if (facetsItems?.attribute === 'non_rep_sale_price') {
        facetItem.ccy = ccy;
        facetItem.currencyPlacement = currencyPlacement;
      }
      return facetItem;
    });
  }

  /**
   * Bind pquery parameters
   * @param params Object
   * @param market Object
   * @returns
   */
  private apptusQueryParams(params, market) {
    const {
      customerKey, sessionKey, productsPerPage,
      rootCategory, selectedCategory, windowLastRecommendations, filter, depth, facets, sortBy, page,
    } = params;
    const windowLast = (page || PAGINATION.apptus.page) * (productsPerPage || PAGINATION.apptus.offerPerPage);
    const windowsFirst = (windowLast - (productsPerPage || PAGINATION.apptus.offerPerPage)) + 1;
    const rootCategoryBase = `categories_${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}`;
    return {
      'esales.market': `${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}`,
      'esales.customerKey': customerKey,
      'esales.sessionKey': sessionKey,
      max_facets: params.maxFacets || apptusMaxFacets,
      window_first: windowsFirst,
      window_last: windowLast,
      window_first_recommendations: params.windowFirstRecommendations
        || apptusWindowFirstRecommendations,
      window_last_recommendations: windowLastRecommendations || apptusWindowLastRecommendations,
      root_category: rootCategory
        ? `${rootCategoryBase}:'${rootCategory}'` : `${rootCategoryBase}:'root'`,
      max_products: params.maxProducts || apptusMaxProducts,
      selected_category: params.selectedCategory ? `${rootCategoryBase}:'${selectedCategory}'` : '',
      filter,
      sort_by: sortBy,
      depth,
      facets,
      category_filter: URI.apptus.offerType,
      locale: `${market.locale}-${market.country}`,
    };
  }

  /**
 *  Update search availability data.
 * @param data Object
 * @param availabilityCheck boolean.
 */
  public updateProductAvailability(data, availabilityCheck) {
    let resultSet;
    /* istanbul ignore else */
    if (data.productListWithCount) {
      resultSet = data.productListWithCount;
    }
    const productLists = resultSet.find((item) => item?.name === productListing);
    productLists?.products.forEach((p) => {
      const productParams = p;
      productParams.attributes.inStock = false;
      productParams.variants.forEach((v) => {
        const variantParams = v;
        /* istanbul ignore else */
        if (variantParams.attributes.availability) {
          const productAvailability = JSON.parse(v.attributes.availability);
          variantParams.attributes.availability = {
            stockQty: 0,
            isAvailable: false,

          };
          // eslint-disable-next-line no-prototype-builtins
          if (productAvailability.hasOwnProperty(availabilityCheck)) {
            variantParams.attributes.availability = {
              stockQty: productAvailability[availabilityCheck].available_quantity,
              isAvailable: productAvailability[availabilityCheck].in_stock,
              limited_stock: productAvailability[availabilityCheck].limited_stock,
            };
            /* istanbul ignore else */
            if (productAvailability[availabilityCheck].in_stock === true) {
              productParams.attributes.inStock = true;
            }
          }
        }
      });
    });
  }

  /**
 * Update offer response.
 * @param data Object
 */
  public updateOfferResponse(offerData) {
    return offerData.map((item) => {
      const offerAttributes = item;
      offerAttributes.attributes = this.common.convertUnderScoreToCamelCase(item.attributes);
      return offerAttributes;
    });
  }
}
