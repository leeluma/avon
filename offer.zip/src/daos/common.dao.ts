import axios from 'axios';
import { CommonResponse } from '../dtos';
import { axiosOptions } from '../lib/axios-options';

export interface CommonDaoConfig {
  magnoliaBasePath: string;
  apptusBaseUrl: string,
  apptusClusterId: string,
}
/**
 * `OffersDao` data access class for getting offer settings from magnolia
 */
export class CommonDao {
  /**
   * Get offer from magnolia
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   */
  public async getResult(
    offerPageUrl,
  ): Promise<CommonResponse> {
    const configuration = {
      ...axiosOptions,
      method: 'get' as const,
      url: offerPageUrl,
    };
    try {
      const result = await axios(configuration);
      return result.data;
    } catch (error: any) { // NOSONAR
      throw new Error(`Failed to fetch offer , because: ${error.stack}`);
    }
  }
}
