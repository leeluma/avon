export interface ApptusRequest {
  windowFirst?: string;
  windowLast?: string;
  selectedCategory?: string;
  sortBy?: string;
  windowFirstRecommendations?: string;
  windowLastRecommendations?: string;
  maxFacets?: string;
  rootCategory?: string;
  maxProducts?: string;
  filter?: string;
  depth?: string;
  searchPhrase?: string;
  facets?: string;
  page?: string;
}
