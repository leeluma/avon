export interface MagnoliaInfo {
  url: string;
  ispreview: boolean;
  marketPath: string;
}
export interface CommonResponse {
  [x: string]: any | unknown; // NOSONAR
}
