export interface Dto {
    [k: string]: string;
  }

export interface MagnoliaDto {
    [key: string]: string;
  }

export interface MagnoliaPagesDto {
    '@name': string;
    '@path':string;
    '@id': string;
    '@nodeType': string;
    brandName?: string;
    facebookType? : string;
    addressFinderLabel?: string;
    blankMsg?: string;
    addressFinderPlaceholder?: string;
    signinButton?: string;
    payNowButtonText?: string;
    saveButtonText?: string;
    placeOrderButtonText?: string;
    continueButton?: string;
    selectButtonText?: string;
    cancelText?: string;
    changeText?: string;
    editText?: string;
    requiredErrorMessage?: string;
    incorrectLoginDetails?: string;
    dynamicYieldID?: string;
    googleAnalyticsID?: string;
    '@nodes': []
  }
export interface MagnoliaGlobalSettingDto {
    '@name': string;
    '@path': string;
    '@id': string;
    '@nodeType': string;
    text?: string;
    name?: string;
    priceFormat?: MagnoliaPagesDto [],
    thirdPartySettings?: MagnoliaPagesDto[],
    socialMediaSettings?: MagnoliaPagesDto [],
    fieldValidators?: MagnoliaPagesDto [],
    addressSettings?: MagnoliaPagesDto [],
    buttonTexts?: MagnoliaPagesDto[],
    linkTexts?: MagnoliaPagesDto[],
    generalSettings?: MagnoliaPagesDto[],
    brandName: string;
    warehouseSettings: {
      isSingleWarehouse: string;
      defaultWarehouse: string;
    }
    '@nodes': []
  }
