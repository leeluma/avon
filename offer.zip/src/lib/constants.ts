export const URI = {
  apptus: {
    getOffer: 'panels/navigation-page?',
    esales: 'notifications/click',
    nonEsales: 'notifications/non-esales-click',
    esaleAddToCart: 'notifications/adding-to-cart',
    nonEsaleAddToCart: 'notifications/non-esales-adding-to-cart',
    offerDetail: 'panels/product-list-page?',
    offerType: 'type:\'offer\'',
  },
  magnolia: {
    getOffer: '/offers',
    logSetting: '.rest/delivery/pages/v1/{{country}}/apptusSetting',
    offerDetail: '/offers/offers-details',
    pageData: '.rest/delivery/pages/v1/{{country}}',
    getmgnlTemplate: 'mgnl:template',
    templatePath: '.rest/template-definitions/v1/',
    categorySearch: '.rest/delivery/ecommerce-categories?q=',
  },
  commonConfig: {
    contentType: 'application/json',
    productList: 'product-list',

  },
  tokens: {
    clusterId: '{{CLUSTER_ID}}',
  },
};

export const PAGINATION = {
  apptus: {
    offerPerPage: 10,
    page: 1,
  },
};

export const MAGNOLIA_KEYS = {
  nameKey: '@name',
  generalSettingsValue: 'generalSettings',
  settingsValue: 'settings',
};
