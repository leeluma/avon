/**
 * It contains common functions to use within application.
 */
export class Common {
  /**
   * It used to convert object parameters to query string.
   *
   * @param params
   * @returns
   */
  public queryString(params: Record<string, any>): string {
    const removeUndefined = JSON.parse(JSON.stringify(params));
    return Object.entries(removeUndefined).map(
      ([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value as string)}`,
    ).join('&');
  }

  public convertUnderScoreToCamelCaseForApptus(params:Record<string, any>): Record<string, any> {
    return Object.fromEntries(
      Object.entries(params).map(([key, value]) =>
        [key.replace(/_([a-z])/g, (g) => { return g[1].toUpperCase(); }), value[0]]),
    );
  }

  public convertUnderScoreToCamelCase(params: Record<string, any>): Record<string, any> {
    return Object.fromEntries(
      Object.entries(params).map(([key, value]) =>
        [
          key.replace(/_([a-z])/g, (g) => g[1].toUpperCase()),
          value[0],
        ]),
    );
  }

  /**
   * Update
   * @param data Object
   */
  public updateApptusResponse(data) {
    let resultSet;
    if (data.productListWithCount) {
      resultSet = data.productListWithCount;
    }
    resultSet = resultSet.find((item) => item.name === 'product-list');
    resultSet?.products?.forEach((p) => {
      const productAttributes = p;
      productAttributes.attributes = this.convertUnderScoreToCamelCase(p.attributes);
      productAttributes.variants.forEach((v) => {
        const variantAttributes = v;
        variantAttributes.attributes = this.convertUnderScoreToCamelCase(v.attributes);
      });
    });
  }

  public isResponseOK = (status) => status >= 200 && status < 299;
}
