import { Router } from 'express';
import { magnoliaUrlMiddleware, validateRequestSchema } from '../middlewares';
import { OffersController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import { offerValidator, validateCategory } from '../validators';

export interface OffersRouterConfig {
  offersController: OffersController;
  Router: typeof Router;
}

/**
 * `OffersRouter` for all the routes related to `/offers`
 */
export class OffersRouter {
  private readonly offersController: OffersController;

  private readonly Router: typeof Router;

  constructor(config: OffersRouterConfig) {
    this.offersController = config.offersController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /{locale}-{country}:
     *   get:
     *     summary: Get offer
     *     tags: [Offers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: query
     *         name: path
     *         schema:
     *            type: string
     *            default: Global,CEE
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: header
     *         name: isPreview
     *         schema:
     *            type: boolean
     *            default: true
     *       - in: query
     *         name: offerFacet
     *         schema:
     *            type: string
     *            default: 'XXXX'
     *         required: false
     *       - in: header
     *         name: isPage
     *         schema:
     *            type: boolean
     *            default: true
     *       - in: header
     *         name: sessionkey
     *         schema:
     *            type: string
     *            default: XXXX
     *         required: true
     *       - in: header
     *         name: customerkey
     *         schema:
     *            type: string
     *            default: XXXX
     *         required: true
     *     responses:
     *       200:
     *         description: Get Offer
     *       404:
     *         description: Something went wrong.
    */
    router.get(
      '/',
      offerValidator,
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.offersController.index.bind(this.offersController),
      ),
    );
    /**
     * @swagger
     * /{locale}-{country}/detail:
     *   get:
     *     summary: Get offer detail
     *     tags: [Offers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: query
     *         name: rootCategory
     *         schema:
     *            type: string
     *            default: '******'
     *       - in: query
     *         name: path
     *         schema:
     *            type: string
     *            default: Global,CEE
     *         required: true
     *       - in: header
     *         name: isPreview
     *         schema:
     *            type: boolean
     *            default: true
     *       - in: query
     *         name: offerFacet
     *         schema:
     *            type: string
     *            default: 'XXXX'
     *         required: false
     *       - in: header
     *         name: isPage
     *         schema:
     *            type: boolean
     *            default: true
     *       - in: header
     *         name: sessionkey
     *         schema:
     *            type: string
     *            default: XXXX
     *         required: true
     *       - in: header
     *         name: customerkey
     *         schema:
     *            type: string
     *            default: XXXX
     *         required: true
     *     responses:
     *       200:
     *         description: Get Offer
     *       404:
     *         description: Something went wrong.
    */
    router.get(
      '/detail',
      validateCategory,
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.offersController.detail.bind(this.offersController),
      ),
    );

    return router;
  }
}
