import log4js from 'log4js';
import { NextFunction, Request, Response } from 'express';
import { logError, logger } from '../lib';

export const requestLoggerMiddleware = log4js.connectLogger(logger, {
  level: 'info',
});
export const requestBodyLoggerMiddleware = async (
  req: Request,
  res: Response,
  next: NextFunction,
): Promise<void> => {
  if (logger.isDebugEnabled()) {
    try {
      if (req.body) {
        logger.debug(`${req.originalUrl} Request body: ${JSON.stringify(req.body)}`);
      }
    } catch (err: any) { // NOSONAR
      logError('requestBodyLoggerMiddleware', 'Failed to serialize input', err);
    }

    const oldWrite = res.write;
    const oldEnd = res.end;
    const chunks: any[] = []; // NOSONAR
    res.write = (chunk: any, ...args: any[]) => { // NOSONAR
      chunks.push(Buffer.from(chunk));
      return oldWrite.apply(res, [chunk, ...args] as any); // NOSONAR
    };
    res.end = (chunk: any, ...args: any[]) => { // NOSONAR
      if (chunk) {
        chunks.push(Buffer.from(chunk));
      }
      try {
        const body = Buffer.concat(chunks).toString('utf8');
        logger.debug(`${req.originalUrl} Response body: ${body}`);
      } catch (err: any) { // NOSONAR
        logError('requestBodyLoggerMiddleware', 'Failed to serialize output', err);
      }

      return oldEnd.apply(res, [chunk, ...args] as any); // NOSONAR
    };
  }
  next();
};
