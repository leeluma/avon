import { NextFunction, Request, Response } from 'express';
import { validationResult } from 'express-validator';
import { StatusCodes } from 'http-status-codes';
import i18next from 'i18next';
import { ApiError } from '../lib';

export function validateRequestSchema(
  req: Request,
  res: Response,
  next: NextFunction,
): void {
  const errors = validationResult(req);

  if (!errors.isEmpty()) {
    const err = errors.array().map((e) => {
      e.msg = i18next.t(e.msg);
      e.nestedErrors = e.nestedErrors?.map((nestedError) => {
        const currentError = nestedError;
        currentError.msg = i18next.t(currentError.msg);
        return currentError;
      });
      return e;
    });
    throw new ApiError(StatusCodes.BAD_REQUEST, err);
  } else {
    next();
  }
}
