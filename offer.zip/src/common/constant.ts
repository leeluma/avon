export enum MAGNOLIA_URI {
    globalSettings = '.rest/delivery/global-settings/{{country}}/settings',
}
