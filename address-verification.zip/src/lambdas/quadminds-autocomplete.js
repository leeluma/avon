import common from '/opt/address-validator-layer/common.js';
import quadMinds from '/opt/address-validator-layer/quadminds.js';

export const handler = async (event) => {
    const correlationId = event.headers ? event.headers["X-Correlation-ID"] : "";
    try {
        const configuration = await common.getConfiguration(event.resource);
        const configWithSettingOverridden = {...configuration, quadMindsAvoidTypeahead: undefined};
        const addressList = await quadMinds.geocode(event.queryStringParameters.address, configWithSettingOverridden);

        if (!Array.isArray(addressList)) {
            return {
                statusCode: common.statusCodes.INTERNAL_SERVER_ERROR,
                body: JSON.stringify(addressList),
                headers: {
                    "X-Correlation-ID": correlationId
                }
            };
        }

        const mapper = a => {
            const addressId = Buffer.from(a.normalizedAddress).toString('base64');
            return {
                id: addressId,
                normalizedAddress: a.normalizedAddress,
                exactMatch: a.exactMatch
            };
        };
        const responseBody = {
            suggestions: addressList.map(mapper)
        };

        return {
            statusCode: common.statusCodes.OK,
            body: JSON.stringify(responseBody),
            headers: {
                "X-Correlation-ID": correlationId
            }
        };

    } catch (error) {
        return common.createErrorResponse(correlationId, error.message);
    }
};