import common from '/opt/address-validator-layer/common.js';
import quadMinds from '/opt/address-validator-layer/quadminds.js';

const sampleAddress = "Calea 13 Septembrie 90, 050726 București, România";
const sampleMarket = "ro-ro";
const serviceStatus = {
    healthy: "Healthy",
    unhealthy: "Unhealthy",
    unauthorized: "Unauthorised",
};

const statusCodes = common.statusCodes;

export const handler = async () => {
    const quadMindsResult = await checkQuadMinds(sampleAddress);
    // const arvatoResult = ...
    // const hopewiserResult = ...
    // const woosMapResult = ...

    return calculateServiceStatus({ quadMindsResult /*, arvatoResult, hopewiserResult, woosMapResult */ });
};

export const calculateServiceStatus = ({ quadMindsResult }) => {
    const isQuadMindsHealthy = quadMindsResult.status === serviceStatus.healthy;
    const overallStatus = isQuadMindsHealthy ? serviceStatus.healthy : serviceStatus.unhealthy;
    const overallStatusCode = quadMindsResult.statusCode;
    const result = {
        status: overallStatus,
        details: {
            quadMinds: quadMindsResult.status,
            arvato: undefined,
            woosMap: undefined,
            hopewiser: undefined,
        }
    };

    return {
        statusCode: overallStatusCode,
        body: JSON.stringify(result)
    };
};

export const checkQuadMinds = async (address) => {
    if(!address || !sampleMarket) {
        return;
    }

    try {
        const configuration = await common.getConfiguration(sampleMarket);
        const response = await quadMinds.geocode(address, configuration);

        if (Array.isArray(response)) {
            return {
                statusCode: statusCodes.OK,
                status: serviceStatus.healthy,
                message: response
            };
        }

        if (response === "Not Authorized") {
            return {
                statusCode: statusCodes.UNAUTHORIZED,
                status: serviceStatus.unauthorized,
                message: response
            };
        }

        return {
            statusCode: statusCodes.INTERNAL_SERVER_ERROR,
            status: serviceStatus.unhealthy,
            message: "Return value is not an array"
        };
    } catch (error) {
        return {
            statusCode: statusCodes.SERVICE_UNAVAILABLE,
            status: serviceStatus.unhealthy,
            message: error.message
        };
    }
};