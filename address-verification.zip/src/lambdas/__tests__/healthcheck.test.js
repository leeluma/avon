import * as uut from "../healthcheck";
import { jest } from '@jest/globals';
import common from '/opt/address-validator-layer/common.js';
import quadMinds from '/opt/address-validator-layer/quadminds.js';

const resultNotAnArrayMsg = "Return value is not an array";

describe("healthcheck.js tests", () => {
    it("returns unhealthy service status", () => {
        const quadMindsResult = {
            statusCode: 401,
            status: "Unauthorised",
            message: ""
        };

        const serviceStatus = uut.calculateServiceStatus({ quadMindsResult });
        const result = JSON.parse(serviceStatus.body);

        expect(serviceStatus.statusCode).toEqual(quadMindsResult.statusCode);
        expect(result.status).toEqual("Unhealthy");
        expect(result.details.quadMinds).toEqual("Unauthorised");
    });

    it("returns healthy service status", () => {
        const quadMindsResult = {
            statusCode: 200,
            status: "Healthy",
            message: ""
        };

        const serviceStatus = uut.calculateServiceStatus({ quadMindsResult });
        const result = JSON.parse(serviceStatus.body);

        expect(serviceStatus.statusCode).toEqual(quadMindsResult.statusCode);
        expect(result.status).toEqual("Healthy");
        expect(result.details.quadMinds).toEqual("Healthy");
    });
});

describe("healthcheck.js checkQuadmind function tests", () => {
    it("will return a healthy status", async () => {
        const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [{ "market": "ro", "language": "ro", "environment": "sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }]);
        const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation((address) => [{ "address": { "bldgTxt": "60", "city": "București", "county": "București", "flatTxt": "B/2/6", "neighborhood": "Sectorul 2", "prmssTxt": "", "prvnc": "", "strNm": "Strada Heliade Între Vii", "zipCd": "023385" }, "avonTranslation": null, "exactMatch": true, "latitude": 44.45668, "longitude": 26.14409, "mapImage": "https://saas.quadminds.com/api/services/staticmap?key=7dP86X4tWrwmfmxETYwL7exKmNj2tIwE&coords=44.45668,26.14409&width=400&height=400&zoom=&color=0cafef&mapType=5&showMarker=true", "matchLabel": "Strada Heliade Între Vii 60, 023385 București, România", "normalizedAddress": "Strada Heliade Între Vii 60, 023385 București, România" }]);

        const result = await uut.handler();
        const body = JSON.parse(result.body);
        expect(spyGetConfig).toHaveBeenCalledTimes(1);
        expect(spyGeocode).toHaveBeenCalledTimes(1);
        expect(body.status).toEqual("Healthy");
        expect(body.details.quadMinds).toEqual("Healthy");
    });

    it("will return an unauthorized status", async () => {
        const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [{ "market": "ro", "language": "ro", "environment": "sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }]);
        const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation((address) => "Not Authorized");

        const result = await uut.checkQuadMinds('Budapest 12');
        expect(spyGetConfig).toHaveBeenCalledTimes(1);
        expect(spyGeocode).toHaveBeenCalledTimes(1);
        expect(result.statusCode).toEqual(401);
        expect(result.status).toEqual("Unauthorised");
    });

    it("will return empty object for no address", async () => {
        const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [{ "market": "ro", "language": "ro", "environment": "sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }]);
        const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation((address) => "Not Authorized");

        const result = await uut.checkQuadMinds('');
        expect(spyGetConfig).toHaveBeenCalledTimes(0);
        expect(spyGeocode).toHaveBeenCalledTimes(0);
        expect(result).toBeUndefined();
    });

    it("will return an internal server error", async () => {
        const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [{ "market": "ro", "language": "ro", "environment": "sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }]);
        const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation((address) => "");

        const result = await uut.checkQuadMinds('Budapest 12');
        expect(spyGetConfig).toHaveBeenCalledTimes(1);
        expect(spyGeocode).toHaveBeenCalledTimes(1);
        expect(result.statusCode).toEqual(500);
        expect(result.status).toEqual("Unhealthy");
        expect(result.message).toEqual(resultNotAnArrayMsg);
    });

    it("will return a service unavailable error", async () => {
        const errorMessage = "Service unavailable";
        const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [{ "market": "ro", "language": "ro", "environment": "sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }]);
        const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation((address) => { throw new Error(errorMessage) });

        const result = await uut.checkQuadMinds('Budapest 12');
        expect(spyGetConfig).toHaveBeenCalledTimes(1);
        expect(spyGeocode).toHaveBeenCalledTimes(1);
        expect(result.statusCode).toEqual(503);
        expect(result.status).toEqual("Unhealthy");
        expect(result.message).toEqual(errorMessage);
    });
});