import { jest } from '@jest/globals';
import { handler } from '../quadminds-addressdetails';
import common from '/opt/address-validator-layer/common.js';
import quadMinds from '/opt/address-validator-layer/quadminds.js';

describe("handler", () => {
   const env = process.env;
   const xCorrelationID = '12345'; 
   const addressId = Buffer.from("Strada Budapesta, 307160 Dumbr\u0103vi\u021ba, Rom\u00e2nia").toString('base64');
   const testAddress = { 
      "address": { "bldgTxt": "60", "city": "București", "county": "București", "flatTxt": "B/2/6", "neighborhood": "Sectorul 2", "prmssTxt": "", "prvnc": "", "strNm": "Strada Heliade Între Vii", "zipCd": "023385" }, 
      "avonTranslation": null, 
      "exactMatch": true, 
      "latitude": 44.45668, 
      "longitude": 26.14409, 
      "mapImage": "https://saas.quadminds.com/api/services/staticmap?key=7dP86X4tWrwmfmxETYwL7exKmNj2tIwE&coords=44.45668,26.14409&width=400&height=400&zoom=&color=0cafef&mapType=5&showMarker=true", 
      "matchLabel": "Strada Heliade Între Vii 60, 023385 București, România", 
      "normalizedAddress": "Strada Heliade Între Vii 60, 023385 București, România" 
   };
   const testConfig = { 
      "market": "ro", 
      "language": "ro", 
      "environment": "sandbox", 
      "countryName": "România", 
      "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", 
      "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" 
   };

   it("will receive the default X-Correlation-ID", async () => {   
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [testConfig]);
      const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation(() => [testAddress]);
       
      const result = await handler({'queryStringParameters': { 'addressId': addressId }, 'resource' : 'ro-ro'});
      
      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(spyGeocode).toHaveBeenCalledTimes(1);
      expect(result.headers["X-Correlation-ID"]).toEqual('');
    });

    it("will receive undefined X-Correlation-ID", async () => {   
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [testConfig]);
      const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation(() => [testAddress]);
       
      const result = await handler({ 'headers': {}, 'queryStringParameters': { 'addressId': addressId }, 'resource' : 'ro-ro' });
      
      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(spyGeocode).toHaveBeenCalledTimes(1);
      expect(result.headers["X-Correlation-ID"]).toBeUndefined();
    });

   it("will receive the correct X-Correlation-ID", async () => {
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [testConfig]);
      const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation(() => [testAddress]);
      
      const result = await handler({'headers': { "X-Correlation-ID": xCorrelationID }, 'queryStringParameters': { 'addressId': addressId }, 'resource' : 'ro-ro'});
      
      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(spyGeocode).toHaveBeenCalledTimes(1);
      expect(result.headers["X-Correlation-ID"]).toEqual(xCorrelationID);
   });

   it("will receive internal server error for invalid type address list", async () => {
      const addressList = 23;
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [testConfig]);
      const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation(() => addressList);
    
      const result = await handler({'headers': { "X-Correlation-ID": xCorrelationID }, 'queryStringParameters': { 'addressId': addressId }, 'resource' : 'ro-ro'});
    
      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(spyGeocode).toHaveBeenCalledTimes(1);
      expect(result.statusCode).toEqual(common.statusCodes.INTERNAL_SERVER_ERROR);
      const expected = {
         message: 'Invalid response: ' + addressList,
         status: 'Failed',
         statusCode: common.statusCodes.INTERNAL_SERVER_ERROR
      };
      expect(JSON.parse(result.body)).toEqual(expected);
   });

   it("will receive internal server error for no exact match found", async () => {
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [testConfig]);
      const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation(() => [testAddress]);

      const result = await handler({'headers': { "X-Correlation-ID": xCorrelationID }, 'queryStringParameters': { 'addressId': addressId }, 'resource' : 'ro-ro'});
    
      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(spyGeocode).toHaveBeenCalledTimes(1);
      expect(result.statusCode).toEqual(common.statusCodes.INTERNAL_SERVER_ERROR);
      const expected = {
         message: 'No exact match has been found.',
         status: 'Failed',
         statusCode: common.statusCodes.INTERNAL_SERVER_ERROR
      };
      expect(JSON.parse(result.body)).toEqual(expected);
   });

   it("will map matched address", async () => {
      const matchingAddressId = Buffer.from("Strada Heliade Între Vii 60, 023385 București, România").toString('base64');
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [testConfig]);
      const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation(() => [testAddress]);

      const result = await handler({'headers': { "X-Correlation-ID": xCorrelationID }, 'queryStringParameters': { 'addressId': matchingAddressId, 'fields' : 'city,zipCode,houseNumber' }, 'resource' : 'ro-ro'});
    
      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(spyGeocode).toHaveBeenCalledTimes(1);
      const expectedBody = {
         city: testAddress.address.city,
         zipCode: testAddress.address.zipCd,
         houseNumber: testAddress.address.bldgTxt
      };
      expect(JSON.parse(result.body)).toEqual(expectedBody);
      expect(result.headers["X-Correlation-ID"]).toEqual(xCorrelationID);
   });

   it("will map all possible address fields", async () => {
      const matchingAddressId = Buffer.from("Strada Heliade Între Vii 60, 023385 București, România").toString('base64');
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [testConfig]);
      const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation(() => [testAddress]);

      const result = await handler({'headers': { "X-Correlation-ID": xCorrelationID }, 'queryStringParameters': { 'addressId': matchingAddressId }, 'resource' : 'ro-ro'});
    
      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(spyGeocode).toHaveBeenCalledTimes(1);
      const expectedBody = {
         region1: testAddress.address.county,
         city: testAddress.address.city,
         district1: testAddress.address.neighborhood,
         zipCode: testAddress.address.zipCd,
         streetName: testAddress.address.strNm,
         houseNumber: testAddress.address.bldgTxt,
         flat: testAddress.address.flatTxt,
         latitude: testAddress.latitude,
         longitude: testAddress.longitude
      };
      expect(JSON.parse(result.body)).toEqual(expectedBody);
      expect(result.headers["X-Correlation-ID"]).toEqual(xCorrelationID);
   });


   it("will throw an error", async () => {
      const errorMsg = "Error message from the mock";
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => { throw new Error(errorMsg); });
      
      const result = await handler({'headers': {}, 'queryStringParameters': { 'address': 'abc'}, 'resource' : 'ro-ro'});
    
      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(result.statusCode).toEqual(common.statusCodes.INTERNAL_SERVER_ERROR);
      const expected = {
         message: errorMsg,
         status: 'Failed',
         statusCode: common.statusCodes.INTERNAL_SERVER_ERROR
      };
      expect(JSON.parse(result.body)).toEqual(expected);
   });

   afterEach(() => {
      jest.restoreAllMocks();
   });

});