import { jest } from '@jest/globals';
import { handler } from '../quadminds-autocomplete';
import common from '/opt/address-validator-layer/common.js';
import quadMinds from '/opt/address-validator-layer/quadminds.js';

describe("handler", () => {
   const env = process.env;

   it("will receive the default X-Correlation-ID", async () => {
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [{ "market": "ro", "language": "ro", "environment": "sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }]);
      const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation(() => [{ "address": { "bldgTxt": "60", "city": "București", "county": "București", "flatTxt": "B/2/6", "neighborhood": "Sectorul 2", "prmssTxt": "", "prvnc": "", "strNm": "Strada Heliade Între Vii", "zipCd": "023385" }, "avonTranslation": null, "exactMatch": true, "latitude": 44.45668, "longitude": 26.14409, "mapImage": "https://saas.quadminds.com/api/services/staticmap?key=7dP86X4tWrwmfmxETYwL7exKmNj2tIwE&coords=44.45668,26.14409&width=400&height=400&zoom=&color=0cafef&mapType=5&showMarker=true", "matchLabel": "Strada Heliade Între Vii 60, 023385 București, România", "normalizedAddress": "Strada Heliade Între Vii 60, 023385 București, România" }]);

      const result = await handler({ 'queryStringParameters': { 'address': 'abc' }, 'resource': 'ro-ro' });

      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(spyGeocode).toHaveBeenCalledTimes(1);
      expect(result.headers["X-Correlation-ID"]).toEqual('');
   });

   it("will receive undefined X-Correlation-ID", async () => {
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [{ "market": "ro", "language": "ro", "environment": "sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }]);
      const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation(() => [{ "address": { "bldgTxt": "60", "city": "București", "county": "București", "flatTxt": "B/2/6", "neighborhood": "Sectorul 2", "prmssTxt": "", "prvnc": "", "strNm": "Strada Heliade Între Vii", "zipCd": "023385" }, "avonTranslation": null, "exactMatch": true, "latitude": 44.45668, "longitude": 26.14409, "mapImage": "https://saas.quadminds.com/api/services/staticmap?key=7dP86X4tWrwmfmxETYwL7exKmNj2tIwE&coords=44.45668,26.14409&width=400&height=400&zoom=&color=0cafef&mapType=5&showMarker=true", "matchLabel": "Strada Heliade Între Vii 60, 023385 București, România", "normalizedAddress": "Strada Heliade Între Vii 60, 023385 București, România" }]);

      const result = await handler({ 'headers': {}, 'queryStringParameters': { 'address': 'abc' }, 'resource': 'ro-ro' });

      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(spyGeocode).toHaveBeenCalledTimes(1);
      expect(result.headers["X-Correlation-ID"]).toBeUndefined();
   });

   it("will receive the correct X-Correlation-ID", async () => {
      const xCorrelationID = '12345';
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [{ "market": "ro", "language": "ro", "environment": "sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }]);
      const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation(() => [{ "address": { "bldgTxt": "60", "city": "București", "county": "București", "flatTxt": "B/2/6", "neighborhood": "Sectorul 2", "prmssTxt": "", "prvnc": "", "strNm": "Strada Heliade Între Vii", "zipCd": "023385" }, "avonTranslation": null, "exactMatch": true, "latitude": 44.45668, "longitude": 26.14409, "mapImage": "https://saas.quadminds.com/api/services/staticmap?key=7dP86X4tWrwmfmxETYwL7exKmNj2tIwE&coords=44.45668,26.14409&width=400&height=400&zoom=&color=0cafef&mapType=5&showMarker=true", "matchLabel": "Strada Heliade Între Vii 60, 023385 București, România", "normalizedAddress": "Strada Heliade Între Vii 60, 023385 București, România" }]);

      const result = await handler({ 'headers': { "X-Correlation-ID": xCorrelationID }, 'queryStringParameters': { 'address': 'abc' }, 'resource': 'ro-ro' });

      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(spyGeocode).toHaveBeenCalledTimes(1);
      expect(result.headers["X-Correlation-ID"]).toEqual(xCorrelationID);
   });

   it("will receive internal server error for invalid type address list", async () => {
      const addressList = 12345;
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [{ "market": "ro", "language": "ro", "environment": "sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }]);
      const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation(() => addressList);

      const result = await handler({ 'headers': {}, 'queryStringParameters': { 'address': 'abc' }, 'resource': 'ro-ro' });

      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(spyGeocode).toHaveBeenCalledTimes(1);
      expect(result.statusCode).toEqual(common.statusCodes.INTERNAL_SERVER_ERROR);
      expect(result.body).toBe(JSON.stringify(addressList));
      expect(result.headers["X-Correlation-ID"]).toBeFalsy();
      expect(result.headers.hasOwnProperty("X-Correlation-ID")).toBe(true);
   });

   it("will throw an error", async () => {
      const errorMsg = "Error message from the mock";
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => { throw new Error(errorMsg); });

      const result = await handler({ 'headers': {}, 'queryStringParameters': { 'address': 'abc' }, 'resource': 'ro-ro' });

      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(result.statusCode).toEqual(common.statusCodes.INTERNAL_SERVER_ERROR);
      const expected = {
         message: errorMsg,
         status: 'Failed',
         statusCode: 500
      };
      expect(JSON.parse(result.body)).toEqual(expected);
   });

   it("will return the correct result", async () => {
      const xCorrelationID = '12345';
      const spyGetConfig = jest.spyOn(common, 'getConfiguration').mockImplementation(() => [{ "market": "ro", "language": "ro", "environment": "sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }]);
      const spyGeocode = jest.spyOn(quadMinds, 'geocode').mockImplementation(() => [{ "address": { "bldgTxt": "60", "city": "București", "county": "București", "flatTxt": "B/2/6", "neighborhood": "Sectorul 2", "prmssTxt": "", "prvnc": "", "strNm": "Strada Heliade Între Vii", "zipCd": "023385" }, "avonTranslation": null, "exactMatch": true, "latitude": 44.45668, "longitude": 26.14409, "mapImage": "https://saas.quadminds.com/api/services/staticmap?key=7dP86X4tWrwmfmxETYwL7exKmNj2tIwE&coords=44.45668,26.14409&width=400&height=400&zoom=&color=0cafef&mapType=5&showMarker=true", "matchLabel": "Strada Heliade Între Vii 60, 023385 București, România", "normalizedAddress": "Strada Heliade Între Vii 60, 023385 București, România" }]);

      const result = await handler({ 'headers': { "X-Correlation-ID": xCorrelationID }, 'queryStringParameters': { 'address': 'abc' }, 'resource': 'ro-ro' });
      const body = JSON.parse(result.body);

      expect(spyGetConfig).toHaveBeenCalledTimes(1);
      expect(spyGeocode).toHaveBeenCalledTimes(1);
      expect(result.headers["X-Correlation-ID"]).toEqual(xCorrelationID);
      expect(result.statusCode).toEqual(common.statusCodes.OK);
      expect(body.suggestions).toBeDefined();
      expect(body.suggestions).toBeDefined();
      expect(Array.isArray(body.suggestions)).toBe(true);
      expect(body.suggestions.length).toEqual(1);
      expect(body.suggestions[0].id).toBeTruthy();
      expect(body.suggestions[0].normalizedAddress).toBeTruthy();
      expect(body.suggestions[0].exactMatch).toBe(true);
   });

   afterEach(() => {
      jest.restoreAllMocks();
   });

});