import common from '/opt/address-validator-layer/common.js';
import quadMinds from '/opt/address-validator-layer/quadminds.js';

export const handler = async (event) => {
    const correlationId = event.headers ? event.headers["X-Correlation-ID"] : "";
    try {
        const configuration = await common.getConfiguration(event.resource);
        const normalizedAddress = Buffer.from(event.queryStringParameters.addressId, 'base64').toString('utf8');
        const addressList = await quadMinds.geocode(normalizedAddress, configuration);

        if (!Array.isArray(addressList)) {
            return common.createErrorResponse(correlationId, `Invalid response: ${addressList}`);
        }

        const selectedAddress = addressList.find(a => a.exactMatch && a.normalizedAddress === normalizedAddress);

        if (!selectedAddress) {
            return common.createErrorResponse(correlationId, "No exact match has been found.");
        }

        const addressFields = mapAddress(configuration, selectedAddress);

        const fields = event.queryStringParameters.fields ? event.queryStringParameters.fields.split(',') : [];
        const body = fields.length === 0 ?
            JSON.stringify(addressFields, (key, value) => value ? value : undefined) :
            JSON.stringify(addressFields, fields);

        return {
            statusCode: common.statusCodes.OK,
            body,
            headers: {
                "X-Correlation-ID": correlationId
            }
        };
    } catch (error) {
        return common.createErrorResponse(correlationId, error.message);
    }
};

const mapAddress = (configuration, selectedAddress) => {
    return {
        "country": configuration.countryName,
        "region1": selectedAddress.address.county,
        "region2": selectedAddress.address.prvnc,
        "city": selectedAddress.address.city,
        "district1": selectedAddress.address.neighborhood,
        "district2": selectedAddress.address.prmssTxt,
        "zipCode": selectedAddress.address.zipCd,
        "streetName": selectedAddress.address.strNm,
        "houseNumber": selectedAddress.address.bldgTxt,
        "floor": "",
        "flat": selectedAddress.address.flatTxt,
        "latitude": selectedAddress.latitude,
        "longitude": selectedAddress.longitude
    };
};