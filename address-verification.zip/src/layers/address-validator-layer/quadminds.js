import axios from 'axios';

const geocode = async (address, { quadMindsBaseUrl, quadMindsApikey, language, quadMindsAvoidTypeahead }) => {
    try {
        if (!quadMindsBaseUrl || !quadMindsApikey) {
            return "Missing configuration";
        }

        const url = new URL(quadMindsBaseUrl);
        url.searchParams.append("key", quadMindsApikey);
        url.searchParams.append("completeAddress", address);

        if (language) {
            url.searchParams.append("language", language);
        }

        if (quadMindsAvoidTypeahead !== undefined) {
            url.searchParams.append("avoidTypeahead", quadMindsAvoidTypeahead);
        }

        const response = await axios.get(url.href);
        const addressList = response.data;

        if (addressList["error"]) {
            return addressList["error"];
        }

        if (Array.isArray(addressList)) {
            return addressList;
        }

        return "Quadminds return value is not an array";
    } catch (error) {
        return error.message;
    }
};

const quadMinds = {
    geocode
}
export default quadMinds;