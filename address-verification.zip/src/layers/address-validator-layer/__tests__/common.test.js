//import SecretsManager from AWS;
import common from '/opt/address-validator-layer/common.js';
import { jest } from '@jest/globals';
import axios from 'axios';
global.axios = axios;

const secretName = "awa-sandbox-leap-quadminds-apikey";
const market = 'ro-ro';
const testConfig = {
  headers: {},
  data: [{ "market": "ro", "language": "ro", "environment": "Sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }]
};

describe("common.js", () => {

  process.env.APPCONFIG_URL = "http://localhost:2772/applications/cop3fw7/environments/qyfz9g4?region=eu-west-1";

  it("will call console.error the invalid resource path", async () => {
    const resourcePath = '-ro';
    const errorMsg = `Invalid resource path: ${resourcePath}`;
    const spyLogError = jest.spyOn(console, 'error').mockImplementation((input) => expect(input).toEqual(errorMsg));

    await common.getConfiguration(resourcePath);

    expect(spyLogError).toHaveBeenCalledTimes(1);
  });

  it("will call console.error the missing configuration error", async () => {
    const errorMsg = `Configuration is missing for resource: ${market}`;
    const spyAxios = jest.spyOn(global.axios, 'get').mockImplementation(() => ({ headers: {}, data: ['first', 'second'] }));
    const spyLogError = jest.spyOn(console, 'error').mockImplementation((input) => expect(input).toEqual(errorMsg));

    await common.getConfiguration(market);

    expect(spyAxios).toHaveBeenCalledTimes(1);
    expect(spyLogError).toHaveBeenCalledTimes(1);
  });

  it("will call console.error that no configuration found", async () => {
    const errorMsg = `No configuration found on AppConfig url: ${process.env.APPCONFIG_URL}`;
    const spyAxios = jest.spyOn(global.axios, 'get').mockImplementation(() => ({ headers: {}, data: 'notAnArray' }));
    const spyLogError = jest.spyOn(console, 'error').mockImplementation((input) => expect(input).toEqual(errorMsg));

    await common.getConfiguration(market);

    expect(spyAxios).toHaveBeenCalledTimes(1);
    expect(spyLogError).toHaveBeenCalledTimes(1);
  });

  it("will call console.error that APPCONFIG_URL is not set", async () => {
    process.env.APPCONFIG_URL = '';
    const errorMsg = 'APPCONFIG_URL is not set';
    const spyLogError = jest.spyOn(console, 'error').mockImplementation((input) => expect(input).toEqual(errorMsg));

    await common.getConfiguration(market);

    expect(spyLogError).toHaveBeenCalledTimes(1);
    process.env.APPCONFIG_URL = "http://localhost:2772/applications/cop3fw7/environments/qyfz9g4?region=eu-west-1";
  });

  it("will return proper configuration", async () => {
    const testEnv = 'sandbox';
    const testCountry = 'România';
    const testSecret = 'testSecret';
    const spyAxios = jest.spyOn(global.axios, 'get').mockImplementation(() => ({ headers: {}, data: [{ "market": "ro", "language": "ro", "environment": testEnv, "countryName": testCountry, "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }] }));
    const spyAWS = jest.spyOn(common.client, 'send').mockImplementation(() => ({ SecretString: `{ "apikey": "${testSecret}" }` }));

    const result = await common.getConfiguration(market);
    expect(result.environment).toEqual(testEnv);
    expect(result.countryName).toEqual(testCountry);
    expect(result.quadMindsApikey).toEqual(testSecret);
    expect(spyAxios).toHaveBeenCalledTimes(1);
    expect(spyAWS).toHaveBeenCalledTimes(1);
    expect(spyAWS).toBeCalledWith(expect.objectContaining({
      input: expect.objectContaining({ "SecretId": "awa-sandbox-leap-quadminds-apikey" }),
    }));
  });

  it("won't receive secret", async () => {
    const errorMsg = `Secret ${secretName} is missing.`;
    const spyAxios = jest.spyOn(global.axios, 'get').mockImplementation(() => (testConfig));
    const spyAWS = jest.spyOn(common.client, 'send').mockImplementation(() => null);
    const spyLogError = jest.spyOn(console, 'error').mockImplementation((input) => expect(input).toEqual(errorMsg));

    const result = await common.getConfiguration(market);

    expect(result.quadMindsApikey).toBeUndefined();
    expect(spyAxios).toHaveBeenCalledTimes(1);
    expect(spyAWS).toHaveBeenCalledTimes(1);
    expect(spyLogError).toHaveBeenCalledTimes(1);
  });

  it("will call console.error the missing configuration error, because of the language code does not match", async () => {
    const errorMsg = `Configuration is missing for resource: ${market}`;
    const spyAxios = jest.spyOn(global.axios, 'get').mockImplementation(() => ({ headers: {}, data: [{ "market": "ro", "language": "hu", "environment": "Sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }] }));
    const spyLogError = jest.spyOn(console, 'error').mockImplementation((input) => expect(input).toEqual(errorMsg));

    await common.getConfiguration(market);

    expect(spyAxios).toHaveBeenCalledTimes(1);
    expect(spyLogError).toHaveBeenCalledTimes(1);
  });

  it("will call console.error the missing configuration error, because of the market code does not match", async () => {
    const errorMsg = `Configuration is missing for resource: ${market}`;
    const spyAxios = jest.spyOn(global.axios, 'get').mockImplementation(() => ({ headers: {}, data: [{ "market": "gr", "language": "ro", "environment": "Sandbox", "countryName": "România", "quadMindsBaseUrl": "https://saas.quadminds.com/api/services/geocode", "quadMindsSecretName": "awa-sandbox-leap-quadminds-apikey" }] }));
    const spyLogError = jest.spyOn(console, 'error').mockImplementation((input) => expect(input).toEqual(errorMsg));

    await common.getConfiguration(market);

    expect(spyAxios).toHaveBeenCalledTimes(1);
    expect(spyLogError).toHaveBeenCalledTimes(1);
  });

  it("will call console.error that Secret is missing", async () => {
    const errorMsg = `Secret ${secretName} is missing.`;
    const spyAxios = jest.spyOn(global.axios, 'get').mockImplementation(() => (testConfig));
    const spyAWS = jest.spyOn(common.client, 'send').mockImplementation(() => ({}));
    const spyLogError = jest.spyOn(console, 'error').mockImplementation((input) => expect(input).toEqual(errorMsg));

    await common.getConfiguration(market);
    expect(spyAxios).toHaveBeenCalledTimes(1);
    expect(spyAWS).toHaveBeenCalledTimes(1);
    expect(spyLogError).toHaveBeenCalledTimes(1);
  });

  it("will handle SecretsManager error properly", async () => {
    const errorMsg = `Secret ${secretName} is missing.`;
    const spyAxios = jest.spyOn(global.axios, 'get').mockImplementation(() => (testConfig));
    const spyAWS = jest.spyOn(common.client, 'send').mockImplementation(() => { throw new Error(errorMsg); });
    const spyLogError = jest.spyOn(console, 'error').mockImplementation((input) => expect(input).toEqual(errorMsg));

    await common.getConfiguration(market);

    expect(spyAxios).toHaveBeenCalledTimes(1);
    expect(spyAWS).toHaveBeenCalledTimes(1);
    expect(spyLogError).toHaveBeenCalledTimes(1);
  });

  it("will return proper error response", async () => {
    const correlationId = 12345;
    const message = 'test error message';

    const result = common.createErrorResponse(correlationId, message);

    expect(result.statusCode).toEqual(common.statusCodes.INTERNAL_SERVER_ERROR);
    expect(result.headers).toBeDefined();
    expect(result.headers['X-Correlation-ID']).toEqual(correlationId);
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });
});