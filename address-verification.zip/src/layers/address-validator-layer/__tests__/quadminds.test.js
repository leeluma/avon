import { jest } from '@jest/globals';
import quadMinds from '/opt/address-validator-layer/quadminds.js';
import axios from 'axios';

global.axios = axios;

const quadmindsDataWithoutLanguage = {
   quadMindsBaseUrl: "https://saas.quadminds.com/api/services/geocode",
   quadMindsApikey: '0imfnc8mVLWwsAawjYr4Rx',
};

const quadmindsData = {
   ...quadmindsDataWithoutLanguage,
   language: 'ro-ro'
};

describe("geocode function", () => {

   it("should return missing configuration alert text for no quadminds api url", async () => {
      const result = await quadMinds.geocode(null, { quadMindsBaseUrl: null, quadMindsApikey: 'helloTest', language: 'ro-ro' });
      expect(result).toBe("Missing configuration");
   });

   it("Should return missing configuration alert text for no quadminds api key", async () => {
      const result = await quadMinds.geocode(null, { quadMindsBaseUrl: 'helloTest', quadMindsApikey: null, language: 'ro-ro' });
      expect(result).toBe("Missing configuration");
   });

   it("Should add AvoidTypeahead flag to quadminds url", async () => {
      const spy = jest.spyOn(global.axios, 'get').mockImplementation(() => { throw new Error(errorMsg); });
      const result = await quadMinds.geocode('dummyAddress', { ...quadmindsData,  quadMindsAvoidTypeahead: '1' });
      expect(spy).toBeCalledWith(expect.stringContaining("&avoidTypeahead=1"));
   });

   it("Should not add AvoidTypeahead flag to quadminds url", async () => {
      const spy = jest.spyOn(global.axios, 'get').mockImplementation(() => { throw new Error(errorMsg); });
      const result = await quadMinds.geocode('dummyAddress', quadmindsData);
      expect(spy).toBeCalledWith(expect.not.stringContaining("&avoidTypeahead=1"));
   });

   it("should throw error", async () => {
      const errorMsg = "Error message from the mock";
      const spy = jest.spyOn(global.axios, 'get').mockImplementation(() => { throw new Error(errorMsg); });
      const result = await quadMinds.geocode('Budapest', quadmindsData);
      expect(result).toBe(errorMsg);
      expect(spy).toHaveBeenCalledTimes(1);
   });

   it("should return not an array static message", async () => {
      const spy = jest.spyOn(global.axios, 'get').mockImplementation(() => ({ headers: {}, data: 'hello' }));
      const expected = "Quadminds return value is not an array";
      const result = await quadMinds.geocode('Budapest', quadmindsData);
      expect(result).toEqual(expected);
      expect(spy).toHaveBeenCalledTimes(1);
   });

   it("should return error property of quadminds call result data", async () => {
      const spy = jest.spyOn(global.axios, 'get').mockImplementation(() => ({ headers: {}, data: { "error": "Not Authorized" } }));
      const expected = 'Not Authorized';
      const result = await quadMinds.geocode('Budapest', quadmindsData);
      expect(result).toEqual(expected);
      expect(spy).toHaveBeenCalledTimes(1);
   });

   it("should return data from quadminds", async () => {
      const spy = jest.spyOn(global.axios, 'get').mockImplementation(() => ({ headers: {}, data: ['first', 'second'] }));
      const expected = ['first', 'second'];
      const address = "Budapest 12";
      const result = await quadMinds.geocode(address, quadmindsData);
      expect(result).toEqual(expected);
      expect(spy).toHaveBeenCalledTimes(1);
   });

   it("should called with correct url", async () => {
      const spy = jest.spyOn(global.axios, 'get').mockImplementation(() => ({ headers: {}, data: ['first', 'second'] }));
      const address = "Budapest 12";
      const result = await quadMinds.geocode(address, quadmindsData);
      let url = "https://saas.quadminds.com/api/services/geocode?key=0imfnc8mVLWwsAawjYr4Rx&completeAddress=Budapest+12&language=ro-ro";
      expect(spy).toHaveBeenCalledTimes(1);
      expect(spy).toBeCalledWith(url);
   });

   it("should called with correct url, without language", async () => {
      const spy = jest.spyOn(global.axios, 'get').mockImplementation(() => ({ headers: {}, data: ['first', 'second'] }));
      const address = "Budapest 12";
      const result = await quadMinds.geocode(address, quadmindsDataWithoutLanguage);
      let url = "https://saas.quadminds.com/api/services/geocode?key=0imfnc8mVLWwsAawjYr4Rx&completeAddress=Budapest+12";
      expect(spy).toHaveBeenCalledTimes(1);
      expect(spy).toBeCalledWith(url);
   });

   afterEach(() => {
      jest.restoreAllMocks();
   });

});