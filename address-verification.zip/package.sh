#! /bin/bash

mkdir zip;
cd zip
zip -j -X healthcheck_lambda.zip ../src/lambdas/healthcheck.js ../src/package.json
zip -j -X quadminds_autocomplete_lambda.zip ../src/lambdas/quadminds-autocomplete.js ../src/package.json
zip -j -X quadminds_addressdetails_lambda.zip ../src/lambdas/quadminds-addressdetails.js ../src/package.json
cd ../src/layers
touch -t '202201010000.00' `find .`
zip -r -X ../../zip/quadminds_lambda_layer.zip ./address-validator-layer/*