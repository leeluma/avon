#! /bin/bash


npm ci --prefix src/layers/address-validator-layer