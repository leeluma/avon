# leap-infra-be-address-verification

Terraform repository for Address validation service and its connected infrastructure componenets.

### What is this repository for? ###

Repository is dedicated to define AWS Infrastucture elements on prod/non-prod accounts of OmniCom.