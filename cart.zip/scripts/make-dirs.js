/**
 * This file is required so the preinstall script
 * will work on all platforms that this project should
 * support: Windows, Linux, Mac
 */

const fs = require('fs');

const mkdirP = (dir) => {
  if (!fs.existsSync(dir)) {
    console.log(`Creating ${dir}`);
    fs.mkdirSync(dir);
  } else {
    console.log(`Skipping creating ${dir} because it already exists`);
  }
};

mkdirP('./artifacts');
mkdirP('./logs');
