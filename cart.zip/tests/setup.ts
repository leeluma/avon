import { logger } from '../src/lib';

logger.info('Placeholder setup.ts for when the tests are properly configured and implemented');
