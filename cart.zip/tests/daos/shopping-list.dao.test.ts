import faker from '@faker-js/faker';
import {
  ShoppingList,
} from '@commercetools/platform-sdk';
import { CtClient } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import Mock = jest.Mock;
import { ShoppingListDao } from '../../src/daos';
import { stubMarket, stubShoppingList } from '../__stubs__';
import { stubCtClient } from '../__stubs__/ct-client.stub';
import { graphql } from '../../src/graphql';

describe('ShoppingListDao', () => {
  let shoppingListDao: ShoppingListDao;

  let ctClient: CtClient;
  let market: MarketInfo;
  let post: Mock;
  let withId: Mock;
  let get: Mock;
  let execute: Mock;
  let gql: typeof graphql;

  let shoppingList: ShoppingList;

  beforeEach(() => {
    market = stubMarket();

    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    ctClient = stubCtClient(market.country, {
      shoppingLists: jest.fn().mockReturnValueOnce({ withId, post, get }),
      graphql: jest.fn().mockReturnValueOnce({ post }),
    });

    gql = {
      getProducts: Promise.resolve('query () { product {} }'),
      getShoppingListById: Promise.resolve('query () { shoppingList {} }'),
      getCartPaymentInfo: Promise.resolve('query () { cart {} }'),
      getInventoriesById: Promise.resolve('query () { Inventories {} }'),
      getDiscountcodeById: Promise.resolve('query () { discountCode {} }'),
      getShippingMethods: Promise.resolve('query () { shippingMethods {} }'),
    };
    shoppingList = stubShoppingList(market);
    shoppingListDao = new ShoppingListDao({ ctClient, graphql: gql });
  });

  describe('findGraphQLOne()', () => {
    let shoppingListDto: ShoppingList;
    let ctResponse: any;

    beforeEach(() => {
      shoppingListDto = stubShoppingList(market);
      ctResponse = { body: { data: { shoppingList } } };
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await shoppingListDao.findGraphQLOne(market, shoppingListDto.id);
      expect(result).toBe(shoppingList);
    });

    test('throws error if the GQL returns 0 item test 1', async () => {
      ctResponse.body.data.shoppingList = null;
      execute.mockReturnValueOnce(ctResponse);

      const result = await shoppingListDao.findGraphQLOne(market, shoppingListDto.id);
      expect(result).toBe(undefined);
    });

    test('rethrows HTTP errors', async () => {
      const error = new Error('Something went wrong');
      (error as any).body = {};
      execute.mockRejectedValueOnce(error);

      const result = shoppingListDao.findGraphQLOne(market, shoppingListDto.id);

      await expect(result).rejects.toThrow(error);
    });
  });
});
