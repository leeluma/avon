import faker from '@faker-js/faker';
import axios from 'axios';
import { MarketInfo } from '../../src/middlewares';
import { stubMarket, stubMagnoliaInfo } from '../__stubs__';
import Mock = jest.Mock;
import { MagnoliaDao } from '../../src/daos';
import { MagnoliaUri } from '../../src/common/constants';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import { axiosOptions } from '../../src/lib';

jest.mock('axios');

describe('Magnolia Dao testing Suit', () => {
  let magnoliaDao: MagnoliaDao;
  let market: MarketInfo;
  let magnolia: MagnoliaInfo;
  let magnoliaBasePath: string;
  const templateName = faker.datatype.string();
  const mockResponse = {
    data: {
      name: faker.datatype.string(),
      path: faker.datatype.string(),
      id: faker.datatype.uuid(),
      nodeType: faker.datatype.string(),
      title: faker.datatype.string(),
      facebook: {
        name: faker.datatype.string(),
        path: faker.datatype.string(),
      },
      twitter: {
        name: faker.datatype.string(),
        path: faker.datatype.string(),
      },
    },
  };
  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();
    magnoliaBasePath = faker.internet.url();
    /* Stubs */
    magnoliaDao = new MagnoliaDao();
  });

  // Unite test case for getCartDataFromMagnolia() method
  describe('getCartDataFromMagnolia()', () => {
    beforeEach(() => {
      //
    });

    test('returns magnolia response body', async () => {
      /* Prepare */
      const queryParams = `lang=${market.locale}-${market.country}`;
      let cartUrl = `${magnolia.url}${MagnoliaUri.cart}{{country}}/cart?${queryParams}`;
      cartUrl = cartUrl.replace('{{country}}', `${magnolia.marketPath}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: cartUrl,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getCartDataFromMagnolia(market, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(
        1,
        config,
      );
    });

    test('Failed to fetch magnolia data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getCartDataFromMagnolia(market, magnolia));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch cart data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getTemplateDataFromMagnolia()', () => {
    test('returns magnolia template response body', async () => {
      /* Prepare */
      const templateUrl = `${magnolia.url}${MagnoliaUri.template}${templateName}`;
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: templateUrl,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getTemplateDataFromMagnolia(templateName, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(
        1,
        config,
      );
    });

    test('Failed to fetch magnolia template data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getTemplateDataFromMagnolia(templateName, magnolia));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch Cart template data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getPriceFormatSettings()', () => {
    test('returns price format response body', async () => {
      /* Prepare */
      const queryParams = `lang=${market.locale}-${market.country}`;
      let priceFormatUrl = `${magnoliaBasePath}${MagnoliaUri.priceFormat}?${queryParams}`;
      priceFormatUrl = priceFormatUrl.replace('{{country}}', `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: priceFormatUrl,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getPriceFormatSettings(market, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(
        1,
        config,
      );
    });

    test('Failed to fetch magnolia price format data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getPriceFormatSettings(market, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch price format settings data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getGlobalSettings()', () => {
    test('returns magnolia global setting response body', async () => {
      /* Prepare */
      const queryParams = `lang=${market.locale}-${market.country}`;
      let globalSettingsUrl = `${magnoliaBasePath}${MagnoliaUri.globalSettings}?${queryParams}`;
      globalSettingsUrl = globalSettingsUrl.replace('{{country}}', `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: globalSettingsUrl,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getGlobalSettings(market, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(
        1,
        config,
      );
    });

    test('returns magnolia global setting response body in case of magnoliaBasePath undefined', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getGlobalSettings(market, undefined);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia global setting data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getGlobalSettings(market, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch global settings data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
});
