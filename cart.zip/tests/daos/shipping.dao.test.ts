import faker from '@faker-js/faker';
import i18next from 'i18next';
import { CtClient, ApiError } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import { graphql } from '../../src/graphql';
import {
  shippingAddressDto, stubCtCartDto, stubMarket, stubDiscountedDto,
} from '../__stubs__';
import Mock = jest.Mock;
import { ShippingDao } from '../../src/daos';
import { stubCtClient } from '../__stubs__/ct-client.stub';
import { CartDto, ShippingAddressDto } from '../../src/dtos';

jest.mock('axios');

describe('CartDao', () => {
  let shippingDao: ShippingDao;
  let cartDto: CartDto;
  let ctClient: CtClient;
  let gql: typeof graphql;
  let market: MarketInfo;
  let post: Mock;
  let withId: Mock;
  let get: Mock;
  let execute: Mock;
  let replicate: Mock;
  beforeEach(() => {
    market = stubMarket();

    cartDto = stubCtCartDto();
    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    replicate = jest.fn().mockReturnValueOnce({ post });
    ctClient = stubCtClient(market.country, {
      carts: jest.fn().mockReturnValueOnce({ withId, post, replicate }),
      graphql: jest.fn().mockReturnValueOnce({ get, post }),
      discountCodes: jest.fn().mockReturnValueOnce({ withId, post }),
    });

    gql = {
      getProducts: Promise.resolve('query () { product {} }'),
      getShoppingListById: Promise.resolve('query () { shoppingList {} }'),
      getCartPaymentInfo: Promise.resolve('query () { cart {} }'),
      getInventoriesById: Promise.resolve('query () { Inventories {} }'),
      getDiscountcodeById: Promise.resolve('query () { discountCode {} }'),
      getShippingMethods: Promise.resolve('query () { shippingMethods {} }'),
    };

    shippingDao = new ShippingDao({ ctClient, graphql: gql });
  });

  describe('getShippingMethods()', () => {
    test('get data from shipping method by graphql query', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });
      /* Execute */
      await shippingDao.getShippingMethod(market);
      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
    });
    test('getShippingMethods() returns undefined if CtClient throws 404', async () => {
      /* Prepare */
      const notFoundError = new Error('Not Found');
      (notFoundError as any).statusCode = 404;
      execute.mockRejectedValueOnce(notFoundError);
      /* Execute */
      const result = await shippingDao.getShippingMethod(market);
      /* Verify */
      expect(result).toBe(undefined);
    });
    test('getShippingMethods() re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);
      /* Execute */
      const result = expect(() => shippingDao.getShippingMethod(market));
      /* Verify */
      await result.rejects.toThrow(isError);
    });
  });

  describe('setShippingAddress()', () => {
    let cart: any;
    let shippingAddressDetails: ShippingAddressDto;
    let shippingAddressBody: any;
    beforeEach(() => {
      cart = stubCtCartDto();
      shippingAddressDetails = shippingAddressDto();
      shippingAddressBody = {
        version: cart.version,
        actions: [{
          action: 'setShippingAddress',
          address: {
            custom: {
              type: {
                typeId: 'type',
                key: 'address-type',
              },
              fields: {
                Address1: shippingAddressDetails.address1,
                Address2: shippingAddressDetails.address2,
                county: shippingAddressDetails.county,
              },
            },
            postalCode: shippingAddressDetails.postalCode,
            city: shippingAddressDetails.city,
            phone: shippingAddressDetails.phoneNumber,
            country: market.country,
          },
        }],
      };
    });

    test('queries ctClient with cart and set shipping address', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await shippingDao.setShippingAddress(market.country, cart, shippingAddressBody);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(1,
        { ID: cart.id });
      expect(post).toHaveBeenNthCalledWith(1,
        {
          body: shippingAddressBody,
        });
    });

    test('returns ctClient response body for set shipping address', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await shippingDao.setShippingAddress(market.country, cart, shippingAddressDetails as any);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => shippingDao.setShippingAddress(market.country, cart, shippingAddressDetails as any));

      /* Verify */
      await result.rejects.toThrow(isError);
    });
  });
});
