import faker from '@faker-js/faker';
import i18next from 'i18next';
import { Cart } from '@commercetools/platform-sdk';
import axios, { AxiosRequestConfig } from 'axios';
import HttpStatusCodes from 'http-status-codes';
import { CtClient, ApiError } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import { graphql } from '../../src/graphql';
import {
  shippingAddressDto, stubCtCartDto, stubMarket, stubDiscountedDto,
} from '../__stubs__';
import { createCartDraft } from '../../src/common/daos.helper';
import Mock = jest.Mock;
import { CartDao } from '../../src/daos';
import { stubCtClient } from '../__stubs__/ct-client.stub';
import { CartDto, ShippingAddressDto } from '../../src/dtos';
import { RESPONSE_KEY } from '../../src/common/constants';

jest.mock('axios');

describe('CartDao', () => {
  let cartDao: CartDao;
  let cartDto: CartDto;
  let ctClient: CtClient;
  let gql: typeof graphql;
  let market: MarketInfo;
  let post: Mock;
  let withId: Mock;
  let get: Mock;
  let execute: Mock;
  let replicate: Mock;
  let beOrderUrl: string;
  let discountCodeDao:any;
  beforeEach(() => {
    market = stubMarket();

    cartDto = stubCtCartDto();
    discountCodeDao = stubDiscountedDto();
    beOrderUrl = faker.internet.url();
    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    replicate = jest.fn().mockReturnValueOnce({ post });
    ctClient = stubCtClient(market.country, {
      carts: jest.fn().mockReturnValueOnce({ withId, post, replicate }),
      graphql: jest.fn().mockReturnValueOnce({ get, post }),
      discountCodes: jest.fn().mockReturnValueOnce({ withId, post }),
    });

    gql = {
      getProducts: Promise.resolve('query () { product {} }'),
      getShoppingListById: Promise.resolve('query () { shoppingList {} }'),
      getCartPaymentInfo: Promise.resolve('query () { cart {} }'),
      getInventoriesById: Promise.resolve('query () { Inventories {} }'),
      getDiscountcodeById: Promise.resolve('query () { discountCode {} }'),
      getShippingMethods: Promise.resolve('query () { shippingMethods {} }'),
    };

    cartDao = new CartDao({ ctClient, beOrderUrl, graphql: gql });
  });

  describe('createCart()', () => {
    test('queries CommerceTools Client with the cartDraft', async () => {
      /* Prepare */
      const { lineItems, anonymousId, customerId } = cartDto;
      const currency = 'RON';
      const { country } = market;
      const cartData = {
        country,
        currency,
        anonymousId,
        customerId,
        lineItems,
      };
      const cartDraft = createCartDraft(currency, cartData);
      execute.mockReturnValueOnce({ body: undefined });
      /* Execute */
      await cartDao.createCart(market.country, currency, lineItems, anonymousId, customerId);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1,
        { body: cartDraft });
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      const { anonymousId, customerId, lineItems } = cartDto;
      const currency = 'RON';
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.createCart(market.country, currency, lineItems, anonymousId, customerId);
      /* Verify */
      expect(result).toBe(cartDto);
    });
  });

  describe('removeLineItem()', () => {
    let cart: any;
    let lineItemId: string;
    let removeLineItemBody: any;
    beforeEach(() => {
      cart = {
        id: faker.datatype.uuid(),
        version: faker.datatype.number(),
        lineItems: [{
          lineItemId: faker.datatype.uuid(),
          productId: faker.datatype.uuid(),
          productKey: faker.datatype.string(),
          name: faker.datatype.string(),
          skuCode: faker.datatype.string(),
        }],
      };
      lineItemId = faker.datatype.uuid();
      removeLineItemBody = {
        version: cart.version,
        actions: [{
          action: 'removeLineItem',
          lineItemId,
        },
        { action: 'setShippingMethod' },
        ],
      };
    });

    test('queries ctClient with cart id and remove line item', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.removeLineItem(market.country, cart, lineItemId);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(1,
        { ID: cart.id });
      expect(post).toHaveBeenNthCalledWith(1,
        {
          body: removeLineItemBody,
          queryArgs: { expand: ['lineItems[*].discountedPricePerQuantity[*].discountedPrice.includedDiscounts[*].discount'] },
        });
    });

    test('returns ctClient response body for remove line item', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.removeLineItem(market.country, cart, lineItemId);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('returns 404 if CtClient throws 404 for remove line item', async () => {
      /* Prepare */
      const isError = new ApiError(404, `Cart with lineItemId "${lineItemId}" not found.`);
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.removeLineItem(market.country, cart, lineItemId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.removeLineItem(market.country, cart, lineItemId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });
  });

  describe('changeLineItemQuantity()', () => {
    let cart: any;
    let lineItemId: string;
    let quantity: number;
    let changeLineItemQuantityBody: any;
    beforeEach(() => {
      cart = {
        id: faker.datatype.uuid(),
        version: faker.datatype.number(),
      };
      lineItemId = faker.datatype.uuid();
      quantity = 1;
      changeLineItemQuantityBody = {
        version: cart.version,
        actions: [{
          action: 'recalculate',
          updateProductData: true,
        },
        {
          action: 'changeLineItemQuantity',
          lineItemId,
          quantity,
        }],
      };
    });

    test('queries ctClient with cart id and update line item quantity', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.changeLineItemQuantity(market.country, cart, lineItemId, quantity);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(1,
        { ID: cart.id });
      expect(post).toHaveBeenNthCalledWith(1,
        {
          body: changeLineItemQuantityBody,
          queryArgs: { expand: ['lineItems[*].discountedPricePerQuantity[*].discountedPrice.includedDiscounts[*].discount'] },
        });
    });

    test('returns ctClient response body for update line item quantity', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.changeLineItemQuantity(market.country, cart, lineItemId, quantity);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('returns 404 if CtClient throws 404 for change line item quantity', async () => {
      /* Prepare */
      const isError = new ApiError(404, `Cart with lineItemId "${lineItemId}" not found.`);
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.changeLineItemQuantity(market.country, cart, lineItemId, quantity));

      /* Verify */
      await result.rejects.toThrow(isError);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.changeLineItemQuantity(market.country, cart, lineItemId, quantity));

      /* Verify */
      await result.rejects.toThrow(isError);
    });
  });

  describe('addProductToCart()', () => {
    let customerId: string;
    let anonymousId: string;
    let channelKey: string;
    let cartId: string;
    let sku: string;
    let quantity: number;
    let productKey: string;

    let cart: Cart;

    beforeEach(() => {
      customerId = faker.datatype.uuid();
      cartId = faker.datatype.uuid();
      sku = faker.datatype.uuid();
      quantity = faker.datatype.number();
      productKey = faker.datatype.uuid();
      anonymousId = faker.datatype.uuid();
      channelKey = 'DC-RO';
      cart = { id: faker.datatype.uuid() } as Cart;
    });

    test('builds axiosConfig', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockReturnValueOnce({ data: { data: cart } });

      /* Execute */
      const data = {
        market,
        channelKey,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
      };
      await cartDao.addProductToCart(data);

      /* Verify */
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(
        1,
        {
          method: 'post',
          url: `${beOrderUrl.replace('{{MARKET}}', market.localeAndCountry)}/carts`,
          headers: {
            'Content-Type': 'application/json',
            Accepts: 'application/json',
          },
          data: {
            anonymousId,
            customerId,
            channelKey,
            cartId,
            lineItems: { sku, quantity, productKey },
          },
        },
      );
    });

    test('returns data from leap-be-order', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockReturnValueOnce({ data: { data: cart } });

      /* Execute */
      const data = {
        market,
        channelKey,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
      };
      const response = await cartDao.addProductToCart(data);

      /* Verify */
      expect(response).toBe(cart);
    });

    test('rethrows connection errors', async () => {
      const connectionError = new Error('something went wrong');
      (axios as unknown as Mock).mockRejectedValueOnce(connectionError);
      const data = {
        market,
        channelKey,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
      };
      const response = () => cartDao.addProductToCart(data);

      await expect(response).rejects.toThrow(connectionError);
    });

    test('returns leap-be-order errors', async () => {
      const beOrderError = Object.assign(
        new Error('something went wrong'),
        {
          response: {
            status: HttpStatusCodes.NOT_FOUND,
            data: { errors: ['sku not found'] },
          },
        },
      );
      (axios as unknown as Mock).mockRejectedValueOnce(beOrderError);
      const data = {
        market,
        channelKey,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
      };
      const response = () => cartDao.addProductToCart(data);

      await expect(response).rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, ['sku not found']),
      );
    });
  });
  describe('recalculateCart()', () => {
    let cart: any;
    let recalculateCartBody: any;
    let queryArgs;

    beforeEach(() => {
      cart = {
        id: faker.datatype.uuid(),
        version: faker.datatype.number(),
      };
      recalculateCartBody = {
        version: cart.version,
        actions: [{
          action: 'recalculate',
          updateProductData: true,
        }],
      };
      queryArgs = { expand: ['lineItems[*].discountedPricePerQuantity[*].discountedPrice.includedDiscounts[*].discount'] };
    });

    test('queries ctClient to recalculate cart', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.recalculateCart(market, cart);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(1,
        { ID: cart.id });
      expect(post).toHaveBeenNthCalledWith(1,
        {
          body: recalculateCartBody,
          queryArgs,
        });
    });

    test('returns ctClient response body for recalculated cart', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.recalculateCart(market, cart);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('returns 400 if CtClient throws 400 for recalculated cart', async () => {
      /* Prepare */
      const isError = new ApiError(400, i18next.t('error.cartIdNotFound', { cartId: cart.id }));
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.recalculateCart(market, cart));

      /* Verify */
      await result.rejects.toThrow(isError);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.recalculateCart(market, cart));

      /* Verify */
      await result.rejects.toThrow(isError);
    });
  });

  /**
   * Unit test case for getCartPaymentInfo function of cart.dao
   */
  describe('getCartPaymentInfo()', () => {
    let ctResponse: any;
    const cartId = faker.datatype.uuid();
    beforeEach(() => {
      ctResponse = {
        body: {
          data: {
            cart: {
              ...cartDto,
            },
          },
        },
      };
    });

    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      const locale = market.locale.toLocaleUpperCase();
      const expectedBody = {
        query: 'query () { cart {} }',
        variables: {
          cartId,
          locale,
        },
      };
      execute.mockReturnValueOnce(ctResponse);

      /* Execute */
      await cartDao.getCartPaymentInfo(market, cartId);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: expectedBody },
      );
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await cartDao.getCartPaymentInfo(market, cartId);

      expect(result).toBe(ctResponse.body.data.cart);
    });

    test('returns the result data NULL from the GraphQL server', async () => {
      const ctResponses = {
        body: {
          data: null,
          errors: {
            error: 'Malformed parameter: UUID string is invalid',
          },
        },
      };
      execute.mockReturnValueOnce(ctResponses);

      const result = await cartDao.getCartPaymentInfo(market, cartId);

      expect(result).toBeUndefined();
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {};
      execute.mockRejectedValueOnce(err);

      const result = cartDao.getCartPaymentInfo(market, cartId);

      await expect(result).rejects.toThrow(err);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);
      /* Execute */
      const result = expect(() => cartDao.getCartPaymentInfo(market, cartId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });

    test('returns 404 if CtClient throws 404 for getDiscountById', async () => {
      /* Prepare */
      const isError = new ApiError(404, `Payment info with cartId "${cartId}" not found.`);
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.getCartPaymentInfo(market, cartId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });
  });

  describe('getCartById()', () => {
    let ctResponse: any;
    const cartId = faker.datatype.uuid();
    beforeEach(() => {
      ctResponse = {
        body: {
          data: {
            cart: {
              ...cartDto,
            },
          },
        },
      };
    });

    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      const locale = market.locale.toLocaleUpperCase();
      const expectedBody = {
        query: 'query () { cart {} }',
        variables: {
          cartId,
          locale,
        },
      };
      execute.mockReturnValueOnce(ctResponse);

      /* Execute */
      await cartDao.getCartById(market, cartId);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: expectedBody },
      );
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await cartDao.getCartById(market, cartId);

      expect(result).toBe(ctResponse.body.data.cart);
    });

    test('returns the result data NULL from the GraphQL server', async () => {
      const ctResponses = {
        body: {
          data: null,
          errors: {
            error: 'Malformed parameter: UUID string is invalid',
          },
        },
      };
      execute.mockReturnValueOnce(ctResponses);

      const result = await cartDao.getCartById(market, cartId);

      expect(result).toBeUndefined();
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {};
      execute.mockRejectedValueOnce(err);

      const result = cartDao.getCartById(market, cartId);

      await expect(result).rejects.toThrow(err);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);
      /* Execute */
      const result = expect(() => cartDao.getCartById(market, cartId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });

    test('returns 404 if CtClient throws 404 for getCartById', async () => {
      /* Prepare */
      const isError = new ApiError(404, `Cart with CartId "${cartId}" not found.`);
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.getCartById(market, cartId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });
  });
  describe('getDiscountById()', () => {
    let ctResponse: any;
    const discountCodeId = faker.datatype.uuid();
    beforeEach(() => {
      ctResponse = {
        body: {
          data: {
            discountCode: {
              ...discountCodeDao,
            },
          },
        },
      };
    });

    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      const expectedBody = {
        query: 'query () { discountCode {} }',
        variables: {
          id: discountCodeId,
        },
      };
      execute.mockReturnValueOnce(ctResponse);

      /* Execute */
      await cartDao.getDiscountById(market, discountCodeId);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: expectedBody },
      );
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await cartDao.getDiscountById(market, discountCodeId);

      expect(result).toBe(ctResponse.body.data.discountCode);
    });

    test('returns the result data NULL from the GraphQL server', async () => {
      const ctResponses = {
        body: {
          data: null,
          errors: {
            error: 'Malformed parameter: UUID string is invalid',
          },
        },
      };
      execute.mockReturnValueOnce(ctResponses);

      const result = await cartDao.getDiscountById(market, discountCodeId);

      expect(result).toBeUndefined();
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {};
      execute.mockRejectedValueOnce(err);

      const result = cartDao.getDiscountById(market, discountCodeId);

      await expect(result).rejects.toThrow(err);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);
      /* Execute */
      const result = expect(() => cartDao.getDiscountById(market, discountCodeId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });
    test('returns 404 if CtClient throws 404 for getDiscountById', async () => {
      /* Prepare */
      const isError = new ApiError(404, `Discountcode with discountCodeId "${discountCodeId}" not found.`);
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.getDiscountById(market, discountCodeId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });
  });

  describe('replicateCartById()', () => {
    const cartId = faker.datatype.uuid();
    let cart: any;
    let cartReference: any;
    beforeEach(() => {
      cart = stubCtCartDto();
      cartReference = {
        reference: {
          typeId: 'cart',
          id: cartId,
        },
      };
    });

    test('post cart reference to replicate', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.replicateCartById(market.country, cartId);

      /* Verify */
      expect(replicate).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1,
        {
          body: cartReference,
        });
    });

    test('returns ctClient response body for replicate cart', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.replicateCartById(market.country, cartId);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.replicateCartById(market.country, cartId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });

    test('returns 400 if CtClient throws 400 for replicate cart', async () => {
      /* Prepare */
      const isError = new ApiError(400, i18next.t('error.cartIdNotFound', { cartId: cart.id }));
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.replicateCartById(market.country, cartId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });
  });
});
