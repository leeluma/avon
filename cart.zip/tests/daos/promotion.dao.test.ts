import faker from '@faker-js/faker';
import { CtClient, ApiError } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import { graphql } from '../../src/graphql';
import {
  stubCtCartDto, stubMarket, stubDiscountedDto,
} from '../__stubs__';
import Mock = jest.Mock;
import { PromotionDao } from '../../src/daos';
import { stubCtClient } from '../__stubs__/ct-client.stub';
import { CartDto } from '../../src/dtos';

jest.mock('axios');

describe('CartDao', () => {
  let promotionDao: PromotionDao;
  let cartDto: CartDto;
  let ctClient: CtClient;
  let gql: typeof graphql;
  let market: MarketInfo;
  let post: Mock;
  let withId: Mock;
  let get: Mock;
  let execute: Mock;
  let replicate: Mock;
  let discountCodeDao:any;
  beforeEach(() => {
    market = stubMarket();
    cartDto = stubCtCartDto();
    discountCodeDao = stubDiscountedDto();
    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    replicate = jest.fn().mockReturnValueOnce({ post });
    ctClient = stubCtClient(market.country, {
      carts: jest.fn().mockReturnValueOnce({ withId, post, replicate }),
      graphql: jest.fn().mockReturnValueOnce({ get, post }),
      discountCodes: jest.fn().mockReturnValueOnce({ withId, post }),
    });

    gql = {
      getProducts: Promise.resolve('query () { product {} }'),
      getShoppingListById: Promise.resolve('query () { shoppingList {} }'),
      getCartPaymentInfo: Promise.resolve('query () { cart {} }'),
      getInventoriesById: Promise.resolve('query () { Inventories {} }'),
      getDiscountcodeById: Promise.resolve('query () { discountCode {} }'),
      getShippingMethods: Promise.resolve('query () { shippingMethods {} }'),
    };

    promotionDao = new PromotionDao({ ctClient, graphql: gql });
  });

  describe('applyPromotion()', () => {
    let cart: any;
    let promotionCode: string;
    let applyPromotionBody: any;
    let action:string;
    let queryArgs:any;
    let promotionId: string;
    beforeEach(() => {
      action = 'addDiscountCode';
      cart = {
        id: faker.datatype.uuid(),
        version: faker.datatype.number(),
      };
      promotionCode = faker.datatype.string();
      promotionId = faker.datatype.string();
      applyPromotionBody = {
        version: cart.version,
        actions: [{
          action: 'recalculate',
          updateProductData: true,
        },
        {
          action,
          code: promotionCode,
        }],
      };
      queryArgs = {
        expand: ['discountCodes[*].discountCode',
          'lineItems[*].discountedPricePerQuantity[*].discountedPrice.includedDiscounts[*].discount',
        ],
      };
    });

    test('queries ctClient with cart id and Apply the promotion', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await promotionDao.applyPromotion(market.country, cart, promotionCode);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(1,
        { ID: cart.id });
      expect(post).toHaveBeenNthCalledWith(1,
        {
          body: applyPromotionBody,
          queryArgs,
        });
    });

    test('returns ctClient response body for apply cart promotion', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await promotionDao.applyPromotion(market.country, cart, promotionCode);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('returns 400 if Promotioncode is not found', async () => {
      /* Prepare */
      const isError = new ApiError(400, 'Promo code not found');
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => promotionDao.applyPromotion(market.country, cart, promotionCode));

      /* Verify */
      await result.rejects.toThrow(isError);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => promotionDao.applyPromotion(market.country, cart, promotionCode));

      /* Verify */
      await result.rejects.toThrow(isError);
    });

    test('returns ctClient response body after removing promotion', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await promotionDao.removePromotion(market.country, cart, promotionCode, promotionId);

      /* Verify */
      expect(withId).toHaveBeenNthCalledWith(1,
        { ID: cart.id });
      expect(result).toBe(cartDto);
    });

    test('returns 400 if Promotion code is not found while removing promotion', async () => {
      /* Prepare */
      const isError = new ApiError(400, 'Promo code not found in cart');
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => promotionDao.removePromotion(market.country, cart, promotionCode, promotionId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });

    test('re-throws non-400 ctClient errors while removing promotion', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => promotionDao.removePromotion(market.country, cart, promotionCode, promotionId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });
  });
});
