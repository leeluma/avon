import faker from '@faker-js/faker';

export const stubGlobalSettings = (
  config: Partial<any> = {},
): any => {
  return {
    '@name': faker.datatype.string(),
    '@path': faker.datatype.string(),
    '@id': faker.datatype.uuid(),
    '@nodeType': faker.datatype.string(),
    name: faker.datatype.string(),
    warehouseSettings: {
      '@name': faker.datatype.string(),
      '@path': faker.datatype.string(),
      '@id': faker.datatype.uuid(),
      '@nodeType': faker.datatype.string(),
      defaultWarehouse: 'DC-RO',
      isSingleWarehouse: 'true',
      '@nodes': [],
    },
    priceFormat: {
      '@name': faker.datatype.string(),
      '@path': faker.datatype.string(),
      '@id': faker.datatype.uuid(),
      '@nodeType': faker.datatype.string(),
      ccy: 'RON',
      showDecimalZero: 'true',
      thousandSeperator: ',',
      noOfDigit: '2',
      currencyPlacement: 'before',
      decimalPoint: '.',
      isVatIncluded: 'true',
      vatIncludedMessage: 'Vat Include',
      baseMeasure: {
        '@name': 'baseMeasure',
        '@path': '/ro/settings/priceFormat/baseMeasure',
        '@id': 'ebae5260-ab77-4651-b611-5218f9851bff',
        '@nodeType': 'mgnl:contentNode',
        translation: 'mg',
        unitPriceBaseMeasure: '100 mg',
        containerSizeLimit: '10',
        '@nodes': [],
      },
      '@nodes': [
        'baseMeasure',
      ],
    },
    '@nodes': [
      'warehouseSettings',
      'priceFormat',
    ],
    ...config,
  };
};
