import faker from '@faker-js/faker';
import { stubTrackingFields } from './trackingfields.stub';
import {
  CtLineItemDto, ShippingInfo, ShippingMethodServiceDto, ShippingAddressDto,
} from '../../src/dtos';

export const stubCtCartDraftDto = (
  config = {},
) => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    totalPrice: faker.commerce.price(),
    customerId: faker.datatype.number(),
    lineItems: [],
    discountCodes: [],
    shippingAddress: {},
    shippingInfo: {},
    paymentInfo: {},
    ...stubTrackingFields(),
    ...config,
  };
};
export const stubCtCartDraftDtoWithEmptyShipping = (
  config = {},
) => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    totalPrice: faker.commerce.price(),
    customerId: faker.datatype.number(),
    lineItems: [],
    discountCodes: [],
    shippingAddress: {},
    paymentInfo: {},
    ...stubTrackingFields(),
    ...config,
  };
};
export const stubCtCartLineItemDraftDto = (
  config: Partial<CtLineItemDto> = {},
): CtLineItemDto => {
  return {
    id: faker.datatype.string(),
    productId: faker.datatype.string(),
    name: { ro: faker.datatype.string() },
    variant: [],
    quantity: faker.datatype.number(),
    lastModifiedAt: faker.datatype.string(),
    ...config,
  };
};

export const stubCtCartShippingInfo = (
  config: Partial<ShippingInfo> = {},
): ShippingInfo => {
  return {
    shippingMethodName: faker.datatype.string(),
    price: {
      type: faker.datatype.string(),
      currencyCode: faker.finance.currencyCode(),
      centAmount: 2048,
      fractionDigits: faker.datatype.number({
        min: 0,
        max: 2,
      }),
    },
    ...config,
  };
};

export const shippingMethodDto = (
  config: Partial<ShippingMethodServiceDto> = {},
): ShippingMethodServiceDto => {
  return {
    id: faker.datatype.uuid(),
    name: faker.datatype.string(),
    isDefault: true,
    zoneRates: [
      {
        shippingRates: [
          {
            price: {
              centAmount: 5000,
              currencyCode: 'RON',
              fractionDigits: 2,
            },
            freeAbove: {
              centAmount: 20000,
              currencyCode: 'RON',
              fractionDigits: 2,
            },
          },
        ],
      },
    ],
  };
};
export const shippingAddressDto = (): ShippingAddressDto => {
  return {
    address1: faker.datatype.string(),
    address2: faker.datatype.string(),
    postalCode: faker.datatype.string(),
    city: faker.datatype.string(),
    county: faker.datatype.string(),
    phoneNumber: faker.datatype.string(),
  };
};

export const shippingAddressCtRes = () => {
  return {
    postalCode: faker.datatype.string(),
    city: faker.datatype.string(),
    phone: faker.datatype.string(),
    county: faker.datatype.string(),
    custom: {
      fields: {
        Address1: faker.datatype.string(),
        Address2: faker.datatype.string(),
        county: faker.datatype.string(),
      },
    },
  };
};
