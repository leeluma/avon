import faker from '@faker-js/faker';
import { CtTrackingFieldsDto } from '../../src/dtos';

export const stubTrackingFields = (
  config: Partial<CtTrackingFieldsDto> = {},
): CtTrackingFieldsDto => {
  return {
    createdAt: faker.datatype.datetime().toISOString(),
    createdBy: {
      clientId: faker.datatype.uuid(),
      isPlatformClient: faker.datatype.boolean(),
    },
    lastModifiedAt: faker.datatype.datetime().toISOString(),
    lastModifiedBy: {
      clientId: faker.datatype.uuid(),
      isPlatformClient: faker.datatype.boolean(),
    },
    ...config,
  };
};
