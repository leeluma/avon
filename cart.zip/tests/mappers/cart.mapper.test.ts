import faker from '@faker-js/faker';
import i18next from 'i18next';
import { DiscountCode } from '@commercetools/platform-sdk';
import { CartMapper } from '../../src/mappers/cart.mapper';
import { DEFAULT_INVENTORY_QUANTITY } from '../../src/common/constants';
import { ShippingDao } from '../../src/daos';
import {
  stubCartServiceToMapper,
  stubCartMapperResult,
  stubCartServiceToMapper8,
  stubCartServiceToMapper9,
  shippingAddressCtRes,
  stubPriceFormatSettings,
  stubMarket,
  stubDiscountedDto,
} from '../__stubs__';
import { CartDto, GraphQLDiscountCode, ShippingMethodDto } from '../../src/dtos';
import { MarketInfo } from '../../src/middlewares';
import { ApiError } from '../../src/lib';

describe('CartMapper', () => {
  let cartMapper: CartMapper;
  let cart:any;
  let cartExpected:CartDto;
  let market: MarketInfo;
  let discountCode: GraphQLDiscountCode;
  let shippingDao:ShippingDao;
  beforeEach(() => {
    market = stubMarket();
    cartMapper = new CartMapper({ shippingDao });
    cart = stubCartServiceToMapper();
    cartExpected = stubCartMapperResult();
    discountCode = stubDiscountedDto();
  });
  test('cartToDto', () => {
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart, market, stubPriceFormatSettings(),
    {} as ShippingMethodDto, [], discountCode);

    /* Verify */
    expect(result).toMatchObject(cartExpected);
  });

  test('cart mapper with no lineItems', () => {
    const cart8 = stubCartServiceToMapper8();
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart8, market, stubPriceFormatSettings());

    /* Verify */
    expect(result.lineItems.length).toBe(0);
  });

  test('cart mapper discount DoesNotMatchCart', () => {
    const cart9 = stubCartServiceToMapper9();
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart9, market, stubPriceFormatSettings());

    /* Verify */
    expect(result.promotion?.promotionState).toBe('DoesNotMatchCart');
  });

  test('shippingAddressToDto mapper', () => {
    /* Prepare */
    const shippingAddressRes = shippingAddressCtRes();
    const shippingAddressExpected = {
      address1: shippingAddressRes.custom.fields.Address1,
      address2: shippingAddressRes.custom.fields.Address2,
      county: shippingAddressRes.custom.fields.county,
      city: shippingAddressRes.city,
      phoneNumber: shippingAddressRes.phone,
      postalCode: shippingAddressRes.postalCode,
    };
    /* Execute */
    const result = (cartMapper as any).shippingAddressToDto(shippingAddressRes);

    /* Verify */
    expect(result).toMatchObject(shippingAddressExpected);
  });

  test('shippingAddressToDto mapper having no address details', () => {
    /* Prepare */
    const shippingAddressDetails = {};
    const shippingAddressExpected = {
      address1: '',
      address2: '',
      postalCode: '',
      city: '',
      county: '',
      phoneNumber: '',
    };
    /* Execute */
    const result = (cartMapper as any).shippingAddressToDto(shippingAddressDetails);

    /* Verify */
    expect(result).toMatchObject(shippingAddressExpected);
  });

  test('lineItemsToDto lineItemVariantAttributesNotDefined', () => {
    /* Prepare */
    const cartData = {
      id: faker.datatype.uuid(),
      lineItems: [{
        lineItemId: faker.datatype.string(),
        productId: faker.datatype.string(),
        discountedPricePerQuantity: [
          {
            discountedPrice: {
              includedDiscounts: [
                {
                  discount: {
                    obj: {
                      custom: {
                        fields: {
                          'offer-category': {
                            id: faker.datatype.uuid(),
                          },
                        },
                      },
                    },
                  },
                },
              ],
            },
          },
        ],
      }],
    };
    /* Verify */
    const expectedError = new ApiError(400, i18next.t('error.lineItemVariantAttributesNotDefined'));

    /* Execute */
    expect(() => (cartMapper as any).lineItemsToDto(cartData.lineItems as any, market, {}))
      .toThrow(expectedError);
  });

  test('lineItemsToDto lineItemVariantSupplyChannelNotDefined', () => {
    /* Prepare */
    const cartData = {
      id: faker.datatype.uuid(),
      lineItems: [{
        lineItemId: faker.datatype.string(),
        productId: faker.datatype.string(),
        variant: {
          attributes: [{
            name: faker.datatype.string(),
            value: faker.datatype.string(),
          }],
        },
      }],
    };
    /* Verify */
    const expectedError = new ApiError(400, i18next.t('error.lineItemVariantSupplyChannelNotDefined'));

    /* Execute */
    expect(() => (cartMapper as any).lineItemsToDto(cartData.lineItems as any, market, {}))
      .toThrow(expectedError);
  });

  test('getLineItemAvailability  Channel not available', () => {
    const cartLineItemData = {
      variant: {
        availability: {},
      },
    };
    const supplyChannelId = faker.datatype.uuid();
    const getLineItemAvailabilityresponse = (cartMapper as any).getLineItemAvailability(
      cartLineItemData as any, supplyChannelId, [],
    );
    expect(getLineItemAvailabilityresponse)
      .toEqual({
        availableQuantity: DEFAULT_INVENTORY_QUANTITY,
        isAvailable: true,
        limitedStock: false,
      });
  });

  test('getLineItemAvailability  Channel with available', () => {
    const supplyChannelId = 'e58d62fe-cfb0-417a-b77f-cb8762aa12f8';
    const inventory = [
      {
        id: 'e58d62fe-cfb0-417a-b77f-cb8762aa12f8',
        custom: {
          customFieldsRaw: [
            {
              name: 'isLowAvailability',
              value: false,
            },
          ],
        },
      },
    ];
    const cartLineItemData = {
      variant: {
        availability: {
          channels: {
            'e58d62fe-cfb0-417a-b77f-cb8762aa12f8': {
              id: 'e58d62fe-cfb0-417a-b77f-cb8762aa12f8',
              availableQuantity: 1,
            },
          },
        },
      },
    };
    const getLineItemAvailabilityresponse = (cartMapper as any).getLineItemAvailability(
      cartLineItemData as any, supplyChannelId, inventory,
    );
    expect(getLineItemAvailabilityresponse)
      .toEqual({
        availableQuantity: 1,
        isAvailable: true,
        limitedStock: false,
      });
  });

  describe('getCartById()', () => {
    const inventoryId = faker.datatype.uuid();
    const supplyChannelId = faker.datatype.uuid();
    const channelData = {
      [supplyChannelId]: {
        isOnStock: faker.datatype.boolean(),
        availableQuantity: faker.datatype.number(),
        version: faker.datatype.number(),
        id: inventoryId,
      },
      [faker.datatype.uuid()]: {
        isOnStock: faker.datatype.boolean(),
        availableQuantity: faker.datatype.number(),
        version: faker.datatype.number(),
        id: faker.datatype.uuid(),
      },
    };
  });
  describe('getVatText()', () => {
    test('getVatText()', () => {
      /* Prepare */
      const priceFormat = {
        vatIncludedMessage: 'test',
        isVatIncluded: 'true',
      };
      /* Execute */
      const result = (cartMapper as any).getVatText(priceFormat);

      /* Verify */
      expect(result).toEqual('test');
    });

    test('getVatText() for false scenario', () => {
      /* Execute */
      const result = (cartMapper as any).getVatText({});

      /* Verify */
      expect(result).toEqual('');
    });
  });
});
