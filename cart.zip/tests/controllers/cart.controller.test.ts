import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubCtCartDto,
  stubCartAddProductToCartDto, stubShippingMethodDto, shippingAddressDto,
} from '../__stubs__';
import { CartController } from '../../src/controllers';
import { CartService, PromotionService, ShippingService } from '../../src/services';
import { MagnoliaInfo } from '../../src/dtos/common.dto';

import Mock = jest.Mock;
import {
  CartDto, CartAddProductToCartDto, ShippingMethodDto, ShippingAddressDto,
} from '../../src/dtos';

import { ApiError } from '../../src/lib';

describe('LeapApp', () => {
  /* System Under Test */
  let cartController: CartController;
  let magnolia : MagnoliaInfo;

  /* Dependencies */
  let cartService: CartService;
  let promotionService: PromotionService;
  let shippingService: ShippingService;
  let market: MarketInfo;
  let channelKey: 'DC-RO' | undefined;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();
    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes({ locals: { market } });
    promotionService = {
      promotion: jest.fn(),
      checkCartPaymentInfo: jest.fn(),
    } as any;

    shippingService = {
      getShippingMethod: jest.fn(),
      setShippingAddress: jest.fn(),
    } as any;
    /* Dependencies */
    cartService = {} as any;

    /* SUT */
    cartController = new CartController({ cartService, promotionService, shippingService });
  });

  describe('getById()', () => {
    let cartDto: CartDto;

    beforeEach(() => {
      cartService.getCartById = jest.fn();
      cartDto = stubCtCartDto();
      req.params.id = cartDto.id;
    });

    test('fetches data from cartService', async () => {
      /* Prepare */
      (cartService.getCartById as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartController.getCartById(req, res);

      /* Verify */
      expect(cartService.getCartById).toHaveBeenCalledTimes(1);
      expect(cartService.getCartById).toHaveBeenNthCalledWith(1,
        market, cartDto.id, undefined, undefined);
    });

    test('returns cartDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (cartService.getCartById as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartController.getCartById(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: cartDto,
      });
    });

    test('throws ApiError(NOT_FOUND) if cart does not exist', async () => {
      /* Prepare */
      (cartService.getCartById as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(400, `Cart with id "${cartDto.id}" not found.`);

      /* Execute */
      await expect(() => cartController.getCartById(req, res))
        .rejects.toThrow(expectedError);
    });
  });

  describe('removeLineItem()', () => {
    let cartDto: CartDto;

    beforeEach(() => {
      cartService.removeLineItem = jest.fn();
      cartDto = stubCtCartDto();
      req.params.cartId = cartDto.id;
      req.params.lineItemId = faker.datatype.uuid();
    });

    test('fetches data from cartService', async () => {
      /* Prepare */
      (cartService.removeLineItem as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartController.removeLineItem(req, res);

      /* Verify */
      expect(cartService.removeLineItem).toHaveBeenCalledTimes(1);
      expect(cartService.removeLineItem).toHaveBeenNthCalledWith(1,
        market, cartDto.id, req.params.lineItemId);
    });

    test('returns cartDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (cartService.removeLineItem as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartController.removeLineItem(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: cartDto,
      });
    });

    test('throws ApiError(NOT_FOUND) if cart does not exist', async () => {
      /* Prepare */
      (cartService.removeLineItem as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(404, `Cart with key "${cartDto.id}" not found.`);

      /* Execute */
      await expect(() => cartController.removeLineItem(req, res))
        .rejects.toThrow(expectedError);
    });
  });

  describe('changeLineItemQuantity()', () => {
    let cartDto: CartDto;

    beforeEach(() => {
      cartService.changeLineItemQuantity = jest.fn();
      cartDto = stubCtCartDto();
      req.params.cartId = cartDto.id;
      req.params.lineItemId = faker.datatype.uuid();
      req.body.quantity = '1';
    });

    test('fetches data from cartService', async () => {
      /* Prepare */
      (cartService.changeLineItemQuantity as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartController.changeLineItemQuantity(req, res);

      /* Verify */
      expect(cartService.changeLineItemQuantity).toHaveBeenCalledTimes(1);
      expect(cartService.changeLineItemQuantity).toHaveBeenNthCalledWith(1,
        market, cartDto.id, req.params.lineItemId, 1);
    });

    test('returns cartDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (cartService.changeLineItemQuantity as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartController.changeLineItemQuantity(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: cartDto,
      });
    });

    test('throws ApiError(NOT_FOUND) if cart does not exist', async () => {
      /* Prepare */
      (cartService.changeLineItemQuantity as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(404, `Cart with key "${cartDto.id}" not found.`);

      /* Execute */
      await expect(() => cartController.changeLineItemQuantity(req, res))
        .rejects.toThrow(expectedError);
    });
  });

  describe('addProductToCart()', () => {
    let cartAddProductToCartDto: CartAddProductToCartDto;
    let cartDto: CartDto;
    let data;
    beforeEach(() => {
      cartService.addProductToCart = jest.fn();
      cartAddProductToCartDto = stubCartAddProductToCartDto();
      cartDto = stubCtCartDto();
      const { customerId, cartId, lineItems } = cartAddProductToCartDto;
      req.body.customerId = customerId;
      req.body.anonymousId = cartAddProductToCartDto.anonymousId;
      req.body.cartId = cartId;
      req.body.lineItems = lineItems;
      req.headers.channelkey = channelKey;
      data = {
        market,
        channelKey,
        customerId,
        anonymousId: req.body.anonymousId,
        cartId,
        sku: cartAddProductToCartDto.lineItems.sku,
        quantity: cartAddProductToCartDto.lineItems.quantity,
        productKey: cartAddProductToCartDto.lineItems.productKey,
      };
    });
    test('reads all the data from the request body', async () => {
      /* Prepare */
      (cartService.addProductToCart as Mock).mockReturnValueOnce(cartDto);
      /* Execute */
      await cartController.addProductToCart(req, res);

      /* Verify */
      expect(cartService.addProductToCart).toHaveBeenCalledTimes(1);
      expect(cartService.addProductToCart).toHaveBeenNthCalledWith(
        1,
        data,
      );
    });

    test('returns result from cartService.addProductToCart in JsonResponseEntity format', async () => {
      /* Prepare */
      (cartService as any).addProductToCart = jest.fn().mockReturnValueOnce(cartDto);
      /* Execute */
      const result = await cartController.addProductToCart(req, res);

      /* Verify */
      expect(result).toEqual({
        statusCode: 200,
        body: cartDto,
      });
    });
  });

  describe('cartPromotion()', () => {
    let cartDto: CartDto;

    beforeEach(() => {
      promotionService.promotion = jest.fn();
      cartDto = stubCtCartDto();
      req.params.cartId = cartDto.id;
      req.body.promotionCode = 'discoun';
      req.body.action = 'addDiscountCode';
      req.body.promotionId = faker.datatype.string;
    });

    test('fetches data from cartService', async () => {
      /* Prepare */
      (promotionService.promotion as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartController.cartPromotion(req, res);

      /* Verify */
      expect(promotionService.promotion).toHaveBeenCalledTimes(1);
      expect(promotionService.promotion).toHaveBeenNthCalledWith(1,
        market, cartDto.id, req.body.promotionCode, req.body.action, req.body.promotionId);
    });

    test('returns cartDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (promotionService.promotion as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartController.cartPromotion(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: cartDto,
      });
    });

    test('throws ApiError(NOT_FOUND) if cart does not exist', async () => {
      /* Prepare */
      (promotionService.promotion as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(404, `Cart with key "${cartDto.id}" not found.`);

      /* Execute */
      await expect(() => cartController.cartPromotion(req, res))
        .rejects.toThrow(expectedError);
    });
  });

  describe('getShippingMethod()', () => {
    let shippingMethodDto: ShippingMethodDto;
    beforeEach(() => {
      cartService.getCartById = jest.fn();
      shippingService.getShippingMethod = jest.fn();
      shippingMethodDto = stubShippingMethodDto();
    });

    test('fetches data from cartService for default shippingMethod', async () => {
      /* Prepare */
      (shippingService.getShippingMethod as Mock).mockReturnValueOnce(shippingMethodDto);

      /* Execute */
      await cartController.getShippingMethod(req, res);

      /* Verify */
      expect(shippingService.getShippingMethod).toHaveBeenCalledTimes(1);
      expect(shippingService.getShippingMethod).toHaveBeenNthCalledWith(1, magnolia, market);
    });

    test('returns cartDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (shippingService.getShippingMethod as Mock).mockReturnValueOnce(shippingMethodDto);

      /* Execute */
      const response = await cartController.getShippingMethod(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: shippingMethodDto,
      });
    });

    test('throws ApiError(NOT_FOUND) if shipping method does not exist', async () => {
      /* Prepare */
      // ApiError(NOT_FOUND) if shipping method does not exist
      const expectedError = new ApiError(404, 'Shipping method not found.');
      (shippingService.getShippingMethod as Mock).mockReturnValueOnce(expectedError);

      /* Execute */
      const result = await cartController.getShippingMethod(req, res);
      /* Verify */
      expect(result.body).toEqual(expectedError);
    });
  });

  describe('setShippingAddress()', () => {
    let cartDto: CartDto;
    let shippingAddressDetails: ShippingAddressDto;

    beforeEach(() => {
      shippingService.setShippingAddress = jest.fn();
      cartDto = stubCtCartDto();
      req.params.cartId = cartDto.id;
      shippingAddressDetails = shippingAddressDto();
      req.body = shippingAddressDetails;
    });

    test('fetches data from cartService', async () => {
      /* Prepare */
      (shippingService.setShippingAddress as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartController.setShippingAddress(req, res);

      /* Verify */
      expect(shippingService.setShippingAddress).toHaveBeenCalledTimes(1);
      expect(shippingService.setShippingAddress).toHaveBeenNthCalledWith(1,
        market, cartDto.id, shippingAddressDetails);
    });

    test('returns cartDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (shippingService.setShippingAddress as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartController.setShippingAddress(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: cartDto,
      });
    });

    test('throws ApiError(NOT_FOUND) if cart does not exist', async () => {
      /* Prepare */
      (shippingService.setShippingAddress as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(404, `Cart with key "${cartDto.id}" not found.`);

      /* Execute */
      await expect(() => cartController.setShippingAddress(req, res))
        .rejects.toThrow(expectedError);
    });
  });
});
