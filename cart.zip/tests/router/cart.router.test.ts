import { Router } from 'express';
import { CartRouter } from '../../src/routers';
import { CartController } from '../../src/controllers';
import { validateAddToCart, validateId } from '../../src/validators';
import { validateRequestSchema } from '../../src/middlewares';
import { magnoliaUrlMiddleware } from '../../src/middlewares/magnolia-url.middleware';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks__/express-validator.mock').default);

describe('CartRouter', () => {
  let cartController: CartController;
  let cartRouter: CartRouter;
  let mockRouter: Router;

  beforeEach(() => {
    cartController = {
      addProductToCart: jest.fn(),
      getCartById: jest.fn(),
      removeLineItem: jest.fn(),
      changeLineItemQuantity: jest.fn(),
      cartPromotion: jest.fn(),
      getShippingMethodsByCartId: jest.fn(),
      addShippingMethod: jest.fn(),
      getShippingMethod: jest.fn(),
      setShippingAddress: jest.fn(),
    } as any;

    mockRouter = {
      get: jest.fn(() => mockRouter),
      post: jest.fn(() => mockRouter),
      delete: jest.fn(() => mockRouter),
    } as any;

    cartRouter = new CartRouter({
      cartController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = cartRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      cartRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenCalledTimes(2);
      expect(mockRouter.post).toHaveBeenCalledTimes(4);
      expect(mockRouter.delete).toHaveBeenCalledTimes(1);
    });

    test('configures the GET /:id route', () => {
      cartRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(2,
        '/:id',
        validateId,
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function));
    });

    test('configures the POST / route', () => {
      cartRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenNthCalledWith(1,
        '/',
        validateAddToCart,
        validateRequestSchema,
        expect.any(Function));
    });
  });
});
