interface ProxyChainContainer {
    _validationChain: any[];
    toString: () => string;
  }

/**
   * @example
   * import { param } from 'express-validator';
   * import { validateAddToCart, validateId, validateDeleteLineItem } from '../../src/validators';
   * import { validateRequestSchema } from '../../src/middlewares';
   *
   * jest.mock('express-validator', () =>
   *   jest.requireActual('../__mocks/express-validator.mock').default);
   *
   * test('delete endpoint', () => {
   *   wishlistRouter.buildExpressRouter();
   *
   *   expect(mockRouter.delete).toHaveBeenCalledTimes(1);
   *   expect(mockRouter.delete).toHaveBeenNthCalledWith(1,
   *     '/:cartId/lineitems/:lineItemId',
   *     validateDeleteLineItem,
   *     // NOTE THE `.toString()` BELOW !
   *     param('lineItemId').isUUID().toString(),
   *     validateRequestSchema,
   *     expect.anything());
   * });
   *
   * Note that the difference between the router and the test expectation is that in the test
   * the mock validators MUST end with `.toString()`. This works because jest matchers for
   * `.toHaveBeenNthCalledWith()` arguments comparison are using standard equality comparison (`==`)
   * which coerces the SUT validator to be converted into string.
   */

const makeProxy = (): any => {
  const container: ProxyChainContainer = Object.assign(
    (req, res, next) => next(), // Container needs to fundamentally be a function for express.Router
    {
      _validationChain: [],
      // eslint-disable-next-line no-underscore-dangle
      toString: () => JSON.stringify(container._validationChain),
    },
  );

  const proxy = new Proxy(container, {
    get(target, property: string | symbol): any {
      if (property in target) {
        return target[property];
      }

      return (...args) => {
        // eslint-disable-next-line no-underscore-dangle
        target._validationChain.push({ method: property, args });

        return proxy;
      };
    },
  });

  return proxy;
};

export default Object.assign(makeProxy(), { __esModule: true });
