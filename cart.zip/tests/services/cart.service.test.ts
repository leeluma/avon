import faker from '@faker-js/faker';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { MarketInfo } from '../../src/middlewares';
import { CartMapper } from '../../src/mappers';
import {
  stubMarket, stubCtCartDto, stubCtCartDraftDto, stubCtCartLineItemDraftDto,
  stubCtProductDto, stubMagnoliaInfo, stubCtInventoryDto,
  stubGlobalSettings, stubPriceFormatSettings, stubCtCartDraftDtoWithEmptyShipping,
} from '../__stubs__';
import {
  CartDao, ProductDao, MagnoliaDao, ShoppingListDao, InventoryDao, PromotionDao, ShippingDao,
} from '../../src/daos';
import { CartService, ShippingService } from '../../src/services';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import Mock = jest.Mock;
import { CartDto, CtLineItemDto } from '../../src/dtos';
import { ApiError } from '../../src/lib';

describe('LeapApp', () => {
  /* System Under Test */
  let cartService: CartService;

  /* Dependencies */
  let cartDao: CartDao;
  let promotionDao:PromotionDao;
  let shippingDao:ShippingDao;
  let magnoliaDao: MagnoliaDao;
  let shoppingListDao: ShoppingListDao;
  let productDao: ProductDao;
  let cartMapper: CartMapper;
  let market: MarketInfo;
  let multiProductDto;
  let magnoliaInfo: MagnoliaInfo;
  let wishlistId: string;
  let inventoryDao: InventoryDao;
  let shippingService: ShippingService;
  let multiInventoryDto;
  const stubShipping = {
    id: 'cbd394b9-d5d7-4d84-ba6e-215522975b97',
    name: 'Standard Delivery',
    isDefault: true,
    formattedDeliveryCharge: 'RON 15.00',
    deliveryCharge: 15,
    freeAbove: 250,
  };
  let globalSettings: any;
  const discountCodeRes = { code: faker.datatype.string() };
  beforeEach(() => {
    market = stubMarket();
    multiProductDto = stubCtProductDto();
    magnoliaInfo = stubMagnoliaInfo();
    wishlistId = faker.datatype.uuid();
    multiInventoryDto = stubCtInventoryDto();
    globalSettings = stubGlobalSettings();
    /* Dependencies */
    cartDao = { recalculateCart: jest.fn(), getDiscountById: jest.fn() } as any;
    promotionDao = { applyPromotion: jest.fn(), removePromotion: jest.fn() } as any;
    shippingDao = { addShippingMethod: jest.fn(), getShippingMethod: jest.fn(), setShippingAddress: jest.fn() } as any;
    magnoliaDao = { getTemplateDataFromMagnolia: jest.fn(), getPriceFormatSettings: jest.fn() } as any;
    cartMapper = {
      cartToDto: jest.fn(),
      getCartProductId: jest.fn(),
      getVariantInventoryIds: jest.fn(),
    } as any;
    productDao = { fetchProductsDetail: jest.fn() } as any;
    shoppingListDao = { findGraphQLOne: jest.fn() } as any;
    inventoryDao = { fetchInventoryDetail: jest.fn() } as any;
    shippingService = {} as any;
    /* SUT */
    cartService = new CartService({
      cartMapper, cartDao, productDao, magnoliaDao, shoppingListDao, inventoryDao, shippingDao,
    });
  });

  describe('getCartById()', () => {
    let cartDto: CartDto;
    let cartDraftDto;
    let cartDraftDtoForShipping;
    let cartId: string;
    let magnoliaTemplateDefinition: {
      'mgnl:template': string;
    };

    beforeEach(() => {
      cartId = faker.datatype.uuid();
      magnoliaTemplateDefinition = { 'mgnl:template': faker.datatype.string() };
      magnoliaDao.getGlobalSettings = jest.fn();
      cartDao.getCartById = jest.fn();
      magnoliaDao.getCartDataFromMagnolia = jest.fn();
      cartDto = stubCtCartDto();
      cartDraftDto = stubCtCartDraftDto();
      cartDraftDtoForShipping = stubCtCartDraftDtoWithEmptyShipping();
    });

    test('getShippingDetails() for default shippinginfo', async () => {
      /* Prepare */
      const shippingRes = [
        {
          id: 'cbd394b9-d5d7-4d84-ba6e-215522975b97',
          name: 'Standard Delivery',
          isDefault: true,
          localizedDescription: 'Standard Delivery',
          localizedName: null,
          zoneRates: [
            {
              shippingRates: [
                {
                  price: {
                    centAmount: 1500,
                    currencyCode: 'RON',
                    fractionDigits: 2,
                  },
                  freeAbove: {
                    currencyCode: 'RON',
                    centAmount: 25000,
                    fractionDigits: 2,
                  },
                },
              ],
            },
          ],
        },
      ];
      (shippingDao.getShippingMethod as Mock).mockReturnValueOnce(shippingRes);
      const result = await cartService.getShippingDetails(undefined, stubPriceFormatSettings(), market);
      expect(result).toEqual(stubShipping);
    });

    test('getShippingDetails() for cart info', async () => {
      /* Prepare */
      const cartShippingInfo = {
        shippingMethod: {
          isDefault: true,
          id: 'cbd394b9-d5d7-4d84-ba6e-215522975b97',
          name: 'Standard Delivery',
          localizedDescription: 'Standard Delivery',
          localizedName: null,
        },
        shippingRate: {
          price: {
            type: 'centPrecision',
            fractionDigits: 2,
            centAmount: 1500,
            currencyCode: 'RON',
          },
          freeAbove: {
            type: 'centPrecision',
            fractionDigits: 2,
            centAmount: 25000,
            currencyCode: 'RON',
          },
        },
      };
      const result = await cartService.getShippingDetails(cartShippingInfo, stubPriceFormatSettings(), market);
      expect(result).toEqual(stubShipping);
    });
    test('fetches data from cartDao for undefined shippingInfo', async () => {
      /* Prepare */
      const shippingCartdto = cartDraftDtoForShipping;
      shippingCartdto.shippingInfo = undefined;
      (cartDao.getCartById as Mock).mockReturnValueOnce(shippingCartdto);
      (cartDao.recalculateCart as Mock).mockReturnValueOnce(shippingCartdto);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getCartDataFromMagnolia as Mock).mockReturnValueOnce(magnoliaTemplateDefinition);

      /* Execute */
      await cartService.getCartById(market, cartId, magnoliaInfo, wishlistId);

      /* Verify */
      expect(cartDao.getCartById).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartById).toHaveBeenNthCalledWith(1,
        market, cartId);
      expect(shoppingListDao.findGraphQLOne).toHaveBeenCalledWith(market, wishlistId);
      expect(magnoliaDao.getCartDataFromMagnolia).toHaveBeenCalledTimes(1);
    });

    test('fetches data from cartDao', async () => {
      /* Prepare */
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.recalculateCart as Mock).mockReturnValueOnce(cartDraftDto);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getCartDataFromMagnolia as Mock).mockReturnValueOnce(magnoliaTemplateDefinition);

      /* Execute */
      await cartService.getCartById(market, cartId, magnoliaInfo, wishlistId);

      /* Verify */
      expect(cartDao.getCartById).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartById).toHaveBeenNthCalledWith(1,
        market, cartId);
      expect(shoppingListDao.findGraphQLOne).toHaveBeenCalledWith(market, wishlistId);
      expect(magnoliaDao.getCartDataFromMagnolia).toHaveBeenCalledTimes(1);
    });

    test('maps CtCartDraftDto to CartDto', async () => {
      /* Prepare */
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      cartService.getShippingDetails = jest.fn();
      (cartService.getShippingDetails as Mock).mockReturnValueOnce(stubShipping);
      (cartDao.recalculateCart as Mock).mockReturnValueOnce(cartDraftDto);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getCartDataFromMagnolia as Mock).mockReturnValueOnce(magnoliaTemplateDefinition);

      /* Execute */
      await cartService.getCartById(market, cartId, magnoliaInfo, wishlistId);

      /* Verify */
      expect(cartMapper.cartToDto).toHaveBeenCalledTimes(1);
      expect(cartMapper.cartToDto).toHaveBeenNthCalledWith(1,
        cartDraftDto, market, globalSettings.priceFormat, stubShipping, undefined, undefined, undefined);
    });

    test('returns the cartDto from mapper', async () => {
      /* Prepare */
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.recalculateCart as Mock).mockReturnValueOnce(cartDraftDto);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(stubGlobalSettings);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getCartDataFromMagnolia as Mock).mockReturnValueOnce(magnoliaTemplateDefinition);

      /* Execute */
      const response:any = await cartService.getCartById(market, cartDto.id, magnoliaInfo, wishlistId);
      /* Verify */
      expect(response.cart).toBe(cartDto);
    });

    test('returns the cartDto from mapper for default shipping', async () => {
      /* Prepare */
      const shippingInfo = cartDraftDto;
      shippingInfo.shippingInfo = {};
      (cartDao.getCartById as Mock).mockReturnValueOnce(shippingInfo);
      (cartDao.recalculateCart as Mock).mockReturnValueOnce(cartDraftDto);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(stubGlobalSettings);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getCartDataFromMagnolia as Mock).mockReturnValueOnce(magnoliaTemplateDefinition);

      /* Execute */
      const response:any = await cartService.getCartById(market, cartDto.id, magnoliaInfo, wishlistId);
      /* Verify */
      expect(response.cart).toBe(cartDto);
    });

    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      (cartDao.getCartById as Mock).mockReturnValueOnce(null);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      /* Execute */
      const result = await cartService.getCartById(market, cartId, magnoliaInfo, wishlistId);

      /* Verify */
      expect(result).toEqual(undefined);
    });

    test('getCartProductId and fetchProductsDetail', async () => {
      /* Prepare */
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDto);
      (cartDao.recalculateCart as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getCartDataFromMagnolia as Mock).mockReturnValueOnce(magnoliaTemplateDefinition);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);
      (productDao.fetchProductsDetail as Mock).mockReturnValueOnce(multiProductDto);
      (inventoryDao.fetchInventoryDetail as Mock).mockReturnValueOnce(multiInventoryDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartService.getCartById(market, cartId, magnoliaInfo, wishlistId);

      /* Verify */
      expect(productDao.fetchProductsDetail).toHaveBeenNthCalledWith(1, market, `"${cartDto.lineItems[0].productId}"`);
    });
  });

  describe('removeLineItem()', () => {
    let cartDto: CartDto;
    let cartDraftDto;
    let lineItemId: string;
    let lineItemDraftDto: CtLineItemDto;
    let cartPaymentInfoData: any;

    beforeEach(() => {
      lineItemId = faker.datatype.uuid();
      lineItemDraftDto = stubCtCartLineItemDraftDto({ id: lineItemId });
      cartPaymentInfoData = {
        isPaymentInitiated: false,
      };
      cartService.getShippingDetails = jest.fn();

      cartDao.getCartById = jest.fn();
      cartDao.getCartPaymentInfo = jest.fn();
      cartDao.removeLineItem = jest.fn();
      cartDto = stubCtCartDto();
      cartDraftDto = stubCtCartDraftDto({ lineItems: [lineItemDraftDto] });
    });

    test('remove line item from cartDao', async () => {
      /* Prepare */
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.removeLineItem as Mock).mockReturnValueOnce(cartDraftDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartService.removeLineItem(market, cartDto.id, lineItemId);

      /* Verify */
      expect(cartDao.getCartById).toHaveBeenCalledTimes(1);
      expect(cartDao.removeLineItem).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartById).toHaveBeenNthCalledWith(1,
        market, cartDto.id);
      expect(cartDao.removeLineItem).toHaveBeenNthCalledWith(1,
        market.country, cartDraftDto, lineItemId);
    });

    test('check cart payment info for remove line item from cart', async () => {
      /* Prepare */
      const cartPaymentInfo = {
        isPaymentInitiated: true,
        cart: cartDraftDto,
        oldCart: cartDraftDto,
      };
      cartService.checkCartPaymentInfo = jest.fn();
      (cartService.checkCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfo);
      (cartDao.removeLineItem as Mock).mockReturnValueOnce(cartDraftDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartService.removeLineItem(market, cartDto.id, lineItemId);

      /* Verify */
      expect(cartService.checkCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(cartDao.removeLineItem).toHaveBeenCalledTimes(1);
      expect(cartService.checkCartPaymentInfo).toHaveBeenNthCalledWith(1,
        market, cartDto.id);
      expect(cartDao.removeLineItem).toHaveBeenNthCalledWith(1,
        market.country, cartDraftDto, lineItemId);
      expect(cartDao.getCartById).not.toHaveBeenCalled();
    });

    test('maps CtCartDraftDto to CartDto', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.removeLineItem as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (productDao.fetchProductsDetail as Mock).mockReturnValueOnce(multiProductDto);
      (cartDao.getDiscountById as Mock).mockReturnValueOnce(discountCodeRes);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);
      (cartService.getShippingDetails as Mock).mockReturnValueOnce(stubShipping);
      cartDraftDto.discountCodes = [{ discountCode: { id: faker.datatype.uuid() } }];
      /* Execute */
      await cartService.removeLineItem(market, cartDto.id, lineItemId);

      /* Verify */
      expect(cartMapper.cartToDto).toHaveBeenCalledTimes(1);
      expect(cartMapper.cartToDto).toHaveBeenNthCalledWith(1,
        cartDraftDto, market, stubPriceFormatSettings, stubShipping, multiProductDto, discountCodeRes);
    });

    test('returns the cartDto from mapper', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.removeLineItem as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);

      /* Execute */
      const response = await cartService.removeLineItem(market, cartDto.id, lineItemId);

      /* Verify */
      expect(response).toBe(cartDto);
    });

    test('returns 404 if the line Item does not exist', async () => {
      /* Prepare */
      const expectedError = new ApiError(
        HttpStatusCodes.NOT_FOUND,
        i18next.t('error.cartWithThisLineItemIdNotFound'),
      );
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.removeLineItem as Mock).mockRejectedValueOnce(expectedError);

      /* Execute */
      const result = expect(() => {
        return cartService.removeLineItem(market, cartDto.id, lineItemId);
      });
      /* Verify */
      await result.rejects.toThrow(expectedError);
      expect(cartDao.getCartById).toHaveBeenCalledTimes(1);
      expect(cartMapper.cartToDto).not.toHaveBeenCalled();
    });

    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(null);
      /* Execute */
      const result = await cartService.removeLineItem(market, cartDto.id, lineItemId);

      /* Verify */
      expect(result).toEqual(undefined);
    });

    test('returns 404 if the line item does not exist', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDto);

      const expectedError = new ApiError(
        HttpStatusCodes.NOT_FOUND,
        i18next.t('error.cartWithThisLineItemIdNotFound'),
      );

      /* Execute */
      await expect(() => cartService.removeLineItem(market, cartDto.id, lineItemId))
        .rejects.toThrow(expectedError);

      /* Verify */
      expect(cartDao.removeLineItem).not.toHaveBeenCalled();
      expect(cartMapper.cartToDto).not.toHaveBeenCalled();
    });
  });

  describe('changeLineItemQuantity()', () => {
    let cartDto: CartDto;
    let cartDraftDto;
    let lineItemId: string;
    let quantity: number;
    let lineItemDraftDto: CtLineItemDto;
    let cartPaymentInfoData: any;

    beforeEach(() => {
      lineItemId = faker.datatype.uuid();
      quantity = 1;
      lineItemDraftDto = stubCtCartLineItemDraftDto({ id: lineItemId });
      cartPaymentInfoData = {
        isPaymentInitiated: false,
      };
      cartService.getShippingDetails = jest.fn();
      cartDao.getCartById = jest.fn();
      cartDao.getCartPaymentInfo = jest.fn();
      cartDao.changeLineItemQuantity = jest.fn();
      cartDto = stubCtCartDto();
      cartDraftDto = stubCtCartDraftDto({ lineItems: [lineItemDraftDto] });
    });

    test('Change line item from cartDao', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.changeLineItemQuantity as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);

      /* Execute */
      await cartService.changeLineItemQuantity(market, cartDto.id, lineItemId, quantity);

      /* Verify */
      expect(cartDao.getCartById).toHaveBeenCalledTimes(1);
      expect(cartDao.changeLineItemQuantity).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartById).toHaveBeenNthCalledWith(1,
        market, cartDto.id);
      expect(cartDao.changeLineItemQuantity).toHaveBeenNthCalledWith(1,
        market.country, cartDraftDto, lineItemId, quantity);
    });

    test('check cart payment info for change line item in cart', async () => {
      /* Prepare */
      const cartPaymentInfo = {
        isPaymentInitiated: true,
        cart: cartDraftDto,
        oldCart: cartDraftDto,
      };
      cartService.checkCartPaymentInfo = jest.fn();
      (cartService.checkCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfo);
      (cartDao.changeLineItemQuantity as Mock).mockReturnValueOnce(cartDraftDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartService.changeLineItemQuantity(market, cartDto.id, lineItemId, quantity);

      /* Verify */
      expect(cartService.checkCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(cartDao.changeLineItemQuantity).toHaveBeenCalledTimes(1);
      expect(cartService.checkCartPaymentInfo).toHaveBeenNthCalledWith(1,
        market, cartDto.id);
      expect(cartDao.changeLineItemQuantity).toHaveBeenNthCalledWith(1,
        market.country, cartDraftDto, lineItemId, quantity);
      expect(cartDao.getCartById).not.toHaveBeenCalled();
    });

    test('maps CtCartDraftDto to CartDto', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartService.getShippingDetails as Mock).mockReturnValueOnce(stubShipping);
      (cartDao.changeLineItemQuantity as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (productDao.fetchProductsDetail as Mock).mockReturnValueOnce(multiProductDto);
      (cartDao.getDiscountById as Mock).mockReturnValueOnce(discountCodeRes);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);
      cartDraftDto.discountCodes = [{ discountCode: { id: faker.datatype.uuid() } }];

      /* Execute */
      await cartService.changeLineItemQuantity(market, cartDto.id, lineItemId, quantity);

      /* Verify */
      expect(cartMapper.cartToDto).toHaveBeenCalledTimes(1);
      expect(cartMapper.cartToDto).toHaveBeenNthCalledWith(1,
        cartDraftDto, market, stubPriceFormatSettings, stubShipping, multiProductDto, discountCodeRes);
    });

    test('returns the cartDto from mapper', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.changeLineItemQuantity as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartService.changeLineItemQuantity(market, cartDto.id, lineItemId, quantity);

      /* Verify */
      expect(response).toBe(cartDto);
    });

    test('returns 404 if the line Item does not exist', async () => {
      /* Prepare */
      const expectedError = new ApiError(
        HttpStatusCodes.NOT_FOUND,
        i18next.t('error.cartWithThisLineItemIdNotFound'),
      );
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.changeLineItemQuantity as Mock).mockRejectedValueOnce(expectedError);
      // (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const result = expect(() => {
        return cartService.changeLineItemQuantity(market, cartDto.id, lineItemId, quantity);
      });
      /* Verify */
      await result.rejects.toThrow(expectedError);
      expect(cartDao.getCartById).toHaveBeenCalledTimes(1);
      expect(cartMapper.cartToDto).not.toHaveBeenCalled();
    });

    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(null);
      /* Execute */
      const result = await cartService.changeLineItemQuantity(market, cartDto.id, lineItemId, quantity);

      /* Verify */
      expect(result).toEqual(undefined);
    });

    test('returns 404 if the line item does not exist', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDto);

      const expectedError = new ApiError(
        HttpStatusCodes.NOT_FOUND,
        i18next.t('error.cartWithThisLineItemIdNotFound'),
      );

      /* Execute */
      await expect(() => cartService.changeLineItemQuantity(market, cartDto.id, lineItemId, quantity))
        .rejects.toThrow(expectedError);

      /* Verify */
      expect(cartDao.changeLineItemQuantity).not.toHaveBeenCalled();
      expect(cartMapper.cartToDto).not.toHaveBeenCalled();
    });
  });

  describe('addProductToCart()', () => {
    let customerId : string;
    let anonymousId : string;
    let channelKey: string;
    let cartId : string;
    let sku: string;
    let quantity:number;
    let productKey: string;
    let cartFoundDto: CartDto;
    let createCartDto: any;
    beforeEach(() => {
      cartDao.getCartById = jest.fn();
      cartDao.addProductToCart = jest.fn();
      cartMapper.cartToDto = jest.fn();
      cartDao.createCart = jest.fn();
      cartFoundDto = stubCtCartDto();
      createCartDto = {
        body: { cartFoundDto },
        statusCode: 201,
      };
    });

    test('adds the product to cart', async () => {
      /* Prepare */
      (cartDao.addProductToCart as Mock).mockReturnValue(createCartDto);
      cartId = '1fc2b587-eec7-4228-9575-fd30d8907d49';
      sku = '106826-9161866660405752377';
      quantity = 1;
      productKey = '106826';
      channelKey = 'DC-RO';

      const data = {
        market,
        channelKey,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
      };
      /* Execute */
      const response = await cartService.addProductToCart(data);

      /* Verify */
      expect(cartDao.addProductToCart).toHaveBeenCalledTimes(1);
      expect(cartDao.addProductToCart).toHaveBeenNthCalledWith(1, data);
    });
  });

  describe('getCartPaymentInfo()', () => {
    let cartDto: CartDto;
    let cartDraftDto;
    let cartId: string;
    let magnoliaTemplateDefinition: {
      'mgnl:template': string;
    };
    let stubCartWithPaymentInfo;
    let paymentInfo;

    beforeEach(() => {
      cartId = faker.datatype.uuid();
      magnoliaTemplateDefinition = { 'mgnl:template': faker.datatype.string() };

      cartDao.getCartPaymentInfo = jest.fn();
      cartDao.replicateCartById = jest.fn();
      magnoliaDao.getCartDataFromMagnolia = jest.fn();
      cartDto = stubCtCartDto();
      cartDraftDto = stubCtCartDraftDto();
      paymentInfo = {
        paymentInfo: {
          payments: [{
            paymentStatus: {
              state: {
                name: 'Initial',
              },
            },
          }],
        },
      };
      stubCartWithPaymentInfo = {
        ...cartDto,
        paymentInfo,
      };
    });

    test('fetches data from cartDao getShippingDetails', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(paymentInfo);
      (cartDao.replicateCartById as Mock).mockReturnValueOnce(stubCartWithPaymentInfo);

      /* Execute */
      const result = await cartService.checkCartPaymentInfo(market, cartId);

      /* Verify */
      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartPaymentInfo).toHaveBeenNthCalledWith(1,
        market, cartId);
      expect(cartDao.replicateCartById).toHaveBeenCalledTimes(1);
      expect(result.isPaymentInitiated).toBe(true);
      expect(result.cart).toBe(stubCartWithPaymentInfo);
    });

    test('fetches data from cartDao', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(paymentInfo);
      (cartDao.replicateCartById as Mock).mockReturnValueOnce(stubCartWithPaymentInfo);

      /* Execute */
      const result = await cartService.checkCartPaymentInfo(market, cartId);

      /* Verify */
      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartPaymentInfo).toHaveBeenNthCalledWith(1,
        market, cartId);
      expect(cartDao.replicateCartById).toHaveBeenCalledTimes(1);
      expect(result.isPaymentInitiated).toBe(true);
      expect(result.cart).toBe(stubCartWithPaymentInfo);
    });

    test('returns isPaymentInitiated false', async () => {
      /* Prepare */
      const cartPaymentInfo = {
        paymentInfo: {
          payments: [{
            paymentStatus: {
              state: {
                name: null,
              },
            },
          }],
        },
      };
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfo);

      /* Execute */
      const result = await cartService.checkCartPaymentInfo(market, cartId);

      /* Verify */
      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(result.isPaymentInitiated).toBe(false);
      expect(cartDao.replicateCartById).not.toHaveBeenCalled();
    });

    test('returns isPaymentInitiated false if does not match payments', async () => {
      /* Prepare */
      const cartPaymentInfo = {
        paymentInfo: {
          payments: [],
        },
      };
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfo);

      /* Execute */
      const result = await cartService.checkCartPaymentInfo(market, cartId);

      /* Verify */
      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(result.isPaymentInitiated).toBe(false);
      expect(cartDao.replicateCartById).not.toHaveBeenCalled();
    });

    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(null);
      const expectedError = new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('error.cartIdNotFound', { cartId }));
      /* Execute */
      await expect(() => cartService.checkCartPaymentInfo(market, cartId))
        .rejects.toThrow(expectedError);

      /* Verify */
      expect(cartDao.replicateCartById).not.toHaveBeenCalled();
    });
  });
});
