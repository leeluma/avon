import faker from '@faker-js/faker';
import i18next from 'i18next';
import { MarketInfo } from '../../src/middlewares';
import { CartMapper } from '../../src/mappers';
import {
  stubMarket, stubCtCartDto, stubCtCartDraftDto, stubCtCartLineItemDraftDto,
  stubMagnoliaInfo, shippingAddressDto, stubGlobalSettings, stubPriceFormatSettings,
} from '../__stubs__';
import { CartDao, MagnoliaDao, ShippingDao } from '../../src/daos';
import { ShippingService } from '../../src/services';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import Mock = jest.Mock;
import { CartDto, CtLineItemDto, ShippingAddressDto } from '../../src/dtos';
import { ApiError } from '../../src/lib';

describe('LeapApp', () => {
  /* System Under Test */
  let shippingService: ShippingService;

  /* Dependencies */
  let cartDao: CartDao;
  let shippingDao:ShippingDao;
  let magnoliaDao: MagnoliaDao;
  let cartMapper: CartMapper;
  let market: MarketInfo;
  let magnoliaInfo: MagnoliaInfo;

  let globalSettings: any;
  beforeEach(() => {
    market = stubMarket();
    magnoliaInfo = stubMagnoliaInfo();
    globalSettings = stubGlobalSettings();
    /* Dependencies */
    cartDao = { recalculateCart: jest.fn(), getDiscountById: jest.fn() } as any;
    shippingDao = { addShippingMethod: jest.fn(), getShippingMethod: jest.fn(), setShippingAddress: jest.fn() } as any;
    magnoliaDao = { getTemplateDataFromMagnolia: jest.fn(), getPriceFormatSettings: jest.fn() } as any;
    cartMapper = {
      cartToDto: jest.fn(),
      getCartProductId: jest.fn(),
      getVariantInventoryIds: jest.fn(),
    } as any;
    /* SUT */
    shippingService = new ShippingService({
      cartMapper, cartDao, magnoliaDao, shippingDao,
    });
  });

  describe('getShippingMethod()', () => {
    let response: any;
    beforeEach(() => {
      shippingDao.getShippingMethod = jest.fn();
      cartDao.getCartById = jest.fn();
      magnoliaDao.getGlobalSettings = jest.fn();
    });

    test('returns empty response if empty response', async () => {
      /* Prepare */
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (shippingDao.getShippingMethod as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(400, i18next.t('error.emptyResponse'));
      /* Execute */
      await expect(shippingService.getShippingMethod(magnoliaInfo, market)).rejects.toThrow(expectedError);
    });

    test('returns error if zone Rates Not Set', async () => {
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      response = [{
        zoneRates: undefined,
      }];
      (shippingDao.getShippingMethod as Mock).mockReturnValueOnce(response);
      const expectedError = new ApiError(400, i18next.t('error.zoneRatesNotSet'));
      /* Execute */
      await expect(shippingService.getShippingMethod(magnoliaInfo, market)).rejects.toThrow(expectedError);
    });

    test('returns error if shipping rates Not Set', async () => {
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      response = [{
        zoneRates: {
          shippingRates: undefined,
        },
      },
      ];
      /* Prepare */
      (shippingDao.getShippingMethod as Mock).mockReturnValueOnce(response);
      const expectedError = new ApiError(400, i18next.t('error.shippingRatesNotSet'));
      /* Execute */
      await expect(shippingService.getShippingMethod(magnoliaInfo, market)).rejects.toThrow(expectedError);
    });

    test('fetch shipping address data', async () => {
      /* Prepare */
      const shippingRes = [
        {
          id: 'cbd394b9-d5d7-4d84-ba6e-215522975b97',
          name: 'Standard Delivery',
          localizedDescription: 'Standard Delivery',
          localizedName: null,
          isDefault: true,
          zoneRates: [
            {
              shippingRates: [
                {
                  price: {
                    centAmount: 1500,
                    currencyCode: 'RON',
                    fractionDigits: 2,
                  },
                  freeAbove: {
                    currencyCode: 'RON',
                    centAmount: 25000,
                    fractionDigits: 2,
                  },
                },
              ],
            },
          ],
        },
      ];
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (shippingDao.getShippingMethod as Mock).mockReturnValueOnce(shippingRes);
      /* Execute */
      const ShippingMethodRes = await shippingService.getShippingMethod(magnoliaInfo, market);

      /* Verify */
      expect(ShippingMethodRes).toEqual({
        id: 'cbd394b9-d5d7-4d84-ba6e-215522975b97',
        name: 'Standard Delivery',
        isDefault: true,
        formattedDeliveryCharge: 'RON 15.00',
        deliveryCharge: 15,
        freeAbove: 250,
      });
    });
  });
  describe('setShippingAddress()', () => {
    let cartDto: CartDto;
    let cartDraftDto;
    let shippingAddressDetails: ShippingAddressDto;
    let lineItemDraftDto: CtLineItemDto;
    let shippingAddressBody: any;
    beforeEach(() => {
      shippingAddressDetails = shippingAddressDto();
      cartDao.getCartById = jest.fn();
      shippingDao.setShippingAddress = jest.fn();
      cartDto = stubCtCartDto();
      lineItemDraftDto = stubCtCartLineItemDraftDto();
      cartDraftDto = stubCtCartDraftDto({
        lineItems: [lineItemDraftDto],
        shippingAddress: shippingAddressDetails,
      });
      shippingAddressBody = {
        version: cartDraftDto.version,
        actions: [{
          action: 'setShippingAddress',
          address: {
            custom: {
              type: {
                typeId: 'type',
                key: 'address-type',
              },
              fields: {
                Address1: shippingAddressDetails.address1,
                Address2: shippingAddressDetails.address2,
                county: shippingAddressDetails.county,
              },
            },
            postalCode: shippingAddressDetails.postalCode,
            city: shippingAddressDetails.city,
            phone: shippingAddressDetails.phoneNumber,
            country: market.country,
          },
        }],
      };
    });

    test('add shipping address from cartDao', async () => {
      /* Prepare */
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (shippingDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);

      /* Execute */
      await shippingService.setShippingAddress(market, cartDto.id, shippingAddressDetails as any);

      /* Verify */
      expect(cartDao.getCartById).toHaveBeenCalledTimes(1);
      expect(shippingDao.setShippingAddress).toHaveBeenCalledTimes(1);
      expect(cartMapper.cartToDto).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartById).toHaveBeenNthCalledWith(1,
        market, cartDto.id);
      expect(shippingDao.setShippingAddress).toHaveBeenNthCalledWith(1,
        market.country, cartDraftDto, shippingAddressBody);
      expect(cartMapper.cartToDto).toHaveBeenNthCalledWith(1,
        cartDraftDto, market, stubPriceFormatSettings);
    });

    test('returns the cartDto from mapper', async () => {
      /* Prepare */
      cartDraftDto.version = undefined;
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (shippingDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);

      /* Execute */
      const response = await shippingService.setShippingAddress(market, cartDto.id, shippingAddressDetails as any);

      /* Verify */
      expect(response).toBe(cartDto);
    });
    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      (cartDao.getCartById as Mock).mockReturnValueOnce(null);
      /* Execute */
      const result = await shippingService.setShippingAddress(market, cartDto.id, shippingAddressDetails as any);

      /* Verify */
      expect(result).toEqual(undefined);
    });
  });
});
