import faker from '@faker-js/faker';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { MarketInfo } from '../../src/middlewares';
import { CartMapper } from '../../src/mappers';
import {
  stubMarket, stubCtCartDto, stubCtCartDraftDto, stubCtCartLineItemDraftDto, stubPriceFormatSettings,
} from '../__stubs__';
import {
  CartDao, ProductDao, MagnoliaDao, PromotionDao, ShippingDao,
} from '../../src/daos';
import { CartService, PromotionService } from '../../src/services';
import Mock = jest.Mock;
import { CartDto, CtLineItemDto } from '../../src/dtos';
import { ApiError } from '../../src/lib';

describe('LeapApp', () => {
  /* System Under Test */
  let promotionService: PromotionService;

  /* Dependencies */
  let cartDao: CartDao;
  let promotionDao:PromotionDao;
  let magnoliaDao: MagnoliaDao;
  let productDao: ProductDao;
  let cartMapper: CartMapper;
  let market: MarketInfo;
  let shippingDao: ShippingDao;
  let cartService: CartService;
  beforeEach(() => {
    market = stubMarket();
    /* Dependencies */
    cartDao = { recalculateCart: jest.fn(), getDiscountById: jest.fn() } as any;
    promotionDao = { applyPromotion: jest.fn(), removePromotion: jest.fn() } as any;
    magnoliaDao = { getTemplateDataFromMagnolia: jest.fn(), getPriceFormatSettings: jest.fn() } as any;
    shippingDao = {
      getShippingMethod: jest.fn(),
    } as any;
    cartService = {
      checkCartPaymentInfo: jest.fn(),
    } as any;
    cartMapper = {
      cartToDto: jest.fn(),
      getCartProductId: jest.fn(),
      getVariantInventoryIds: jest.fn(),
    } as any;
    productDao = { fetchProductsDetail: jest.fn() } as any;
    /* SUT */
    promotionService = new PromotionService({
      cartMapper, cartDao, productDao, magnoliaDao, promotionDao, shippingDao, cartService,
    });
  });
  const stubShipping = {
    id: 'cbd394b9-d5d7-4d84-ba6e-215522975b97',
    name: 'Standard Delivery',
    isDefault: true,
    formattedDeliveryCharge: 'RON 15.00',
    deliveryCharge: 15,
    freeAbove: 250,
  };

  describe('Promotion()', () => {
    let cartDto: CartDto;
    let cartDraftDto;
    let promotionCode: string;
    let action:string;
    let lineItemDraftDto: CtLineItemDto;
    let actionRemovePromotion:string;
    let promotionId: string;

    beforeEach(() => {
      promotionCode = faker.datatype.string(10);
      action = 'applyPromotion';
      cartDao.getCartById = jest.fn();
      promotionDao.applyPromotion = jest.fn();
      cartDao.getCartPaymentInfo = jest.fn();
      cartService.checkCartPaymentInfo = jest.fn();
      cartDto = stubCtCartDto();
      lineItemDraftDto = stubCtCartLineItemDraftDto();
      promotionId = faker.datatype.string();
      cartDraftDto = stubCtCartDraftDto({
        lineItems: [lineItemDraftDto],
        discountCodes: [
          {
            discountCode: {
              typeId: 'discount-code',
              id: promotionId,
            },
            state: 'DoesNotMatchCart',
          },
        ],
        paymentInfo: {
          payments: [
          ],
        },
      });
      actionRemovePromotion = 'removePromotion';
      promotionDao.removePromotion = jest.fn();
    });
    test('getShippingDetails() for default shippinginfo', async () => {
      /* Prepare */
      const shippingRes = [
        {
          id: 'cbd394b9-d5d7-4d84-ba6e-215522975b97',
          name: 'Standard Delivery',
          isDefault: true,
          localizedDescription: 'Standard Delivery',
          localizedName: null,
          zoneRates: [
            {
              shippingRates: [
                {
                  price: {
                    centAmount: 1500,
                    currencyCode: 'RON',
                    fractionDigits: 2,
                  },
                  freeAbove: {
                    currencyCode: 'RON',
                    centAmount: 25000,
                    fractionDigits: 2,
                  },
                },
              ],
            },
          ],
        },
      ];
      (shippingDao.getShippingMethod as Mock).mockReturnValueOnce(shippingRes);
      const result = await promotionService.getShippingDetails(undefined, stubPriceFormatSettings(), market);
      expect(result).toEqual(stubShipping);
    });

    test('getShippingDetails() for cart info', async () => {
      /* Prepare */
      const cartShippingInfo = {
        shippingMethod: {
          isDefault: true,
          id: 'cbd394b9-d5d7-4d84-ba6e-215522975b97',
          name: 'Standard Delivery',
          localizedDescription: 'Standard Delivery',
          localizedName: null,
        },
        shippingRate: {
          price: {
            type: 'centPrecision',
            fractionDigits: 2,
            centAmount: 1500,
            currencyCode: 'RON',
          },
          freeAbove: {
            type: 'centPrecision',
            fractionDigits: 2,
            centAmount: 25000,
            currencyCode: 'RON',
          },
        },
      };
      const result = await promotionService.getShippingDetails(cartShippingInfo, stubPriceFormatSettings(), market);
      expect(result).toEqual(stubShipping);
    });
    test('Apply promotion from cartDao', async () => {
      /* Prepare */
      promotionService.getShippingDetails = jest.fn();
      (promotionService.getShippingDetails as Mock).mockReturnValueOnce(stubShipping);
      (cartService.checkCartPaymentInfo as Mock).mockReturnValueOnce({ cart: cartDraftDto, isPaymentInitiated: true });
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartDraftDto);
      (promotionDao.applyPromotion as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);

      /* Execute */
      await promotionService.promotion(market, cartDto.id, promotionCode, action);

      /* Verify */
      expect(promotionDao.applyPromotion).toHaveBeenCalledTimes(1);
      expect(promotionDao.applyPromotion).toHaveBeenNthCalledWith(1, market.country, cartDraftDto, promotionCode);
    });

    test('returns the cartDto from mapper', async () => {
      /* Prepare */
      (cartService.checkCartPaymentInfo as Mock).mockReturnValueOnce({ cart: cartDraftDto, isPaymentInitiated: true });
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartDraftDto);
      (promotionDao.applyPromotion as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);

      /* Execute */
      const response = await promotionService.promotion(market, cartDto.id, promotionCode, action);

      /* Verify */
      expect(response).toBe(cartDto);
    });

    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      (cartService.checkCartPaymentInfo as Mock).mockReturnValueOnce({ cart: undefined, isPaymentInitiated: false });
      (cartDao.getCartById as Mock).mockReturnValueOnce(undefined);
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce({ isPaymentInitiated: true, cart: undefined });
      const expectedError = new ApiError(
        HttpStatusCodes.BAD_REQUEST,
        i18next.t('error.cartNotFound'),
      );

      /* Execute */
      await expect(() => promotionService.promotion(market, cartDto.id, promotionCode, action))
        .rejects.toThrow(expectedError);

      /* Verify */
      expect(promotionDao.applyPromotion).not.toHaveBeenCalled();
      expect(cartMapper.cartToDto).not.toHaveBeenCalled();
    });

    test('Remove promotion from cartDao', async () => {
      /* Prepare */
      const promotionAction = actionRemovePromotion === 'applyPromotion' ? 'addDiscountCode' : 'removeDiscountCode';
      (cartService.checkCartPaymentInfo as Mock).mockReturnValueOnce({ cart: cartDraftDto, isPaymentInitiated: true });
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartDraftDto);
      (promotionDao.removePromotion as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);

      /* Execute */
      await promotionService.promotion(market, cartDto.id, promotionCode, actionRemovePromotion, promotionId);

      /* Verify */
      expect(promotionDao.removePromotion).toHaveBeenCalledTimes(1);
      expect(promotionDao.removePromotion).toHaveBeenNthCalledWith(1,
        market.country, cartDraftDto, promotionAction, promotionId);
    });

    test('Return error if promotion is not applicable in cart', async () => {
      cartDraftDto.discountCodes = [];
      /* Prepare */
      (cartService.checkCartPaymentInfo as Mock).mockReturnValueOnce({ cart: cartDraftDto, isPaymentInitiated: true });
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartDraftDto);
      (promotionDao.removePromotion as Mock).mockReturnValueOnce(cartDraftDto);
      const expectedError = new ApiError(
        HttpStatusCodes.NOT_FOUND,
        i18next.t('error.promotionNotFoundInCart'),
      );

      /* Execute */
      await expect(() =>
        promotionService.promotion(market, cartDto.id, promotionCode, actionRemovePromotion, promotionId))
        .rejects.toThrow(expectedError);
      /* Verify */
      expect(promotionDao.removePromotion).not.toHaveBeenCalledTimes(1);
      expect(cartMapper.cartToDto).not.toHaveBeenCalledTimes(1);
    });

    test('Remove promotion in add promotion cartDao', async () => {
      /* Prepare */
      cartDraftDto = stubCtCartDraftDto({
        lineItems: [lineItemDraftDto],
        discountCodes: [
          {
            discountCode: {
              typeId: 'discount-code',
              id: promotionId,
            },
            state: 'DoesNotMatchCart',
          },
        ],
        paymentInfo: {
          payments: [
            {
              key: 'test',
              paymentStatus: {
                state: 'Initial',
              },
            },
          ],
        },
      });
      (cartService.checkCartPaymentInfo as Mock).mockReturnValueOnce({ cart: cartDraftDto, isPaymentInitiated: true });
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartDraftDto);
      (promotionDao.removePromotion as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);

      /* Execute */
      await promotionService.promotion(market, cartDto.id, promotionCode, 'applyPromotion', promotionId);

      /* Verify */
      expect(promotionDao.removePromotion).toHaveBeenCalledTimes(1);
      expect(promotionDao.removePromotion).toHaveBeenNthCalledWith(1,
        market.country, cartDraftDto, 'removeDiscountCode', promotionId);
    });
  });
});
