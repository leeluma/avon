// eslint-disable-next-line @typescript-eslint/no-var-requires
const path = require('path');

const config = {
  verbose: true,
  setupFiles: [path.resolve(__dirname, 'tests/setup.ts')],
  modulePathIgnorePatterns: ['__stubs__'],
  maxWorkers: '100%',
  resetMocks: true,
  coverageDirectory: path.resolve(__dirname, 'artifacts/coverage'),
  cacheDirectory: path.resolve(__dirname, 'artifacts/jest-cache'),
  testPathIgnorePatterns: ['/node_modules/', '/dist/'],
  testResultsProcessor: 'jest-sonar-reporter',
  coveragePathIgnorePatterns: [path.resolve(__dirname, 'src/lib'), path.resolve(__dirname, 'src/middlewares'),
    path.resolve(__dirname, 'src/common'), path.resolve(__dirname, 'tests/__stubs__')],
};

module.exports = config;
