import { MarketInfo } from '../middlewares';
import { CommonResponse, MagnoliaInfo, MagnoliaDto } from '../dtos';
import { MagnoliaDao } from '../daos';

interface MagnoliaServiceConfig {
  magnoliaDao: MagnoliaDao;
}

/**
 * `MagnoliaService` for business logic Magnolia data
 */
export class MagnoliaService {
  private readonly magnoliaDao: MagnoliaDao;

  /**
   * Constructor for `MagnoliaService` class
   * @param config injects dependencies into the object
   */
  constructor(config: MagnoliaServiceConfig) {
    this.magnoliaDao = config.magnoliaDao;
  }

  public async getTemplateData(
    templateName: string,
    magnolia: MagnoliaInfo,
  ): Promise<MagnoliaDto> {
    return this.magnoliaDao.getTemplateDataFromMagnolia(templateName, magnolia);
  }

  /**
   * Get magnolia checkout page data
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   * @returns Page data from Magnolia
   */
  public async fetchMagnoliaData(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ): Promise<MagnoliaDto | undefined> {
    const staticPageResponse = await this.magnoliaDao.getCartDataFromMagnolia(market, magnolia);
    return {
      ...staticPageResponse,
    };
  }

  /**
   * Get magnolia global settings data
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   * @returns Global settings data from Magnolia
   */
  public async getGlobalSettingsData(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ): Promise<CommonResponse | undefined> {
    const globalSettings = await this.magnoliaDao.getGlobalSettings(market, magnolia.url);
    return {
      ...globalSettings,
    };
  }
}
