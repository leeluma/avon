import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { Cart, Product } from '@commercetools/platform-sdk';
import {
  CartDao, ProductDao, MagnoliaDao, ShoppingListDao, InventoryDao, ShippingDao,
} from '../daos';
import {
  ShippingMethodDto, CartDto, MagnoliaInfo, CartPaymentInfo, CommonResponse,
  CartsInfo, GraphQLInventoryEntry, PriceFormat,
} from '../dtos';
import { CartMapper } from '../mappers';
import { ApiError } from '../lib';
import { MarketInfo } from '../middlewares';
import { config } from '../config/config';
import {
  getVariantInventoryIds, getCartProductId, mapShippingInfo, shippingMethodToDto,
} from '../lib/cart-order';

interface ProductServiceConfig {
  cartMapper: CartMapper;
  cartDao: CartDao;
  magnoliaDao: MagnoliaDao;
  productDao: ProductDao;
  shoppingListDao: ShoppingListDao;
  inventoryDao: InventoryDao;
  shippingDao: ShippingDao;
}

/**
 * `CartService` for business logic `CartService`
 */
export class CartService {
  private readonly cartDao: CartDao;

  private readonly magnoliaDao: MagnoliaDao;

  private readonly productDao: ProductDao;

  private readonly cartMapper: CartMapper;

  private readonly shoppingListDao: ShoppingListDao;

  private readonly inventoryDao: InventoryDao;

  private readonly cartWithThisLineItemIdNotFound = 'error.cartWithThisLineItemIdNotFound';

  private readonly cartIdNotFound = 'error.cartIdNotFound';

  private readonly lineItemIdNotFound = 'error.lineItemIdNotFound';

  private readonly mgnlTemplate = 'mgnl:template';

  private readonly shippingDao: ShippingDao;

  /**
   * Constructor for `CartService` class
   * @param productServiceConfig injects dependencies into the object
   */
  constructor(productServiceConfig: ProductServiceConfig) {
    this.cartMapper = productServiceConfig.cartMapper;
    this.cartDao = productServiceConfig.cartDao;
    this.magnoliaDao = productServiceConfig.magnoliaDao;
    this.productDao = productServiceConfig.productDao;
    this.shoppingListDao = productServiceConfig.shoppingListDao;
    this.inventoryDao = productServiceConfig.inventoryDao;
    this.shippingDao = productServiceConfig.shippingDao;
  }

  public getShippingDetails = async (
    cartShipping: any | null | undefined, // NOSONAR
    priceFormat: PriceFormat,
    market: MarketInfo,
  ): Promise<ShippingMethodDto> => {
    let shippingInfo;
    if (!cartShipping) {
      const shippingMethod = await this.shippingDao.getShippingMethod(market);
      shippingInfo = shippingMethod ? shippingMethodToDto(shippingMethod[0], priceFormat) : {} as ShippingMethodDto;
    } else {
      shippingInfo = mapShippingInfo(
        {
          ...cartShipping?.shippingRate, ...cartShipping?.shippingMethod,
        }, priceFormat,
      );
    }
    return shippingInfo;
  };

  /** Cart Get by ID implementation * @param market - MarketInfo
   * @param cartId - String  * @param magnolia - MagnoliaInfo * @returns Cart Response  */
  public getCartById = async (
    market: MarketInfo, cartId: string, magnolia: MagnoliaInfo, wishlistId: string | undefined,
  ): Promise<CommonResponse | undefined> => {
    let isWishlistHasItem;
    if (wishlistId) {
      const shoppingList = await this.shoppingListDao.findGraphQLOne(market, wishlistId);
      isWishlistHasItem = !!shoppingList?.lineItems?.length;
    }
    const cart = await this.cartDao.getCartById(market, cartId);
    if (cart === null) {
      return undefined;
    }
    const recalculatedCart = await this.cartDao.recalculateCart(market, cart);
    let productDetails: Product[] | undefined;
    let inventoryDetails: GraphQLInventoryEntry[] | undefined;
    let magnoliaData;
    let globalSettings;
    if (recalculatedCart?.lineItems.length > 0) {
      const productsIds = getCartProductId(recalculatedCart.lineItems);
      const inventoriesIds = getVariantInventoryIds(recalculatedCart.lineItems);
      [productDetails, magnoliaData, globalSettings, inventoryDetails] = await Promise.all([
        this.productDao.fetchProductsDetail(market, productsIds),
        this.magnoliaDao.getCartDataFromMagnolia(market, magnolia),
        this.magnoliaDao.getGlobalSettings(market, magnolia.url),
        (inventoriesIds) ? this.inventoryDao.fetchInventoryDetail(market, inventoriesIds) : Promise.resolve([]),
      ]);
    } else {
      [magnoliaData, globalSettings] = await Promise.all([
        this.magnoliaDao.getCartDataFromMagnolia(market, magnolia),
        this.magnoliaDao.getGlobalSettings(market, magnolia.url),
      ]);
    }
    let discountCodeId = '';
    if (recalculatedCart?.discountCodes?.length && cart?.discountCodes) {
      discountCodeId = cart.discountCodes[0].discountCode.id;
    }
    const [discountCode, shippingInfo, templateData] = await Promise.all([
      (discountCodeId) ? this.cartDao.getDiscountById(market, discountCodeId) : Promise.resolve(undefined),
      this.getShippingDetails(cart?.shippingInfo, globalSettings.priceFormat, market),
      (magnolia.isPreview) ? this.magnoliaDao.getTemplateDataFromMagnolia(magnoliaData[this.mgnlTemplate], magnolia)
        : Promise.resolve({}),
    ]);
    const cartData = this.cartMapper.cartToDto(
      recalculatedCart, market, globalSettings.priceFormat, shippingInfo, productDetails as Product[], discountCode,
      inventoryDetails,
    );

    delete globalSettings.fieldValidators;
    delete globalSettings.addressSettings;
    return {
      ...magnoliaData,
      templateDefinition: templateData,
      globalSettings,
      cart: cartData,
      isWishlistHasItem,
    };
  };

  public removeLineItemMapper = async (market:MarketInfo,
    country:string, lineItemId: string, cart: Cart | undefined): Promise<CartDto | undefined> => {
    let discountCodeId = '';
    const [updatedCart, priceFormatSettings] = await Promise.all([
      this.cartDao.removeLineItem(country, cart, lineItemId),
      this.magnoliaDao.getPriceFormatSettings(market, config.magnoliaBasePath as string),
    ]);

    let productsIds = '';
    if (updatedCart?.lineItems.length > 0) {
      productsIds = getCartProductId(updatedCart.lineItems);
    }
    if (updatedCart?.discountCodes?.length && updatedCart?.discountCodes) {
      discountCodeId = updatedCart.discountCodes[0].discountCode.id;
    }

    const [productDetails, discountCode, shippingInfo] = await Promise.all([
      (productsIds) ? this.productDao.fetchProductsDetail(market, productsIds) : Promise.resolve(undefined),
      (discountCodeId) ? this.cartDao.getDiscountById(market, discountCodeId) : Promise.resolve(undefined),
      this.getShippingDetails(cart?.shippingInfo, priceFormatSettings, market),
    ]);

    return this.cartMapper.cartToDto(
      updatedCart, market, priceFormatSettings, shippingInfo, productDetails as Product[], discountCode,
    );
  };

  /** Cart Remove Line Item implementation * @param market - MarketInfo
   * @param cartId - String * @param lineItemId - String * @returns Cart Response */
  public removeLineItem = async (market: MarketInfo, cartId: string, itemId: string): Promise<CartDto | undefined> => {
    const { country } = market;
    let lineItemId = itemId;
    const cartPaymentInfo = await this.checkCartPaymentInfo(market, cartId);
    const { isPaymentInitiated, oldCart } = cartPaymentInfo;
    let { cart } = cartPaymentInfo;
    if (isPaymentInitiated === false && cart === undefined) {
      cart = await this.cartDao.getCartById(market, cartId);
    }
    if (isPaymentInitiated === true) {
      lineItemId = this.getMatchedLineItemId(cart as Cart, oldCart as Cart, itemId);
    }
    if (cart === null) {
      return undefined;
    }
    const lineItemExist = cart?.lineItems.filter((lineItem) => lineItem.id === lineItemId);
    if (lineItemExist && lineItemExist.length < 1) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t(this.cartWithThisLineItemIdNotFound));
    }
    return this.removeLineItemMapper(market, country, lineItemId, cart);
  };

  /** Cart Add Product implementation * @param market - MarketInfo * @param customerId - String
   * @param sku - String * @param quantity - String * @param productKey - String * @returns Cart Response  */
  public async addProductToCart(
    cartsInfo: CartsInfo,
  ): Promise<CartDto> {
    return this.cartDao.addProductToCart(cartsInfo);
  }

  /** Cart Update Line Item quantity implementation * @param market - MarketInfo * @param cartId - String
   * @param lineItemId - String  * @param quantity - String * @returns Cart Response */
  public changeLineItemQuantity = async (
    market: MarketInfo, cartId: string, itemId: string, quantity: number,
  ): Promise<CartDto | undefined> => {
    const { country } = market;
    let lineItemId = itemId;
    const cartPaymentInfo = await this.checkCartPaymentInfo(market, cartId);
    const { isPaymentInitiated, oldCart } = cartPaymentInfo;
    let { cart } = cartPaymentInfo;
    if (isPaymentInitiated === false) {
      cart = await this.cartDao.getCartById(market, cartId);
    } else {
      lineItemId = this.getMatchedLineItemId(cart as Cart, oldCart as Cart, itemId);
    }
    if (cart === null) {
      return undefined;
    }
    const lineItemExist = cart?.lineItems.filter((lineItem) => lineItem.id === lineItemId);
    if (lineItemExist && lineItemExist.length < 1) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t(this.cartWithThisLineItemIdNotFound));
    }
    const [updatedCart, priceFormatSettings] = await Promise.all([
      this.cartDao.changeLineItemQuantity(country, cart, lineItemId, quantity),
      this.magnoliaDao.getPriceFormatSettings(market, config.magnoliaBasePath as string),
    ]);
    let productsIds = '';
    if (updatedCart?.lineItems?.length > 0) {
      productsIds = getCartProductId(updatedCart.lineItems);
    }
    /* If cart has a discount code attached, fetch it's details and add in response.
    Since single discount code can be there in a cart at a time we are reading zeroth index of discountCodes.
    */
    let discountCodeId = '';
    if (Array.isArray(updatedCart.discountCodes) && updatedCart.discountCodes.length > 0) {
      discountCodeId = updatedCart.discountCodes[0].discountCode.id;
    }

    const [productDetails, discountCode, shippingInfo] = await Promise.all([
      (productsIds) ? this.productDao.fetchProductsDetail(market, productsIds) : Promise.resolve(undefined),
      (discountCodeId) ? this.cartDao.getDiscountById(market, discountCodeId) : Promise.resolve(undefined),
      this.getShippingDetails(cart?.shippingInfo, priceFormatSettings, market),
    ]);

    return this.cartMapper.cartToDto(
      updatedCart, market, priceFormatSettings, shippingInfo, productDetails as Product[], discountCode,
    );
  };

  /** Check cart payment info and status * if payment initiated then Replicate the cart and return new cart data
  * @param market - MarketInfo * @param cartId - cartId * @returns List of cart Response */
  public async checkCartPaymentInfo(
    market: MarketInfo,
    cartId: string,
  ): Promise<CartPaymentInfo> {
    const { country } = market;
    const cart = await this.cartDao.getCartPaymentInfo(market, cartId);
    if (!cart) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t(this.cartIdNotFound, { cartId }));
    }
    if (!cart.paymentInfo || cart.paymentInfo.payments.length === 0) {
      return { isPaymentInitiated: false };
    }
    const { payments } = cart.paymentInfo;
    const isPaymentPendingOrInitiated = payments.every((payment) => payment?.paymentStatus.state.name === 'Initial'
      || payment?.paymentStatus.state.name === 'Pending');
    if (isPaymentPendingOrInitiated) {
      const replicatedCart = await this.cartDao.replicateCartById(country, cartId);
      return { isPaymentInitiated: true, cart: replicatedCart, oldCart: cart };
    }
    return { isPaymentInitiated: false };
  }

  /** Function to get matched line item id  */
  private getMatchedLineItemId(cart: Cart, oldCart:Cart, lineItemId:string): string {
    const lineItem = oldCart.lineItems.find((item) => item.id === lineItemId);
    if (lineItem === undefined) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t(this.lineItemIdNotFound, { lineItemId }));
    }
    const { productId } = lineItem;
    const { sku } = lineItem.variant;
    const newLineItem = cart.lineItems.find((item) => item.productId === productId && item.variant.sku === sku);
    return newLineItem?.id ?? '';
  }
}
