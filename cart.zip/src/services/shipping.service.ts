import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { CartDao, MagnoliaDao, ShippingDao } from '../daos';
import {
  AddressRequest, CartDto, MagnoliaInfo, ShippingMethodDto,
} from '../dtos';
import { CartMapper } from '../mappers';
import { ApiError } from '../lib';
import { MarketInfo } from '../middlewares';
import { config } from '../config/config';
import { shippingMethodToDto } from '../lib/cart-order';

interface ProductServiceConfig {
  cartMapper: CartMapper;
  cartDao: CartDao;
  magnoliaDao: MagnoliaDao;
  shippingDao: ShippingDao
}

/**
 * `CartService` for business logic `CartService`
 */
export class ShippingService {
  private readonly cartDao: CartDao;

  private readonly shippingDao: ShippingDao;

  private readonly magnoliaDao: MagnoliaDao;

  private readonly cartMapper: CartMapper;

  private readonly cartIdNotFound = 'error.cartIdNotFound';

  /**
   * Constructor for `CartService` class
   * @param productServiceConfig injects dependencies into the object
   */
  constructor(productServiceConfig: ProductServiceConfig) {
    this.cartMapper = productServiceConfig.cartMapper;
    this.cartDao = productServiceConfig.cartDao;
    this.magnoliaDao = productServiceConfig.magnoliaDao;
    this.shippingDao = productServiceConfig.shippingDao;
  }

  /** Shipping Method implementation * @param market - MarketInfo * @returns shipping method Response */
  public getShippingMethod = async (magnolia: MagnoliaInfo, market: MarketInfo):Promise<ShippingMethodDto> => {
    const [shippingMethod, globalSettings] = await Promise.all([
      this.shippingDao.getShippingMethod(market),
      this.magnoliaDao.getGlobalSettings(market, magnolia.url),
    ]);
    if (!shippingMethod) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('error.emptyResponse'));
    }
    if (!shippingMethod[0].zoneRates || !shippingMethod[0].zoneRates === undefined) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('error.zoneRatesNotSet'));
    }
    if (shippingMethod[0]?.zoneRates[0]?.shippingRates === undefined) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('error.shippingRatesNotSet'));
    }
    return shippingMethodToDto(shippingMethod[0], globalSettings.priceFormat);
  };

  /** set cart shipping address implementation * @param market - MarketInfo * @param cartId - String
  * @param shippingAddressDetails - AddressRequest * @returns Cart Response */
  public setShippingAddress = async (
    market: MarketInfo, cartId: string, shippingAddressDetails: AddressRequest,
  ): Promise<CartDto | undefined> => {
    const { country } = market;
    const cart = await this.cartDao.getCartById(market, cartId);
    if (cart === null) {
      return undefined;
    }
    const shippingAddressDraft = {
      version: cart?.version ?? 0,
      actions: [{
        action: 'setShippingAddress',
        address: {
          custom: {
            type: { typeId: 'type', key: 'address-type' },
            fields: {
              Address1: shippingAddressDetails.address1,
              Address2: shippingAddressDetails.address2,
              county: shippingAddressDetails.county,
            },
          },
          postalCode: shippingAddressDetails.postalCode,
          city: shippingAddressDetails.city,
          phone: shippingAddressDetails.phoneNumber,
          country: country.toLocaleUpperCase(),
        },
      }],
    };
    const [updatedCartWithShippingAddress, priceFormatSettings] = await Promise.all([
      this.shippingDao.setShippingAddress(country, cart, shippingAddressDraft),
      this.magnoliaDao.getPriceFormatSettings(market, config.magnoliaBasePath as string),
    ]);
    return this.cartMapper.cartToDto(updatedCartWithShippingAddress, market, priceFormatSettings);
  };
}
