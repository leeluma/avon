import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { Product, Cart } from '@commercetools/platform-sdk';
import {
  CartDao, ProductDao, MagnoliaDao, PromotionDao, ShippingDao,
} from '../daos';
import {
  CartDto, GraphQLDiscountCode, PriceFormat, ShippingMethodDto,
} from '../dtos';
import { CartMapper } from '../mappers';
import { CartService } from '.';
import { ApiError } from '../lib';
import { MarketInfo } from '../middlewares';
import { config } from '../config/config';
import { getCartProductId, mapShippingInfo, shippingMethodToDto } from '../lib/cart-order';

interface ProductServiceConfig {
  cartMapper: CartMapper;
  cartDao: CartDao;
  magnoliaDao: MagnoliaDao;
  productDao: ProductDao;
  promotionDao: PromotionDao;
  shippingDao: ShippingDao;
  cartService: CartService;
}

/**
 * `PromotionService` for business logic `PromotionService`
 */
export class PromotionService {
  private readonly cartDao: CartDao;

  private readonly promotionDao: PromotionDao;

  private readonly magnoliaDao: MagnoliaDao;

  private readonly productDao: ProductDao;

  private readonly cartMapper: CartMapper;

  private readonly cartNotFound = 'error.cartNotFound';

  private readonly cartIdNotFound = 'error.cartIdNotFound';

  private readonly shippingDao: ShippingDao;

  private readonly cartService: CartService;

  /**
   * Constructor for `CartService` class
   * @param productServiceConfig injects dependencies into the object
   */
  constructor(productServiceConfig: ProductServiceConfig) {
    this.cartMapper = productServiceConfig.cartMapper;
    this.cartDao = productServiceConfig.cartDao;
    this.magnoliaDao = productServiceConfig.magnoliaDao;
    this.productDao = productServiceConfig.productDao;
    this.promotionDao = productServiceConfig.promotionDao;
    this.shippingDao = productServiceConfig.shippingDao;
    this.cartService = productServiceConfig.cartService;
  }

  public getShippingDetails = async (
    cartShipping: any | null, // NOSONAR
    priceFormat: PriceFormat,
    market: MarketInfo,
  ): Promise<ShippingMethodDto> => {
    let shippingInfo;
    if (!cartShipping) {
      const shippingMethod = await this.shippingDao.getShippingMethod(market);
      shippingInfo = shippingMethod ? shippingMethodToDto(shippingMethod[0], priceFormat) : {} as ShippingMethodDto;
    } else {
      shippingInfo = mapShippingInfo(
        {
          ...cartShipping?.shippingRate, ...cartShipping?.shippingMethod,
        }, priceFormat,
      );
    }
    return shippingInfo;
  };

  public promotionMapper = async (market:MarketInfo,
    country:string, promotionId: string | undefined, promotionAction: string, promotionCode: string | undefined,
    isPaymentInitiated: boolean, cart: Cart | undefined):
    Promise<CartDto | undefined> => {
    let updatedCart;
    let priceFormatSettings;
    let discountCode: GraphQLDiscountCode | undefined;
    const condition = (cart?.discountCodes !== undefined && promotionId);
    if (condition && promotionAction === 'removeDiscountCode') {
      const promotionExists = cart.discountCodes.filter((discount) => discount.discountCode.id === promotionId);
      if (promotionExists.length < 1) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.promotionNotFoundInCart'));
      }
      [updatedCart, priceFormatSettings] = await Promise.all([
        this.promotionDao.removePromotion(country, cart, promotionAction, promotionId),
        this.magnoliaDao.getPriceFormatSettings(market, config.magnoliaBasePath as string),
      ]);
    } else if (promotionCode) {
      if (isPaymentInitiated === true && condition) {
        this.promotionDao.removePromotion(country, cart, 'removeDiscountCode', promotionId);
      }
      [updatedCart, priceFormatSettings] = await Promise.all([
        this.promotionDao.applyPromotion(country, cart, promotionCode),
        this.magnoliaDao.getPriceFormatSettings(market, config.magnoliaBasePath as string),
      ]);
    }
    let productDetails: Product[] | undefined;
    if (updatedCart?.lineItems.length > 0) {
      const productsIds = getCartProductId(updatedCart.lineItems);
      productDetails = await this.productDao.fetchProductsDetail(market, productsIds);
    }

    if (updatedCart?.discountCodes?.length > 0) {
      discountCode = await this.cartDao.getDiscountById(market, updatedCart.discountCodes[0].discountCode.id);
    }
    const shippinginfo = await this.getShippingDetails((cart?.shippingInfo), priceFormatSettings, market);
    return this.cartMapper.cartToDto(
      updatedCart, market, priceFormatSettings, shippinginfo, productDetails as Product[], discountCode,
    );
  };

  /** Apply/Remove cart promotion implementation * @param market - MarketInfo * @param cartId - String
   * @body promotionCode - String * @body action - String * @returns Cart Response */
  public promotion = async (
    market: MarketInfo, cartId: string, promotionCode: string, action: string, promotionId?: string,
  ): Promise<CartDto | undefined> => {
    const { country } = market;
    const cartPaymentInfo = await this.cartService.checkCartPaymentInfo(market, cartId);
    const { isPaymentInitiated } = cartPaymentInfo;
    let { cart } = cartPaymentInfo;
    if (isPaymentInitiated === false && cart === undefined) {
      cart = await this.cartDao.getCartById(market, cartId);
    }
    if (cart === undefined) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t(this.cartNotFound));
    }
    const promotionAction = action === 'applyPromotion' ? 'addDiscountCode' : 'removeDiscountCode';
    return this.promotionMapper(market, country, promotionId, promotionAction,
      promotionCode, isPaymentInitiated, cart);
  };

  // /** Check cart payment info and status * if payment initiated then Replicate the cart and return new cart data
  // * @param market - MarketInfo * @param cartId - cartId * @returns List of cart Response */
  // public async checkCartPaymentInfo(
  //   market: MarketInfo,
  //   cartId: string,
  // ): Promise<CartPaymentInfo> {
  //   const { country } = market;
  //   const cart = await this.cartDao.getCartPaymentInfo(market, cartId);
  //   if (!cart) {
  //     throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t(this.cartIdNotFound, { cartId }));
  //   }
  //   if (!cart.paymentInfo || cart.paymentInfo.payments.length === 0) {
  //     return { isPaymentInitiated: false };
  //   }
  //   const { payments } = cart.paymentInfo;
  //   const isPaymentPendingOrInitiated = payments.every((payment) => payment?.paymentStatus.state.name === 'Initial'
  //       || payment?.paymentStatus.state.name === 'Pending');
  //   if (isPaymentPendingOrInitiated) {
  //     const replicatedCart = await this.cartDao.replicateCartById(country, cartId);
  //     return { isPaymentInitiated: true, cart: replicatedCart, oldCart: cart };
  //   }
  //   return { isPaymentInitiated: false };
  // }
}
