import { MarketInfo } from '../middlewares';
import { NotificationsDao } from '../daos/notifications.dao';

export interface NotificationsServiceConfig {
  notificationsDao: NotificationsDao;
}

export interface NotificationsParams {
sessionKey: string | string[],
customerKey: string | string[],
ticket?: string,
productKey?:string,
variantKey?: string,
}

/**
 * Service for managing notifications
 */
export class NotificationsService {
  private readonly notificationsDao: NotificationsDao;

  constructor(config: NotificationsServiceConfig) {
    this.notificationsDao = config.notificationsDao;
  }

  /**
   * create a notification for a add to cart
   * @param market - MarketInfo
   * @param productId - Product id
   * @returns ProductResponseDto
   * @throws ApiError 400
   */
  public async addToCart(
    market: MarketInfo,
    params,
  ): Promise<boolean> {
    return this.notificationsDao.cartNotifications(market, params);
  }
}
