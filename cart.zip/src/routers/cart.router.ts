import { Router } from 'express';
import {
  validateAddToCart,
  validateDeleteLineItem,
  validateUpdateLineItem,
  validateAddCartPromotion,
  validateSetCartAddress,
  validateId,
} from '../validators';
import { validateRequestSchema } from '../middlewares';
import { CartController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import { magnoliaUrlMiddleware } from '../middlewares/magnolia-url.middleware';

export interface CartRouterConfig {
  cartController: CartController;
  Router: typeof Router;
}
/**
 * @swagger
 * components:
 *  schemas:
 *    LineItemRequest:
 *      type: object
 *      properties:
 *        sku:
 *          type: string
 *        quantity:
 *          type: integer
 *    CartPromotionRequest:
 *      type: object
 *      properties:
 *        promotionCode:
 *          type: string
 *          example: AVON10%
 *        promotionId:
 *          type: string
 *          example: 5d06c34c-5f40-4897-abdb-99cc9adc97ff
 *        action:
 *          type: string
 *          example: applyPromotion or removePromotion
 *    ChangeLineItemQuantityRequest:
 *      type: object
 *      properties:
 *        quantity:
 *          type: integer
 *          format: int32
 *          required: true
 *          example: 5
 *          description: Quantity
 *    AddShippingAddressRequest:
 *      type: object
 *      properties:
 *        address1:
 *          type: string
 *          example: address1
 *        address2:
 *          type: string
 *          example: address2
 *        county:
 *          type: string
 *          example: county
 *        city:
 *          type: string
 *          example: city
 *        postalCode:
 *          type: string
 *          example: 80933
 *        phoneNumber:
 *          type: string
 *          example: +49 89 12345678
 *    CartRequest:
 *      type: object
 *      properties:
 *        cartId:
 *          type: string
 *        anonymousId:
 *          type: string
 *        customerId:
 *          type: string
 *        lineItems:
 *          type: object
 *          properties:
 *            sku:
 *              type: string
 *            quantity:
 *              type: integer
 *    CartResponse:
 *      type: object
 *      properties:
 *        status:
 *          type: object
 *          properties:
 *            statusCode:
 *              type: integer
 *              format: int32
 *              example: 200
 *            message:
 *              type: string
 *              example: OK
 *            timestamp:
 *              type: string
 *              example: 2021-12-31T07:32:43.751Z
 *        data:
 *          type: object
 *          properties:
 *            id:
 *              type: string
 *              example: 796c0b39-0a6b-4930-a987-a762149a71d8
 *            version:
 *              type: integer
 *              format: int32
 *              example: 17
 *            totalRetailPriceAmount:
 *              type: string
 *              example: 35.16
 *            totalInvoiceAmount:
 *              type: string
 *              example: 35.16
 *            currencyCode:
 *              type: string
 *              example: RON
 *            customerId:
 *              type: integer
 *              format: int32
 *              example: 0
 *            lineItems:
 *              type: array
 *              items:
 *                type: object
 *                properties:
 *                  lineItemId:
 *                    type: string
 *                    example: 8f6dbef7-6590-4d07-bdab-51a858907970
 *                  productId:
 *                    type: string
 *                    example: 12ad8823-ce25-4978-b8c1-cd9504898c46
 *                  name:
 *                    type: string
 *                    example: Mini-apă de parfum Far Away Glamour
 *                  skuCode:
 *                    type: string
 *                    example: 77567-9161866660405752600
 *                  images:
 *                    type: array
 *                    items:
 *                      type: object
 *                      properties:
 *                        label:
 *                          type: string
 *                          example: Gallery
 *                        url:
 *                          type: string
 *                          example: https://www.avon.ro/assets/ro-RO/images/product/prod_1200539_1_613x613.jpg
 *                        width:
 *                          type: integer
 *                          format: int32
 *                          example: 613
 *                        height:
 *                          type: integer
 *                          format: int32
 *                          example: 613
 *                  sellPrice:
 *                    type: string
 *                    example: 65.98
 *                  listPrice:
 *                    type: string
 *                    example: 65.98
 *                  formattedListPrice:
 *                    type: string
 *                    example: 65.98 RON
 *                  formattedSellPrice:
 *                    type: string
 *                    example: 65.98 RON
 *                  vatMessage:
 *                    type: string
 *                    example: Vat Included
 *                  quantity:
 *                    type: integer
 *                    format: int32
 *                    example: 2
 *                  modifiedTimeStamp:
 *                    type: string
 *                    example: 2021-12-28T07:49:54.341Z
 *                  sequenceNumber:
 *                    type: integer
 *                    format: int32
 *                    example: 0
 *                  maxPurchasableQty:
 *                    type: integer
 *                    format: int32
 *                    example: 10
 *                  availableQuantity:
 *                    type: integer
 *                    format: int32
 *                    example: 12
 *                  isAvailable:
 *                    type: boolean
 *                    example: true
 *                  variantType:
 *                    type: string
 *                    example: variantType
 *                  variantValue:
 *                    type: string
 *                    example: variantValue
 *                  hexCode:
 *                    type: string
 *                    example: hexCode
 *                  isDiscontinued:
 *                    type: boolean
 *                    example: false
 *                  offers:
 *                    type: array
 *                    items:
 *                      type: object
 *                      properties:
 *                        key:
 *                          type: string
 *                          example: Oricare-2-cu-21-RON
 *                        displayName:
 *                          type: string
 *                          example: Oricare 2 cu 21 RON!
 *                        url:
 *                          type: string
 *                          example: /c/oricare-2-cu-21-ron
 *                        description:
 *                          type: string
 *                          example: Oricare 2 cu 21 RON!
 *                        fulfilled:
 *                          type: boolean
 *                          example: true
 *            promotion:
 *              type: object
 *              properties:
 *                promotionId:
 *                  type: string
 *                  example: 032295d2-ed3a-48c5-9f07-3f2e15d384a9
 *                promotionCode:
 *                  type: string
 *                  example: discoun
 *                promotionAmount:
 *                  type: integer
 *                  format: int32
 *                  example: 0
 *                promotionDescription:
 *                  type: string
 *                  example: This is a test discount which is applied on cart if total is less than 10 RON
 *            shippingAddress:
 *              type: object
 *              properties:
 *                address1:
 *                  type: string
 *                  example: address1
 *                address2:
 *                  type: string
 *                  example: address2
 *                postalCode:
 *                  type: string
 *                  example: 80933
 *                city:
 *                  type: string
 *                  example: city
 *                county:
 *                  type: string
 *                  example: county
 *                phoneNumber:
 *                  type: string
 *                  example: +49 89 12345678
 *            shippingInfo:
 *              type: object
 *              properties:
 *                shippingMethodName:
 *                  type: string
 *                  example: Default shipping method
 *                shippingMethodPrice:
 *                  type: number
 *                  example: 100
 *    CartShippingMethodsResponse:
 *      type: object
 *      properties:
 *        statusCode:
 *          type: integer
 *          format: int32
 *          example: 200
 *        message:
 *          type: string
 *          example: OK
 *        timestamp:
 *          type: string
 *          example: 2021-12-31T07:32:43.751Z
 *        data:
 *          type: object
 *          properties:
 *            id:
 *              type: string
 *              example: 796c0b39-0a6b-4930-a987-a762149a7123
 *            name:
 *              type: string
 *              example: Next day delivery
 *            deliveryCharge:
 *              type: string
 *              example: 7.00 RON
 *            freeAbove:
 *              type: string
 *              example: 87.00 RON
 *    shippingMethodResponse:
 *      type: object
 *      properties:
 *        statusCode:
 *          type: integer
 *          format: int32
 *          example: 200
 *        message:
 *          type: string
 *          example: OK
 *        timestamp:
 *          type: string
 *          example: 2021-12-31T07:32:43.751Z
 *        data:
 *          type: object
 *          properties:
 *            id:
 *              type: string
 *              example: 796c0b39-0a6b-4930-a987-a762149a7123
 *            name:
 *              type: string
 *              example: Next day delivery
 *            isDefault:
 *              type: boolean
 *              example: true
 *            formattedDeliveryCharge:
 *              type: string
 *              example: 7.00 RON
 *            deliveryCharge:
 *              type: string
 *              example: 7.00
 *            freeAbove:
 *              type: string
 *              example: 87.00
 */

/**
 * `CartRouter` for all the routes related to `/carts`
 */

export class CartRouter {
  private readonly cartController: CartController;

  private readonly Router: typeof Router;
  /**
   * Constructor for `CartRouter` class
   * @param config injects dependencies into the object
   */

  constructor(config: CartRouterConfig) {
    this.cartController = config.cartController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /{language}-{market}/carts:
     *   post:
     *     summary: Add Line Item to cart
     *     tags: [Cart APIs]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *           type: string
     *         required: true
     *         description: language
     *       - in: path
     *         name: market
     *         schema:
     *           type: string
     *         required: true
     *         description: Market
     *       - name: channelkey
     *         in: header
     *         description: Channel key header
     *         required: false
     *         type: string
     *     requestBody:
     *       content:
     *         application/json:
     *          schema:
     *            $ref: '#/components/schemas/CartRequest'
     *     responses:
     *       "400":
     *         description: default response
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *       "500":
     *         description: default response
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *       "404":
     *         description: default response
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *       "200":
     *         description: add to cart response
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CartResponse'
     */
    router.post('/',
      validateAddToCart,
      validateRequestSchema,
      wrapJsonApiController(
        this.cartController.addProductToCart.bind(this.cartController),
      ));

    /**
       * @swagger
       * /{language}-{market}/shippingMethod:
       *   get:
       *     summary: Get the shipping-methods
       *     tags: [Shipping Method]
       *     parameters:
       *       - in: path
       *         name: language
       *         schema:
       *           type: string
       *         required: true
       *         description: language
       *         example: ro
       *       - in: path
       *         name: market
       *         schema:
       *           type: string
       *         required: true
       *         description: Market
       *         example: RO
       *     responses:
       *       200:
       *         description: The shipping-methods details
       *         content:
       *           application/json:
       *             schema:
       *               $ref: '#/components/schemas/shippingMethodResponse'
       */

    router.get('/shippingMethod',
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.cartController.getShippingMethod.bind(this.cartController),
      ));
    /**
       * @swagger
       * /{language}-{market}/carts/{id}:
       *   get:
       *     summary: Get the cart by id
       *     tags: [Cart APIs]
       *     parameters:
       *       - in: header
       *         name: wishlistId
       *         schema:
       *            type: string
       *       - in: path
       *         name: id
       *         schema:
       *           type: string
       *         required: true
       *         description: The cart id
       *         example: d4223b0e-3b24-4818-a92e-923497ab67f3
       *       - in: path
       *         name: language
       *         schema:
       *           type: string
       *         required: true
       *         description: language
       *         example: ro
       *       - in: path
       *         name: market
       *         schema:
       *           type: string
       *         required: true
       *         description: Market
       *         example: RO
       *     responses:
       *       200:
       *         description: The cart details by id
       *         content:
       *           application/json:
       *             schema:
       *               $ref: '#/components/schemas/CartResponse'
       */

    router.get('/:id',
      validateId,
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.cartController.getCartById.bind(this.cartController),
      ));

    /**
       * @swagger
       * /{language}-{market}/carts/{cartId}/lineItems/{lineItemId}:
       *   delete:
       *     summary: Remove line item from cart
       *     tags: [Cart APIs]
       *     parameters:
       *       - in: path
       *         name: language
       *         schema:
       *           type: string
       *         required: true
       *         description: Language.
       *       - in: path
       *         name: market
       *         schema:
       *           type: string
       *         required: true
       *         description: Market.
       *       - in: path
       *         name: cartId
       *         schema:
       *           type: string
       *           format: uuid
       *         required: true
       *         description: The cart id.
       *       - in: path
       *         name: lineItemId
       *         schema:
       *           type: string
       *           format: uuid
       *         required: true
       *         description: The line item id of cart to remove.
       *     responses:
       *       200:
       *         description: Remove line item from cart.
       *         content:
       *           application/json:
       *             schema:
       *               $ref: '#/components/schemas/CartResponse'
       */
    router.delete(
      '/:cartId/lineItems/:lineItemId',
      validateDeleteLineItem,
      validateRequestSchema,
      wrapJsonApiController(
        this.cartController.removeLineItem.bind(this.cartController),
      ),
    );

    /**
       * @swagger
       * /{language}-{market}/carts/{cartId}/lineItems/{lineItemId}:
       *   post:
       *     summary: Change Line item quantity
       *     tags: [Cart APIs]
       *     parameters:
       *       - in: path
       *         name: language
       *         schema:
       *           type: string
       *         required: true
       *         description: Language.
       *         example: ro
       *       - in: path
       *         name: market
       *         schema:
       *           type: string
       *         required: true
       *         description: Market.
       *         example: RO
       *       - in: path
       *         name: cartId
       *         schema:
       *           type: string
       *           format: uuid
       *         required: true
       *         description: Cart id.
       *         example: d4223b0e-3b24-4818-a92e-923497ab67f3
       *       - in: path
       *         name: lineItemId
       *         schema:
       *           type: string
       *           format: uuid
       *         required: true
       *         example: 8b8fb4ed-de0e-42ab-9aaf-48381e74bb92
       *         description: The line item id whose quantity you wish to update.
       *     requestBody:
       *       required: true
       *       content:
       *         application/json:
       *           schema:
       *             $ref: '#/components/schemas/ChangeLineItemQuantityRequest'
       *     responses:
       *       200:
       *         description: Change line item quantity in cart.
       *         content:
       *           application/json:
       *             schema:
       *               $ref: '#/components/schemas/CartResponse'
       */
    router.post(
      '/:cartId/lineItems/:lineItemId/',
      validateUpdateLineItem,
      validateRequestSchema,
      wrapJsonApiController(
        this.cartController.changeLineItemQuantity.bind(this.cartController),
      ),
    );

    /**
       * @swagger
       * /{language}-{market}/carts/{cartId}/promotions:
       *   post:
       *     summary: Add/Remove Cart promotion
       *     tags: [Cart Promotion]
       *     parameters:
       *       - in: path
       *         name: language
       *         schema:
       *           type: string
       *         required: true
       *         description: Language.
       *         example: ro
       *       - in: path
       *         name: market
       *         schema:
       *           type: string
       *         required: true
       *         description: Market.
       *         example: RO
       *       - in: path
       *         name: cartId
       *         schema:
       *           type: string
       *           format: uuid
       *         required: true
       *         description: Cart id.
       *         example: d4223b0e-3b24-4818-a92e-923497ab67f3
       *     requestBody:
       *       required: true
       *       content:
       *         application/json:
       *           schema:
       *             $ref: '#/components/schemas/CartPromotionRequest'
       *     responses:
       *       200:
       *         description: Add/remove Promo code in cart.
       *         content:
       *           application/json:
       *             schema:
       *               $ref: '#/components/schemas/CartResponse'
       */

    router.post(
      '/:cartId/promotions',
      validateAddCartPromotion,
      validateRequestSchema,
      wrapJsonApiController(
        this.cartController.cartPromotion.bind(this.cartController),
      ),
    );

    /**
     * @swagger
     * /{language}-{market}/carts/{cartId}/shippingAddress:
     *   post:
     *     summary: Add shipping address in cart.
     *     tags: [Cart Shipping Address]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *           type: string
     *         required: true
     *         description: Language.
     *         example: ro
     *       - in: path
     *         name: market
     *         schema:
     *           type: string
     *         required: true
     *         description: Market.
     *         example: RO
     *       - in: path
     *         name: cartId
     *         schema:
     *           type: string
     *           format: uuid
     *         required: true
     *         description: Cart id.
     *         example: 456c0685-d0e6-4eb3-a11d-b26273940e74
     *     requestBody:
     *       required: true
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/AddShippingAddressRequest'
     *     responses:
     *       200:
     *         description: Add shipping address in cart.
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CartResponse'
     */
    router.post(
      '/:cartId/shippingAddress',
      validateSetCartAddress,
      validateRequestSchema,
      wrapJsonApiController(
        this.cartController.setShippingAddress.bind(this.cartController),
      ),
    );
    return router;
  }
}
