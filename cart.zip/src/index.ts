import { Router } from 'express';
import { Common, CtClient } from './lib';
import { LeapApp, LeapAppConfig } from './app/leap-app';
import {
  CartDao, ProductDao, MagnoliaDao, NotificationsDao, ShoppingListDao, DefaultDao, PromotionDao, ShippingDao,
} from './daos';
import { CartController, NotificationsController, DefaultController } from './controllers';
import {
  CartService, NotificationsService, DefaultService, MagnoliaService, PromotionService, ShippingService,
} from './services';
import { CartRouter, NotificationsRouter, DefaultRouter } from './routers';
import { CartMapper } from './mappers';
import { graphql } from './graphql';
import { config } from './config/config';
import { InventoryDao } from './daos/inventory.dao';

/* Build configuration */
const {
  projectName, projectVersion, apiContextPath, apiVersion, port, magnoliaBasePath, previewMagnoliaBasePath,
  apptusBaseUrl, apptusClusterId, apptusEsalesMarket, beOrderUrl,
} = config;

if (!projectName) {
  throw new Error('The "name" field in package.json is mandatory!');
}

if (!projectVersion) {
  throw new Error('The "version" field in package.json is mandatory!');
}

if (!apiContextPath) {
  throw new Error('The "API_CONTEXT_PATH" environment variable is mandatory! (suggested value: api)');
}

if (!apiVersion) {
  throw new Error('The "API_VERSION" environment variable is mandatory! (suggested value: v1)');
}

if (!port) {
  throw new Error('The "API_PORT" environment variable is missing or not a valid number! (suggested value: 3000)');
}

if (!magnoliaBasePath) {
  throw new Error('The "MAGNOLIA_BASE_PATH" environment variable is mandatory!');
}

if (!previewMagnoliaBasePath) {
  throw new Error('The "PREVIEW_MAGNOLIA_BASE_PATH" environment variable is mandatory!');
}

if (!apptusClusterId) {
  throw new Error('The "APPTUS_CLUSTER_ID" environment variable is missing');
}

if (!apptusBaseUrl) {
  throw new Error('The "APPTUS_BASE_URL" environment variable is missing');
}

if (!apptusEsalesMarket) {
  throw new Error('The "APPTUS_ESALES_MARKET" environment variable is missing');
}

if (!beOrderUrl) {
  throw new Error('The "LEAP_BE_ORDER" environment variable is mandatory!');
}

const appConfig: LeapAppConfig = {
  projectName,
  projectVersion,
  apiContextPath,
  apiVersion,
  port,
};

/* Initialize dependencies */

const ctClient = new CtClient(process.env as any);
const shoppingListDao = new ShoppingListDao({ ctClient, graphql });
const cartDao = new CartDao({ ctClient, beOrderUrl, graphql });
const promotionDao = new PromotionDao({ ctClient, graphql });
const shippingDao = new ShippingDao({ ctClient, graphql });
const magnoliaDao = new MagnoliaDao();
const productDao = new ProductDao({ ctClient, graphql });
const inventoryDao = new InventoryDao({ ctClient, graphql });
const cartMapper = new CartMapper({ shippingDao });
const cartService = new CartService({
  cartMapper, cartDao, productDao, magnoliaDao, shoppingListDao, inventoryDao, shippingDao,
});

const promotionService = new PromotionService({
  cartMapper, cartDao, productDao, magnoliaDao, promotionDao, shippingDao, cartService,
});

const shippingService = new ShippingService({
  cartMapper, cartDao, magnoliaDao, shippingDao,
});

const magnoliaService = new MagnoliaService({ magnoliaDao });
const defaultDao = new DefaultDao({ ctClient });
const defaultService = new DefaultService({ defaultDao });
const defaultController = new DefaultController({ defaultService, magnoliaService });
const cartController = new CartController({ cartService, promotionService, shippingService });
const cartRouter = new CartRouter({ cartController, Router });
const defaultRouter = new DefaultRouter({ defaultController, Router });
const common = new Common();
const notificationsDao = new NotificationsDao({
  common,
  apptusBaseUrl,
  apptusClusterId,
  apptusEsalesMarket,
});
const notificationsService = new NotificationsService({ notificationsDao });
const notificationsController = new NotificationsController({ notificationsService });
const notificationsRouter = new NotificationsRouter({ Router, notificationsController });
/* Start app */

const leapApp = new LeapApp(appConfig);
leapApp.bootstrap().then(() => {
  leapApp.mount('/', defaultRouter.buildExpressRouter());
  leapApp.mount('/carts', cartRouter.buildExpressRouter());
  leapApp.mount('/notifications', notificationsRouter.buildExpressRouter());
  leapApp.listen();
});
