export const DEFAULT_QUANTITY = {
  DEFAULT_MAX_PURCHASABLE_QUANTITY: 9999999,
  DEFAULT_MAX_AVAILABLE_QUANTITY: 9999999,
  DEFAULT_CENT_AMOUNT: 9999,
  BASE_NUMBER: 10,
};

export const DEFAULT_INVENTORY_QUANTITY = 999;

export const VARIANT_ATTRIBUTES = {
  variantType: 'variantType',
  variantValue: 'variantValue',
  hexCode: 'hexCode',
  maxPurchasableQty: 'maxPurchasableQty',
  isDiscontinued: 'isDiscontinued',
};

export const CATEGORY_TYPE = {
  offer: 'Offer',
};

export const ATTRIBUTE_NAMES = {
  config: 'config',
  galleryVideo: 'galleryVideo',
  badges: 'badges',
  contentFillMeasurement: 'ContentFillMeasure',
  contentFill: 'ContentFill',
  availability: 'availability',
  excludeCountDown: 'excludeCountDown',
};

export const ATTRIBUTE_VALUES = {
  attributeValue: 'value',
  availabilitySku: 'skuCode',
  assetType: 'Video Gallery',
};

export const MEASUREMENT = {
  baseMeasure: 'baseMeasure',
  nodes: '@nodes',
};

export enum MagnoliaUri {
    cart = '.rest/delivery/pages/v1/',
    template = '.rest/template-definitions/v1/',
    priceFormat = '.rest/delivery/global-settings/{{country}}/settings/priceFormat',
    globalSettings = '.rest/delivery/global-settings/{{country}}/settings',
}

export const URI = {
  apptus: {
    esaleAddToCart: 'notifications/adding-to-cart',
    nonEsaleAddToCart: 'notifications/non-esales-adding-to-cart',
  },
};

export const RESPONSE_KEY = {
  applicationJson: 'application/json',
};
