// eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
const createCartDraft = (currency: string, cartData: any): any => {
  const { customerId, anonymousId, lineItems: lineItemDraft } = cartData;
  return {
    currency,
    anonymousId,
    customerId,
    taxMode: 'Disabled',
    lineItems: [lineItemDraft],
  };
};

export {
  createCartDraft,
};
