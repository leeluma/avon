export default {
  RO: 'RON',
  USA: 'USD',
};
