import { HttpStatus } from '../models';

export default class HttpResponseEntity<T> {
  // eslint-disable-next-line no-useless-constructor
  constructor(
    private readonly status: HttpStatus,
    private readonly data?: T,
    // eslint-disable-next-line @typescript-eslint/explicit-module-boundary-types
    private readonly errors?: unknown,
  ) {}
}
