import { readFile } from 'fs/promises';

const loadAsync = async (fileName: string): Promise<string> =>
  (await readFile(`${__dirname}/../graphql/${fileName}.graphql`, 'utf-8'))
    .toString();

export const graphql = {
  getProducts: loadAsync('get-products'),
  getShoppingListById: loadAsync('get-shopping-list-by-id'),
  getCartPaymentInfo: loadAsync('get-cart-payment-info'),
  getInventoriesById: loadAsync('get-inventories-by-id'),
  getDiscountcodeById: loadAsync('get-discountcode-by-id'),
  getShippingMethods: loadAsync('get-shipping-methods'),
};
