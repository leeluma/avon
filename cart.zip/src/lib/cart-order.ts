import currency from 'currency.js';
import {
  Cart, Product, LineItem, ShippingMethod, Price, DiscountCode,
} from '@commercetools/platform-sdk';
import { PriceFormat } from '../dtos/magnolia.dto';
import { PromotionDto } from '../dtos/order.dto';
import {
  VariantAttribute, CommonResponse, PriceDto, PriceCurrencyDto, ShippingMethodDto, GraphQLDiscountCode,
} from '../dtos/cart.dto';
import {
  ATTRIBUTE_NAMES, ATTRIBUTE_VALUES, MEASUREMENT, DEFAULT_QUANTITY, CATEGORY_TYPE, VARIANT_ATTRIBUTES,
} from '../common/constants';
import {
  ImageDto, ShippingInfoDto, ShippingInfo, OffersDto, CartProductVariantChannelAvailabilityMap,
} from '../dtos';
import { MarketInfo } from '../middlewares';
/**
 * function to convert number to decimal in given fraction
 * @param amount - Given amount
 * @param fraction - Given fraction
 * @returns
 */
export const priceConverter = (amount:number, fraction:number) => {
  const denominator = DEFAULT_QUANTITY.BASE_NUMBER ** fraction; // Ma th.pow(10, fraction);
  return (amount / denominator).toFixed(fraction);
};

/**
  * Get Formatted Magnolia Price
  * @param price - List of prices
  * @param priceFormat - Magnolia Price Format
  * @returns Magnolia Formatted Price
  */
export const magnoliaPriceFormatter = (price: number, priceFormat: PriceFormat): string => {
  let calculatedPrice = '';
  const numberTen = 10;
  const magnoliacurrency: string = priceFormat.ccy;
  const showDecimalZero = Boolean(priceFormat.showDecimalZero ?? false);
  const noOfDigitAtLast = Number(priceFormat.noOfDigit ?? 0);
  const decimalPoint: string = priceFormat.decimalPoint ?? '.';
  const thousandSeparator: string = priceFormat.thousandSeperator ?? '';
  const currencyPlacement: string = priceFormat.currencyPlacement ?? 'after';
  const lastDigitNo: number = numberTen ** noOfDigitAtLast;
  const sellPrice = (price / lastDigitNo).toFixed(noOfDigitAtLast);
  const parts = sellPrice.toString().split('.');
  const calculation = parts[1] ? decimalPoint + parts[1] : '';
  const returnPrice = showDecimalZero === true ? (parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator)
    + calculation) : parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator);
  calculatedPrice = (currencyPlacement === 'before')
    ? `${magnoliacurrency} ${returnPrice}` : `${returnPrice} ${magnoliacurrency}`;
  return calculatedPrice;
};

/**
   * @param attributes all variant attributes
   * @param sellPrice : variant sell price after discount
   * @param locale : market locale
   * @returns : string with unit price measurement
   */
export const getUnitPrice = (
  attributes:VariantAttribute[],
  sellPrice:number,
  priceFormat: PriceFormat,
):string => {
  let allBaseNodes: any[];
  let measuredValue;
  let result = '';
  let formattedPrice;
  const unitFillMeasureObj = attributes.find((value) => value.name === ATTRIBUTE_NAMES.contentFillMeasurement);
  const unitFillValueObj = attributes.find((value) => value.name === ATTRIBUTE_NAMES.contentFill);
  const unitFillMeasure = ((typeof unitFillMeasureObj !== 'undefined')
      && (ATTRIBUTE_VALUES.attributeValue in unitFillMeasureObj)) ? unitFillMeasureObj.value.key : '';
  const unitFillValue = ((typeof unitFillValueObj !== 'undefined')
      && (ATTRIBUTE_VALUES.attributeValue in unitFillValueObj)) ? unitFillValueObj.value : '';
  const allNodes: any = {};
  /* istanbul ignore else */
  if (Object.keys(priceFormat).length > 0 && (unitFillMeasure !== '') && (unitFillValue !== '')) {
    // normalizing unit price json response
    if (MEASUREMENT.baseMeasure in priceFormat) {
      if (MEASUREMENT.nodes in priceFormat.baseMeasure) {
        allBaseNodes = priceFormat.baseMeasure[MEASUREMENT.nodes];
        allBaseNodes.forEach((key) => {
          allNodes[priceFormat.baseMeasure[key].unitType] = priceFormat.baseMeasure[key];
          return allNodes;
        });
      }
    }
    // get Unit Price Measurement details
    if (unitFillMeasure in allNodes) {
      if (unitFillValue > allNodes[unitFillMeasure].containerSizeLimit) {
        measuredValue = sellPrice * (allNodes[unitFillMeasure].unitPriceBaseMeasure / unitFillValue);
        formattedPrice = magnoliaPriceFormatter(Math.round(measuredValue), priceFormat);
        result = `${formattedPrice} per ${allNodes[unitFillMeasure].unitPriceBaseMeasure}`
            + `${allNodes[unitFillMeasure].translation}`;
      }
    }
  }
  return result;
};

/**
   * Maps promotion
   * @param order GraphQLOrder
   * @returns promotion data
   */
export const promotionToDto = (cart: Cart, priceFormat: PriceFormat): PromotionDto | undefined => {
  let promotionId = '';
  const promotionCode = '';
  let promotionState: string | undefined;
  let totalPromotionAmount = 0.0;
  let promotionApplied = false;
  if (Array.isArray(cart.discountCodes) && cart.discountCodes[0]) {
    promotionState = cart.discountCodes[0].state;
    promotionId = cart.discountCodes[0].discountCode.id;
    if (cart.discountCodes[0].state === 'MatchesCart') {
      promotionApplied = true;
    }
    cart.lineItems.forEach((lineItem) => {
      if (
        Array.isArray(lineItem.discountedPricePerQuantity)
        && lineItem.discountedPricePerQuantity.length
      ) {
        lineItem.discountedPricePerQuantity.forEach((discount) => {
          discount.discountedPrice.includedDiscounts.forEach((element) => {
            totalPromotionAmount
              += element.discountedAmount.centAmount * discount.quantity;
          });
        });
      }
    });
  }
  const promotionDto: PromotionDto = {
    promotionId,
    promotionCode,
    promotionAmount: Number(priceConverter(totalPromotionAmount, cart.totalPrice.fractionDigits)),
    formattedPromotionAmount: magnoliaPriceFormatter(totalPromotionAmount, priceFormat),
    promotionState,
    promotionApplied,
  };
  return promotionDto;
};

/**
 * This function calculate any discount given by discount/coupon code.
 * Since there can be only one code applied at a time checking zeroth position of discountCodes
 * @param cart - any
 * @returns
 */
export const cartPromotionToDto = (
  cart: Cart,
  discountCode: GraphQLDiscountCode | undefined,
  priceFormat: PriceFormat,
): PromotionDto | undefined => {
  let promotionId;
  const promotionCode = '';
  let promotionState: string | undefined;
  let totalPromotionAmount = 0.0;
  let promotionApplied = false;
  /* istanbul ignore else */
  if (Array.isArray(cart.discountCodes) && cart.discountCodes[0]) {
    promotionState = cart.discountCodes?.[0].state;
    promotionId = cart.discountCodes?.[0].discountCode.id;
    // Calculate discount code saving only when it's state in cart is MatchesCart.
    if (cart.discountCodes[0].state === 'MatchesCart') {
      cart.lineItems.forEach((lineItem) => {
        /* istanbul ignore else */
        if (Array.isArray(lineItem.discountedPricePerQuantity) && lineItem.discountedPricePerQuantity.length) {
          lineItem.discountedPricePerQuantity.forEach((discount) => {
            discount.discountedPrice.includedDiscounts.forEach((element) => {
              // Comparing cart-discount id at line item level with cart-discount in discount code
              // As this code is supposed to tally savings through discount codes.
              if (element.discount.id === discountCode?.cartDiscountRefs[0].id) {
                promotionApplied = true;
                totalPromotionAmount += element.discountedAmount.centAmount * discount.quantity;
              }
            });
          });
        }
      });
    }
  }
  const promotionDto: PromotionDto = {
    promotionId,
    promotionCode,
    promotionAmount: Number(priceConverter(totalPromotionAmount, cart.totalPrice.fractionDigits)),
    formattedPromotionAmount: magnoliaPriceFormatter(totalPromotionAmount, priceFormat),
    promotionState,
    promotionApplied,
  };
  return promotionDto;
};

/**
 * function to convert number to decimal in given fraction with currency
 * @param amount - Given amount
 * @param fraction - Given fraction
 * @param fraction - Given fraction
 * @param fraction - Given fraction
 * @returns formatted amount with currency
 */
export const getPriceWithCurrency = (price: number | string, currencyCode: string, priceFormat: PriceFormat): string => {
  const currencyPlacement: string = priceFormat.currencyPlacement ?? 'after';
  return (currencyPlacement === 'before') ? `${currencyCode} ${price}` : `${price} ${currencyCode}`;
};

/**
   * Maps Line Item to Image DTO
   * @param lineItem - any
   * @returns
   */
export const imageToDto = (lineItem): ImageDto[] => lineItem.variant.images.map((image) => {
  const imageDto: ImageDto = {
    label: image.label,
    url: image.url,
    width: image.dimensions.w,
    height: image.dimensions.h,
  };
  return imageDto;
});

/**
   * Maps shipping method info
   * @param shippingInfo - shippingInfo
   * @returns Shipping method info
   */
export const shippingInfoToDto = (
  shippingInfo: ShippingInfo,
  priceFormat: PriceFormat,
): ShippingInfoDto => {
  const shippingMethodName = shippingInfo.shippingMethodName ? shippingInfo.shippingMethodName : '';
  const shippingMethodPrice = (shippingInfo.price && shippingInfo.price.centAmount)
    ? magnoliaPriceFormatter(shippingInfo?.price?.centAmount, priceFormat) : '0';
  return { shippingMethodName, shippingMethodPrice };
};

/**
   * Maps missing offer info
   * @param productDetails - productDetails
   * @param productId - productId
   * @returns missing offer details
   */
export const getProductOffer = (market: MarketInfo, productDetails: Product[],
  productId: string, fulfilledOfferCategoryId: string): OffersDto[] => {
  const offerArray: OffersDto[] = [];

  // missed offer details
  /* istanbul ignore else */
  if (productDetails && productDetails.length > 0) {
    for (let index = 0; index < productDetails.length; index += 1) {
      /* istanbul ignore else */
      if (productDetails[index].id === productId) {
        let offerObj: OffersDto;
        productDetails[index].masterData.current.categories.forEach((category: any) => {
          /* istanbul ignore else */
          if (category?.custom && category?.custom.customFieldsRaw[0].value === CATEGORY_TYPE.offer) {
            offerObj = {
              key: category.key,
              displayName: category.name ? category.name : '',
              url: category.slug ? `/${market.country.toLocaleLowerCase()}/offers/${category.slug}` : '',
              description: category.description
                ? category.description : '',
              fulfilled: category.id === fulfilledOfferCategoryId,
            };
            offerArray.push(offerObj);
          }
        });
      }
    }
  }
  return offerArray;
};

/**
   * maps attributes
   * @param attributes
   */
export const getProductAttributes = (attributes) => {
  const variantArr = attributes.map((attribute) => {
    if (attribute.name === VARIANT_ATTRIBUTES.variantType
        || attribute.name === VARIANT_ATTRIBUTES.variantValue
        || attribute.name === VARIANT_ATTRIBUTES.hexCode
        || attribute.name === VARIANT_ATTRIBUTES.maxPurchasableQty
        || attribute.name === VARIANT_ATTRIBUTES.isDiscontinued) {
      return { [attribute.name]: attribute?.value?.key ? attribute?.value?.label : attribute?.value };
    }
    return undefined;
  });
  return Object.assign({}, ...variantArr);
};

/**
   * Get shipping info data
   * @param shippingInfo ShippingInfo
   * @returns ShippingInfoDto
   */
export const getShippingInfo = (
  shippingInfo: ShippingInfo | undefined,
  priceFormat: PriceFormat,
): ShippingInfoDto | undefined => {
  if (shippingInfo === undefined || shippingInfo === null) {
    return undefined;
  }
  return {
    shippingMethodName: shippingInfo.shippingMethodName,
    shippingMethodPrice: magnoliaPriceFormatter(shippingInfo.price.centAmount, priceFormat),
    // shippingPrice: shippingInfo.price.centAmount,
  };
};

/**
 * Function to return specific field value
 */
export const getCustomFieldData = (
  custom,
  fieldName: string,
): string | undefined => {
  if (custom === undefined || custom === null) {
    return undefined;
  }
  let fieldValue;
  custom.customFieldsRaw.forEach((field) => {
    if (field.name === fieldName) {
      fieldValue = field.value;
    }
  });
  return fieldValue;
};

/**
 * Function to return variant inventory ids
 */
export const getVariantInventoryIds = (lineItems: LineItem[]): string => {
  return lineItems
    .map((lineItem) => {
      const lineItemSupplyChannelId = lineItem.supplyChannel?.id;
      const inventoryChannels: CartProductVariantChannelAvailabilityMap = lineItem.variant?.availability?.channels as
       CartProductVariantChannelAvailabilityMap;
      if (!inventoryChannels) {
        return undefined;
      }
      const inventoryChannelsArray = Object.entries(inventoryChannels);
      const inventoryId: CommonResponse | undefined = inventoryChannelsArray.find((key) => {
        if (key[0] === lineItemSupplyChannelId) {
          return key[1].id;
        }
        return undefined;
      });
      if (!inventoryId) {
        return undefined;
      }
      return `"${inventoryId[1].id}"`;
    })
    .join(', ');
};

/**
 * Function to return total price and currencycode
 */
export const getTotalPriceAndCurrencyCode = (
  price: PriceDto,
): PriceCurrencyDto => {
  const totalPrice = currency(price.centAmount, {
    fromCents: true,
    precision: price.fractionDigits,
  });
  const currencyCode = price?.currencyCode;
  return {
    totalPrice: totalPrice.value,
    currencyCode,
  };
};
/**
 * Function to return cart product id
 */
export const getCartProductId = (lineItems: LineItem[]): string => {
  return lineItems
    .map((lineItem) => {
      return `"${lineItem.productId}"`;
    })
    .join(', ');
};

export const mapShippingInfo = (shippingMethodDetails: any, priceFormat: PriceFormat): ShippingMethodDto => {
  const price = shippingMethodDetails?.price ?? {
    centAmount: 0,
    currencyCode: '',
    fractionDigits: 0,
  };
  const freeAbove = shippingMethodDetails?.freeAbove ?? null;
  return {
    id: shippingMethodDetails?.id,
    name: shippingMethodDetails?.localizedDescription ? shippingMethodDetails?.localizedDescription : shippingMethodDetails?.name,
    isDefault: shippingMethodDetails?.isDefault ?? false,
    formattedDeliveryCharge: shippingMethodDetails?.price && shippingMethodDetails.price.centAmount
      ? magnoliaPriceFormatter(shippingMethodDetails.price.centAmount, priceFormat) : '0',
    deliveryCharge:
      price?.centAmount && price?.fractionDigits
        ? parseFloat(
          priceConverter(price.centAmount, price.fractionDigits),
        )
        : null,
    freeAbove:
      freeAbove && Object.keys(freeAbove)?.length > 0
        ? parseFloat(
          priceConverter(
            freeAbove.centAmount,
            freeAbove.fractionDigits,
          ),
        )
        : null,
  };
};
/**
 * Function to return shipping method details
 */
export const shippingMethodToDto = (
  shippingMethodDetails: ShippingMethod, priceFormat: PriceFormat,
): ShippingMethodDto => {
  const shippingRates = shippingMethodDetails.zoneRates[0]
    ? shippingMethodDetails?.zoneRates[0]?.shippingRates[0]
    : null;
  return mapShippingInfo({
    id: shippingMethodDetails?.id,
    localizedDescription: shippingMethodDetails?.localizedDescription ?? shippingMethodDetails.name,
    isDefault: shippingMethodDetails?.isDefault,
    ...shippingRates,
  }, priceFormat);
};
/**
 * Function to return discount details
 */
export const checkProductDiscount = (price: Price) => {
  if (Object.prototype.hasOwnProperty.call(price, 'discounted') && price.discounted) {
    return {
      sellPrice: priceConverter(price.discounted.value.centAmount, price.discounted.value.fractionDigits),
      listPrice: priceConverter(price.value.centAmount, price.value.fractionDigits),
      sellPriceCT: price.discounted.value.centAmount,
      listPriceCT: price.value.centAmount,
      isPromotionApplied: true,
    };
  }
  return {
    sellPrice: priceConverter(price.value.centAmount, price.value.fractionDigits),
    listPrice: priceConverter(price.value.centAmount, price.value.fractionDigits),
    sellPriceCT: price.value.centAmount,
    listPriceCT: price.value.centAmount,
    isPromotionApplied: false,
  };
};

export const calculateOfferSavings = (
  lineItem: LineItem,
  discountCode: GraphQLDiscountCode | undefined,
): number => {
  let totalOfferAmount = 0.0;
  let totalPromoAmount = 0.0;
  const lineItemQuantity = lineItem.quantity;
  if (Array.isArray(lineItem.discountedPricePerQuantity) && lineItem.discountedPricePerQuantity.length) {
    lineItem.discountedPricePerQuantity.forEach((discount) => {
      discount.discountedPrice.includedDiscounts.forEach((element) => {
        // Comparing cart-discount id at line item level with cart-discount in discount code
        // As this code is supposed to tally savings through discount codes.
        if (element.discount.id !== discountCode?.cartDiscountRefs[0].id) {
          totalOfferAmount += element.discountedAmount.centAmount * discount.quantity;
        } else {
          totalPromoAmount += element.discountedAmount.centAmount * discount.quantity;
        }
      });
    });
  } else {
    return 0.0;
  }
  const discountPerQuantity = (totalOfferAmount + totalPromoAmount) / lineItemQuantity;
  return Number(priceConverter(discountPerQuantity, lineItem.totalPrice.fractionDigits));
};
