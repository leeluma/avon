export class Common {
  /**
   * It used to convert object parameters to query string.
   *
   * @param params
   * @returns
   */
  public queryString(params: Record<string, any>): string {
    const removeUndefined = JSON.parse(JSON.stringify(params));
    return Object.entries(removeUndefined).map(
      ([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value as string)}`,
    ).join('&');
  }
}
