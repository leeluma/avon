/* eslint-disable @typescript-eslint/no-unused-vars */
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import {
  Cart, LineItem, Product, Price, AddressDraft,
} from '@commercetools/platform-sdk';
import { ApiError } from '../lib';
import { ShippingDao } from '../daos';
import {
  magnoliaPriceFormatter, priceConverter, getUnitPrice, cartPromotionToDto, getTotalPriceAndCurrencyCode,
  checkProductDiscount, getPriceWithCurrency, imageToDto, getProductAttributes, getProductOffer,
  calculateOfferSavings,
} from '../lib/cart-order';
import {
  CartDto, LineItemDto, ShippingAddressDto, PromotionDto, GraphQLDiscountCode,
} from '../dtos/cart.dto';
import { DEFAULT_QUANTITY, DEFAULT_INVENTORY_QUANTITY } from '../common/constants';
import {
  CartVariantAvailability, GraphQLInventoryEntry, PriceFormat, ShippingMethodDto,
} from '../dtos';
import { MarketInfo } from '../middlewares';

interface CartMapperConfig {
  shippingDao: ShippingDao;
}

/**
 * Maps attribute to cart DTO
 * @param cart- Cart,
 * @param locale- locale of market,
 * @param priceFormat- PriceFormat,
 * @param productDetails- Product[],
 * @param promotionCode- Promotion code
 * @returns
 */
export class CartMapper {
  private readonly shippingDao: ShippingDao;

  constructor(productServiceConfig: CartMapperConfig) {
    this.shippingDao = productServiceConfig.shippingDao;
  }

  public cartToDto = (
    cart: Cart,
    market: MarketInfo,
    priceFormat: PriceFormat,
    shippingInfo?: ShippingMethodDto,
    productDetails?: Product[],
    discountCode?: GraphQLDiscountCode | undefined,
    inventoryDetails? : GraphQLInventoryEntry[],
  ): CartDto => {
    const totalInvoiceAmount = Number(
      priceConverter(
        cart.totalPrice.centAmount,
        cart.totalPrice.fractionDigits,
      ),
    );
    const totalPriceAndCurrencyCode = getTotalPriceAndCurrencyCode(
      cart.totalPrice,
    );
    let totalRetailPriceAmount = totalInvoiceAmount;
    let totalAmount = totalInvoiceAmount;
    let promotion: PromotionDto | undefined;
    if (Array.isArray(cart.discountCodes) && cart.discountCodes.length) {
      promotion = cartPromotionToDto(cart, discountCode, priceFormat);
      if (promotion) {
        totalRetailPriceAmount += promotion.promotionAmount;
        promotion.promotionCode = discountCode?.code || '';
      }
    }

    // subtract shipping price from retail price
    if (cart?.shippingInfo) {
      const shippingPrice = Number(
        priceConverter(cart.shippingInfo.price.centAmount, cart.shippingInfo.price.fractionDigits),
      );
      totalRetailPriceAmount -= shippingPrice;
      totalAmount = Number((totalAmount - shippingPrice).toFixed(cart.totalPrice.fractionDigits));
    }

    const cartDto: CartDto = {
      id: cart.id,
      version: cart.version,
      totalRetailPriceAmount: getPriceWithCurrency(
        (totalRetailPriceAmount).toFixed(cart.totalPrice.fractionDigits),
        totalPriceAndCurrencyCode.currencyCode, priceFormat,
      ),
      totalInvoiceAmount: getPriceWithCurrency(
        totalInvoiceAmount, totalPriceAndCurrencyCode.currencyCode, priceFormat,
      ),
      totalAmount,
      currencyCode: totalPriceAndCurrencyCode.currencyCode,
      promotion,
      customerId: cart.customerId,
      anonymousId: cart.anonymousId,
      lineItems: this.lineItemsToDto(
        cart.lineItems, market, priceFormat, productDetails, inventoryDetails as GraphQLInventoryEntry[], discountCode,
      ),
      shippingAddress: cart.shippingAddress ? this.shippingAddressToDto(cart.shippingAddress) : {} as ShippingAddressDto,
      shippingInfo: shippingInfo ?? {} as ShippingMethodDto,
    };
    return cartDto;
  };

  /**
   *
   * @param priceFormat priceFormat
   * @returns Vat message if applicable on a market
   */
  private readonly getVatText = (priceFormat: PriceFormat): string => {
    const vatMessage = priceFormat.vatIncludedMessage ?? '';
    const isVatIncluded = priceFormat.isVatIncluded ?? false;
    return isVatIncluded === 'true' ? vatMessage : '';
  };

  /**
   * Maps shipping Address
   * @param shippingAddress - ShippingAddressDto
   * @returns ShippingAddressDto
   */
   private readonly shippingAddressToDto = (
     shippingAddress: AddressDraft,
   ): ShippingAddressDto => {
     return {
       address1: shippingAddress?.custom?.fields?.Address1 || '',
       address2: shippingAddress?.custom?.fields?.Address2 || '',
       postalCode: shippingAddress.postalCode || '',
       city: shippingAddress.city || '',
       county: shippingAddress?.custom?.fields?.county || '',
       phoneNumber: shippingAddress.phone || '',
     };
   };

  /**
   * Check variant prices have channel price
   * @param prices variants prices
   * @returns
   */
  private readonly checkChannel = (prices: Price) => {
    return checkProductDiscount(prices);
  };

  /**
   * Maps line Item to Line Item DTO
   * @param lineItems - LineItem
   * @param locale - string
   * @param priceFormat - PriceFormat
   * @param productDetails? - Product
   * @returns
   */
  private readonly lineItemsToDto = (
    lineItems: LineItem[],
    market: MarketInfo,
    priceFormat: PriceFormat,
    productDetails?: Product[],
    inventoryDetails?: GraphQLInventoryEntry[],
    discountCode?: GraphQLDiscountCode | undefined,
  ): LineItemDto[] => {
    let maxPurchasableQty: number;
    let availableQuantity: number;
    let variantAttributes: {
      maxPurchasableQty: number;
      variantType: string;
      variantValue: string;
      hexCode: string;
      isDiscontinued: boolean;
    };
    let fulfilledOfferCategoryId: string;
    let supplyChannelId: string | number | undefined;
    if (lineItems?.length > 0 && market.locale) {
      return lineItems.map((lineItem) => {
        if (lineItem?.variant?.attributes) {
          variantAttributes = getProductAttributes(lineItem.variant.attributes);
        } else {
          throw new ApiError(
            HttpStatusCodes.BAD_REQUEST,
            i18next.t('error.lineItemVariantAttributesNotDefined'),
          );
        }
        supplyChannelId = lineItem.supplyChannel?.id;
        const lineItemAvailability = this.getLineItemAvailability(
          lineItem, supplyChannelId, inventoryDetails as GraphQLInventoryEntry[],
        );
        availableQuantity = lineItemAvailability.availableQuantity;
        const { isAvailable } = lineItemAvailability;
        const { limitedStock } = lineItemAvailability;
        const {
          sellPrice, listPrice, listPriceCT,
        } = this.checkChannel(lineItem.price ?? []);
        maxPurchasableQty = variantAttributes.maxPurchasableQty
          ?? DEFAULT_QUANTITY.DEFAULT_MAX_PURCHASABLE_QUANTITY;
        // set category id of fulfilled offer
        if (lineItem?.discountedPricePerQuantity.length > 0) {
          lineItem?.discountedPricePerQuantity.forEach((discountedPricePerQuantity) => {
            discountedPricePerQuantity.discountedPrice.includedDiscounts.forEach((includedDiscount) => {
              fulfilledOfferCategoryId = includedDiscount.discount.obj?.custom
              && includedDiscount.discount.obj?.custom.fields['offer-category'].id;
            });
          });
        }
        const numberTen = 10;
        const offerAmount = calculateOfferSavings(lineItem, discountCode);
        const salePriceAfterOffer = Number((Number(sellPrice) - offerAmount).toFixed(lineItem.totalPrice.fractionDigits));
        const lineItemDto: LineItemDto = {
          lineItemId: lineItem.id,
          productId: lineItem.productId,
          productKey: lineItem.productKey,
          name: lineItem.name[market.locale],
          skuCode: lineItem.variant.sku,
          images: imageToDto(lineItem),
          sellPrice: salePriceAfterOffer,
          listPrice: Number(listPrice),
          formattedListPrice: magnoliaPriceFormatter(listPriceCT, priceFormat),
          formattedSellPrice: magnoliaPriceFormatter(
            (salePriceAfterOffer * (numberTen ** lineItem.totalPrice.fractionDigits)), priceFormat,
          ),
          vatMessage: this.getVatText(priceFormat),
          unitPrice: getUnitPrice(
            lineItem.variant.attributes,
            Number((salePriceAfterOffer * (numberTen ** lineItem.totalPrice.fractionDigits))),
            priceFormat,
          ),
          quantity: lineItem.quantity,
          modifiedTimeStamp: lineItem.lastModifiedAt,
          sequenceNumber: 0,
          maxPurchasableQty,
          availableQuantity,
          isAvailable,
          limitedStock,
          variantType: variantAttributes.variantType,
          variantValue: variantAttributes.variantValue,
          hexCode: variantAttributes.hexCode,
          isDiscontinued: variantAttributes.isDiscontinued ?? false,
          offers: getProductOffer(
            market,
                productDetails as Product[],
                lineItem.productId,
                fulfilledOfferCategoryId,
          ),
        };
        return lineItemDto;
      });
    }
    return [];
  };

  /**
   * gets line item availability
   * @param lineItem - line item
   * @param supplyChannelId - supplyChannelId
   * @returns availability and quantity
   */
  private readonly getLineItemAvailability = (
    lineItem: LineItem, supplyChannelId: string | number | undefined, inventoryDetails: GraphQLInventoryEntry[],
  ) => {
    let lineItemAvailability: CartVariantAvailability = {};
    if (!supplyChannelId) {
      throw new ApiError(
        HttpStatusCodes.BAD_REQUEST,
        i18next.t('error.lineItemVariantSupplyChannelNotDefined', { sku: lineItem.variant.sku }),
      );
    }
    const channelAvailable = lineItem.variant.availability?.channels;
    if (!channelAvailable) {
      return {
        availableQuantity: DEFAULT_INVENTORY_QUANTITY,
        isAvailable: true,
        limitedStock: false,
      };
    }
    lineItemAvailability = channelAvailable[supplyChannelId];

    let limitedStock = false;
    const inventory = inventoryDetails?.find((inv) => inv.id === lineItemAvailability?.id);
    if (inventory !== undefined && inventory.custom !== null) {
      inventory.custom.customFieldsRaw.forEach((field) => {
        if (field.name === 'isLowAvailability') {
          limitedStock = field.value;
        }
      });
    }
    const availableQuantity = lineItemAvailability?.availableQuantity ?? DEFAULT_QUANTITY.DEFAULT_MAX_AVAILABLE_QUANTITY;
    const isAvailable = lineItemAvailability?.isOnStock ?? true;
    return { availableQuantity, isAvailable, limitedStock };
  };
}
