import { body, oneOf, param } from 'express-validator';

const validationErrorLineItemInvalid = 'validationError.lineItemIdInvalid';
const validationErrorLineItemQuantityInvalid = 'validationError.lineItemQuantityInvalid';
const validationErrorCartInvalid = 'validationError.cartInvalid';
const lineItemsQuantity = 'lineItems.quantity';
const validationErrorCartIdMandatory = 'validationError.cartIdMandatory';
const validationErrorLineItemQtyMandatory = 'validationError.lineItemQuantityMandatory';

export const validateAddToCart = [
  body('cartId')
    .optional({ checkFalsy: true })
    .isUUID()
    .withMessage(validationErrorCartInvalid),
  body('lineItems.sku')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.skuMandatory'),
  body(lineItemsQuantity)
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage(validationErrorLineItemQtyMandatory),
  body(lineItemsQuantity)
    .if(body(lineItemsQuantity).notEmpty())
    .isInt({ min: 1, max: 2000 })
    .withMessage(validationErrorLineItemQuantityInvalid),
  oneOf([
    body('customerId').notEmpty().withMessage('common.notEmpty').isUUID()
      .withMessage('datatype.uuid'),
    body('anonymousId').notEmpty().withMessage('common.notEmpty').isUUID()
      .withMessage('datatype.uuid'),
  ]),
];

export const validateCartId = [
  param('cartId')
    .exists({ checkNull: true, checkFalsy: true })
    .isUUID()
    .withMessage(validationErrorCartInvalid),
];

export const validateDeleteLineItem = [
  param('cartId')
    .exists({ checkNull: true, checkFalsy: true })
    .isUUID()
    .withMessage(validationErrorCartInvalid),
  param('lineItemId')
    .exists({ checkNull: true, checkFalsy: true })
    .isUUID()
    .withMessage(validationErrorLineItemInvalid),
];

export const validateUpdateLineItem = [
  param('cartId')
    .if(param('cartId').notEmpty())
    .isUUID()
    .withMessage(validationErrorCartInvalid),
  param('lineItemId')
    .if(param('lineItemId').notEmpty())
    .isUUID()
    .withMessage(validationErrorLineItemInvalid),
  body('quantity')
    .if(body('quantity').notEmpty())
    .isInt({ min: 1, max: 2000 })
    .withMessage(validationErrorLineItemQuantityInvalid),
  param('cartId')
    .exists({ checkNull: true })
    .withMessage(validationErrorCartIdMandatory),
  param('lineItemId')
    .exists({ checkNull: true })
    .withMessage('validationError.lineItemIdMandatory'),
  body('quantity')
    .exists({ checkNull: true })
    .withMessage(validationErrorLineItemQtyMandatory),
];

export const validateAddCartPromotion = [
  param('cartId')
    .if(param('cartId').notEmpty())
    .isUUID()
    .withMessage(validationErrorCartInvalid),
  param('cartId')
    .exists({ checkNull: true })
    .withMessage(validationErrorCartIdMandatory),
  body('promotionCode')
    .if(body('action').equals('applyPromotion'))
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.promotionCodeMandatoryApplyPromotion'),
  body('promotionId')
    .if(body('action').equals('removePromotion'))
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.promotionIdMandatoryRemovePromotion'),
  body('action')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.promotionActionMandatory')
    .if(body('action').notEmpty())
    .isString()
    .withMessage('validationError.promotionActionMustBeString')
    .if(body('action').isString())
    .isIn(['applyPromotion', 'removePromotion'])
    .withMessage('validationError.promotionInvalidValue'),
];

export const validateAddShippingMethod = [
  param('cartId')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('cart.cartId')
    .isUUID()
    .withMessage('cart.cartIdUuid'),
  body('shippingMethodId')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('cart.shippingMethodId')
    .isUUID()
    .withMessage('cart.shippingMethodIdUuid'),
];
export const validateSetCartAddress = [
  param('cartId')
    .if(param('cartId').notEmpty())
    .isUUID()
    .withMessage('validationError.cartInvalid'),
  param('cartId')
    .exists({ checkNull: true })
    .withMessage('validationError.cartIdMandatory'),
  body('address1')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('cart.address1')
    .isString()
    .withMessage('cart.validString'),
  body('address2')
    .optional({ checkFalsy: true })
    .isString()
    .withMessage('cart.validString'),
  body('county')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('cart.county')
    .isString()
    .withMessage('cart.validString'),
  body('city')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('cart.city')
    .isString()
    .withMessage('cart.validString'),
  body('postalCode')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('cart.postalCode')
    .isString()
    .withMessage('cart.validString'),
  body('phoneNumber')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('cart.phoneNumber')
    .isString()
    .withMessage('cart.validString'),
];
