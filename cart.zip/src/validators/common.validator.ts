import {
  body, header, oneOf, param,
} from 'express-validator';

const commonNotEmpty = 'common.notEmpty';
const datatypeUUid = 'datatype.uuid';
export const validateId = [
  param('id')
    .exists({ checkNull: true, checkFalsy: true })
    .isUUID()
    .withMessage('validationError.idMustExistAndValidUuid'),
];

export const validateNotifications = [
  header('sessionKey').notEmpty().withMessage(commonNotEmpty).isUUID()
    .withMessage(datatypeUUid),
  header('customerKey').notEmpty().withMessage(commonNotEmpty).isUUID()
    .withMessage(datatypeUUid),
  oneOf([
    [
      body('productKey').notEmpty().withMessage(commonNotEmpty),
      body('variantKey').notEmpty().withMessage(commonNotEmpty),
    ],
    body('ticket').notEmpty().withMessage(commonNotEmpty),
  ]),
];

export const validateRefreshToken = [
  header('refreshtoken').notEmpty().withMessage('common.notEmpty'),
];
