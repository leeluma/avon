export interface BaseMeasure {
  '@name': string;
  '@path': string;
  '@id': string;
  '@nodeType': string;
  translation: string;
  unitPriceBaseMeasure: string;
  containerSizeLimit: string;
  '@nodes': Array<string>;
}

export interface PriceFormat {
  '@name': string;
  '@path': string;
  '@id': string;
  '@nodeType': string;
  ccy: string;
  showDecimalZero: string;
  thousandSeperator: string;
  noOfDigit: string;
  currencyPlacement: string;
  decimalPoint: string;
  isVatIncluded: string;
  vatIncludedMessage: string;
  baseMeasure: BaseMeasure;
  '@nodes': Array<string>;
}

export interface MagnoliaDto {
  [key: string]: string;
}

export interface ProductIds {
  [key: string]: Array<string>;
}

export interface ProductsIds {
  productIds: ProductIds;
  keys: Array<string>;
}

export interface MagnoliaData {
  data: any; // NOSONAR
  productIds: ProductsIds;
  templateName: string;
}

export interface CartShippingInfo {
  shippingMethod: {
    isDefault: boolean,
    id: string,
    name: string,
    localizedDescription: string | null,
    localizedName: string | null
  },
  shippingRate: {
    price: {
      type: string,
      fractionDigits: number,
      centAmount: number,
      currencyCode: string
    },
    freeAbove: {
      type: string,
      fractionDigits: number,
      centAmount: number,
      currencyCode: string
    }
  }
}
