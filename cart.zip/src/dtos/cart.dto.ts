import { Cart, DiscountCode } from '@commercetools/platform-sdk';
import { MarketInfo } from '../middlewares';
import { CtLocalizedStringDto } from './common.dto';

export interface VariantAttribute {
  name: string;
  value: any; // NOSONAR
}
export interface ImageDto {
  url: string;
  label: string;
  width: number;
  height: number;
}
export interface OffersDto {
  key: string;
  displayName: string;
  url: string;
  description: string;
  fulfilled: boolean;
}
export interface LineItemDto {
  lineItemId: string;
  productId: string;
  productKey?: string;
  name: string;
  skuCode?: string;
  images: ImageDto[];
  listPrice: number;
  sellPrice: number;
  formattedListPrice: string;
  formattedSellPrice: string;
  vatMessage: string;
  unitPrice: string;
  quantity: number;
  modifiedTimeStamp?: string;
  sequenceNumber: number;
  maxPurchasableQty: number;
  availableQuantity: number;
  isAvailable: boolean;
  limitedStock: boolean;
  hexCode: string;
  variantType: string;
  variantValue: string;
  isDiscontinued: boolean;
  offers: OffersDto[];
}
export interface ShippingAddressDto {
  address1?: string;
  address2?: string;
  postalCode?: string;
  city?: string;
  county?: string;
  phoneNumber?: string;
}
export interface PromotionDto {
  promotionId?: string;
  promotionCode: string;
  promotionAmount: number;
  formattedPromotionAmount: string;
  promotionState?: string;
  promotionApplied: boolean;
}
export interface ShippingInfo {
  shippingMethodName: string;
  price: {
    type: string;
    currencyCode: string;
    centAmount: number;
    fractionDigits: number;
  };
}
export interface ShippingInfoDto {
  shippingMethodName: string;
  shippingMethodPrice: string;
}
export interface ShippingMethodDto {
  id: string;
  name: string | null;
  isDefault: boolean;
  formattedDeliveryCharge: string;
  deliveryCharge: number | string | null;
  freeAbove: number | string | null;
}
export interface CartDto {
  id: string;
  version: number;
  totalRetailPriceAmount: string;
  totalInvoiceAmount: string;
  totalAmount: number;
  currencyCode: string;
  customerId?: string;
  anonymousId?: string;
  promotion?: PromotionDto;
  lineItems: LineItemDto[];
  shippingAddress: ShippingAddressDto;
  shippingInfo: ShippingMethodDto | null;
}
export interface LineItemsAddProductDto {
  productKey: string;
  sku: string;
  quantity: number;
}
export interface CartAddProductToCartDto {
  cartId: string;
  customerId: string;
  anonymousId: string;
  lineItems: LineItemsAddProductDto;
}
export interface CtLineItemDto {
  id: string;
  productId: string;
  name: CtLocalizedStringDto;
  variant: [];
  quantity: number;
  lastModifiedAt: string;
}
export interface ShippingMethodServiceDto {
  id: string;
  name: string;
  isDefault: boolean;
  zoneRates: [
    {
      shippingRates: [
        {
          price: {
            centAmount: number;
            currencyCode: string;
            fractionDigits: number;
          };
          freeAbove: {
            centAmount: number;
            currencyCode: string;
            fractionDigits: number;
          };
        }
      ];
    }
  ];
}
export interface ShippingMethodServiceTODto {
  shippingMethod: ShippingMethodServiceDto[];
}
export interface PriceCurrencyDto {
  totalPrice: number;
  currencyCode: string;
}
export interface PriceDto {
  centAmount: number;
  currencyCode: string;
  fractionDigits: number;
}

export interface AddressRequest {
  address1: string;
  address2?: string;
  city: string;
  postalCode: string;
  county: string;
  phoneNumber: string;
}
export interface CartPaymentInfo {
  isPaymentInitiated: boolean;
  cart?: Cart;
  oldCart?: Cart;
}
export interface CommonResponse {
  cart?: CartDto,
  [x: string]: any | unknown; // NOSONAR
}
export interface CartsInfo {
  market: MarketInfo,
  channelKey: string | undefined,
  customerId: string,
  anonymousId: string | undefined,
  cartId: string,
  sku: string,
  quantity: number,
  productKey: string,
}

export interface CartDiscountRefs{
  id: string,
}
export interface GraphQLDiscountCode extends Omit<DiscountCode,
'cartDiscountRefs'> {
  cartDiscountRefs: CartDiscountRefs;
}
