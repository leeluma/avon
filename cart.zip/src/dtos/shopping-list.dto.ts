import { ShoppingListLineItem, ShoppingList } from '@commercetools/platform-sdk';

export interface GraphQLShoppingListLineItem extends Omit<ShoppingListLineItem, 'name' | 'productSlug' |
'addedAt' | 'productType'> {
  name: string;
  productSlug: string;
}

export interface GraphQLShoppingList extends Omit<ShoppingList, 'name' | 'lineItems' |
'createdAt' | 'lastModifiedAt'> {
  name: string;
  lineItems?: GraphQLShoppingListLineItem[],
}
