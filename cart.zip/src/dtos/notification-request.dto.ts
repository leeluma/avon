/**
 * @swagger
 * components:
 *   schemas:
 *     NotificationRequest:
 *       additionalProperties: false
 *       properties:
 *         ticket:
 *           type: string
 *         productKey:
 *           type: string
 *         variantKey:
 *           type: string
 *       type: object
 */

export interface NotificationRequest {
  ticket?: string;
  productKey?: string;
  variantKey?: string;
}
