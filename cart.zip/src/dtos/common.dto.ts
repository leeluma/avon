import { InventoryEntry, ProductVariantChannelAvailability } from '@commercetools/platform-sdk';

export interface CtId {
  id: string;
}

/** See https://docs.commercetools.com/api/types#references */
export interface CtRef<T> extends CtId {
  typeId: string;
  obj?: T;
}

export interface CtTrackingClientDto {
  clientId: string;
  isPlatformClient: boolean;
}

export interface CtLocalizedStringDto {
  [locale: string]: string;
}

/** Common interface to extend from in most other Ct* interfaces */
export interface CtTrackingFieldsDto {
  createdAt: string;
  createdBy: CtTrackingClientDto;
  lastModifiedAt: string;
  lastModifiedBy: CtTrackingClientDto;
}

/** Generic response from CommerceTools */
export interface CtResponse<T> {
  statusCode: number;
  body: T;
}

export interface MagnoliaInfo {
  url: string;
  isPreview: boolean;
  marketPath: string;
}

export interface FieldRaw {
  name: string;
  value: boolean;
}
export interface FieldType {
  name: string;
  id: string;
}

export interface CustomFields {
  type: FieldType;
  customFieldsRaw: FieldRaw[];
}

export interface GraphQLInventoryEntry extends Omit<InventoryEntry, 'custom'> {
  custom: CustomFields;
}

export interface CartVariantAvailability extends Omit<ProductVariantChannelAvailability,
  'id' > {
  id?: string;
}

export interface CartProductVariantChannelAvailabilityMap {
  [key: string]: CartVariantAvailability;
}
