import HttpStatusCodes from 'http-status-codes';
import {
  Cart, CartUpdate, GraphQLResponse, Update,
} from '@commercetools/platform-sdk';
import { CtClient, logger } from '../lib';
import { graphql } from '../graphql';
import { MarketInfo } from '../middlewares';

interface ShippingDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

/* `CtCartDao` data access class for CommerceTools `Cart` */
export class ShippingDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `CartDao` class
   * @param config injects dependencies into the object
   */
  constructor(config: ShippingDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /** Shipping Method get from CommerceTools
     * @param country - string * @param cartId - string * @returns Shipping Method from the commercetools
   */
  public getShippingMethod = async (market: MarketInfo): Promise<GraphQLResponse | undefined> => {
    try {
      const body = {
        query: await this.graphql.getShippingMethods,
        variables: {
          where: 'isDefault= true',
          locale: market.locale,
        },
      };
      const shippingMethods = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body }).execute();
      return shippingMethods?.body?.data?.shippingMethods?.results;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to retrieve shipping method  from CT, because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        return undefined;
      }
      throw err;
    }
  };

  /* set shipping address to cart * @param market - string
   * @param cart - Cart * @param shippingAddressDetails - Base address details * @returns Updated cart after setting the shipping address */
  public setShippingAddress = async (market: string, cart: Cart | undefined, shippingAddressDetails: Update):
   Promise<Cart> => {
    try {
      const updatedCart = await this
        .ctClient.getClient(market).carts().withId({ ID: cart?.id }).post({
          body: shippingAddressDetails as CartUpdate,
        })
        .execute();
      return updatedCart.body;
    } catch (err) {
      logger.error(`Failed to set shipping address to cart because:\n${(err as Error).stack}`);
      throw err;
    }
  };
}
