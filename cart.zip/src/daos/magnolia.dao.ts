import axios from 'axios';
import { axiosOptions } from '../lib';
import { MarketInfo } from '../middlewares';
import { MagnoliaUri } from '../common/constants';
import { CommonResponse, MagnoliaDto, PriceFormat } from '../dtos';
import { MagnoliaInfo } from '../dtos/common.dto';

const country = '{{country}}';

/**
 * `MagnoliaDao` data access class for Magnolia
 */
export class MagnoliaDao {
  /**
   * Get Cart data From Magnolia
   * @param market - MarketInfo
   * @returns Return cart data from Magnolia
   */

  public async getCartDataFromMagnolia(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ) : Promise<MagnoliaDto> {
    const queryParam = `lang=${market.locale}-${market.country}`;
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: `${magnolia.url}${MagnoliaUri.cart}${magnolia.marketPath}/cart?${queryParam}`,
    };
    try {
      const cartResult = await axios(config);
      return cartResult.data;
    } catch (error) {
      throw new Error(`Failed to fetch cart data from Magnolia, because: ${(error as Error).stack}`);
    }
  }

  /**
   * Get Cart template data from Magnolia
   * @param templateName magnolia template name
   * @returns return Cart template data from Magnolia
   */
  public async getTemplateDataFromMagnolia(
    templateName: string,
    magnolia: MagnoliaInfo,
  ): Promise<MagnoliaDto> {
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: `${magnolia.url}${MagnoliaUri.template}${templateName}`,
    };
    try {
      const templateDefinition = await axios(config);
      return templateDefinition.data;
    } catch (error) {
      throw new Error(`Failed to fetch Cart template data from Magnolia, because: ${(error as Error).stack}`);
    }
  }

  /**
   * Get price format settings data from magnolia
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   */
  public async getPriceFormatSettings(
    market: MarketInfo,
    magnoliaBasePath: string,
  ) : Promise<PriceFormat> {
    try {
      let priceFormatSettingsUrl = `${magnoliaBasePath}${MagnoliaUri.priceFormat}?lang=${market.localeAndCountry}`;
      priceFormatSettingsUrl = priceFormatSettingsUrl.replace(country, `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: priceFormatSettingsUrl,
      };
      const result = await axios(config);

      return result.data;
    } catch (error) {
      throw new Error(`Failed to fetch price format settings data from magnolia, because: ${(error as Error).stack}`);
    }
  }

  /**
   * Get global settings data
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   */
  public async getGlobalSettings(
    market: MarketInfo,
    magnoliaBasePath?: string | undefined,
  ): Promise<CommonResponse> {
    try {
      const queryParams = `lang=${market.locale}-${market.country}`;
      let globalSettingsUrl = `${magnoliaBasePath}${MagnoliaUri.globalSettings}?${queryParams}`;
      globalSettingsUrl = globalSettingsUrl.replace(country, `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: globalSettingsUrl,
      };
      const result = await axios(config);
      return result.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch global settings data from magnolia, because: ${error.stack}`);
    }
  }
}
