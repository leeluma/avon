import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import {
  GraphQLResponse, Product, ClientResponse,
} from '@commercetools/platform-sdk';
import { CtClient, ApiError, logger } from '../lib';
import { MarketInfo } from '../middlewares';
import { graphql } from '../graphql';

interface ProductDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;

}

/**
 * `CtProductDao` data access class for CommerceTools `Cart`
 */
export class ProductDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `ProductDao` class
   * @param config injects dependencies into the object
   */
  constructor(config: ProductDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
   * Fetch products data based on provided ids using GraphQL
   * @param market - Market info
   * @param productIds - multiple product ids as comma separated
   * @returns - product details
   */
  public async fetchProductsDetail(
    market: MarketInfo,
    productIds: string,
  ): Promise<Product[] | undefined> {
    const body = {
      query: await this.graphql.getProducts,
      variables: {
        where: `id in (${productIds})`,
        locale: market.locale,
      },
    };

    let productResponse: ClientResponse<GraphQLResponse>;

    try {
      productResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body })
        .execute();
      if (productResponse.body?.data === null && productResponse.body?.errors?.length !== undefined) {
        throw new ApiError(
          HttpStatusCodes.BAD_REQUEST,
          i18next.t('error.productsInvalidUuid'),
        );
      }
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
        + ` GraphQL returned: ${JSON.stringify(err.body?.errors)}.`);
      throw err;
    }
    return productResponse.body?.data?.products.results ?? undefined;
  }
}
