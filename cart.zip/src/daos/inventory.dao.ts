import { ClientResponse, GraphQLResponse } from '@commercetools/platform-sdk';
import i18next from 'i18next';
import HttpStatusCodes from 'http-status-codes';
import { graphql } from '../graphql';
import { CtClient, ApiError, logger } from '../lib';
import { MarketInfo } from '../middlewares';
import { GraphQLInventoryEntry } from '../dtos';

interface CartDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;

}

export class InventoryDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  constructor(config: CartDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
   * Fetch inventories data based on provided ids using GraphQL
   * @param market - Market info
   * @param inventoryIds - multiple inventory ids as comma separated
   * @returns - inventory details
   */
  public async fetchInventoryDetail(
    market: MarketInfo,
    inventoryIds: string,
  ): Promise<GraphQLInventoryEntry[] | undefined> {
    const body = {
      query: await this.graphql.getInventoriesById,
      variables: {
        where: `id in (${inventoryIds})`,
        locale: market.locale,
      },
    };

    let inventoryResponse: ClientResponse<GraphQLResponse>;

    try {
      inventoryResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body })
        .execute();
      if (inventoryResponse.body?.data === null && inventoryResponse.body?.errors?.length !== undefined) {
        throw new ApiError(
          HttpStatusCodes.BAD_REQUEST,
          i18next.t('error.inventoryInvalidUuid'),
        );
      }
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
        + ` GraphQL returned: ${JSON.stringify(err.body?.errors)}.`);
      throw err;
    }
    return inventoryResponse.body?.data?.inventoryEntries.results ?? undefined;
  }
}
