import HttpStatusCodes from 'http-status-codes';
import { Cart } from '@commercetools/platform-sdk';
import { CtClient, ApiError, logger } from '../lib';
import { graphql } from '../graphql';

const queryCondition = 'lineItems[*].discountedPricePerQuantity[*].discountedPrice.includedDiscounts[*].discount';

interface PromotionDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

/* `CtPromotionDao` data access class for CommerceTools `Cart` */
export class PromotionDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  private readonly cartIdNotFound = 'error.cartIdNotFound';

  /**
   * Constructor for `CartDao` class
   * @param config injects dependencies into the object
   */
  constructor(config: PromotionDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /** Apply Promotion Code to cart
   * @param country - string * @param cart - Cart * @param promotionCode - string * @param action - string
   * @returns Updated cart after Applying the promotion code
   */
  public applyPromotion = async (country: string, cart: Cart | undefined, promotionCode: string): Promise<Cart> => {
    try {
      const updatedCart = await this
        .ctClient.getClient(country).carts().withId({ ID: cart?.id }).post({
          body: {
            version: cart?.version,
            actions: [{
              action: 'recalculate', updateProductData: true,
            },
            {
              action: 'addDiscountCode', code: promotionCode,
            }],
          },
          queryArgs: {
            expand: ['discountCodes[*].discountCode',
              queryCondition],
          },
        })
        .execute();
      return updatedCart.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to apply promotion code to cart because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.BAD_REQUEST) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, 'Promo code not found');
      }
      throw err;
    }
  };

  /** Remove promo code from cart
   * @param country- string * @param cart - Cart * @param action - string * @param promotionId - string
   * @returns Updated cart after removing the promotion code
   */
  public removePromotion = async (country: string, cart: Cart, action: string, promotionId: string): Promise<Cart> => {
    try {
      const updatedCart = await this.ctClient.getClient(country).carts().withId({ ID: cart.id }).post({
        body: {
          version: cart.version,
          actions: [{
            action: 'removeDiscountCode',
            discountCode: {
              typeId: 'discount-code', id: promotionId,
            },
          }],
        },
        queryArgs: { expand: [queryCondition] },
      })
        .execute();
      return updatedCart.body;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to remove promotion code from cart because:\n${error.stack}`);
      if (error.statusCode === HttpStatusCodes.BAD_REQUEST) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, 'Promo code not found in cart');
      }
      throw error;
    }
  };
}
