/* eslint-disable max-len */
import axios from 'axios';
import { NotificationRequest } from '../dtos';
import { Common, ApiError, axiosOptions } from '../lib';
import { URI } from '../common/constants';
import { MarketInfo } from '../middlewares';

export interface NotificationsDaoConfig {
  common: Common;
  apptusBaseUrl: string,
  apptusClusterId: string
  apptusEsalesMarket: string
}
export interface NotificationsRequestDto {
  sessionKey: string | string[];
  customerKey: string | string[];
  ticket?: string;
  productKey?: string;
  variantKey?: string;
}
/**
 * `CtNotificationsDao` data access class for CommerceTools `Product`
 */
export class NotificationsDao {
  private readonly common: Common;

  private readonly apptusBaseUrl: string;

  private readonly apptusClusterId: string;

  private readonly apptusEsalesMarket: string;

  /**
   * Constructor for `CtNotificationsDao` class
   * @param config Injects dependencies into the object
   */
  constructor(config: NotificationsDaoConfig) {
    this.common = config.common;
    this.apptusBaseUrl = config.apptusBaseUrl;
    this.apptusClusterId = config.apptusClusterId;
    this.apptusEsalesMarket = config.apptusEsalesMarket;
  }

  /**
   * Gets apptus product search
   * @param market - MarketInfo
   * @param id - Product id
   * @returns Product | undefined
   */
  public async cartNotifications(
    market: MarketInfo,
    params: NotificationsRequestDto,
  ): Promise<boolean> {
    const clusterId = '{{CLUSTER_ID}}';
    try {
      const currentMarket = `${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}`;
      const apptusQueryParams = {
        'esales.market': currentMarket,
        'esales.customerKey': params.customerKey,
        'esales.sessionKey': params.sessionKey,
      };

      const queryParams = this.common.queryString(apptusQueryParams);
      let url = `${this.apptusBaseUrl.replace(clusterId, this.apptusClusterId)}${URI.apptus.nonEsaleAddToCart}?${queryParams}`;
      let payload: NotificationRequest = {
        productKey: `${params.productKey}_${currentMarket}`,
        variantKey: `${params.variantKey}_${currentMarket}`,
      };
      if (params.ticket) {
        url = `${this.apptusBaseUrl.replace(clusterId, this.apptusClusterId)}${URI.apptus.esaleAddToCart}?${queryParams}`;
        payload = { ticket: params.ticket };
      }

      await axios.post(url, payload, axiosOptions);
      return true;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      if (error.response) {
        throw new ApiError(error.response.status, error.response.data);
      }
      throw new Error(`Failed to fetch notifications from Apps, because: ${error.stack}`);
    }
  }
}
