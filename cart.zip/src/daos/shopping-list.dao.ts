import { ClientResponse, GraphQLResponse } from '@commercetools/platform-sdk';
import { MarketInfo } from '../middlewares';
import { CtClient, logger } from '../lib';
import { graphql } from '../graphql';
import { GraphQLShoppingList } from '../dtos';

export interface ShoppingListDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

/**
 * `ShoppingListDao` data access class for CommerceTools `ShoppingList`
 */
export class ShoppingListDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
     * Constructor for `ShoppingListDao` class
     * @param config injects dependencies into the object
     */
  constructor(config: ShoppingListDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
 * Reads a Wishlist from CommerceTools
 * @param market - MarketInfo
 * @param wishListId - Id of CT Wishlist to retrieve
 * @returns Fetched wishlistDao (or undefined if the Wishlist doesn't exist)
 */
  public async findGraphQLOne(
    market: MarketInfo,
    wishListId: string,
  ): Promise<GraphQLShoppingList | undefined> {
    const body = {
      query: await this.graphql.getShoppingListById,
      variables: {
        id: wishListId,
        locale: market.locale,
      },
    };
    try {
      const result: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body })
        .execute();
      const { shoppingList } = result.body.data;
      if (shoppingList === null) {
        return undefined;
      }
      return shoppingList;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
        + ` GraphQL returned: ${JSON.stringify(err.body.errors)}.`);

      throw err;
    }
  }
}
