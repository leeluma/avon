import HttpStatusCodes from 'http-status-codes';
import axios, { AxiosRequestConfig } from 'axios';
import i18next from 'i18next';
import {
  Cart, CartUpdateAction, ClientResponse, GraphQLResponse,
} from '@commercetools/platform-sdk';
import { CtClient, ApiError, logger } from '../lib';
import { createCartDraft } from '../common/daos.helper';
import {
  LineItemDto, CartDto, CartsInfo, GraphQLDiscountCode,
} from '../dtos';
import { MarketInfo } from '../middlewares';
import { RESPONSE_KEY } from '../common/constants';
import { graphql } from '../graphql';

const queryCondition = 'lineItems[*].discountedPricePerQuantity[*].discountedPrice.includedDiscounts[*].discount';

interface CartDaoConfig {
  ctClient: CtClient;
  beOrderUrl: string;
  graphql: typeof graphql;
}

/* `CtCartDao` data access class for CommerceTools `Cart` */
export class CartDao {
  private readonly ctClient: CtClient;

  private readonly beOrderUrl: string;

  private readonly graphql: typeof graphql;

  private readonly cartIdNotFound = 'error.cartIdNotFound';

  /**
   * Constructor for `CartDao` class
   * @param config injects dependencies into the object
   */
  constructor(config: CartDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
    this.beOrderUrl = config.beOrderUrl;
  }

  /** Creates a cart in CommerceTools
   * @param country - Country * @param currency - Currency * @param anonymousId - string  * @param customerId - string
   * @param lineItems - string   * @returns created cart
   */
  public createCart = async (country: string, currency: string, lineItems: LineItemDto[],
    anonymousId?: string, customerId?: string):Promise<Cart> => {
    const cartDraft = createCartDraft(currency, {
      country, currency, anonymousId, customerId, lineItems,
    });
    const cart = await this.ctClient.getClient(country).carts().post({ body: cartDraft }).execute();
    return cart.body;
  };

  /** Get cart by Id from CommerceTools
   * @param country - string * @param cartId - string * @returns cart from the commercetools
   */
  public getCartById = async (market: MarketInfo, cartId: string): Promise<Cart | undefined> => {
    try {
      const locale = market.locale.toLocaleUpperCase();
      const body = {
        query: await this.graphql.getCartPaymentInfo,
        variables: {
          cartId,
          locale,
        },
      };
      const cart: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
        .graphql().post({ body }).execute();
      return cart.body.data?.cart;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possiblities of types in case of error i.e. any|unknown
      logger.error(`from Commerce tool, because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, `Cart with CartId "${cartId}" not found.`);
      }
      throw err;
    }
  };

  /** Get discount by Id from CommerceTools
   * @param country - string  * @param discountCodeId - string * @returns cart from the commercetools
   */
  public getDiscountById = async (market: MarketInfo, discountCodeId: string): Promise<GraphQLDiscountCode | undefined> => {
    const body = {
      query: await this.graphql.getDiscountcodeById,
      variables: {
        id: discountCodeId,
      },
    };

    let discountResponse: ClientResponse<GraphQLResponse>;
    try {
      discountResponse = await this.ctClient.getClient(market.country).graphql().post({ body }).execute();
      return discountResponse.body.data?.discountCode;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
        + ` GraphQL returned: ${JSON.stringify(err.body?.errors)}.`);
      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, `Discountcode with discountCodeId "${discountCodeId}" not found.`);
      }
      throw err;
    }
  };

  /**  Add product to cart from order bff
  * @param country - string * @param cartId - string * @param cartVersion - number * @param sku - string
  * @param quantity - number * @returns Updated cart after adding the product in cart from order bff
  */
  public async addProductToCart(cartInfo: CartsInfo): Promise<CartDto> {
    const {
      market, channelKey, customerId, anonymousId, cartId, sku, quantity, productKey,
    } = cartInfo;
    const axiosConfig: AxiosRequestConfig = {
      method: 'post' as const,
      url: `${this.beOrderUrl.replace('{{MARKET}}', market.localeAndCountry)}/carts`,
      headers: {
        'Content-Type': RESPONSE_KEY.applicationJson,
        Accepts: RESPONSE_KEY.applicationJson,
      },
      data: {
        anonymousId,
        customerId,
        channelKey,
        cartId,
        lineItems: { sku, quantity, productKey },
      },
    };
    try {
      const response = await axios(axiosConfig);
      return response.data.data;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`LEAP BE ORDER returned error: ${err}`);
      if (!err.response) {
        throw err;
      }
      throw new ApiError(err.response.status, err.response.data?.errors);
    }
  }

  /** Remove Line Item in cart from CommerceTools
   * @param country - string * @param cart - Cart  * @param lineItemId - string
   * @returns Updated cart after removing the product in cart
   */
  public removeLineItem = async (country: string, cart: Cart | undefined, lineItemId: string): Promise<Cart> => {
    try {
      const actions: CartUpdateAction[] = [{
        action: 'removeLineItem',
        lineItemId,
      }];
      if (cart?.lineItems.length === 1) {
        actions.push({
          action: 'setShippingMethod',
        });
      }
      const updatedCart = await this
        .ctClient.getClient(country).carts().withId({ ID: cart?.id }).post({
          body: {
            version: cart?.version,
            actions,
          },
          queryArgs: { expand: [queryCondition] },
        })
        .execute();
      return updatedCart.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to delete cart id "${lineItemId}" from CT, because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, `Cart with lineItemId "${lineItemId}" not found.`);
      }
      throw err;
    }
  };

  /** Change Line Item Quantity in cart in Commercetools
   * @param country - string * @param cart - Cart * @param lineItemId - string
   * @returns Updated cart after removing the product in cart
   */
  public changeLineItemQuantity = async (country: string, cart: Cart | undefined, lineItemId: string, quantity: number):
   Promise<Cart> => {
    try {
      const updatedCart = await this
        .ctClient.getClient(country).carts().withId({ ID: cart?.id }).post({
          body: {
            version: cart?.version,
            actions: [{
              action: 'recalculate', updateProductData: true,
            },
            {
              action: 'changeLineItemQuantity',
              lineItemId,
              quantity,
            }],
          },
          queryArgs: { expand: [queryCondition] },
        })
        .execute();
      return updatedCart.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to change quantity of line item in cart from CT, because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, `Cart with lineItemId "${lineItemId}" not found.`);
      }
      throw err;
    }
  };

  /** Recalculate cart
   * @param country - string * @param cart - any  * @param action - string * @returns Updated cart after recalculating it */
  public recalculateCart = async (market: MarketInfo, cart: Cart | undefined): Promise<Cart> => {
    try {
      const recalculatedCart = await this
        .ctClient.getClient(market.country).carts().withId({ ID: cart?.id }).post({
          body: {
            version: cart?.version,
            actions: [{
              action: 'recalculate',
              updateProductData: true,
            }],
          },
          queryArgs: { expand: [queryCondition] },
        })
        .execute();
      return recalculatedCart.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to recalculate cart because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.BAD_REQUEST) {
        throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t(this.cartIdNotFound, { cartId: cart?.id }));
      }
      throw err;
    }
  };

  /** Get cart payment information from CommerceTools using graphql * @param market - MarketInfo
   * @param cartId - Id of Commerce tool cart to retrieve * @returns Fetched cartDao (or undefined if the cart don't exist) */
  public async getCartPaymentInfo(market: MarketInfo, cartId: string) {
    try {
      const locale = market.locale.toLocaleUpperCase();
      const body = {
        query: await this.graphql.getCartPaymentInfo,
        variables: { cartId, locale },
      };

      const cart: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          body,
        })
        .execute();
      return cart.body.data?.cart;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possiblities of types in case of error i.e. any|unknown
      logger.error(`from Commerce tool, because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, `Payment info with cartId "${cartId}" not found.`);
      }
      throw err;
    }
  }

  /** replicate cart by cart id * @param country - string * @param cartId - cartId * @returns replicated new cart using old cart id */
  public replicateCartById = async (country: string, cartId: string): Promise<Cart> => {
    try {
      const updatedCart = await this
        .ctClient.getClient(country).carts().replicate()
        .post({
          body: {
            reference: {
              typeId: 'cart', id: cartId,
            },
          },
        })
        .execute();
      return updatedCart.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possiblities of types in case of error i.e. any|unknown
      logger.error(`Failed to replicate cart because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.BAD_REQUEST) {
        throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t(this.cartIdNotFound, { cartId }));
      }
      throw err;
    }
  };
}
