import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { CartService, PromotionService, ShippingService } from '../services';
import { MarketInfo } from '../middlewares';
import {
  CartDto, CommonResponse, MagnoliaInfo, ShippingMethodDto,
} from '../dtos';
import { JsonApiResponseEntity, ApiError } from '../lib';

interface CartControllerConfig {
  cartService: CartService;
  promotionService: PromotionService;
  shippingService: ShippingService;
}

export class CartController {
  private readonly cartService: CartService;

  private readonly promotionService: PromotionService;

  private readonly shippingService: ShippingService;

  constructor(config: CartControllerConfig) {
    this.cartService = config.cartService;
    this.promotionService = config.promotionService;
    this.shippingService = config.shippingService;
  }

  public getCartById = async (
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<CommonResponse>> => {
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;
    const { id } = req.params;
    const { wishlistid } = req.headers;

    const cart = await this.cartService.getCartById(market, id, magnolia, wishlistid as string | undefined);
    if (cart === undefined) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, `Cart with id "${id}" not found.`);
    }
    return {
      statusCode: HttpStatusCodes.OK,
      body: cart,
    };
  };

  public addProductToCart = async (
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<CartDto>> => {
    const market = res.locals.market as MarketInfo;
    const {
      anonymousId, customerId, cartId, lineItems,
    } = req.body;
    const { sku, quantity, productKey } = lineItems;
    const channelKey = req.headers.channelkey;
    const data = {
      market,
      channelKey: channelKey as string | undefined,
      customerId,
      anonymousId,
      cartId,
      sku,
      quantity,
      productKey,
    };
    /* Call service */
    const cart = await this.cartService.addProductToCart(data);
    return {
      statusCode: HttpStatusCodes.OK,
      body: cart,
    };
  };

  public removeLineItem = async (req: Request,
    res: Response): Promise<JsonApiResponseEntity<CartDto>> => {
    const market = res.locals.market as MarketInfo;
    const { cartId } = req.params;
    const { lineItemId } = req.params;
    const cart = await this.cartService.removeLineItem(market, cartId, lineItemId);
    if (cart === undefined) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, `Cart with key "${cartId}" not found.`);
    }
    return {
      statusCode: HttpStatusCodes.OK,
      body: cart,
    };
  };

  public changeLineItemQuantity = async (req: Request,
    res: Response): Promise<JsonApiResponseEntity<CartDto>> => {
    const market = res.locals.market as MarketInfo;
    const { cartId, lineItemId } = req.params;
    const quantity = parseInt(req.body.quantity, 10);
    const cart = await this.cartService.changeLineItemQuantity(market, cartId, lineItemId, quantity);
    if (cart === undefined) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, `Cart with key "${cartId}" not found.`);
    }
    return {
      statusCode: HttpStatusCodes.OK,
      body: cart,
    };
  };

  public cartPromotion = async (req: Request,
    res: Response): Promise<JsonApiResponseEntity<CartDto>> => {
    const market = res.locals.market as MarketInfo;
    const { cartId } = req.params;
    const { promotionCode, action, promotionId } = req.body;
    const cart = await this.promotionService.promotion(market, cartId, promotionCode, action, promotionId);
    if (cart === undefined) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, `Cart with key "${cartId}" not found.`);
    }
    return {
      statusCode: HttpStatusCodes.OK,
      body: cart,
    };
  };

  /**
   * Get all the shipping method controller implementation
   * @param req - Request
   * @param res - Response
   * @returns shipping method body and Status code
   */
  public getShippingMethod = async (
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<ShippingMethodDto>> => {
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;
    const shoppingMethodCart = await this.shippingService.getShippingMethod(magnolia, market);
    return {
      statusCode: HttpStatusCodes.OK,
      body: shoppingMethodCart,
    };
  };

  /**
   * Sets shipping address in cart
   * @param req Request
   * @param res Response
   * @returns Cart Data
   */
  public setShippingAddress = async (req: Request,
    res: Response): Promise<JsonApiResponseEntity<CartDto>> => {
    const market = res.locals.market as MarketInfo;
    const { cartId } = req.params;
    const shippingAddressDetails = req.body;
    const updatedCartWithShippingAddress = await this.shippingService.setShippingAddress(market, cartId, shippingAddressDetails);
    if (updatedCartWithShippingAddress === undefined) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, `Cart with key "${cartId}" not found.`);
    }
    return {
      statusCode: HttpStatusCodes.OK,
      body: updatedCartWithShippingAddress,
    };
  };
}
