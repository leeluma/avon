import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { DefaultService, MagnoliaService } from '../services';
import { MarketInfo } from '../middlewares';
import {
  AnonymousFlowResponseDto, CommonResponse, MagnoliaInfo,
} from '../dtos';
import { JsonApiResponseEntity } from '../lib';

export interface DefaultControllerConfig {
  defaultService: DefaultService;
  magnoliaService: MagnoliaService;
}

export class DefaultController {
  private readonly defaultService: DefaultService;

  private readonly magnoliaService: MagnoliaService;

  constructor(config: DefaultControllerConfig) {
    this.defaultService = config.defaultService;
    this.magnoliaService = config.magnoliaService;
  }

  /**
   * Create Anonymous session
   * @param request - Express request object
   * @param response - Express response object
   */
  public async createAnonymousSession(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<AnonymousFlowResponseDto>> {
    const market = response.locals.market as MarketInfo;

    const result = await this.defaultService.createAnonymousSession(market);
    return {
      statusCode: HttpStatusCodes.OK,
      body: result,
    };
  }

  /**
   * Get Account magnolia data
   * @param req - Express request object
   * @param res - Express response object
   * @returns Promise
   */
  public async fetchMagnoliaData(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<CommonResponse>> {
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;
    const [globalSettings, staticPageData] = await Promise.all([
      this.magnoliaService.getGlobalSettingsData(market, magnolia),
      this.magnoliaService.fetchMagnoliaData(market, magnolia),
    ]);
    let magnoliaTemplateData = {};
    if (magnolia.isPreview && staticPageData !== undefined) {
      magnoliaTemplateData = await this.magnoliaService.getTemplateData(staticPageData['mgnl:template'], magnolia);
    }
    const responseData = {
      ...staticPageData,
      globalSettings,
      templateDefinition: magnoliaTemplateData,
    };
    return {
      statusCode: HttpStatusCodes.OK,
      body: responseData,
    };
  }

  /**
   * Refresh token
   * @param request - Express request object
   * @param response - Express response object
   */
  public async refreshToken(
    request: Request,
    response: Response,
  ):Promise<JsonApiResponseEntity<CommonResponse>> {
    const market = response.locals.market as MarketInfo;
    const { refreshtoken } = request.headers;
    const refreshTokenResult = await this.defaultService.refreshToken(market, refreshtoken);
    return {
      statusCode: HttpStatusCodes.OK,
      body: refreshTokenResult,
    };
  }
}
