const { handler } = require('../index');

describe('handler', () => {
  let callback;
  let event;
  beforeEach(() => {
    callback = jest.fn();
    event = {
      pathParameters: {
        country: 'RO',
        thepath: '/path',
      },
    };
  });

  describe('handler()', () => {
    test('handler', async () => {
      event = {
        pathParameters: {
          country: 'RO',
          thepath: 'pages/privacy-policy',
        },
      };
      await handler(event, undefined, callback);
      expect(handler).toEqual(expect.any(Function));
    });
  });
});
