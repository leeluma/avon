```shell
npm install
sls deploy
sls deploy --verbose --force
sls deploy --stage production --region eu-west-1
sls remove
```

# Invoke function locally

Create `.env` file containing:

```dotenv
AWS_REGION: eu-west-1
AWS_BUCKET: leap-s3-redirection-rules
AWS_KEY: redirection-rules.json
EXISTING_REDIRECT_RULES_API: {aws_cloudfront_distribution.config_distribution.domain_name}
```

```

1. add package json [DONE]
2. add env. variable [DONE]
3. add dependency for AWS [DONE]

```



