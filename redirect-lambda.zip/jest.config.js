const path = require('path');

const config = {
  verbose: true,
  // setupFiles: [path.resolve(__dirname, 'tests/setup.ts')],
  modulePathIgnorePatterns: ['__stubs__'],
  maxWorkers: '100%',
  resetMocks: true,
  coverageDirectory: path.resolve(__dirname, 'artifacts/coverage'),
  cacheDirectory: path.resolve(__dirname, 'artifacts/jest-cache'),
  testPathIgnorePatterns: ['/node_modules/', '/dist/'],
  coveragePathIgnorePatterns: [],
  testResultsProcessor: 'jest-sonar-reporter',
  reporters: [
    'default',
    ['./node_modules/jest-html-reporter', {
      pageTitle: 'Test Report',
      outputPath: path.resolve(__dirname, 'artifacts/jest-html-report.html'),
    }],
  ],
};

module.exports = config;

process.env = Object.assign(process.env, {
  AWS_BUCKET: 'leap-s3-redirection-rules',
  AWS_KEY: 'redirection-rules.json',
  EXISTING_REDIRECT_RULES_API: 'https://{{AWS_BUCKET}}.s3.{{AWS_REGION}}.amazonaws.com',
  URL: 'https://{{S3_BUCKET}}-{{COUNTRY}}.s3.{{AWS_REGION}}.amazonaws.com/redirection-rules.json',
  AWS_REGION: 'eu-west-1',
  S3_BUCKET: 'leap-s3-redirection-rules',
});
