const axios = require('axios');
const ssm = new (require('aws-sdk/clients/ssm'))()
const CACHE_TIME_IN_SEC = 0;
let cachedTime = 0;

//https://leap-s3-redirection-rules.s3.eu-west-1.amazonaws.com/

async function getRules(country) {
  const url = await ssm.getParameters({
    Names: [`path`]
}).promise();
console.log("mycloudurl", url);
  const config = {
    method: 'get',
    url,
  };
  const result = await axios(config);
  return result.data;
}
function createResponse(status, target) {
  return {
    status,
    headers: { location: target },
  };
}

exports.handler = async (event, _context, callback) => {
  const now = new Date();
  let rules = {};
  /* istanbul ignore else */
  if (rules.length === 0 || ((now - cachedTime) / 1000 > CACHE_TIME_IN_SEC)) {
    const rawRules = await getRules(`${event.pathParameters.country}`);
    rawRules.forEach((item) => {
      // eslint-disable-next-line no-param-reassign
      item.original = item.original.replace(/\/$/, '');
    });
    rules = new Map(rawRules.map((uri) => ([uri.original, uri])));
    console.log('Updated rules:', rules);
    cachedTime = new Date();
  }
  const url = rules.get(`/${event.pathParameters.thepath}`);
  /* istanbul ignore else */
  if (url) {
    const statusCode = parseInt(url.statusCode, 10);
    const target = url.redirect;
    console.log(`Redirecting ${statusCode} from source "${event.path}" to "${target}"`);
    return callback(null, createResponse(statusCode, target));
  }
  console.log(`Path "${event.path}" is not in the redirect list`);
  return callback(null, { status: 404, body: 'Not Found' });
};