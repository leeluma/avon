const packageJson = require('../package.json');

const VERSION_REGEX = /^(\d+\.\d+\.\d+)|(file:.*)$/;

const allDependencies = {
  ...packageJson.dependencies,
  ...packageJson.devDependencies,
  ...packageJson.peerDependencies,
};

const badDependencies = Object.keys(allDependencies)
  .filter((name) => !VERSION_REGEX.test(allDependencies[name]));

if (badDependencies.length) {
  badDependencies.join('\n - ');

  console.error(`The following packages have invalid versions specified in package.json:
 - ${badDependencies.join('\n - ')}
All packages must have exact versions specified!
For example, you should use "1.2.3" instead of "^1.2.3"`);

  process.exit(1);
}
