import faker from '@faker-js/faker';
import { MagnoliaInfo } from '../../src/dtos';

export const stubMagnoliaInfo = (
  config: Partial<MagnoliaInfo> = {},
): MagnoliaInfo => {
  return {
    url: faker.internet.url(),
    ispreview: true,
    marketPath: faker.datatype.string(),
    ...config,
  };
};
