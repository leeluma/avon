import faker from '@faker-js/faker';
import { AddToCartResponseDto } from '../../src/dtos';

export const stubAddToCartResponseDto = (
  config: Partial<AddToCartResponseDto> = {},
): AddToCartResponseDto => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    customerId: faker.datatype.uuid(),
    anonymousId: faker.datatype.uuid(),
    lineItems: [],
    shippingAddress: { country: faker.address.country() },
    totalAdjustmentAmount: faker.datatype.number(),
    totalTaxAmount: faker.datatype.number(),
    totalInvoicedAmount: faker.datatype.number().toString(),
    totalRetailPriceAmount: faker.datatype.number().toString(),
    ...config,
  };
};
