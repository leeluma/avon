import faker from '@faker-js/faker';
import { MagnoliaGlobalSettingDto } from '../dtos';

export const stubMagnoliaGlobalSetting = (
  config: Partial<MagnoliaGlobalSettingDto> = {},
): MagnoliaGlobalSettingDto => {
  return {
    '@name': 'settings',
    '@path': faker.datatype.string(),
    '@id': faker.datatype.uuid(),
    '@nodeType': faker.datatype.string(),
    text: faker.datatype.string(),
    warehouseSettings: {
      isSingleWarehouse : `${faker.datatype.boolean()}`,
      defaultWarehouse : `${faker.datatype.string()}`
    },
    brandName: `${faker.datatype.string()}`,
    '@nodes': [],
    ...config,
  };
};
