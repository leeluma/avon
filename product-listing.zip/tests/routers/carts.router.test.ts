import { Router } from 'express';
import { CartsRouter } from '../../src/routers';
import { CartsController } from '../../src/controllers';
import { validateAddToCart } from '../../src/validators';
import { validateRequestSchema } from '../../src/middlewares';

describe('cartsRouter', () => {
  let cartsRouter: CartsRouter;

  let cartsController: CartsController;
  let mockRouter: Router;

  beforeEach(() => {
    cartsController = {
      addProductToCart: jest.fn(),
    } as any;

    mockRouter = {
      post: jest.fn(),
    } as any;

    cartsRouter = new CartsRouter({
      Router: () => mockRouter,
      cartsController,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = cartsRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      cartsRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenCalledTimes(1);
    });

    test('configures the POST / route', () => {
      cartsRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        1,
        '/',
        validateAddToCart,
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
