import { Router } from 'express';
import { ProductsRouter } from '../../src/routers';
import { ProductsController } from '../../src/controllers';
import { validateCategory, validateProductSearch } from '../../src/validators';
import { apptusLogConfig, magnoliaUrlMiddleware, validateRequestSchema } from '../../src/middlewares';

describe('productsRouter', () => {
  let productsController: ProductsController;
  let productsRouter: ProductsRouter;
  let mockRouter: Router;

  beforeEach(() => {
    productsController = {
      search: jest.fn(),
      category: jest.fn(),
    } as any;

    mockRouter = {
      get: jest.fn(() => mockRouter),
    } as any;

    productsRouter = new ProductsRouter({
      productsController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter() for Search', () => {
    test('returns the express router', () => {
      const response = productsRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      productsRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(2);
    });

    test('configures the GET /search route', () => {
      productsRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/search',
        validateProductSearch,
        validateRequestSchema,
        apptusLogConfig,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
  });

  describe('buildExpressRouter() for category', () => {
    test('returns the express router', () => {
      const response = productsRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('configures the GET /category route', () => {
      productsRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        2,
        '/category',
        validateCategory,
        validateRequestSchema,
        apptusLogConfig,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
  });
});
