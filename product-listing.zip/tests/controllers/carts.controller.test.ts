// eslint-disable-next-line import/no-extraneous-dependencies
import faker from '@faker-js/faker';
import HttpStatusCodes from 'http-status-codes';
import { Request, Response } from 'express';
import { MarketInfo } from '../../src/middlewares';
import { CartsController } from '../../src/controllers';
import { CartsService } from '../../src/services';
import { stubMarket, stubExpressReq, stubExpressRes } from '../__stubs__';
import { AddtoCartRequestDto, AddToCartResponseDto } from '../../src/dtos';
import Mock = jest.Mock;

describe('CartsController', () => {
  /* System Under Test */
  let cartsController: CartsController;

  /* Dependencies */
  let cartsService: CartsService;
  let market: MarketInfo;

  /* Stubs */
  let request: Request;
  let response: Response;

  beforeEach(() => {
    market = stubMarket();
    /* Stubs */
    request = stubExpressReq();
    response = stubExpressRes(market);

    /* Dependencies */
    cartsService = {} as any;

    cartsController = new CartsController({ cartsService });
  });

  describe('addProductToCart()', () => {
    let customerId: string;
    let cartId: string;
    let sku: string;
    let quantity: number;
    let productKey: string;
    let channelkey: string;
    let anonymousId: string;

    beforeEach(() => {
      cartsService.addProductToCart = jest.fn();

      customerId = faker.datatype.uuid();
      cartId = faker.datatype.uuid();
      sku = faker.datatype.uuid();
      quantity = faker.datatype.number();
      productKey = faker.datatype.uuid();
      channelkey = faker.datatype.uuid();
      request.headers.channelkey = channelkey;
      request.body = {
        customerId,
        cartId,
        lineItems: {
          sku,
          quantity,
          productKey,
        },
        channelkey,
      };
    });
    test('returns the result from the cartService', async () => {
      /* Prepare */
      const addToCartResponseDto = { id: faker.datatype.uuid() } as AddToCartResponseDto;
      (cartsService.addProductToCart as Mock).mockReturnValueOnce(addToCartResponseDto);

      /* Execute */
      const result = await cartsController.addProductToCart(request, response);

      /* Verify */
      expect(result).toStrictEqual({
        body: addToCartResponseDto,
        statusCode: HttpStatusCodes.OK,
      });
    });
  });
});
