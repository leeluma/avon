import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { LogConfig, LogStatus, MarketInfo } from '../../src/middlewares';

import { ProductsController } from '../../src/controllers';
import { ProductsService } from '../../src/services';

import Mock = jest.Mock;
import {
  stubMarket, stubExpressReq, stubExpressRes, stubMagnoliaInfo,
} from '../__stubs__';
import { MagnoliaInfo } from '../../src/dtos';

describe('ProductsController', () => {
  /* System Under Test */
  let productsController: ProductsController;

  /* Dependencies */
  let productsService: ProductsService;
  let market: MarketInfo;
  let magnoliaInfo: MagnoliaInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();
    magnoliaInfo = stubMagnoliaInfo();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    productsService = {} as any;

    productsController = new ProductsController({ productsService });
  });

  describe('products methods', () => {
    describe('search()', () => {
      beforeEach(() => {
        productsService.search = jest.fn();
        req.query.windowFirst = faker.datatype.string();
        req.query.windowLast = faker.datatype.string();
        req.query.selectedCategory = faker.datatype.string();
        req.query.sortBy = faker.datatype.string();
        req.query.windowFirstRecommendations = faker.datatype.string();
        req.query.windowLastRecommendations = faker.datatype.string();
        req.query.maxFacets = faker.datatype.string();
        req.query.rootCategory = faker.datatype.string();
        req.query.maxProducts = faker.datatype.string();
        req.headers.channelKey = faker.datatype.string();
        res.locals.logConfig = {
          apptusLogStatus: LogStatus.NONE,
        };
      });

      test('calls product with request parameters', async () => {
        /* Prepare */
        (productsService.search as Mock).mockReturnValueOnce({ data: 'productList' });

        /* Execute */
        await productsController.search(req, res);
        const queryPrams = {
          windowFirst: req.query.windowFirst,
          windowLast: req.query.windowLast,
          selectedCategory: req.query.selectedCategory,
          sortBy: req.query.sortBy,
          windowFirstRecommendations: req.query.windowFirstRecommendations,
          windowLastRecommendations: req.query.windowLastRecommendations,
          maxFacets: req.query.maxFacets,
          rootCategory: req.query.rootCategory,
          maxProducts: req.query.maxProducts,
          depth: req.query.depth,
          filter: req.query.filter,
          searchPhase: req.query.searchPhase,
        };
        const { channelkey } = req.headers;
        const ispage = req.headers.ispage === 'true';
        const logConfig: LogConfig = {
          apptusLogStatus: LogStatus.NONE,
        };

        /* Verify */
        expect(productsService.search).toHaveBeenCalledTimes(1);
        expect(productsService.search).toHaveBeenNthCalledWith(
          1,
          market,
          queryPrams,
          channelkey,
          ispage,
          logConfig,
          undefined,
        );
      });
    });

    describe('category()', () => {
      beforeEach(() => {
        productsService.category = jest.fn();
        req.query.windowFirst = faker.datatype.string();
        req.query.windowLast = faker.datatype.string();
        req.query.selectedCategory = faker.datatype.string();
        req.query.sortBy = faker.datatype.string();
        req.query.windowFirstRecommendations = faker.datatype.string();
        req.query.windowLastRecommendations = faker.datatype.string();
        req.query.maxFacets = faker.datatype.string();
        req.query.rootCategory = faker.datatype.string();
        req.query.maxProducts = faker.datatype.string();
        req.headers.channelKey = faker.datatype.string();
        res.locals.logConfig = {
          apptusLogStatus: LogStatus.NONE,
        };
      });

      test('calls product with request parameters', async () => {
        /* Prepare */
        (productsService.category as Mock).mockReturnValueOnce({ data: 'productList' });

        /* Execute */
        await productsController.category(req, res);
        const queryPrams = {
          windowFirst: req.query.windowFirst,
          windowLast: req.query.windowLast,
          selectedCategory: req.query.selectedCategory,
          sortBy: req.query.sortBy,
          windowFirstRecommendations: req.query.windowFirstRecommendations,
          windowLastRecommendations: req.query.windowLastRecommendations,
          maxFacets: req.query.maxFacets,
          rootCategory: req.query.rootCategory,
          maxProducts: req.query.maxProducts,
          depth: req.query.depth,
          filter: req.query.filter,
        };
        const { channelkey } = req.headers;
        const ispage = req.headers.ispage === 'true';
        const logConfig: LogConfig = {
          apptusLogStatus: LogStatus.NONE,
        };

        /* Verify */
        expect(productsService.category).toHaveBeenCalledTimes(1);
        expect(productsService.category).toHaveBeenNthCalledWith(
          1,
          market,
          queryPrams,
          channelkey,
          ispage,
          logConfig,
          undefined,
        );
      });
    });
  });
});
