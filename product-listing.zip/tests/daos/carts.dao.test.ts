// eslint-disable-next-line import/no-extraneous-dependencies
import faker from '@faker-js/faker';
import { Cart } from '@commercetools/platform-sdk';
import axios from 'axios';
import HttpStatusCodes from 'http-status-codes';
import { MarketInfo } from '../../src/middlewares';
import { CartsDao } from '../../src/daos';
import { stubMarket } from '../__stubs__';
import { ApiError } from '../../src/lib';
import Mock = jest.Mock;
import { AddtoCartRequestDto } from '../../src/dtos';

jest.mock('axios');

describe('CartsDao', () => {
  let cartsDao: CartsDao;

  let market: MarketInfo;
  let beOrderUrl: string;

  beforeEach(() => {
    market = stubMarket();
    beOrderUrl = 'https://url/{{MARKET}}';

    cartsDao = new CartsDao({ beOrderUrl });
  });

  describe('addProductToCart()', () => {
    let customerId: string;
    let cartId: string;
    let sku: string;
    let quantity: number;
    let productKey: string;
    let channelkey: string;
    let anonymousId: string;
    let cart: Cart;

    beforeEach(() => {
      customerId = faker.datatype.uuid();
      cartId = faker.datatype.uuid();
      sku = faker.datatype.uuid();
      quantity = faker.datatype.number();
      productKey = faker.datatype.uuid();
      channelkey = faker.datatype.string();
      cart = { id: faker.datatype.uuid() } as Cart;
    });

    test('builds axiosConfig', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockReturnValueOnce({ data: { data: cart } });
      const params : AddtoCartRequestDto = {
        market,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
        channelkey,
      };
      /* Execute */
      await cartsDao.addProductToCart(params);

      /* Verify */
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(
        1,
        {
          method: 'post',
          url: `https://url/${market.locale}-${market.country}/carts`,
          headers: {
            'Content-Type': 'application/json',
            Accepts: 'application/json',
          },
          data: {
            customerId,
            cartId,
            lineItems: {
              sku,
              quantity,
              productKey,
            },
            channelKey: channelkey,
          },
        },
      );
    });

    test('returns data from leap-be-order', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockReturnValueOnce({ data: { data: cart } });
      const params: AddtoCartRequestDto = {
        market,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
        channelkey,
      };
      /* Execute */
      const response = await cartsDao.addProductToCart(params);

      /* Verify */
      expect(response).toBe(cart);
    });

    test('rethrows connection errors', async () => {
      const params: AddtoCartRequestDto = {
        market,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
        channelkey,
      };
      const connectionError = new Error('something went wrong');
      (axios as unknown as Mock).mockRejectedValueOnce(connectionError);

      const response = () => cartsDao.addProductToCart(params);

      await expect(response).rejects.toThrow(connectionError);
    });

    test('returns leap-be-order errors', async () => {
      const params: AddtoCartRequestDto = {
        market,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
        channelkey,
      };
      const beOrderError = Object.assign(
        new Error('something went wrong'),
        {
          response: {
            status: HttpStatusCodes.NOT_FOUND,
            data: { errors: ['sku not found'] },
          },
        },
      );
      (axios as unknown as Mock).mockRejectedValueOnce(beOrderError);

      const response = () => cartsDao.addProductToCart(params);

      await expect(response).rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, ['sku not found']),
      );
    });
  });
});
