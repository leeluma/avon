// eslint-disable-next-line import/no-extraneous-dependencies
import faker from '@faker-js/faker';
import axios from 'axios';
import { MarketInfo } from '../../src/middlewares';
import { stubMarket } from '../__stubs__';
import Mock = jest.Mock;
import { NotificationsDao } from '../../src/daos/notifications.dao';
import { Common } from '../../src/lib';

jest.mock('axios');

describe('NotificationsDao testing Suit', () => {
  let notificationsDao: NotificationsDao;
  let common: Common;
  let market: MarketInfo;
  let queryString: Mock;
  let log: Mock;
  let convertUnderScoreToCamelCaseForApptus: Mock;
  let convertUnderScoreToCamelCase: Mock;
  let isResponseOK: Mock;
  let apptusBaseUrl: string;
  let apptusClusterId: string;
  let apptusEsalesMarket: string;
  let params;

  beforeEach(() => {
    market = stubMarket();
    apptusBaseUrl = faker.internet.url();
    apptusClusterId = faker.datatype.uuid();
    apptusEsalesMarket = 'AVONSHOP_';

    queryString = jest.fn();
    convertUnderScoreToCamelCaseForApptus = jest.fn();
    convertUnderScoreToCamelCase = jest.fn();
    log = jest.fn();
    isResponseOK = jest.fn();
    common = {
      queryString,
      convertUnderScoreToCamelCaseForApptus,
      convertUnderScoreToCamelCase,
      isResponseOK,
      log,
    };

    notificationsDao = new NotificationsDao({
      common,
      apptusBaseUrl,
      apptusClusterId,
      apptusEsalesMarket,
    });

    params = {
      sessionKey: faker.datatype.uuid(),
      customerKey: faker.datatype.uuid(),
      ticket: faker.datatype.uuid(),
      productKey: undefined,
      variantKey: undefined,
    };
  });

  describe('esaleNotifications()', () => {
    const mockResponse = {
      data: true,
    };
    test('returns apptus response body', async () => {
      /* Prepare */
      (axios.post as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await notificationsDao.esaleNotifications(market, params);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios.post).toHaveBeenCalledTimes(1);
    });

    test('returns apptus response body if params.ticket is undefined', async () => {
      /* Prepare */
      delete params.ticket;
      (axios.post as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await notificationsDao.esaleNotifications(market, params);

      /* Verify */
      expect(axios.post).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia data', async () => {
      const error = new Error('Magnolia throw error');
      (axios.post as unknown as Mock).mockRejectedValueOnce(error);
      /* Execute */
      const response = expect(() => (notificationsDao).esaleNotifications(market, params));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch notifications from Apptus, because: ${error.stack}`),
      );
      expect(axios.post).toHaveBeenCalledTimes(1);
    });

    test('forwards errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 500,
        response: {
          statusCode: 500,
          msg: faker.datatype.string(),
          timestamp: faker.datatype.datetime(),
        },
        errors: [
          {
            msg: faker.datatype.string(),
          },
        ],
      };

      (axios.post as unknown as Mock).mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => notificationsDao.esaleNotifications(market, params));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  describe('cartNotifications()', () => {
    const mockResponse = {
      data: true,
    };
    test('returns apptus response body', async () => {
      /* Prepare */
      (axios.post as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await notificationsDao.cartNotifications(market, params);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios.post).toHaveBeenCalledTimes(1);
    });

    test('returns apptus response body if params.ticket is undefined', async () => {
      /* Prepare */
      delete params.ticket;
      (axios.post as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await notificationsDao.cartNotifications(market, params);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios.post).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia data', async () => {
      const error = new Error('Magnolia throw error');
      (axios.post as unknown as Mock).mockRejectedValueOnce(error);
      /* Execute */
      const response = expect(() => (notificationsDao).cartNotifications(market, params));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch notifications from Apptus, because: ${error.stack}`),
      );
      expect(axios.post).toHaveBeenCalledTimes(1);
    });

    test('forwards errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 500,
        response: {
          statusCode: 500,
          msg: faker.datatype.string(),
          timestamp: faker.datatype.datetime(),
        },
        errors: [
          {
            msg: faker.datatype.string(),
          },
        ],
      };

      (axios.post as unknown as Mock).mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => notificationsDao.cartNotifications(market, params));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });
});
