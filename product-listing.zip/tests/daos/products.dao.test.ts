import axios from 'axios';
import { Request } from 'express';
// eslint-disable-next-line import/no-extraneous-dependencies
import faker from '@faker-js/faker';
import { Common } from '../../src/lib';
import { LogConfig, LogStatus, MarketInfo } from '../../src/middlewares';
import Mock = jest.Mock;
import { ProductsDao } from '../../src/daos';
import { stubMarket, stubExpressReq, stubMagnoliaInfo } from '../__stubs__';
import { MagnoliaInfo } from '../../src/dtos';

jest.mock('axios');

describe('ProductsDao', () => {
  let productsDao: ProductsDao;
  let common: Common;
  let market: MarketInfo;
  let magnoliaInfo: MagnoliaInfo;

  /* Stubs */
  let req: Request; // TODO REMOVE THIS! Express Request has no place in DAOs!
  let queryString: Mock;
  let convertUnderScoreToCamelCaseForApptus: Mock;
  let convertUnderScoreToCamelCase: Mock;
  let isResponseOK: Mock;
  let log: Mock;
  let apptusBaseUrl: string;
  let apptusClusterId: string;
  let apptusEsalesMarket: string;
  let apptusEsalesCustomerKey: string;
  let apptusEsalesSessionKey: string;
  let magnoliaBasePath: string;
  let logConfig: LogConfig;

  beforeEach(() => {
    market = stubMarket();
    magnoliaInfo = stubMagnoliaInfo();
    apptusBaseUrl = 'https://{{CLUSTER_ID}}.api.esales.apptus.cloud/api/v2/panels/';
    apptusClusterId = '12345wegd';
    apptusEsalesMarket = 'AVONSHOP_RO-RO';
    magnoliaBasePath = 'https://c946845e-cbef-4296-bced-6c9fbd053981.mock.pstmn.io/';

    /* Stubs */
    req = stubExpressReq();
    queryString = jest.fn();
    convertUnderScoreToCamelCaseForApptus = jest.fn();
    convertUnderScoreToCamelCase = jest.fn();
    log = jest.fn();
    isResponseOK = jest.fn();
    common = {
      queryString, convertUnderScoreToCamelCaseForApptus, convertUnderScoreToCamelCase, isResponseOK, log,
    };

    /* SUT */
    productsDao = new ProductsDao({
      common,
      apptusBaseUrl,
      apptusClusterId,
      apptusEsalesMarket,
      magnoliaBasePath,
    });
  });

  describe('getPagesFromMagnolia()', () => {
    beforeEach(() => {
      logConfig = {
        apptusLogStatus: LogStatus.NONE,
      };
    });
    test('mocking axios', async () => {
      /* Prepare */
      const magnoliaData = { data: { name: 'test' } };
      (axios as unknown as Mock).mockResolvedValueOnce(magnoliaData);

      /* Execute */
      const response = await (productsDao).getPagesFromMagnolia(market, magnoliaInfo);

      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });
    test('mocking axios if isPreview false', async () => {
      magnoliaInfo.ispreview = false;
      magnoliaInfo.marketPath = 'a';
      /* Prepare */
      const magnoliaData = { data: { name: 'test' } };
      (axios as unknown as Mock).mockResolvedValueOnce(magnoliaData);

      /* Execute */
      const response = await (productsDao).getPagesFromMagnolia(market, magnoliaInfo);

      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch pages data from Magnolia', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (productsDao).getPagesFromMagnolia(market, magnoliaInfo));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch products from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getMagnoliaDataByCategoryId()', () => {
    let categoryId: string;
    beforeEach(() => {
      categoryId = faker.datatype.string();
    });
    test('mocking axios', async () => {
      /* Prepare */
      const result = {
        data: {
          results: [
            {
              '@name': faker.datatype.string(),
            },
          ],
        },
      };

      (axios as unknown as Mock).mockResolvedValueOnce({ ...result });

      /* Execute */
      const response = await (productsDao).getMagnoliaDataByCategoryId(categoryId, magnoliaInfo);

      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch category data from magnolia', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (productsDao).getMagnoliaDataByCategoryId(categoryId, magnoliaInfo));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch category data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
  describe('getTemplateFromMagnolia()', () => {
    let templateName: string;
    beforeEach(() => {
      templateName = faker.datatype.string();
    });
    test('mocking axios', async () => {
      /* Prepare */
      const result = {
        data: {
          results: [
            {
              '@name': faker.datatype.string(),
            },
          ],
        },
      };

      (axios as unknown as Mock).mockResolvedValueOnce({ ...result });

      /* Execute */
      const response = await (productsDao).getTemplateFromMagnolia(templateName);

      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch template data from magnolia', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (productsDao).getTemplateFromMagnolia(templateName));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch template data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('apptusProductSearch()', () => {
    beforeEach(() => {
      productsDao.getPagesFromMagnolia = jest.fn();
      req.query.windowFirst = faker.datatype.string();
      req.query.windowLast = faker.datatype.string();
      productsDao.getMagnoliaDataByCategoryId = jest.fn();
      req.query.selectedCategory = faker.datatype.string();
      req.query.sortBy = faker.datatype.string();
      req.query.windowFirstRecommendations = faker.datatype.string();
      req.query.windowLastRecommendations = faker.datatype.string();
      req.query.maxFacets = faker.datatype.string();
      req.query.rootCategory = faker.datatype.string();
      req.query.maxProducts = faker.datatype.string();
      logConfig = {
        apptusLogStatus: LogStatus.NONE,
      };
    });
    const mockData = {
      data: {
        hits: [
          {
            name: 'search-hits',
            products: [
              {
                variants: [
                  {

                    attributes: {
                      hexCode: [
                        '#ff8da1',
                      ],
                    },
                  },

                ],
                attributes: {
                  brand: [
                    'Avon True',
                  ],
                },
              },
            ],
          },
        ],
        categoryOverview: [
          {
            name: 'category-overview',
            ticket: faker.datatype.string(),
            path: faker.datatype.string(),
            description: faker.datatype.string(),
            displayName: faker.datatype.string(),
            resultType: faker.datatype.string(),
            categoryTree: {
              attributes: {
                category_image: faker.image.imageUrl(),
                description: faker.datatype.string(),
                id: faker.datatype.uuid(),
                keywords: [faker.datatype.string()],
                url: [],
                product_url: ['1', '2'],
              },
            },
          },
        ],
      },
    };
    test('mocking axios', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockData);
      (productsDao.getPagesFromMagnolia as Mock).mockReturnValueOnce({ data: { name: 'test' } });
      const queryPrams = {
        windowFirst: req.query.windowFirst,
        windowLast: req.query.windowLast,
        selectedCategory: req.query.selectedCategory,
        sortBy: req.query.sortBy,
        windowFirstRecommendations: req.query.windowFirstRecommendations,
        windowLastRecommendations: req.query.windowLastRecommendations,
        maxFacets: req.query.maxFacets,
        rootCategory: req.query.rootCategory,
        maxProducts: req.query.maxProducts,
      };

      /* Execute */

      const response = await (productsDao).apptusProductSearch(market, queryPrams, logConfig);

      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });
    test('Failed to fetch pages data from Apptus', async () => {
      const err = new Error('Apptus throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (productsDao).apptusProductSearch(market, mockData, logConfig));

      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch products from Apptus, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('apptusCategorySearch()', () => {
    beforeEach(() => {
      productsDao.getCategoryPagesFromMagnolia = jest.fn();
      req.query.windowFirst = faker.datatype.string();
      req.query.windowLast = faker.datatype.string();
      productsDao.getMagnoliaDataByCategoryId = jest.fn();
      req.query.selectedCategory = faker.datatype.string();
      req.query.sortBy = faker.datatype.string();
      req.query.windowFirstRecommendations = faker.datatype.string();
      req.query.windowLastRecommendations = faker.datatype.string();
      req.query.maxFacets = faker.datatype.string();
      req.query.rootCategory = faker.datatype.string();
      req.query.maxProducts = faker.datatype.string();
      logConfig = {
        apptusLogStatus: LogStatus.NONE,
      };
    });
    const mockData = {
      data: {
        productListWithCount: [
          {
            name: 'product-list',
            ticket: faker.datatype.string(),
            path: faker.datatype.string(),
            description: faker.datatype.string(),
            displayName: faker.datatype.string(),
            resultType: faker.datatype.string(),
            products: [
              {
                key: faker.datatype.string(),
                ticket: faker.datatype.string(),
                variants: [
                  {
                    key: faker.datatype.string(),
                  },
                ],
              },
            ],
          },
        ],
        categoryOverview: [
          {
            name: 'category-overview',
            ticket: faker.datatype.string(),
            path: faker.datatype.string(),
            description: faker.datatype.string(),
            displayName: faker.datatype.string(),
            resultType: faker.datatype.string(),
            categoryTree: {
              attributes: {
                category_image: faker.image.imageUrl(),
                description: faker.datatype.string(),
                id: faker.datatype.uuid(),
                keywords: [faker.datatype.string()],
                url: [],
                product_url: ['1', '2'],
              },
            },
          },
        ],
      },
    };
    test('mocking axios', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockData);
      (productsDao.getCategoryPagesFromMagnolia as Mock).mockReturnValueOnce({
        data:
        { name: faker.datatype.string() },
      });
      const queryPrams = {
        windowFirst: req.query.windowFirst,
        windowLast: req.query.windowLast,
        selectedCategory: req.query.selectedCategory,
        sortBy: req.query.sortBy,
        windowFirstRecommendations: req.query.windowFirstRecommendations,
        windowLastRecommendations: req.query.windowLastRecommendations,
        maxFacets: req.query.maxFacets,
        rootCategory: req.query.rootCategory,
        maxProducts: req.query.maxProducts,
      };

      /* Execute */

      const response = await (productsDao).apptusCategorySearch(market, queryPrams, logConfig);

      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });
    test('Failed to fetch pages data from Apptus', async () => {
      const err = new Error('Apptus throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (productsDao).apptusCategorySearch(market, mockData, logConfig));

      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch products from Apptus, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getCategoryPagesFromMagnolia()', () => {
    test('mocking axios', async () => {
      /* Prepare */
      const magnoliaData = { data: { name: faker.datatype.string() } };
      (axios as unknown as Mock).mockResolvedValueOnce(magnoliaData);

      /* Execute */
      const response = await (productsDao).getCategoryPagesFromMagnolia(market, magnoliaInfo);

      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch pages data from Magnolia', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (productsDao).getCategoryPagesFromMagnolia(market, magnoliaInfo));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch categories from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getMagnoliaGobalSetting()', () => {
    test('mocking axios', async () => {
      /* Prepare */
      const magnoliaData = { data: { results: { name: faker.datatype.string() } } };
      (axios as unknown as Mock).mockResolvedValueOnce(magnoliaData);

      /* Execute */
      const response = await (productsDao).getMagnoliaGobalSetting(market, magnoliaInfo);

      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia golbal setting data', async () => {
      const error = new Error('Unable to get data of magnolia global setting');
      (axios as unknown as Mock).mockRejectedValueOnce(error);
      /* Execute */
      const response = expect(() => (productsDao).getMagnoliaGobalSetting(market, magnoliaInfo));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch global setting data from magnolia, because: ${error.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
});
