import { Request } from 'express';
// eslint-disable-next-line import/no-extraneous-dependencies
import faker from '@faker-js/faker';
import { LogConfig, LogStatus, MarketInfo } from '../../src/middlewares';
import { ProductsDao } from '../../src/daos';
import {
  stubMarket, stubExpressReq, stubMagnoliaInfo, stubMagnoliaGlobalSetting,
} from '../__stubs__';
import { ProductsService } from '../../src/services';
import Mock = jest.Mock;
import { MagnoliaGlobalSettingDto, MagnoliaInfo } from '../../src/dtos';

describe('ProductsService', () => {
  /* System Under Test */
  let productsService: ProductsService;

  /* Dependencies */
  let productsDao: ProductsDao;
  let market: MarketInfo;
  let magnoliaInfo: MagnoliaInfo;
  let ispage: boolean;
  let magnoliaGlobalSetting : MagnoliaGlobalSettingDto[];
  /* Stubs */
  let request: Request; // TODO REMOVE THIS! Express Request has no place in services!

  beforeEach(() => {
    market = stubMarket();
    request = stubExpressReq();
    magnoliaInfo = stubMagnoliaInfo();
    magnoliaGlobalSetting = [stubMagnoliaGlobalSetting()];
    productsDao = {} as any;
    ispage = true;
    /* SUT */
    productsService = new ProductsService({ productsDao });
  });

  describe('search()', () => {
    beforeEach(() => {
      productsDao.apptusProductSearch = jest.fn();
      productsDao.getMagnoliaGobalSetting = jest.fn();
      productsDao.getPagesFromMagnolia = jest.fn();
      productsDao.getTemplateFromMagnolia = jest.fn();
      productsDao.getMagnoliaDataByCategoryId = jest.fn();
      request.query.windowFirst = faker.datatype.string();
      request.query.windowLast = faker.datatype.string();
      request.query.selectedCategory = faker.datatype.string();
      request.query.sortBy = faker.datatype.string();
      request.query.windowFirstRecommendations = faker.datatype.string();
      request.query.windowLastRecommendations = faker.datatype.string();
      request.query.maxFacets = faker.datatype.string();
      request.query.rootCategory = faker.datatype.string();
      request.query.maxProducts = faker.datatype.string();
      request.headers.channelKey = faker.datatype.string();
    });

    test('reads the saerch data from productsDao and channelKey is undefined and isSingleWarehouse=true', async () => {
      /* Prepare */
      magnoliaGlobalSetting[0].warehouseSettings.isSingleWarehouse = 'true';
      const queryPrams = {
        windowFirst: request.query.windowFirst,
        windowLast: request.query.windowLast,
        selectedCategory: request.query.selectedCategory,
        sortBy: request.query.sortBy,
        windowFirstRecommendations: request.query.windowFirstRecommendations,
        windowLastRecommendations: request.query.windowLastRecommendations,
        maxFacets: request.query.maxFacets,
        rootCategory: request.query.rootCategory,
        maxProducts: request.query.maxProducts,
      };
      const channelkey = undefined;

      const logConfig: LogConfig = {
        apptusLogStatus: LogStatus.NONE,
      };
      (productsDao.apptusProductSearch as Mock).mockReturnValueOnce({
        productCount: [
          {
            name: 'product-count',
            ticket: faker.datatype.string(),
            path: faker.datatype.string(),
            description: faker.datatype.string(),
            displayName: faker.datatype.string(),
            resultType: faker.datatype.string(),
            count: 45,
          },
        ],
        hits: [
          {
            name: 'search-hits',
            products: [
              {
                attributes: {
                  inStock: false,
                },
                variants: [
                  {
                    attributes: {
                      availability: [
                      // eslint-disable-next-line max-len
                        '{"4745522":{"in_stock":true,"available_quantity":5026,"channel_id":"9653f17c-352f-4fe9-a5b8-8351ad861896"}}',
                      ],
                    },
                  },
                ],
              },
            ],
          },
        ],
      });
      (productsDao.getTemplateFromMagnolia as Mock).mockReturnValueOnce({
        data: {
          'spa-lm:components/HtmlContainer': {
            dialog: faker.datatype.string(),
            name: faker.datatype.string(),
            id: faker.datatype.string(),
            type: faker.datatype.string(),
            title: faker.datatype.string(),
            'mgnl:template': faker.datatype.string(),
          },
          'spa-lm:pages/search': {
            dialog: faker.datatype.string(),
            templateScript: faker.datatype.string(),
            name: faker.datatype.string(),
            id: faker.datatype.string(),
            type: faker.datatype.string(),
            title: faker.datatype.string(),
            renderType: faker.datatype.string(),
          },
        },
      });
      (productsDao.getPagesFromMagnolia as Mock).mockReturnValueOnce({
        '@name': 's',
        '@path': faker.datatype.string(),
        '@id': faker.datatype.uuid(),
        '@nodeType': faker.datatype.string(),
        'mgnl:template': 'spa-lm:pages/search',
      });
      (productsDao.getMagnoliaDataByCategoryId as Mock).mockReturnValueOnce({
        categorySetting: {
          freeTextBaseSection: {
            name: 'test',
          },
        },
      });
      (productsDao.getMagnoliaGobalSetting as Mock).mockReturnValueOnce(magnoliaGlobalSetting);

      magnoliaInfo.ispreview = false;
      /* Execute */
      await productsService.search(market, queryPrams, channelkey, ispage, logConfig, magnoliaInfo);

      /* Verify */
      expect(productsDao.apptusProductSearch).toHaveBeenCalledTimes(1);
      expect(productsDao.apptusProductSearch).toHaveBeenNthCalledWith(
        1,
        market,
        queryPrams,
        logConfig,
      );

      /* Verify */
      expect(productsDao.getPagesFromMagnolia).toHaveBeenCalledTimes(1);
      expect(productsDao.getPagesFromMagnolia).toHaveBeenNthCalledWith(
        1,
        market,
        magnoliaInfo,
      );

      expect(productsDao.getTemplateFromMagnolia).toHaveBeenCalledTimes(0);
    });
    test(
      'reads the saerch data from productsDao and channelKey is undefined and isSingleWarehouse=true with did you mean',
      async () => {
      /* Prepare */
        const queryPrams = {
          windowFirst: request.query.windowFirst,
          windowLast: request.query.windowLast,
          selectedCategory: request.query.selectedCategory,
          sortBy: request.query.sortBy,
          windowFirstRecommendations: request.query.windowFirstRecommendations,
          windowLastRecommendations: request.query.windowLastRecommendations,
          maxFacets: request.query.maxFacets,
          rootCategory: request.query.rootCategory,
          maxProducts: request.query.maxProducts,
        };
        const channelkey = 'DC-RO';

        const logConfig: LogConfig = {
          apptusLogStatus: LogStatus.NONE,
        };
        (productsDao.apptusProductSearch as Mock).mockReturnValue({
          productCount: [
            {
              name: 'product-count',
              ticket: faker.datatype.string(),
              path: faker.datatype.string(),
              description: faker.datatype.string(),
              displayName: faker.datatype.string(),
              resultType: faker.datatype.string(),
              count: 45,
            },
          ],
          hits: [
            {
              name: 'search-hits',
              products: [
                {
                  attributes: {
                    inStock: false,
                  },
                  variants: [
                    {
                      attributes: {
                        availability: [
                          // eslint-disable-next-line max-len
                          '{"4745522":{"in_stock":true,"available_quantity":5026,"channel_id":"9653f17c-352f-4fe9-a5b8-8351ad861896"}}',
                        ],
                      },
                    },
                  ],
                },
              ],
            },
            {
              name: 'did-you-mean',
              corrections: [{
                text: 'abc',
              }],
            },
          ],
        });
        (productsDao.getTemplateFromMagnolia as Mock).mockReturnValueOnce({
          data: {
            'spa-lm:components/HtmlContainer': {
              dialog: faker.datatype.string(),
              name: faker.datatype.string(),
              id: faker.datatype.string(),
              type: faker.datatype.string(),
              title: faker.datatype.string(),
              'mgnl:template': faker.datatype.string(),
            },
            'spa-lm:pages/search': {
              dialog: faker.datatype.string(),
              templateScript: faker.datatype.string(),
              name: faker.datatype.string(),
              id: faker.datatype.string(),
              type: faker.datatype.string(),
              title: faker.datatype.string(),
              renderType: faker.datatype.string(),
            },
          },
        });
        (productsDao.getPagesFromMagnolia as Mock).mockReturnValueOnce({
          '@name': 's',
          '@path': faker.datatype.string(),
          '@id': faker.datatype.uuid(),
          '@nodeType': faker.datatype.string(),
          'mgnl:template': 'spa-lm:pages/search',
        });
        (productsDao.getMagnoliaDataByCategoryId as Mock).mockReturnValueOnce({
          categorySetting: {
            freeTextBaseSection: {
              name: 'test',
            },
          },
        });
        (productsDao.getMagnoliaGobalSetting as Mock).mockReturnValueOnce(magnoliaGlobalSetting);

        /* Execute */
        await productsService.search(market, queryPrams, channelkey, false, logConfig, magnoliaInfo);

        /* Verify */
        expect(productsDao.apptusProductSearch).toHaveBeenCalledTimes(2);
        expect(productsDao.apptusProductSearch).toHaveBeenNthCalledWith(
          1,
          market,
          queryPrams,
          logConfig,
        );

        /* Verify */
        expect(productsDao.getPagesFromMagnolia).toHaveBeenCalledTimes(1);
        expect(productsDao.getPagesFromMagnolia).toHaveBeenNthCalledWith(
          1,
          market,
          magnoliaInfo,
        );

        expect(productsDao.getTemplateFromMagnolia).toHaveBeenCalledTimes(1);
        expect(productsDao.getTemplateFromMagnolia).toHaveBeenNthCalledWith(
          1,
          'spa-lm:pages/search',
        );
      },
    );
    test('reads the products from productsDao', async () => {
      /* Prepare */
      const queryPrams = {
        windowFirst: request.query.windowFirst,
        windowLast: request.query.windowLast,
        selectedCategory: request.query.selectedCategory,
        sortBy: request.query.sortBy,
        windowFirstRecommendations: request.query.windowFirstRecommendations,
        windowLastRecommendations: request.query.windowLastRecommendations,
        maxFacets: request.query.maxFacets,
        rootCategory: request.query.rootCategory,
        maxProducts: request.query.maxProducts,
        depth: request.query.depth,
      };
      const { channelkey } = request.headers;
      const logConfig: LogConfig = {
        apptusLogStatus: LogStatus.NONE,
      };
      const mockData = {
        productCount: [
          {
            name: 'product-count',
            ticket: faker.datatype.string(),
            path: faker.datatype.string(),
            description: faker.datatype.string(),
            displayName: faker.datatype.string(),
            resultType: faker.datatype.string(),
            count: 45,
          },
        ],
        hits: [
          {
            name: 'search-hits',
            ticket: faker.datatype.string(),
            path: faker.datatype.string(),
            description: faker.datatype.string(),
            displayName: faker.datatype.string(),
            reportTag: faker.datatype.string(),
            resultType: faker.datatype.string(),
            products: [{
              attributes: {
                inStock: false,
              },
              variants: [{
                attributes: {
                  availability:
                '{"4745522":{"in_stock":true,"available_quantity":5026,"channel_id":"97"}}',
                },
              }],
            }],
          },
          {
            name: 'category-search',
            ticket: faker.datatype.string(),
            path: faker.datatype.string(),
            description: faker.datatype.string(),
            displayName: faker.datatype.string(),
            reportTag: faker.datatype.string(),
            resultType: faker.datatype.string(),
            categoryList: [],
          },
          {
            name: 'facets',
            ticket: faker.datatype.string(),
            path: faker.datatype.string(),
            description: faker.datatype.string(),
            displayName: faker.datatype.string(),
            reportTag: faker.datatype.string(),
            resultType: faker.datatype.string(),
            facetList: [{
              attributes: {
                inStock: false,
              },
              attribute: 'non_rep_sale_price',
            }],
          },
        ],
      };
      (productsDao.apptusProductSearch as Mock).mockReturnValueOnce(mockData);
      (productsDao.getTemplateFromMagnolia as Mock).mockReturnValueOnce({
        data: {
          'spa-lm:components/HtmlContainer': {
            dialog: faker.datatype.string(),
            name: faker.datatype.string(),
            id: faker.datatype.string(),
            type: faker.datatype.string(),
            title: faker.datatype.string(),
            'mgnl:template': faker.datatype.string(),
          },
          'spa-lm:pages/search': {
            dialog: faker.datatype.string(),
            templateScript: faker.datatype.string(),
            name: faker.datatype.string(),
            id: faker.datatype.string(),
            type: faker.datatype.string(),
            title: faker.datatype.string(),
            renderType: faker.datatype.string(),
          },
        },
      });
      (productsDao.getPagesFromMagnolia as Mock).mockReturnValueOnce({
        '@name': 's',
        '@path': faker.datatype.string(),
        '@id': faker.datatype.uuid(),
        '@nodeType': faker.datatype.string(),
        'mgnl:template': 'spa-lm:pages/search',
      });
      (productsDao.getMagnoliaDataByCategoryId as Mock).mockReturnValueOnce({
        categorySetting: {
          freeTextBaseSection: {
            name: 'test',
          },
        },
      });
      (productsDao.getMagnoliaGobalSetting as Mock).mockReturnValueOnce(magnoliaGlobalSetting);

      /* Execute */
      await productsService.search(market, queryPrams, channelkey, ispage, logConfig, magnoliaInfo);

      /* Verify */
      expect(productsDao.apptusProductSearch).toHaveBeenCalledTimes(1);
      expect(productsDao.apptusProductSearch).toHaveBeenNthCalledWith(
        1,
        market,
        queryPrams,
        logConfig,
      );

      /* Verify */
      expect(productsDao.getPagesFromMagnolia).toHaveBeenCalledTimes(1);
      expect(productsDao.getPagesFromMagnolia).toHaveBeenNthCalledWith(
        1,
        market,
        magnoliaInfo,
      );

      expect(productsDao.getTemplateFromMagnolia).toHaveBeenCalledTimes(1);
      expect(productsDao.getTemplateFromMagnolia).toHaveBeenNthCalledWith(
        1,
        'spa-lm:pages/search',
      );
    });
  });

  describe('category()', () => {
    beforeEach(() => {
      productsDao.apptusCategorySearch = jest.fn();
      productsDao.getCategoryPagesFromMagnolia = jest.fn();
      productsDao.getMagnoliaGobalSetting = jest.fn();
      productsDao.getTemplateFromMagnolia = jest.fn();
      productsDao.getMagnoliaDataByCategoryId = jest.fn();
      request.query.windowFirst = faker.datatype.string();
      request.query.windowLast = faker.datatype.string();
      request.query.selectedCategory = "categories_AVONSHOP_RO-RO:'398'";
      request.query.sortBy = faker.datatype.string();
      request.query.windowFirstRecommendations = faker.datatype.string();
      request.query.windowLastRecommendations = faker.datatype.string();
      request.query.maxFacets = faker.datatype.string();
      request.query.rootCategory = "categories_AVONSHOP_RO-RO:'398'";
      request.query.maxProducts = faker.datatype.string();
      request.headers.channelKey = faker.datatype.string();
    });
    test('reads the categories from productsDao', async () => {
      const magnoliaCategoryData = {
        categorySetting: {
          bannerCardBaseSection: {
            bannerPosition: 0,
          },
          freeTextBaseSection: {
            data: faker.datatype.string(),
          },
        },
      };
      const apptusResponseTrueCase = {
        productListWithCount: [{
          name: 'product-list',
          products: [
            {
              attributes: {
                inStock: true,
              },
            },
          ],

        }],
      };
      /* Prepare */
      const queryPrams = {
        windowFirst: request.query.windowFirst,
        windowLast: request.query.windowLast,
        selectedCategory: request.query.selectedCategory,
        sortBy: request.query.sortBy,
        windowFirstRecommendations: request.query.windowFirstRecommendations,
        windowLastRecommendations: request.query.windowLastRecommendations,
        maxFacets: request.query.maxFacets,
        rootCategory: request.query.rootCategory,
        maxProducts: request.query.maxProducts,
      };
      const channelkey = { availabilityCheck: { defaultWarehouse: faker.datatype.string() } };
      const logConfig: LogConfig = {
        apptusLogStatus: LogStatus.NONE,
      };
      (productsDao.apptusCategorySearch as Mock).mockReturnValueOnce({

        productListWithCount: [{
          name: 'product-list',
          products: [
            {
              attributes: {
                inStock: false,
              },
              variants: [
                {
                  attributes: {
                    availability: [

                      // eslint-disable-next-line max-len
                      '{"4745522":{"in_stock":true,"available_quantity":5026,"channel_id":"9653f17c-352f-4fe9-a5b8-8351ad861896"}}',

                    ],
                  },
                },
              ],
            },
          ],

        }],
        categoryOverview: [{
          name: 'category-overview',
          categoryTree: {
            attributes: {
              id: faker.datatype.string(),
            },
          },
        }],
        facets: [{
          name: 'facets',
          ticket: faker.datatype.string(),
          path: faker.datatype.string(),
          description: faker.datatype.string(),
          displayName: faker.datatype.string(),
          reportTag: faker.datatype.string(),
          resultType: faker.datatype.string(),
          facetList: [{
            attributes: {
              inStock: false,
            },
            attribute: 'non_rep_sale_price',
          }],
        }],
      });
      (productsDao.getMagnoliaGobalSetting as Mock).mockReturnValueOnce(magnoliaGlobalSetting);
      (productsDao.getCategoryPagesFromMagnolia as Mock).mockReturnValueOnce({
        '@name': 's',
        '@path': faker.datatype.string(),
        '@id': faker.datatype.uuid(),
        '@nodeType': faker.datatype.string(),
        'mgnl:template': 'spa-lm:pages/search',
      });
      /* Execute */
      (productsDao.getMagnoliaDataByCategoryId as Mock).mockReturnValueOnce({
        categorySetting: {
          freeTextBaseSection: {
            name: 'test',
          },
          bannerCardBaseSection: {
            bannerPosition: faker.datatype.number(),
          },
        },
      });

      (productsDao.getTemplateFromMagnolia as Mock).mockReturnValueOnce({
        data: {
          'spa-lm:components/HtmlContainer': {
            dialog: faker.datatype.string(),
            name: faker.datatype.string(),
            id: faker.datatype.string(),
            type: faker.datatype.string(),
            title: faker.datatype.string(),
          },
          'spa-lm:pages/search': {
            dialog: faker.datatype.string(),
            templateScript: faker.datatype.string(),
            name: faker.datatype.string(),
            id: faker.datatype.string(),
            type: faker.datatype.string(),
            title: faker.datatype.string(),
            renderType: faker.datatype.string(),
          },
        },
      });
      (productsDao.getMagnoliaGobalSetting as Mock).mockReturnValueOnce(magnoliaGlobalSetting);
      await productsService.category(market, queryPrams, channelkey, ispage, logConfig, magnoliaInfo);

      productsService.updateApptusProductResponse(apptusResponseTrueCase, magnoliaCategoryData);
      /* Verify */
      expect(productsDao.apptusCategorySearch).toHaveBeenCalledTimes(1);
      expect(productsDao.apptusCategorySearch).toHaveBeenNthCalledWith(
        1,
        market,
        queryPrams,
        logConfig,
      );

      expect(productsDao.getCategoryPagesFromMagnolia).toHaveBeenCalledTimes(1);
      expect(productsDao.getCategoryPagesFromMagnolia).toHaveBeenNthCalledWith(
        1,
        market,
        magnoliaInfo,
      );

      expect(productsDao.getTemplateFromMagnolia).toHaveBeenCalledTimes(1);
      expect(productsDao.getTemplateFromMagnolia).toHaveBeenNthCalledWith(
        1,
        'spa-lm:pages/search',
      );
    });
    test('reads the categories from productsDao for false case', async () => {
      const magnoliaCategoryData = {
        categorySetting: {
          bannerCardBaseSection: {
            bannerPosition: 0,
          },
          freeTextBaseSection: {
            data: faker.datatype.string(),
          },
        },
      };
      const apptusResponsefalseCase = {
        productListWithCount: [{
          name: 'product-list',
          products: [
            {
              attributes: {
                inStock: true,
              },
            },
          ],

        }],
      };
      /* Prepare */
      const queryPrams = {
        windowFirst: request.query.windowFirst,
        windowLast: request.query.windowLast,
        selectedCategory: request.query.selectedCategory,
        sortBy: request.query.sortBy,
        windowFirstRecommendations: request.query.windowFirstRecommendations,
        windowLastRecommendations: request.query.windowLastRecommendations,
        maxFacets: request.query.maxFacets,
        rootCategory: request.query.rootCategory,
        maxProducts: request.query.maxProducts,
      };
      const channelkey = { availabilityCheck: { defaultWarehouse: faker.datatype.string() } };
      const logConfig: LogConfig = {
        apptusLogStatus: LogStatus.NONE,
      };
      (productsDao.apptusCategorySearch as Mock).mockReturnValueOnce({

        productListWithCount: [{
          name: 'product-list',
          products: [
            {
              attributes: {
                inStock: true,
              },
              variants: [
                {
                  attributes: {
                    availability: [

                      // eslint-disable-next-line max-len
                      '{"4745522":{"in_stock":true,"available_quantity":5026,"channel_id":"9653f17c-352f-4fe9-a5b8-8351ad861896"}}',

                    ],
                  },
                },
              ],
            },
          ],

        }],
        categoryOverview: [{
          name: 'category-overview',
          categoryTree: {
            attributes: {
              id: faker.datatype.string(),
            },
          },
        }],

      });
      (productsDao.getMagnoliaGobalSetting as Mock).mockReturnValueOnce(magnoliaGlobalSetting);
      (productsDao.getCategoryPagesFromMagnolia as Mock).mockReturnValueOnce({
        '@name': 's',
        '@path': faker.datatype.string(),
        '@id': faker.datatype.uuid(),
        '@nodeType': faker.datatype.string(),
        'mgnl:template': 'spa-lm:pages/search',
      });
      /* Execute */
      (productsDao.getMagnoliaDataByCategoryId as Mock).mockReturnValueOnce({
        categorySetting: {
          freeTextBaseSection: {
            name: 'test',
          },
          bannerCardBaseSection: {
            bannerPosition: faker.datatype.number(),
          },
        },
      });

      (productsDao.getTemplateFromMagnolia as Mock).mockReturnValueOnce({
        data: {
          'spa-lm:components/HtmlContainer': {
            dialog: faker.datatype.string(),
            name: faker.datatype.string(),
            id: faker.datatype.string(),
            type: faker.datatype.string(),
            title: faker.datatype.string(),
          },
          'spa-lm:pages/search': {
            dialog: faker.datatype.string(),
            templateScript: faker.datatype.string(),
            name: faker.datatype.string(),
            id: faker.datatype.string(),
            type: faker.datatype.string(),
            title: faker.datatype.string(),
            renderType: faker.datatype.string(),
          },
        },
      });
      (productsDao.getMagnoliaGobalSetting as Mock).mockReturnValueOnce(magnoliaGlobalSetting);
      await productsService.category(market, queryPrams, channelkey, ispage, logConfig, magnoliaInfo);

      productsService.updateApptusProductResponse(apptusResponsefalseCase, magnoliaCategoryData);
      /* Verify */
      expect(productsDao.apptusCategorySearch).toHaveBeenCalledTimes(1);
      expect(productsDao.apptusCategorySearch).toHaveBeenNthCalledWith(
        1,
        market,
        queryPrams,
        logConfig,
      );

      expect(productsDao.getCategoryPagesFromMagnolia).toHaveBeenCalledTimes(1);
      expect(productsDao.getCategoryPagesFromMagnolia).toHaveBeenNthCalledWith(
        1,
        market,
        magnoliaInfo,
      );

      expect(productsDao.getTemplateFromMagnolia).toHaveBeenCalledTimes(1);
      expect(productsDao.getTemplateFromMagnolia).toHaveBeenNthCalledWith(
        1,
        'spa-lm:pages/search',
      );
    });
    test('reads the categories from productsDao and channelKey is undefined and isSingleWarehouse=true', async () => {
      /* Prepare */
      magnoliaGlobalSetting[0].warehouseSettings.isSingleWarehouse = 'true';
      const queryPrams = {
        windowFirst: request.query.windowFirst,
        windowLast: request.query.windowLast,
        selectedCategory: request.query.selectedCategory,
        sortBy: request.query.sortBy,
        windowFirstRecommendations: request.query.windowFirstRecommendations,
        windowLastRecommendations: request.query.windowLastRecommendations,
        maxFacets: request.query.maxFacets,
        rootCategory: request.query.rootCategory,
        maxProducts: request.query.maxProducts,
      };
      const channelkey = undefined;
      const logConfig: LogConfig = {
        apptusLogStatus: LogStatus.NONE,
      };
      (productsDao.apptusCategorySearch as Mock).mockReturnValueOnce({
        productListWithCount: [{
          name: 'product-list',
          products: [
            {
              attributes: {
                inStock: false,
              },
              variants: [
                {
                  attributes: {
                    availability: [
                      // eslint-disable-next-line max-len
                      '{"4745522":{"in_stock":true,"available_quantity":5026,"channel_id":"9653f17c-352f-4fe9-a5b8-8351ad861896"}}',
                    ],
                  },
                },
              ],
            },
          ],

        }],
        categoryOverview: [{
          name: 'category-overview',
          categoryTree: {
            attributes: {
              id: faker.datatype.string(),
            },
          },
        }],
      });
      (productsDao.getCategoryPagesFromMagnolia as Mock).mockReturnValueOnce({
        '@name': 's',
        '@path': faker.datatype.string(),
        '@id': faker.datatype.uuid(),
        '@nodeType': faker.datatype.string(),
        'mgnl:template': 'spa-lm:pages/search',
      });
      (productsDao.getMagnoliaGobalSetting as Mock).mockReturnValueOnce(magnoliaGlobalSetting);
      /* Execute */
      (productsDao.getMagnoliaDataByCategoryId as Mock).mockReturnValueOnce({
        categorySetting: {
          freeTextBaseSection: {
            name: 'test',
          },
          bannerCardBaseSection: {
            bannerPosition: faker.datatype.number(),
          },
        },
      });

      (productsDao.getTemplateFromMagnolia as Mock).mockReturnValueOnce({
        data: {
          'spa-lm:components/HtmlContainer': {
            dialog: faker.datatype.string(),
            name: faker.datatype.string(),
            id: faker.datatype.string(),
            type: faker.datatype.string(),
            title: faker.datatype.string(),
          },
          'spa-lm:pages/search': {
            dialog: faker.datatype.string(),
            templateScript: faker.datatype.string(),
            name: faker.datatype.string(),
            id: faker.datatype.string(),
            type: faker.datatype.string(),
            title: faker.datatype.string(),
            renderType: faker.datatype.string(),
          },
        },
      });
      magnoliaInfo.ispreview = false;
      await productsService.category(market, queryPrams, channelkey, false, logConfig, magnoliaInfo);

      /* Verify */
      expect(productsDao.apptusCategorySearch).toHaveBeenCalledTimes(1);
      expect(productsDao.apptusCategorySearch).toHaveBeenNthCalledWith(
        1,
        market,
        queryPrams,
        logConfig,
      );

      expect(productsDao.getCategoryPagesFromMagnolia).toHaveBeenCalledTimes(1);
      expect(productsDao.getCategoryPagesFromMagnolia).toHaveBeenNthCalledWith(
        1,
        market,
        magnoliaInfo,
      );
      expect(productsDao.getMagnoliaGobalSetting).toHaveBeenCalledTimes(1);
      expect(productsDao.getMagnoliaGobalSetting).toHaveBeenNthCalledWith(
        1,
        market,
        magnoliaInfo,
      );

      expect(productsDao.getTemplateFromMagnolia).toHaveBeenCalledTimes(0);
    });
    test('reads the categories from productsDao and channelKey is undefined and isSingleWarehouse=false', async () => {
      /* Prepare */
      const queryPrams = {
        windowFirst: request.query.windowFirst,
        windowLast: request.query.windowLast,
        selectedCategory: request.query.selectedCategory,
        sortBy: request.query.sortBy,
        windowFirstRecommendations: request.query.windowFirstRecommendations,
        windowLastRecommendations: request.query.windowLastRecommendations,
        maxFacets: request.query.maxFacets,
        rootCategory: request.query.rootCategory,
        maxProducts: request.query.maxProducts,
      };
      const channelkey = undefined;
      const logConfig: LogConfig = {
        apptusLogStatus: LogStatus.NONE,
      };
      (productsDao.apptusCategorySearch as Mock).mockReturnValueOnce({
        productListWithCount: [{
          name: 'product-list',
          products: [
            {
              attributes: {
                inStock: false,
              },
              variants: [
                {
                  attributes: {
                    availability: [
                      // eslint-disable-next-line max-len
                      '{"4745522":{"in_stock":true,"available_quantity":5026,"channel_id":"9653f17c-352f-4fe9-a5b8-8351ad861896"}}',
                    ],
                  },
                },
              ],
            },
          ],

        }],
        categoryOverview: [{
          name: 'category-overview',
          categoryTree: {
            attributes: {
              id: faker.datatype.string(),
            },
          },
        }],
      });
      (productsDao.getCategoryPagesFromMagnolia as Mock).mockReturnValueOnce({
        '@name': 's',
        '@path': faker.datatype.string(),
        '@id': faker.datatype.uuid(),
        '@nodeType': faker.datatype.string(),
        'mgnl:template': 'spa-lm:pages/search',
      });
      (productsDao.getMagnoliaGobalSetting as Mock).mockReturnValueOnce(magnoliaGlobalSetting);
      /* Execute */
      (productsDao.getMagnoliaDataByCategoryId as Mock).mockReturnValueOnce({
        categorySetting: {
          freeTextBaseSection: {
            name: 'test',
          },
          bannerCardBaseSection: {
            bannerPosition: faker.datatype.number(),
          },
        },
      });

      (productsDao.getTemplateFromMagnolia as Mock).mockReturnValueOnce({
        data: {
          'spa-lm:components/HtmlContainer': {
            dialog: faker.datatype.string(),
            name: faker.datatype.string(),
            id: faker.datatype.string(),
            type: faker.datatype.string(),
            title: faker.datatype.string(),
          },
          'spa-lm:pages/search': {
            dialog: faker.datatype.string(),
            templateScript: faker.datatype.string(),
            name: faker.datatype.string(),
            id: faker.datatype.string(),
            type: faker.datatype.string(),
            title: faker.datatype.string(),
            renderType: faker.datatype.string(),
          },
        },
      });
      await productsService.category(market, queryPrams, channelkey, ispage, logConfig, magnoliaInfo);

      /* Verify */
      expect(productsDao.apptusCategorySearch).toHaveBeenCalledTimes(1);
      expect(productsDao.apptusCategorySearch).toHaveBeenNthCalledWith(
        1,
        market,
        queryPrams,
        logConfig,
      );

      expect(productsDao.getCategoryPagesFromMagnolia).toHaveBeenCalledTimes(1);
      expect(productsDao.getCategoryPagesFromMagnolia).toHaveBeenNthCalledWith(
        1,
        market,
        magnoliaInfo,
      );
      expect(productsDao.getMagnoliaGobalSetting).toHaveBeenCalledTimes(1);
      expect(productsDao.getMagnoliaGobalSetting).toHaveBeenNthCalledWith(
        1,
        market,
        magnoliaInfo,
      );

      expect(productsDao.getTemplateFromMagnolia).toHaveBeenCalledTimes(1);
      expect(productsDao.getTemplateFromMagnolia).toHaveBeenNthCalledWith(
        1,
        'spa-lm:pages/search',
      );
    });
  });
});
