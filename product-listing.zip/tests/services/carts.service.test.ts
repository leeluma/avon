// eslint-disable-next-line import/no-extraneous-dependencies
import faker from '@faker-js/faker';
import { Cart } from '@commercetools/platform-sdk';
import { MarketInfo } from '../../src/middlewares';
import { CartsDao } from '../../src/daos';
import { stubMarket } from '../__stubs__';
import { CartsService } from '../../src/services';
import { AddtoCartRequestDto } from '../../src/dtos';

describe('CartsService', () => {
  /* System Under Test */
  let cartsService: CartsService;

  /* Dependencies */
  let cartsDao: CartsDao;

  /* Stubs */
  let market: MarketInfo;

  let customerId: string;
  let cartId: string;
  let sku: string;
  let quantity: number;
  let productKey: string;
  let channelkey: string;
  let cart: Cart;
  let anonymousId: string;

  beforeEach(() => {
    market = stubMarket();
    customerId = faker.datatype.uuid();
    cartId = faker.datatype.uuid();
    sku = faker.datatype.uuid();
    quantity = faker.datatype.number();
    productKey = faker.datatype.uuid();
    channelkey = faker.datatype.string();
    cart = { id: faker.datatype.uuid() } as Cart;
    cartsDao = {
      addProductToCart: jest.fn().mockReturnValueOnce(cart),
    } as any;

    cartsService = new CartsService({ cartsDao });
  });

  describe('addProductToCart()', () => {
    test('calls the cartsDao', async () => {
      const params : AddtoCartRequestDto = {
        market,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
        channelkey,
      };
      /* Execute */
      await cartsService.addProductToCart(params);

      /* Verify */
      expect(cartsDao.addProductToCart).toHaveBeenCalledTimes(1);
      expect(cartsDao.addProductToCart).toHaveBeenNthCalledWith(
        1,
        params,
      );
    });

    test('returns the response from cartsDao', async () => {
      const params : AddtoCartRequestDto = {
        market,
        customerId,
        anonymousId,
        cartId,
        sku,
        quantity,
        productKey,
        channelkey,
      };
      /* Execute */
      const result = await cartsService.addProductToCart(params);

      /* Verify */
      expect(result).toBe(cart);
    });
  });
});
