import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { CartsService } from '../services';
import { MarketInfo } from '../middlewares';
import { JsonApiResponseEntity } from '../lib';
import { AddtoCartRequestDto, AddToCartResponseDto } from '../dtos';

export interface CartsControllerConfig {
  cartsService: CartsService;
}

/**
 * Service for managing Carts
 */
export class CartsController {
  private readonly cartsService: CartsService;

  /**
   * Constructor for `CartsController` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: CartsControllerConfig) {
    this.cartsService = config.cartsService;
  }

  public async addProductToCart(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<AddToCartResponseDto>> {
    const channelkey = request.headers.channelKey as string;

    const market = response.locals.market as MarketInfo;
    const {
      anonymousId, customerId, cartId, lineItems: { sku, quantity, productKey },
    } = request.body;
    const params : AddtoCartRequestDto = {
      market,
      customerId,
      anonymousId,
      cartId,
      sku,
      quantity,
      productKey,
      channelkey,
    };
    const cart = await this.cartsService.addProductToCart(params);

    return {
      statusCode: HttpStatusCodes.OK,
      body: cart,
    };
  }
}
