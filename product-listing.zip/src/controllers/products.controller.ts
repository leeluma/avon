import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { ProductsService } from '../services';
import { MarketInfo, LogConfig } from '../middlewares';
import { ApptusRequest, CommonResponse, MagnoliaInfo } from '../dtos';
import { JsonApiResponseEntity } from '../lib';

export interface ProductsControllerConfig {
  productsService: ProductsService;
}

export class ProductsController {
  private readonly productsService: ProductsService;

  constructor(config: ProductsControllerConfig) {
    this.productsService = config.productsService;
  }

  /**
   * Get a search product
   * @param request - Express request object
   * @param response - Express response object
   * @returns Product if it was found
   */
  public async search(
    request: Request,
    response: Response,
  ):Promise<JsonApiResponseEntity<CommonResponse>> {
    const {
      sessionkey,
      customerkey,
      channelkey,
    } = request.headers;
    const market = response.locals.market as MarketInfo;
    const logConfig = response.locals.logConfig as LogConfig;
    const magnolia = response.locals.magnolia as MagnoliaInfo;

    const {
      windowFirst,
      windowLast,
      selectedCategory,
      sortBy,
      windowFirstRecommendations,
      windowLastRecommendations,
      maxFacets,
      rootCategory,
      maxProducts,
      filter,
      depth,
      searchPhrase,
      facets,
      page,
    }: ApptusRequest = request.query;
    const params = {
      windowFirst,
      windowLast,
      selectedCategory,
      sortBy,
      windowFirstRecommendations,
      windowLastRecommendations,
      maxFacets,
      rootCategory,
      maxProducts,
      filter,
      depth,
      searchPhrase,
      facets,
      page,
      sessionKey: sessionkey,
      customerKey: customerkey,
    };

    const isPage: boolean = request.headers.ispage === 'false';
    const apptusResponse = await this.productsService.search(market, params, channelkey, isPage, logConfig, magnolia);
    return {
      statusCode: HttpStatusCodes.OK,
      body: apptusResponse,
    };
  }

  /**
   * Get a search category
   * @param request - Express request object
   * @param response - Express response object
   * @returns Categories if it was found
   */
  public async category(
    request: Request,
    response: Response,
  ):Promise<JsonApiResponseEntity<CommonResponse>> {
    const {
      sessionkey,
      customerkey,
    } = request.headers;
    const market = response.locals.market as MarketInfo;
    const magnolia = response.locals.magnolia as MagnoliaInfo;
    const logConfig = response.locals.logConfig as LogConfig;

    const {
      windowFirst,
      windowLast,
      selectedCategory,
      sortBy,
      windowFirstRecommendations,
      windowLastRecommendations,
      maxFacets,
      rootCategory,
      maxProducts,
      filter,
      depth,
      facets,
      page,
    }: ApptusRequest = request.query;
    const params = {
      windowFirst,
      windowLast,
      selectedCategory,
      sortBy,
      windowFirstRecommendations,
      windowLastRecommendations,
      maxFacets,
      rootCategory,
      maxProducts,
      filter,
      depth,
      facets,
      page,
      sessionKey: sessionkey,
      customerKey: customerkey,
    };
    const { channelkey } = request.headers;
    const isPage: boolean = request.headers.ispage === 'false';

    const apptusResponse = await this.productsService.category(market, params, channelkey, isPage, logConfig, magnolia);
    return {
      statusCode: HttpStatusCodes.OK,
      body: apptusResponse,
    };
  }
}
