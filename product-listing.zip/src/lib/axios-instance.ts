import Agent, { HttpsAgent } from 'agentkeepalive';

const options = {
  maxSockets: 50,
  maxFreeSockets: 10,
  timeout: 60000, // active socket keepalive for 60 seconds
  freeSocketTimeout: 30000, // free socket keepalive for 30 seconds
  keepAlive: true,
};
const keepAliveAgentHttps = new HttpsAgent(options);

const keepAliveAgentHttp = new Agent(options);

export const axiosOptions = {
  httpAgent: keepAliveAgentHttp,
  timeout: 60000,
  httpsAgent: keepAliveAgentHttps,
};
