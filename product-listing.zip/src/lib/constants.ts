export const URI = {
  apptus: {
    search: 'panels/product-list-page?',
    searchPage: 'panels/search-page/search-result-zone?',
    esales: 'notifications/click',
    nonEsales: 'notifications/non-esales-click',
    esaleAddToCart: 'notifications/adding-to-cart',
    nonEsaleAddToCart: 'notifications/non-esales-adding-to-cart',
  },
  magnolia: {
    category: '/c',
    search: '/s',
    pageData: '.rest/delivery/pages/v1/{{country}}',
    logSetting: '.rest/delivery/pages/v1/{{country}}/apptusSetting',
    categorySearch: '.rest/delivery/ecommerce-categories?q=',
    templatePath: '.rest/template-definitions/v1/',
    wareHouseSetting: '.rest/delivery/global-settings/{{country}}/settings/warehouseSettings',
    mgnlTemplate: 'mgnl:template',
  },
  commonConfig: {
    contentType: 'application/json',
    categorySearch: 'category-search',
    searchHits: 'search-hits',
    didYouMean: 'did-you-mean',
    productList: 'product-list',
    categoryNavigation: 'category-navigation',
  },
  tokens: {
    clusterId: '{{CLUSTER_ID}}',
  },
};

export const PAGINATION = {
  apptus: {
    productsPerPage: 10,
    page: 1,
  },
};

export const MAGNOLIA_KEYS = {
  nameKey: '@name',
  generalSettingsValue: 'generalSettings',
  settingsValue: 'settings',
};
