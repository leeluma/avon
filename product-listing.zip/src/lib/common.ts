import { logger } from '.';
import { LogConfig, LogStatus } from '../middlewares';

/**
 * It contains common functions to use within application.
 */
export class Common {
  /**
   * It used to convert object parameters to query string.
   *
   * @param params
   * @returns
   */
  public queryString(params: Record<string, any>): string {
    const removeUndefined = JSON.parse(JSON.stringify(params));
    return Object.entries(removeUndefined).map(
      ([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value as string)}`,
    ).join('&');
  }

  public convertUnderScoreToCamelCaseForApptus(params:Record<string, any>): Record<string, any> {
    return Object.fromEntries(
      Object.entries(params).map(([key, value]) =>
        [key.replace(/_([a-z])/g, (g) => { return g[1].toUpperCase(); }), value[0]]),
    );
  }

  public convertUnderScoreToCamelCase(params: Record<string, any>): Record<string, any> {
    return Object.fromEntries(
      Object.entries(params).map(([key, value]) =>
        [
          key.replace(/_([a-z])/g, (g) => g[1].toUpperCase()),
          value[0],
        ]),
    );
  }

  public isResponseOK = (status) => status >= 200 && status < 299;

  public log(config: any, result: any, status, logConfig: LogConfig):void {
    if (logConfig.apptusLogStatus === LogStatus.TRACE) {
      logger.trace(`Response:: ${JSON.stringify(result)}`);
    } else if (logConfig.apptusLogStatus === LogStatus.INFO && this.isResponseOK(status)) {
      logger.info(`Response:: ${JSON.stringify(result)}`);
    } else if (logConfig.apptusLogStatus === LogStatus.ERROR && !this.isResponseOK(status)) {
      logger.error(`Response:: ${JSON.stringify(result)}`);
    }
  }
}
