import { getReasonPhrase } from 'http-status-codes';

export type GenericError = { [k: string]: any };

/**
 * An error that can be thrown to send a message to the user of the API.
 * Be EXTREMELY CAREFUL about what data is included in the message.
 * The message MUST be i18n.
 */
export class ApiError extends Error {
  /**
   * HTTP status code
   */
  public readonly statusCode: number;

  public readonly messageArray: any[];

  constructor(statusCode: number, message: string | GenericError | GenericError []) {
    super(message ? JSON.stringify(message) : getReasonPhrase(statusCode));

    this.statusCode = statusCode;

    if (Array.isArray(message)) {
      this.messageArray = message;
    } else {
      this.messageArray = [typeof message === 'string' ? { message } : message];
    }
  }

  toString(): string {
    return JSON.stringify({ [this.statusCode]: this.messageArray });
  }
}
