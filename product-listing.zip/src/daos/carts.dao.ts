import axios, { AxiosRequestConfig } from 'axios';
import { ApiError, logger, URI } from '../lib';
import { AddtoCartRequestDto, AddToCartResponseDto } from '../dtos';

export interface CartsDaoConfig {
  beOrderUrl: string;
}

/**
 * `CartsDao` data access class for Carts
 */
export class CartsDao {
  private readonly beOrderUrl: string;

  /**
   * Constructor for `CartsDao` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: CartsDaoConfig) {
    this.beOrderUrl = config.beOrderUrl;
  }

  public async addProductToCart(params: AddtoCartRequestDto): Promise<AddToCartResponseDto> {
    const {
      market,
      customerId,
      anonymousId,
      cartId,
      sku,
      quantity,
      productKey,
      channelkey,
    } = params;
    const axiosConfig: AxiosRequestConfig = {
      method: 'post' as const,
      url: `${this.beOrderUrl.replace('{{MARKET}}', market.localeAndCountry)}/carts`,
      headers: {
        'Content-Type': URI.commonConfig.contentType,
        Accepts: URI.commonConfig.contentType,
      },
      data: {
        anonymousId,
        customerId,
        cartId,
        lineItems: {
          sku, quantity, productKey,
        },
        channelKey: channelkey,
      },
    };

    try {
      const response = await axios(axiosConfig);

      return response.data.data;
    } catch (err: any) { // NOSONAR
      // any is recommended in catch block
      logger.error(`LEAP BE ORDER returned error: ${err}`);

      if (!err.response) {
        throw err;
      }

      throw new ApiError(err.response.status, err.response.data?.errors);
    }
  }
}
