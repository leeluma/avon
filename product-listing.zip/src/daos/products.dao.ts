import axios, { AxiosResponse } from 'axios';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import {
  logger, Common, URI, PAGINATION, ApiError,
} from '../lib';
import {
  CommonResponse, MagnoliaDto, MagnoliaGlobalSettingDto, MagnoliaInfo,
} from '../dtos';
import { MarketInfo, LogConfig } from '../middlewares';
import { config } from '../config';
import { axiosOptions } from '../lib/axios-instance';

const {
  apptusMaxFacets, apptusWindowFirstRecommendations,
  apptusWindowLastRecommendations, apptusMaxProducts,
  magnoliaGlobalSettingsUrl,
} = config;
export interface ProductsDaoConfig {
  common: Common;
  apptusBaseUrl: string,
  apptusClusterId: string,
  apptusEsalesMarket: string,
  magnoliaBasePath: string;
}

/**
 * `ProductsDao` data access class for CommerceTools `Product`
 */
export class ProductsDao {
  private readonly common: Common;

  private readonly apptusBaseUrl: string;

  private readonly apptusClusterId: string;

  private readonly apptusEsalesMarket: string;

  private readonly magnoliaBasePath: string;

  private readonly country = '{{country}}';

  private readonly marketPath = 3;

  private readonly statusCode404 = 400;

  /**
   * Constructor for `ProductsDao` class
   * @param configuration Injects dependencies into the object
   */
  constructor(configuration: ProductsDaoConfig) {
    this.common = configuration.common;
    this.apptusBaseUrl = configuration.apptusBaseUrl;
    this.apptusClusterId = configuration.apptusClusterId;
    this.apptusEsalesMarket = configuration.apptusEsalesMarket;
    this.magnoliaBasePath = configuration.magnoliaBasePath;
  }

  /**
   * Get template From Magnolia
   * @param market - MarketInfo
   * @returns Return pages data from Magnolia
   */

  public async getTemplateFromMagnolia(templateName: string)
    : Promise<AxiosResponse> {
    const configuration = {
      ...axiosOptions,
      method: 'get' as const,
      url: `${this.magnoliaBasePath}${URI.magnolia.templatePath}${templateName}`,
    };

    try {
      const magnoliaTempplateData = await axios(configuration);
      return magnoliaTempplateData.data;
    } catch (error:any) {
      logger.error(`Response body: ${error.response?.data}`);
      throw new Error(`Failed to fetch template data from magnolia, because: ${error.stack}`);
    }
  }

  /**
 * Update
 * @param data Object
 */
  public updateApptusResponse(data) {
    let categoryResultSet;
    this.updateSearchResponse(data);
    /* istanbul ignore else */
    if (data.hasOwnProperty('categoryOverview')) {
      categoryResultSet = data.categoryOverview;
      /* istanbul ignore else */
      if (categoryResultSet.length) {
        categoryResultSet = categoryResultSet.find((item) => item.name === 'category-overview');
        /* istanbul ignore else */
        if (categoryResultSet?.categoryTree) {
          const categoryImage = categoryResultSet?.categoryTree.attributes?.category_image;
          /* istanbul ignore else */
          if (categoryImage && categoryImage.length) {
            categoryResultSet.categoryTree.attributes.categoryImage = categoryImage[categoryImage.length - 1];
            delete categoryResultSet.categoryTree.attributes.category_image;
          }
          const productUrl = categoryResultSet?.categoryTree.attributes?.product_url;
          /* istanbul ignore else */
          if (productUrl?.length) {
            categoryResultSet.categoryTree.attributes.productUrl = productUrl[productUrl.length - 1];
            delete categoryResultSet.categoryTree.attributes.product_url;
          }
          const description = categoryResultSet?.categoryTree.attributes.description;
          categoryResultSet.categoryTree.attributes.description = description[description.length - 1];
          const id = categoryResultSet?.categoryTree.attributes.id;
          categoryResultSet.categoryTree.attributes.id = id[id.length - 1];
          const keywords = categoryResultSet?.categoryTree.attributes.keywords;
          categoryResultSet.categoryTree.attributes.keywords = keywords.join(',');
        }
      }
    }
  }

  private updateSearchResponse(data):void {
    let resultSet;
    if (data && data.hasOwnProperty('hits')) {
      resultSet = data.hits;
    }
    if (data && data.hasOwnProperty('productListWithCount')) {
      resultSet = data.productListWithCount;
    }
    resultSet = resultSet.find((item) => item.name === 'product-list'
    || item.name === 'search-hits');
    resultSet?.products?.forEach((p) => {
      const productAttributes = p;
      productAttributes.attributes = this.common.convertUnderScoreToCamelCase(p.attributes);
      productAttributes.variants.forEach((v) => {
        const variantAttributes = v;
        variantAttributes.attributes = this.common.convertUnderScoreToCamelCase(v.attributes);
      });
    });
  }

  /**
   * Gets apptus product search
   * @param market - MarketInfo
   * @param id - Product id
   * @returns Product | undefined
   */
  public async apptusProductSearch(
    market: MarketInfo,
    params,
    logConfig: LogConfig,
  ): Promise<CommonResponse> {
    try {
      const {
        page, productsPerPage, sessionKey, customerKey,
      } = params;
      const windowLast = (page || PAGINATION.apptus.page) * (productsPerPage || PAGINATION.apptus.productsPerPage);
      const windowsFirst = (windowLast - (productsPerPage || PAGINATION.apptus.productsPerPage)) + 1;
      const apptusQueryParams = {
        'esales.market': `${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}`,
        'esales.customerKey': customerKey,
        'esales.sessionKey': sessionKey,
        max_facets: params.maxFacets || apptusMaxFacets,
        window_first: windowsFirst,
        window_last: windowLast,
        window_first_recommendations: params.windowFirstRecommendations
         || apptusWindowFirstRecommendations,
        window_last_recommendations: params.windowLastRecommendations || apptusWindowLastRecommendations,
        root_category: params.rootCategory
          ? `categories_${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}:
        '${params.rootCategory}'`
          : `categories_${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}:'root'`,
        max_products: params.maxProducts || apptusMaxProducts,
        selected_category: params.selectedCategory
          ? `categories_${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}:
        '${params.selectedCategory}'`
          : `categories_${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}:'root'`,
        filter: params.filter,
        sort_by: params.sortBy,
        search_phrase: params.searchPhrase,
        depth: params.depth,
        facets: params.facets,
        locale: `${market.localeAndCountry}`,
      };
      const searchParams = this.common.queryString(apptusQueryParams);
      const apptusUrl = `${this.apptusBaseUrl
        .replace(URI.tokens.clusterId, this.apptusClusterId)}${URI.apptus.searchPage}${searchParams}`;
      const configuration = {
        ...axiosOptions,
        method: 'get' as const,
        url: apptusUrl,
      };
      const result = await axios(configuration);
      this.common.log(configuration, result.data, result.status, logConfig);
      this.updateApptusResponse(result.data);
      return {
        ...result.data,
      };
    } catch (error: any) {
      this.common.log(null, error.stack, error.statusCode, logConfig);
      throw new Error(`Failed to fetch products from Apptus, because: ${error.stack}`);
    }
  }

  /**
   * Gets apptus category search
   * @param market - MarketInfo
   * @param id - Category id
   * @returns Category | undefined
   */
  public async apptusCategorySearch(
    market: MarketInfo,
    params,
    logConfig: LogConfig,
  ) {
    try {
      const {
        page, productsPerPage, customerKey, sessionKey,
      } = params;
      const windowLast = (page || PAGINATION.apptus.page) * (productsPerPage || PAGINATION.apptus.productsPerPage);
      const windowsFirst = (windowLast - (productsPerPage || PAGINATION.apptus.productsPerPage)) + 1;
      const rootCategoryBase = `categories_${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}`;
      const parameters = {
        market, customerKey, sessionKey, windowsFirst, windowLast, rootCategoryBase,
      };
      const apptusQueryParams = this.searchQueryParameters(parameters, params);
      const searchParams = this.common.queryString(apptusQueryParams);
      const apptusUrl = `${this.apptusBaseUrl
        .replace(URI.tokens.clusterId, this.apptusClusterId)}${URI.apptus.search}${searchParams}`;
      const configuration = {
        ...axiosOptions,
        method: 'get' as const,
        url: apptusUrl,
      };
      const result = await axios(configuration);
      this.common.log(configuration, result.data, result.status, logConfig);
      this.updateApptusResponse(result.data);
      return result.data;
    } catch (error: any) { // NOSONAR
      if (error?.response?.status === this.statusCode404) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.categoryNotFound'));
      }
      this.common.log(null, error.stack, error.statusCode, logConfig);
      throw new Error(`Failed to fetch products from Apptus, because: ${error.stack}`);
    }
  }

  private searchQueryParameters(parameters, params) {
    const {
      market, customerKey, sessionKey, windowsFirst, windowLast, rootCategoryBase,
    } = parameters;
    return {
      'esales.market': `${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}`,
      'esales.customerKey': customerKey,
      'esales.sessionKey': sessionKey,
      max_facets: params.maxFacets || apptusMaxFacets,
      window_first: windowsFirst,
      window_last: windowLast,
      window_first_recommendations: params.windowFirstRecommendations
        || apptusWindowFirstRecommendations,
      window_last_recommendations: params.windowLastRecommendations || apptusWindowLastRecommendations,
      root_category: params.rootCategory
        ? `${rootCategoryBase}:'${params.rootCategory}'`
        : `${rootCategoryBase}:'root'`,
      max_products: params.maxProducts || apptusMaxProducts,
      selected_category: params.selectedCategory ? `${rootCategoryBase}:'${params.selectedCategory}'` : '',
      filter: params.filter,
      sort_by: params.sortBy,
      depth: params.depth,
      facets: params.facets,
      locale: `${market.localeAndCountry}`,
    };
  }
  /**
   * Get Pages From Magnolia
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   * @returns Return pages data from Magnolia
   */

  public async getPagesFromMagnolia(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ): Promise<MagnoliaDto> {
    const queryParam = `lang=${market.locale}-${market.country}`;
    let globalSettingPageUrl;
    const globalSettingUrl = `${magnolia.url}${URI.magnolia.pageData}`.replace(this.country, `${magnolia.marketPath}`);
    globalSettingPageUrl = `${globalSettingUrl}?${queryParam}`;
    if (magnolia.ispreview === false || magnolia.marketPath.length < this.marketPath) {
      globalSettingPageUrl = `${globalSettingUrl}${URI.magnolia.search}?${queryParam}`;
    }
    const configuration = {
      ...axiosOptions,
      method: 'get' as const,
      url: globalSettingPageUrl,
    };
    try {
      const magnoliaPages = await axios(configuration);
      return magnoliaPages.data;
    } catch (error: any) {
      logger.error(`Response body: ${error.response?.data}`);
      throw new Error(`Failed to fetch products from Magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get Category From Magnolia
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   * @returns Return category data from Magnolia
   */
  public async getCategoryPagesFromMagnolia(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ): Promise<MagnoliaDto> {
    let globalSettingPageUrl;
    const queryParam = `lang=${market.locale}-${market.country}`;
    const globalSettingUrl = `${magnolia.url}${URI.magnolia.pageData}`.replace(this.country, `${magnolia.marketPath}`);
    globalSettingPageUrl = `${globalSettingUrl}?${queryParam}`;
    if (magnolia.ispreview === false || magnolia.marketPath.length < this.marketPath) {
      globalSettingPageUrl = `${globalSettingUrl}${URI.magnolia.category}?${queryParam}`;
    }
    const configuration = {
      ...axiosOptions,
      method: 'get' as const,
      url: globalSettingPageUrl,
    };
    try {
      const magnoliaCategories = await axios(configuration);
      return magnoliaCategories.data;
    } catch (error: any) {
      logger.error(`Response body: ${error.response?.data}`);
      throw new Error(`Failed to fetch categories from Magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get banner data from magnolia by categoryId
   * @param categoryId
   * @param magnolia - MagnoliaInfo
   */
  public async getMagnoliaDataByCategoryId(
    categoryId: string,
    magnolia: MagnoliaInfo,
  ): Promise<CommonResponse> {
    try {
      const magnoliaBaseUrl = `${magnolia.url}${URI.magnolia.categorySearch}${categoryId}`;
      const configuration = {
        ...axiosOptions,
        method: 'get' as const,
        url: magnoliaBaseUrl,
      };
      const result = await axios(configuration);
      const data = { ...result.data };
      return data.results[0];
    } catch (error: any) {
      throw new Error(`Failed to fetch category data from magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get global setting data.
   * @param market
   */
  public async getMagnoliaGobalSetting(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ) : Promise<MagnoliaGlobalSettingDto[]> {
    try {
      let configUrl = `${magnolia.url}${magnoliaGlobalSettingsUrl}?lang=${market.localeAndCountry}`;
      configUrl = configUrl.replace(this.country, `${market.country.toLocaleLowerCase()}`);
      const configuration = {
        ...axiosOptions,
        method: 'get' as const,
        url: configUrl,
      };
      const result = await axios(configuration);
      return [result.data];
    } catch (error: any) {
      throw new Error(`Failed to fetch global setting data from magnolia, because: ${error.stack}`);
    }
  }
}
