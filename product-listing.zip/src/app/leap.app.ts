import express, {
  Application, RequestHandler, Router,
} from 'express';
import swaggerUI from 'swagger-ui-express';
import swaggerJsdoc from 'swagger-jsdoc';
import cors from 'cors';
import expressSanitizer from 'express-sanitizer';
import helmet from 'helmet';
import compression from 'compression';
import actuator from 'express-actuator';
import i18next from 'i18next';
import i18nextBackend from 'i18next-fs-backend';
import i18nextMiddleware from 'i18next-http-middleware';
import {
  errorHandlerMiddleware,
  requestLoggerMiddleware,
  marketParserMiddleware,
  switchLangMiddleware,
  requestBodyLoggerMiddleware,

} from '../middlewares';
import { logger } from '../lib';
import { config } from '../config';

const { env } = config;
export interface LeapAppConfig {
  projectName: string;
  projectVersion: string;
  apiContextPath: string;
  apiVersion: string;
  port: number;
}

export class LeapApp {
  private readonly expressApp: Application;

  private readonly expressRouter: Router;

  private readonly routePrefix: string;

  private readonly projectName: string;

  private readonly projectVersion: string;

  private readonly apiContextPath: string;

  private readonly apiContextVersion: string;

  private readonly port: number;

  private i18nextHandler: any;

  constructor(configuration: LeapAppConfig) {
    this.projectName = configuration.projectName;
    this.projectVersion = configuration.projectVersion;
    this.apiContextPath = configuration.apiContextPath;
    this.apiContextVersion = configuration.apiVersion;
    this.port = configuration.port;

    this.expressApp = express();
    this.expressApp.use(cors());
    this.expressRouter = express.Router();
    this.routePrefix = `/${this.apiContextPath}/${this.apiContextVersion}/:locale-:country`;

    this.expressApp.use(this.expressRouter);
  }

  private bootstrapCommonMiddlewares(): void {
    this.expressApp.use(helmet());
    this.expressApp.use(compression());
    this.expressApp.use(expressSanitizer());
  }

  private bootstrapSwagger(): void {
    const swaggerOptions = {
      definition: {
        openapi: '3.0.0',
        info: {
          title: this.projectName,
          version: this.projectVersion,
          description: `Avon API Library : ${this.projectName} v${this.apiContextVersion}`,
        },
        servers: [
          {
            url: `http://localhost:${this.port}/${this.apiContextPath}/${this.apiContextVersion}/`,
            description: 'My local dev',
          },
          {
            url: `https://api.leap-dev.aws.avon.com/${this.apiContextPath}/${this.apiContextVersion}/`,
            description: 'My dev',
          },
        ],
      },
      apis: ['**/*.ts'],
    };

    const swaggerSpecs = swaggerJsdoc(swaggerOptions);

    this.expressApp.use('/api-docs', swaggerUI.serve, swaggerUI.setup(swaggerSpecs));
  }

  private async bootstrapI18next(): Promise<void> {
    const options = {
      order: ['path'],
      lookupPath: 'locale',
      caches: false,
    };
    await i18next
      .use(i18nextMiddleware.LanguageDetector)
      .use(i18nextBackend)
      .init({
        preload: ['en', 'ro'],
        ns: ['translation'],
        defaultNS: 'translation',
        detection: options,
        fallbackLng: 'en',
        backend: {
          loadPath: `${__dirname}/../locale/{{lng}}/translation.json`,
        },
      });
    this.i18nextHandler = i18nextMiddleware.handle(i18next);
  }

  private bootstrapActuator(): void {
    const optionsActuator: actuator.Options = {
      basePath: `/${this.apiContextPath}/${this.apiContextVersion}/actuator`,
      infoGitMode: 'simple',
      customEndpoints: [],
    };

    this.expressApp.use(actuator(optionsActuator));
  }

  public async bootstrap(): Promise<void> {
    this.bootstrapCommonMiddlewares();
    this.bootstrapSwagger();
    this.bootstrapActuator();
    await this.bootstrapI18next();
  }

  public mount(path: string, ...handlers: RequestHandler[]): void {
    logger.info(`Mounting ${this.routePrefix}${path}/*`);

    this.expressRouter.use(
      `${this.routePrefix}${path}`,

      requestLoggerMiddleware,
      express.json(),
      requestBodyLoggerMiddleware,
      marketParserMiddleware,
      this.i18nextHandler,
      switchLangMiddleware,
      ...handlers,
      errorHandlerMiddleware,
    );
  }

  public listen(): void {
    this.expressApp.use((req, res) => {
      const { locale } = req.params;
      i18next.changeLanguage(locale).then(() => {
        res.status(404).send(i18next.t('error.routeNotFound'));
      });
    });

    this.expressApp.listen(this.port, () => {
      logger.info(`${this.projectName} v${this.projectVersion} :: Listening on :${this.port}`);
      if (env !== 'production') {
        logger.info('\u0007');
      }
    });
  }
}
