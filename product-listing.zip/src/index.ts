import { Router } from 'express';
import { Common, CtClient } from './lib';
import { LeapApp, LeapAppConfig } from './app/leap.app';
import {
  CartsDao, NotificationsDao, ProductsDao, DefaultDao,
} from './daos';
import { CtDto } from './dtos';
import {
  CartsRouter, NotificationsRouter, ProductsRouter, DefaultRouter,
} from './routers';
import {
  CartsController, NotificationsController, ProductsController, DefaultController,
} from './controllers';
import { CartsService, ProductsService, DefaultService } from './services';
import { NotificationsService } from './services/notifications.service';
import { config } from './config';
/* Build configuration */
const {
  port, projectName, projectVersion, apiContextPath, apiVersion, magnoliaBasePath,
  beOrderUrl, apptusClusterId, apptusBaseUrl, apptusEsalesMarket,
} = config;

if (!projectName) {
  throw new Error('The "name" field in package.json is mandatory!');
}

if (!projectVersion) {
  throw new Error('The "version" field in package.json is mandatory!');
}

if (!apiContextPath) {
  throw new Error('The "API_CONTEXT_PATH" environment variable is mandatory! (suggested value: api)');
}

if (!magnoliaBasePath) {
  throw new Error('The "MAGNOLIA_BASE_PATH" environment variable is mandatory!');
}

if (!apiVersion) {
  throw new Error('The "API_VERSION" environment variable is mandatory! (suggested value: v1)');
}

if (!port) {
  throw new Error('The "API_PORT" environment variable is missing or not a valid number! (suggested value: 3000)');
}

if (!apptusClusterId) {
  throw new Error('The "APPTUS_CLUSTER_ID" environment variable is missing');
}

if (!apptusEsalesMarket) {
  throw new Error('The "APPTUS_ESALES_MARKET" environment variable is missing');
}

if (!apptusBaseUrl) {
  throw new Error('The "APPTUS_BASE_URL" environment variable is missing');
}

if (!beOrderUrl) {
  throw new Error('The "LEAP_BE_ORDER" environment variable is mandatory!');
}

const appConfig: LeapAppConfig = {
  projectName,
  projectVersion,
  apiContextPath,
  apiVersion,
  port,
};

/* Initialize dependencies */

const common = new Common();

const cartsDao = new CartsDao({ beOrderUrl });
const productsDao = new ProductsDao({
  common,
  apptusBaseUrl,
  apptusClusterId,
  apptusEsalesMarket,
  magnoliaBasePath,
});

const notificationsDao = new NotificationsDao({
  common,
  apptusBaseUrl,
  apptusClusterId,
  apptusEsalesMarket,
});
const ctClient = new CtClient(process.env as CtDto);
const defaultDao = new DefaultDao({ ctClient });

const cartsService = new CartsService({ cartsDao });
const productsService = new ProductsService({ productsDao });
const notificationsService = new NotificationsService({ notificationsDao });
const defaultService = new DefaultService({ defaultDao });

const cartsController = new CartsController({ cartsService });
const productsController = new ProductsController({ productsService });
const notificationsController = new NotificationsController({ notificationsService });
const defaultController = new DefaultController({ defaultService });

const cartsRouter = new CartsRouter({ Router, cartsController });
const productsRouter = new ProductsRouter({ Router, productsController });
const notificationsRouter = new NotificationsRouter({ Router, notificationsController });
const defaultRouter = new DefaultRouter({ defaultController, Router });

/* Start app */

const leapApp = new LeapApp(appConfig);
leapApp.bootstrap().then(() => {
  leapApp.mount('/', defaultRouter.buildExpressRouter());
  leapApp.mount('/carts', cartsRouter.buildExpressRouter());
  leapApp.mount('/products', productsRouter.buildExpressRouter());
  leapApp.mount('/notifications', notificationsRouter.buildExpressRouter());
  leapApp.listen();
});
