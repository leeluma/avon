import { NextFunction, Request, Response } from 'express';
import HttpStatusCodes, { getReasonPhrase, ReasonPhrases } from 'http-status-codes';
import { ApiError, logger } from '../lib';

export const errorHandlerMiddleware = async (
  error: Error,
  request: Request,
  response: Response,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  next: NextFunction,
): Promise<void> => {
  logger.error(`errorHandlerMiddleware caught the following error:\n${error.stack}`);

  let statusCode: number;
  let errors: any[];

  if (error instanceof ApiError) {
    statusCode = error.statusCode;
    errors = error.messageArray;
  } else {
    statusCode = HttpStatusCodes.INTERNAL_SERVER_ERROR;
    errors = [{ msg: ReasonPhrases.INTERNAL_SERVER_ERROR }];
  }

  response.status(statusCode).send({
    status: {
      statusCode,
      msg: getReasonPhrase(statusCode),
      timestamp: new Date().toISOString(),
    },
    errors,
  });
};
