import { NextFunction, Request, Response } from 'express';
import { config } from '../config';
import { MagnoliaInfo } from '../dtos';
import { getMarketPath } from '../lib';

export const magnoliaUrlMiddleware = (request: Request, response: Response, next: NextFunction): void => {
  const { market } = response.locals;

  const { country } = market;
  const magnolia: MagnoliaInfo = {
    url: config.magnoliaBasePath as string,
    ispreview: false,
    marketPath: country.toLocaleLowerCase(),
  };

  const previewValue = request.headers.ispreview ? (request.headers.ispreview as string).toLowerCase() : false;
  if (previewValue === 'true') {
    magnolia.url = config.previewMagnoliaBasePath as string;
    magnolia.ispreview = true;
    const path = request.query.path ? request.query.path as string : '';

    const isGlobal = path ? (path.includes('Global')) : false;

    if (isGlobal) {
      const pathContext = path.split(',');

      magnolia.marketPath = getMarketPath(pathContext);// ['Global','CEE'], ['Global','en_US','CEE']
    }
  }

  response.locals.magnolia = magnolia;
  next();
};
