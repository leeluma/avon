import { AddtoCartRequestDto, AddToCartResponseDto } from '../dtos';
import { CartsDao } from '../daos';

export interface CartsServiceConfig {
  cartsDao: CartsDao;
}

/**
 * Service for managing Carts
 */
export class CartsService {
  private readonly cartsDao: CartsDao;

  /**
   * Constructor for `CartsService` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: CartsServiceConfig) {
    this.cartsDao = config.cartsDao;
  }

  public async addProductToCart(params: AddtoCartRequestDto): Promise<AddToCartResponseDto> {
    return this.cartsDao.addProductToCart(
      params,
    );
  }
}
