import { MarketInfo, LogConfig } from '../middlewares';
import { ProductsDao } from '../daos';
import { MAGNOLIA_KEYS, URI } from '../lib';
import { CommonResponse, FreeTextBaseSectionDto, MagnoliaInfo } from '../dtos';

export interface ProductsServiceConfig {
  productsDao: ProductsDao;
}
const PRODUCT_LIST = 'product-list';
const SEARCH_HITS = 'search-hits';
const FACETS = 'facets';

/**
 * Service for managing products
 */
export class ProductsService {
  private readonly productsDao: ProductsDao;

  constructor(config: ProductsServiceConfig) {
    this.productsDao = config.productsDao;
  }

  /**
   * Filter categoryId from apptus response.
   * @param apptusResponse
   * @returns
   */
  public getCategoryId(data) {
    return data.categoryOverview.find((item) => item.name === 'category-overview')
      .categoryTree.attributes.id;
  }

  /**
  * Modify apptus product's data
  * @param apptusResponse object
  * @param magnoliaCategoryData object
  *
  */
  public updateApptusProductResponse(apptusResponse, magnoliaCategoryData) {
    if (magnoliaCategoryData.categorySetting?.bannerCardBaseSection?.bannerPosition) {
      return apptusResponse?.productListWithCount?.find((item) => item.name === `${URI.commonConfig.productList}`)
        ?.products?.splice(
          magnoliaCategoryData.categorySetting?.bannerCardBaseSection?.bannerPosition,
          0,
          magnoliaCategoryData.categorySetting?.bannerCardBaseSection,
        );
    }
    return apptusResponse;
  }

  /**
  * Modify apptus product's data
  * @param response object
  */
  public apptusSearchMapping(response) {
    let didYouMeans = {
      status: false,
    };
    if (response.hasOwnProperty('did_you_mean')) {
      didYouMeans = response.did_you_mean;
    }
    return {
      productList: {
        didYouMean: didYouMeans,
        productListWithCount: [
          {
            ...response.productCount[0],
          },
          {
            ...response.hits.find((hits) => hits.name === `${URI.commonConfig.searchHits}`),
          },
        ],
        facets: [{ ...response.hits.find((hits) => hits?.name === 'facets') }],
        categoryBreadcrumb: [{
          ...response.hits.find((hits) =>
            hits.name === `${URI.commonConfig.categorySearch}`),
        }],
        categoryNavigation: [{
          ...response.hits.find((hits) =>
            hits.name === `${URI.commonConfig.categorySearch}`),
        }],
        categoryOverview: [
          { ...response.hits.find((hits) => hits.name === `${URI.commonConfig.categoryNavigation}`) }],
        correctionTextList: [{ ...response?.hits.find((hits) => hits.name === `${URI.commonConfig.didYouMean}`) }],
      },
    };
  }

  /**
   * Get product search from apptus
   * @param market - MarketInfo
   * @param productId - Product id
   * @param magnolia - MagnoliaInfo
   * @returns ProductResponseDto
   * @throws ApiError 40m4 if Product was not found
   */
  public async search(
    market: MarketInfo,
    params,
    channelkey,
    isPage: boolean,
    logConfig: LogConfig,
    magnolia: MagnoliaInfo,
  ): Promise<CommonResponse> {
    let apptusResponse;
    let availabilityCheck;
    let templateDefinition = {};
    let singleWarehouse;
    let defaultWarehouse;
    let ccy;
    let currencyPlacement;
    const [magnoliapageData, magnoliaGlobalSettings, apptusData] = await Promise.all([
      this.productsDao.getPagesFromMagnolia(market, magnolia),
      this.productsDao.getMagnoliaGobalSetting(market, magnolia),
      this.productsDao.apptusProductSearch(market, params, logConfig),
    ]);
    apptusResponse = apptusData;
    params.productsPerPage = magnoliapageData.productsPerPage;
    [templateDefinition] = await Promise.all(
      [
        magnolia.ispreview ? this.productsDao
          .getTemplateFromMagnolia(magnoliapageData[`${URI.magnolia.mgnlTemplate}`]) : Promise.resolve({}),

      ],
    );

    const productListWithCount = apptusResponse?.hits?.find((tt) => tt.name === SEARCH_HITS);
    /* istanbul ignore else */
    if (productListWithCount?.products) {
      this.limitedStockProducts(productListWithCount);
    }
    const { nameKey, settingsValue } = MAGNOLIA_KEYS;
    const settings = magnoliaGlobalSettings.find((ms) => ms[nameKey] === settingsValue);
    /* istanbul ignore else */
    if (settings) {
      singleWarehouse = settings.warehouseSettings.isSingleWarehouse;
      defaultWarehouse = settings.warehouseSettings.defaultWarehouse;
      ccy = settings.priceFormat?.ccy;
      currencyPlacement = settings.priceFormat?.currencyPlacement;
    }
    const facetItems = apptusResponse.hits?.find((item) => item.name === FACETS);
    /* istanbul ignore else */
    if (facetItems?.facetList) {
      this.facetData(facetItems, { ccy, currencyPlacement });
    }

    const didYouMeanItem = apptusResponse.hits.find((item) => item.name === 'did-you-mean');
    if (didYouMeanItem) {
      params.searchPhrase = didYouMeanItem.corrections[0].text;
    }
    if (didYouMeanItem) {
      params.searchPhrase = didYouMeanItem.corrections[0].text;
      apptusResponse = await this.productsDao.apptusProductSearch(market, params, logConfig);
      apptusResponse.did_you_mean = {
        status: true,
        correctText: params.searchPhrase,
      };
    }
    availabilityCheck = channelkey;

    if (!channelkey && singleWarehouse === 'true') {
      availabilityCheck = defaultWarehouse;
    }

    this.updateProductAvailability(apptusResponse, availabilityCheck);

    if (isPage) {
      return this.apptusSearchMapping(apptusResponse);
    }
    delete magnoliaGlobalSettings[0].fieldValidators;
    delete magnoliaGlobalSettings[0].addressSettings;
    const magnoliaData = Object.assign(magnoliapageData, { magnoliaGlobalSettings: magnoliaGlobalSettings[0] });
    return {
      ...magnoliaData,
      templateDefinition: { ...templateDefinition },
      ...this.apptusSearchMapping(apptusResponse),
      singleWarehouse,
      defaultWarehouse,
    };
  }

  /**
 *  Update search availability data.
 * @param data Object
 * @param availabilityCheck boolean.
 */
  public updateProductAvailability(data, availabilityCheck) {
    let resultSet;
    if (data.hasOwnProperty('hits')) {
      resultSet = data.hits;
    }
    if (data.hasOwnProperty('productListWithCount')) {
      resultSet = data.productListWithCount;
    }
    const productLists = resultSet.find((item) => item?.name === PRODUCT_LIST || item?.name === SEARCH_HITS);
    productLists?.products.forEach((p) => {
      const productParams = p;
      productParams.attributes.inStock = false;
      productParams.variants.forEach((v) => {
        const variantParams = v;
        /* istanbul ignore else */
        if (variantParams.attributes.availability) {
          const productAvailability = JSON.parse(v.attributes.availability);
          variantParams.attributes.availability = {
            stockQty: 0,
            isAvailable: false,

          };
          /* istanbul ignore else */
          if (productAvailability.hasOwnProperty(availabilityCheck)) {
            variantParams.attributes.availability = {
              stockQty: productAvailability[availabilityCheck].available_quantity,
              isAvailable: productAvailability[availabilityCheck].in_stock,
              limited_stock: productAvailability[availabilityCheck].limited_stock,
            };
            /* istanbul ignore else */
            if (productAvailability[availabilityCheck].in_stock === true) {
              productParams.attributes.inStock = true;
            }
          }
        }
      });
    });
  }

  /**
   * Get category search from apptus
   * @param market - MarketInfo
   * @param productId - Category id
   * @param magnolia - MagnoliaInfo
   * @returns categories
   * @throws ApiError 404 if Product was not found
   */
  public async category(
    market: MarketInfo,
    params,
    channelkey,
    isPage: boolean,
    logConfig: LogConfig,
    magnolia: MagnoliaInfo,
  ): Promise<CommonResponse> {
    let freeTextBaseSection:FreeTextBaseSectionDto;
    let availabilityCheck = channelkey;
    let finalApptusresponse;
    let singleWarehouse;
    let defaultWarehouse;
    let ccy;
    let currencyPlacement;

    const [getMagnoliapageData, magnoliaGlobalSettings, apptusData] = await Promise.all([
      this.productsDao.getCategoryPagesFromMagnolia(market, magnolia),
      this.productsDao.getMagnoliaGobalSetting(market, magnolia),
      this.productsDao.apptusCategorySearch(market, params, logConfig),
    ]);
    params.productsPerPage = getMagnoliapageData?.productsPerPage;

    const { nameKey, settingsValue } = MAGNOLIA_KEYS;
    const settings = magnoliaGlobalSettings.find((m) => m[nameKey] === settingsValue);
    if (settings) {
      singleWarehouse = settings.warehouseSettings.isSingleWarehouse;
      defaultWarehouse = settings.warehouseSettings.defaultWarehouse;
      ccy = settings.priceFormat?.ccy;
      currencyPlacement = settings.priceFormat?.currencyPlacement;
    }

    if (!channelkey && singleWarehouse === 'true') {
      availabilityCheck = defaultWarehouse;
    }

    this.updateProductAvailability(apptusData, availabilityCheck);

    const productListWithCount = apptusData.productListWithCount.find((item) => item.name === PRODUCT_LIST);
    if (productListWithCount?.products) {
      this.limitedStockProducts(productListWithCount);
    }
    const facetItems = apptusData.facets?.find((item) => item.name === FACETS);
    if (facetItems?.facetList) {
      this.facetData(facetItems, { ccy, currencyPlacement });
    }
    const apptusCategoryId = this.getCategoryId(apptusData);

    const [templateDefinition, magnoliaCategoryData] = await Promise.all(
      [
        magnolia.ispreview ? this.productsDao
          .getTemplateFromMagnolia(getMagnoliapageData[`${URI.magnolia.mgnlTemplate}`]) : Promise.resolve({}),
        this.productsDao.getMagnoliaDataByCategoryId(apptusCategoryId, magnolia),
      ],
    );
    finalApptusresponse = { ...apptusData };
    if (magnoliaCategoryData) {
      this.updateApptusProductResponse(apptusData, magnoliaCategoryData);
      freeTextBaseSection = {
        freeTextBaseSection: magnoliaCategoryData.categorySetting?.freeTextBaseSection,
        topBannerSection: magnoliaCategoryData.categorySetting?.topBannerSection,
        seoSettings: magnoliaCategoryData.categorySetting?.seoSettings,
      };
      finalApptusresponse = { ...apptusData, ...freeTextBaseSection };
    }
    if (isPage) {
      return { productList: { ...finalApptusresponse } };
    }
    delete magnoliaGlobalSettings[0].fieldValidators; // NOSONAR
    delete magnoliaGlobalSettings[0].addressSettings; // NOSONAR
    const magnoliapageData = Object.assign(getMagnoliapageData, { magnoliaGlobalSettings: magnoliaGlobalSettings[0] });
    return {
      ...magnoliapageData,
      templateDefinition: { ...templateDefinition },
      productList: { ...finalApptusresponse },
      singleWarehouse,
      defaultWarehouse,
    };
  }

  private limitedStockProducts(productListWithCount) {
    productListWithCount.products.map((ctProduct) => {
      const limitedStock = ctProduct?.variants?.every((variant) =>
        variant?.attributes?.availability?.limited_stock === true);
      ctProduct.limited_stock = limitedStock;
      return {
        ...ctProduct,
        variants: limitedStock,
      };
    }).filter((product) => product.variants?.length);
  }

  /**
   *
   * @param facetsData Object
   * @param priceFormat Object
   * @returns
   */
  private facetData(facetsData, priceFormat) {
    const { ccy, currencyPlacement } = priceFormat;
    return facetsData.facetList?.map((facetsItems) => {
      const facetItem = facetsItems;
      if (facetsItems?.attribute === 'non_rep_sale_price') {
        facetItem.ccy = ccy;
        facetItem.currencyPlacement = currencyPlacement;
      }
      return facetItem;
    });
  }
}
