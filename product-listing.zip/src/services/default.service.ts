import { randomUUID } from 'crypto';
import { DefaultDao } from '../daos';
import {
  AnonymousFlowResponseDto, AnonymousFlowDto, CommonResponse,
} from '../dtos';

import { MarketInfo } from '../middlewares';

export interface DefaultServiceConfig {
  defaultDao: DefaultDao;
}

/**
 * Default Service class
 */
export class DefaultService {
  private readonly defaultDao: DefaultDao;

  constructor(conf: DefaultServiceConfig) {
    this.defaultDao = conf.defaultDao;
  }

  /** Create Anonymous session
   * @param market - MarketInfo
   */
  public async createAnonymousSession(
    market: MarketInfo,
  ): Promise<AnonymousFlowResponseDto> {
    const anonymousId = randomUUID();
    const output: AnonymousFlowDto = await this.defaultDao.createAnonymousSession(market, anonymousId);
    return {
      accessToken: output.access_token,
      expiresIn: output.expires_in,
      refreshToken: output.refresh_token,
      anonymousId,
    };
  }

  /**
   * Refresh token
   * @param market - MarketInfo
   * @param params - Params
   * @param magnolia- MagnoliaInfo,
   * @returns HeaderDefaultResponse
   * @throws ApiError 404 if Header Default data was not found
   */
  public async refreshToken(
    market: MarketInfo,
    params,
  ): Promise<CommonResponse> {
    return this.defaultDao.refreshToken(market, params);
  }
}
