import {
  query, body, oneOf, header,
} from 'express-validator';

export const validateProductSearch = [
  header('sessionkey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  header('customerkey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  query('page').optional().isInt().withMessage('common.integer'),
  query('rootCategory').notEmpty().optional().isString()
    .withMessage('common.string'),
  query('selectedCategory').optional().isString().withMessage('common.string'),
  query('searchPhrase').optional().isString().withMessage('common.string'),
  query('filter').optional().isString().withMessage('common.string'),
  query('maxProducts').optional().isInt().withMessage('common.integer'),
  query('maxFacets').optional().isInt().withMessage('common.integer'),
  query('sortBy').optional().isString().withMessage('common.string'),
  query('windowFirstRecommendations').optional().isInt().withMessage('common.integer'),
  query('windowLastRecommendations').optional().isInt().withMessage('common.integer'),
  query('depth').optional().isInt().withMessage('common.integer'),
];

export const validateCategory = [
  header('sessionkey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  header('customerkey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  query('page').optional().isInt().withMessage('common.integer'),
  query('rootCategory').notEmpty().isInt().withMessage('common.integer'),
  query('selectedCategory').optional().isInt().withMessage('common.integer'),
  query('filter').optional().isString().withMessage('common.string'),
  query('maxProducts').optional().isInt().withMessage('common.integer'),
  query('maxFacets').optional().isInt().withMessage('common.integer'),
  query('sortBy').optional().isString().withMessage('common.string'),
  query('windowFirstRecommendations').optional().isInt().withMessage('common.integer'),
  query('windowLastRecommendations').optional().isInt().withMessage('common.integer'),
  query('depth').optional().isInt().withMessage('common.integer'),
];

export const validateNotifications = [
  header('sessionkey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  header('customerkey').notEmpty().withMessage('common.notEmpty').isUUID()
    .withMessage('datatype.uuid'),
  oneOf([
    [
      body('productKey').notEmpty().withMessage('common.notEmpty'),
      body('variantKey').notEmpty().withMessage('common.notEmpty'),
    ],
    body('ticket').notEmpty().withMessage('common.notEmpty'),
  ]),
];
