import { body, header, oneOf } from 'express-validator';

export const validateAddToCart = [
  header('channelkey').optional().isString().withMessage('common.string')
    .withMessage('datatype.uuid'),
  body('cartId')
    .optional({ checkFalsy: true })
    .isUUID()
    .withMessage('datatype.uuid'),

  body('lineItems.sku')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('common.notEmpty'),

  body('lineItems.quantity')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('common.notEmpty'),

  body('lineItems.quantity')
    .if(body('lineItems.quantity').notEmpty())
    .isInt({ min: 1, max: 2000 })
    .withMessage('common.integer'),

  oneOf([
    body('customerId').notEmpty().withMessage('common.notEmpty').isUUID()
      .withMessage('datatype.uuid'),
    body('anonymousId').notEmpty().withMessage('common.notEmpty').isUUID()
      .withMessage('datatype.uuid'),
  ]),
];
