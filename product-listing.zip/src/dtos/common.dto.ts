export interface CommonResponse {
    [x: string]: any | unknown; // NOSONAR
}
export interface MagnoliaInfo {
  url: string;
  ispreview: boolean;
  marketPath: string;
}

export interface FreeTextBaseDto {
    '@name': string;
    '@path': string;
    '@id': string;
    '@nodeType': string;
    '@nodes': [string]
}

export interface TopBannerSectionDto {
  '@name': string;
  '@path': string;
  '@id': string;
  '@nodeType': string;
  'title': {
      '@name': string;
      '@path': string;
      '@id': string;
      '@nodeType': string;
      '@nodes': []
  },
  'subTitle': {
      '@name': string;
      '@path': string;
      '@id': string;
      '@nodeType': string;
      '@nodes': []
  },
  'link': {
      '@name': string;
      '@path':string;
      '@id': string;
      '@nodeType': string;
      'openBannerLinkInNewTab': string;
      '@nodes': []
  },
  '@nodes': [
    string
  ]
}
export interface FreeTextBaseSectionDto {
  freeTextBaseSection: FreeTextBaseDto;
  topBannerSection: TopBannerSectionDto;
  seoSettings: string;
}

export interface CtDto {
  [k: string]: string;
  }
