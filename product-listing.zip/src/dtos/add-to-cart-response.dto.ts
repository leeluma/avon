import { Address, LineItem } from '@commercetools/platform-sdk';
import { MarketInfo } from '../middlewares';

/**
 * @swagger
 * components:
 *   schemas:
 *     AddToCartResponseDto:
 *       additionalProperties: false
 *       properties:
 *         anonymousId:
 *           type: string
 *         customerId:
 *           type: string
 *         id:
 *           type: string
 *         lineItems:
 *           items: {}
 *           type: array
 *         shippingAddress:
 *           type: object
 *         totalAdjustmentAmount:
 *           type: number
 *         totalInvoicedAmount:
 *           type: string
 *         totalRetailPriceAmount:
 *           type: string
 *         totalTaxAmount:
 *           type: number
 *         version:
 *           type: number
 *       required:
 *         - id
 *         - version
 *         - totalRetailPriceAmount
 *         - totalTaxAmount
 *         - totalAdjustmentAmount
 *         - totalInvoicedAmount
 *         - customerId
 *         - anonymousId
 *         - lineItems
 *         - shippingAddress
 *       type: object
 */

export interface AddToCartResponseDto {
  id: string;
  version: number;
  totalRetailPriceAmount: string;
  totalTaxAmount: number;
  totalAdjustmentAmount: number;
  totalInvoicedAmount: string;
  customerId: string;
  anonymousId: string;
  lineItems: LineItem[];
  shippingAddress: Address;
}

export interface AddtoCartRequestDto {
  market: MarketInfo,
  customerId: string | undefined,
  anonymousId: string | undefined,
  cartId: string,
  sku: string,
  quantity: number,
  productKey: string,
  channelkey : string,
}
