import { Router } from 'express';
import { validateRequestSchema, apptusLogConfig, magnoliaUrlMiddleware } from '../middlewares';
import { ProductsController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import { validateCategory, validateProductSearch } from '../validators';

export interface ProductsRouterConfig {
  productsController: ProductsController;
  Router: typeof Router;
}

/**
 * `ProductsRouter` for all the routes related to `/products`
 */
export class ProductsRouter {
  private readonly productsController: ProductsController;

  private readonly Router: typeof Router;

  constructor(config: ProductsRouterConfig) {
    this.productsController = config.productsController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /{locale}-{country}/products/search:
     *   get:
     *     summary: Get Product search
     *     tags: [Products]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: query
     *         name: rootCategory
     *         schema:
     *            type: string
     *            default: 'root'
     *         required: true
     *       - in: query
     *         name: path
     *         schema:
     *            type: string
     *            default: Global,CEE
     *       - in: query
     *         name: selectedCategory
     *         schema:
     *            type: string
     *            default: 'root'
     *         required: false
     *       - in: query
     *         name: page
     *         schema:
     *            type: number
     *            default: 1
     *         required: true
     *       - in: query
     *         name: maxFacets
     *         schema:
     *            type: number
     *            default: 10
     *         required: false
     *       - in: query
     *         name: sortBy
     *         schema:
     *            type: string
     *            default: title asc
     *         required: false
     *       - in: query
     *         name: windowLastRecommendations
     *         schema:
     *            type: number
     *            default: 5
     *         required: false
     *       - in: query
     *         name: windowFirstRecommendations
     *         schema:
     *            type: number
     *            default: 1
     *         required: false
     *       - in: query
     *         name: searchPhase
     *         schema:
     *            type: string
     *            default: anew
     *         required: false
     *       - in: query
     *         name: depth
     *         schema:
     *            type: number
     *            default: 3
     *         required: false
     *       - in: query
     *         name: maxProducts
     *         schema:
     *            type: number
     *            default: 500
     *         required: false
     *       - in: query
     *         name: filter
     *         schema:
     *            type: string
     *            default: market:'AVONSHOP_RO-RO'
     *         required: false
     *       - in: header
     *         name: customerkey
     *         schema:
     *            type: string
     *            default: 'xxxx'
     *         required: false
     *       - in: header
     *         name: sessionkey
     *         schema:
     *            type: string
     *            default: 'xxxx'
     *         required: false
     *       - in: header
     *         name: channelKey
     *         schema:
     *            type: string
     *            default: DC-RO
     *         required: false
     *       - in: header
     *         name: isPreview
     *         schema:
     *            type: string
     *            default: true
     *         required: false
     *       - in: header
     *         name: isPage
     *         schema:
     *            type: string
     *            default: false
     *         required: false
     *     responses:
     *       200:
     *         description: Product details
     *       404:
     *         description: Product not found
     */

    router.get(
      '/search',
      validateProductSearch,
      validateRequestSchema,
      apptusLogConfig,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.productsController.search.bind(this.productsController),
      ),
    );

    /**
     * @swagger
     * /{locale}-{country}/products/category:
     *   get:
     *     summary: Get Product category
     *     tags: [Categories]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: query
     *         name: rootCategory
     *         schema:
     *            type: number
     *            default: 304
     *         required: true
     *       - in: query
     *         name: selectedCategory
     *         schema:
     *            type: number
     *            default: 304
     *         required: false
     *       - in: query
     *         name: path
     *         schema:
     *            type: string
     *            default: Global,CEE
     *       - in: query
     *         name: page
     *         schema:
     *            type: number
     *            default: 1
     *         required: true
     *       - in: query
     *         name: maxProducts
     *         schema:
     *            type: number
     *            default: 500
     *            required: false
     *       - in: query
     *         name: maxFacets
     *         schema:
     *            type: number
     *            default: 10
     *            required: false
     *       - in: query
     *         name: sortBy
     *         schema:
     *            type: string
     *            default: title asc
     *            required: false
     *       - in: query
     *         name: windowLastRecommendations
     *         schema:
     *            type: number
     *            default: 5
     *            required: false
     *       - in: query
     *         name: windowFirstRecommendations
     *         schema:
     *            type: number
     *            default: 1
     *            required: false
     *       - in: query
     *         name: maxProducts
     *         schema:
     *            type: number
     *            default: 500
     *            required: false
     *       - in: query
     *         name: depth
     *         schema:
     *            type: number
     *            default: 1
     *            required: false
     *       - in: query
     *         name: filter
     *         schema:
     *            type: string
     *            default: market:'AVONSHOP_RO-RO'
     *         required: false
     *       - in: header
     *         name: channelKey
     *         schema:
     *            type: string
     *            default: DC-RO
     *         required: false
     *       - in: header
     *         name: isPreview
     *         schema:
     *            type: string
     *            default: true
     *         required: false
     *       - in: header
     *         name: isPage
     *         schema:
     *            type: string
     *            default: false
     *         required: false
     *       - in: header
     *         name: customerkey
     *         schema:
     *            type: string
     *            default: 'xxxx'
     *         required: true
     *       - in: header
     *         name: sessionkey
     *         schema:
     *            type: string
     *            default: 'xxxx'
     *         required: true
     *     responses:
     *       200:
     *         description: Product details
     *       404:
     *         description: Product not found
     */

    router.get(
      '/category',
      validateCategory,
      validateRequestSchema,
      apptusLogConfig,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.productsController.category.bind(this.productsController),
      ),
    );

    return router;
  }
}
