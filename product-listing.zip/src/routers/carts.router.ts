import { Router } from 'express';
import { validateRequestSchema } from '../middlewares';
import { CartsController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import { validateAddToCart } from '../validators';

export interface CartsRouterConfig {
  cartsController: CartsController;
  Router: typeof Router;
}

/**
 * `CartsRouter` for all the routes related to `/carts`
 */
export class CartsRouter {
  private readonly cartsController: CartsController;

  private readonly Router: typeof Router;

  constructor(config: CartsRouterConfig) {
    this.cartsController = config.cartsController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /{language}-{market}/carts:
     *   post:
     *     summary: Add Line Item to cart
     *     tags: [Cart]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *           type: string
     *         required: true
     *         description: language
     *       - in: path
     *         name: market
     *         schema:
     *           type: string
     *         required: true
     *         description: Market
     *       - in: header
     *         name: channelkey
     *         schema:
     *            type: string
     *            default: 'xxxx'
     *         required: false
     *     responses:
     *       "400":
     *         description: default response
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *       "500":
     *         description: default response
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *       "404":
     *         description: default response
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *       "200":
     *         description: add to cart response
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/AddToCartResponseDto'
     */
    router.post(
      '/',
      validateAddToCart,
      validateRequestSchema,
      wrapJsonApiController(
        this.cartsController.addProductToCart.bind(this.cartsController),
      ),
    );

    return router;
  }
}
