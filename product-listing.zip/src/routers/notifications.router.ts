import { Router } from 'express';
import { validateRequestSchema } from '../middlewares';
import { NotificationsController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import { validateNotifications } from '../validators';

export interface NotificationsRouterConfig {
  notificationsController: NotificationsController;
  Router: typeof Router;
}

/**
 * `NotificationsRouter` for all the routes related to `/notifications`
 */
export class NotificationsRouter {
  private readonly notificationsController: NotificationsController;

  private readonly Router: typeof Router;

  constructor(config: NotificationsRouterConfig) {
    this.notificationsController = config.notificationsController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /{locale}-{country}/notifications/product:
     *   get:
     *     summary: Add apptus notification for esale and non-esale products
     *     tags: [Notifications]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: header
     *         name: sessionkey
     *         schema:
     *            type: string
     *            default: uuid
     *         required: true
     *       - in: header
     *         name: customerKey
     *         schema:
     *            type: string
     *            default: uuid
     *         required: true
     *     requestBody:
     *      description: if token is available then other are optional else required.
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/NotificationRequest'
     *     responses:
     *       200:
     *         description: true
     *       400:
     *         description: Bad request
     */

    router.post(
      '/product',
      validateNotifications,
      validateRequestSchema,
      wrapJsonApiController(
        this.notificationsController.product.bind(this.notificationsController),
      ),
    );

    /**
     * @swagger
     * /{locale}-{country}/notifications/adding-to-cart:
     *   get:
     *     summary: Add apptus notification for cart esale and cart non-esale products
     *     tags: [Notifications]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: header
     *         name: sessionkey
     *         schema:
     *            type: string
     *            default: uuid
     *         required: true
     *       - in: header
     *         name: customerKey
     *         schema:
     *            type: string
     *            default: uuid
     *         required: true
     *     requestBody:
     *      description: if token is available then other are optional else required.
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/NotificationRequest'
     *     responses:
     *       200:
     *         description: true
     *       400:
     *         description: Bad request
     */

    router.post(
      '/adding-to-cart',
      validateNotifications,
      validateRequestSchema,
      wrapJsonApiController(
        this.notificationsController.addToCart.bind(this.notificationsController),
      ),
    );

    return router;
  }
}
