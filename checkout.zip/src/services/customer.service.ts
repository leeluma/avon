import {
  Address, AddressDraft, Customer, CustomerSignin, CustomerUpdate, CustomerUpdateAction,
} from '@commercetools/platform-sdk';
import { randomUUID } from 'crypto';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { AddressDao, CustomerDao, OrderDao } from '../daos';
import {
  addressCustomTypeKey, ApiError, AwsEventBridgeClient, AwsEventBridgeSource,
} from '../lib';
import { AddressMapper, CustomerMapper } from '../mappers';
import { MarketInfo } from '../middlewares';
import { DEFAULT_QUANTITY } from '../common/constants';

import {
  CustomerForgotPassword, AddressResponseDto,
  AddressCollectionResponseDto,
  CustomerResponseDto,
  CustomerRegistrationRequestDto,
  CustomCustomerDraft,
  LoginCustomerDto,
  CustomerLoginResponseDto,
} from '../dtos';

export interface CustomerServiceConfig {
  customerDao: CustomerDao;
  addressDao: AddressDao;
  orderDao: OrderDao;
  eventBridgeClient: AwsEventBridgeClient;
  addressMapper: AddressMapper;
  passwordResetEventBusName: string;
  customerMapper: CustomerMapper;
}

/**
 * Customer Service class
 */
export class CustomerService {
  private readonly customerDao: CustomerDao;

  private readonly addressDao: AddressDao;

  private readonly orderDao: OrderDao;

  private readonly eventBridgeClient: AwsEventBridgeClient;

  private readonly addressMapper: AddressMapper;

  private readonly customerMapper: CustomerMapper;

  private readonly passwordResetEventBusName: string;

  constructor(configuration: CustomerServiceConfig) {
    this.customerDao = configuration.customerDao;
    this.addressDao = configuration.addressDao;
    this.addressMapper = configuration.addressMapper;
    this.eventBridgeClient = configuration.eventBridgeClient;
    this.passwordResetEventBusName = configuration.passwordResetEventBusName;
    this.customerMapper = configuration.customerMapper;
    this.orderDao = configuration.orderDao;
  }

  /** Forgot a Customer's password by email
   * @param market - MarketInfo
   * @param email
   * @param url
   */
  public async forgotCustomersPassword(
    market: MarketInfo,
    email: string,
    url: string,
  ): Promise<void> {
    const forgotPasswordResult: CustomerForgotPassword = await this.customerDao.forgotCustomersPassword(market, email);

    if (!forgotPasswordResult) {
      throw new ApiError(HttpStatusCodes.UNAUTHORIZED, 'Failed to reset password. Email Id does not exist');
    }

    const { value, expiresAt, customerId } = forgotPasswordResult;
    const customerResult = await this.customerDao.findGraphQLOne(market, customerId);
    const { lastName, firstName } = customerResult;

    const messageEvent = {
      customerName: `${firstName} ${lastName}`,
      email,
      url,
      queryParam: {
        token: value,
      },
      expiryDate: expiresAt,
    };

    await this.eventBridgeClient.putEvent(
      this.passwordResetEventBusName,
      AwsEventBridgeSource.passwordResetQueue,
      messageEvent,
    );
  }

  /**
   * Get Addresses By Customer Token implementation
   * @param market - MarketInfo
   * @param authHeader - Authorization header
   * @returns Address Response
   */
  public async getDefaultAddress(
    market: MarketInfo,
    authHeader: string,
  ): Promise<AddressResponseDto | undefined> {
    const customer = await this.customerDao.getCustomerDetailsGraphQL(market, authHeader);
    const { defaultShippingAddressId } = customer;
    const defaultAddress = customer.addresses.find((r) => r.id === defaultShippingAddressId);
    if (defaultAddress) {
      return this.addressMapper.mapGraphQLAddressResponse(defaultAddress, customer);
    }
    return undefined;
  }

  /**
   * Get Customer details by Customer Token implementation
   * @param market - MarketInfo
   * @param authHeader - Customer Token
   * @returns Customer Response
   */
  public async getCustomerDetailsByToken(
    market: MarketInfo,
    authHeader: string,
  ): Promise<CustomerResponseDto | undefined> {
    const customer = await this.customerDao.getCustomerDetailsGraphQL(market, authHeader, false);
    return this.addressMapper.mapCustomerResponse(customer);
  }

  /**
   *
   * post address draft to Commerce Tool.
   * Now mapped data return.
   * @param market - MarketInfo
   * @param customer - Customer
   * @param cartAddress - AddressResponseDto
   * @returns Address Response
   */
  public async addAddress(
    market: MarketInfo,
    customer: Customer,
    cartAddress: AddressResponseDto,
  ): Promise<AddressCollectionResponseDto> {
    const { version } = customer;

    const addressKey = randomUUID();
    let { recipientName, firstName, lastName } = cartAddress;
    firstName = firstName ?? customer.firstName;
    lastName = lastName ?? customer.lastName;
    recipientName = recipientName ?? `${firstName} ${lastName}`.trim();

    const address = {
      custom: {
        type: {
          typeId: 'type',
          key: addressCustomTypeKey,
        },
        fields: {
          RecipientName: recipientName,
          Address1: cartAddress.address1,
          Address2: cartAddress.address2,
          Address3: cartAddress.address3,
          Address4: cartAddress.address4,
          county: cartAddress.county,
          Latitude: cartAddress.latitude,
          Longitude: cartAddress.longitude,
        },
      },
      country: cartAddress.country,
      city: cartAddress.city,
      region: cartAddress.region,
      postalCode: cartAddress.zip,
      state: cartAddress.state,
      phone: cartAddress.phoneNumber,
      firstName,
      lastName,
      key: addressKey,
    };
    const actions: CustomerUpdateAction[] = [
      {
        action: 'addAddress',
        address,
      },
      {
        action: 'addShippingAddressId',
        addressKey,
      },
    ];

    if (cartAddress.isBillingAddress) {
      actions.push({
        action: 'addBillingAddressId',
        addressKey,
      });
    }

    if (!customer.addresses.length) {
      actions.push(
        {
          action: 'setDefaultShippingAddress',
          addressKey,
        },
        {
          action: 'setDefaultBillingAddress',
          addressKey,
        },
      );
    }

    const payload: CustomerUpdate = { version, actions };

    const updatedCustomer = await this.customerDao.updateCustomer(market, customer.id, payload);

    return this.addressMapper.mapAddressCollectionResponse(updatedCustomer, addressKey);
  }

  /**
   * post address draft to Commerce Tool.
   * Now mapped data return.
   * @param market - MarketInfo
   * @param customer - Customer Object
   * @param addressId - Address Id
   * @param cartAddress - AddressRequestDto
   * @returns Address Response
   */
  public async updateAddress(
    market: MarketInfo,
    customer: Customer,
    addressId: string,
    cartAddress: AddressResponseDto,
  ): Promise<AddressResponseDto[] | undefined> {
    const currentAddress = customer.addresses.find((item: Address) => item.id === addressId);
    if (!currentAddress) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, `Address id "${addressId}" does not exist`);
    }
    const { version } = customer;
    const addressKey = currentAddress.key || randomUUID();

    const address = {
      custom: {
        type: {
          key: addressCustomTypeKey,
          typeId: 'type',
        },
        fields: {
          RecipientName: cartAddress.recipientName,
          Address1: cartAddress.address1,
          Address2: cartAddress.address2,
          Address3: cartAddress.address3,
          Address4: cartAddress.address4,
          county: cartAddress.county,
          Latitude: cartAddress.latitude,
          Longitude: cartAddress.longitude,
        },
      },
      country: cartAddress.country,
      city: cartAddress.city,
      region: cartAddress.region,
      postalCode: cartAddress.zip,
      state: cartAddress.state ?? '',
      phone: cartAddress.phoneNumber ?? '',
      key: addressKey,
      id: addressId,
    };
    const actions: CustomerUpdateAction[] = [{
      action: 'changeAddress',
      addressId: currentAddress.id,
      address,
    }, { action: 'addShippingAddressId', addressKey }];

    const payload: CustomerUpdate = { version, actions };

    const updatedCustomer = await this.customerDao.updateCustomer(market, customer.id, payload);
    return updatedCustomer.addresses.map((addressDto) => {
      return this.addressMapper.mapAddressResponse(addressDto, updatedCustomer);
    });
  }

  /**
   * Get List of Delivery Addresses By Customer Token implementation
   * @param market - MarketInfo
   * @param authHeader - string Customer Token
   * @returns list of Delivery Addresses Response
   */
  public async getDeliveryAddressList(
    market: MarketInfo,
    authHeader: string,
  ): Promise<AddressResponseDto[] | undefined> {
    const customer = await this.customerDao.getCustomerDetailsGraphQL(market, authHeader);
    const { shippingAddressIds } = customer;
    if (customer && Array.isArray(shippingAddressIds) && !shippingAddressIds.length) {
      throw new ApiError(
        HttpStatusCodes.NOT_FOUND,
        i18next.t('error.deliveryAddressNotFound'),
      );
    }
    const addresses = customer.addresses
      .filter((address) => shippingAddressIds?.some((shippingAddressId) => shippingAddressId === address.id));
    if (addresses.length) {
      return addresses.map((address) => {
        return this.addressMapper.mapGraphQLAddressResponse(address, customer);
      });
    }
    return undefined;
  }

  /**
   * Creates | Register Customer
   * @param market - MarketInfo
   * @param customer - CustomerRequestDto
   * @returns Default Customer response i.e. minimal information required by Frontend
   */
  public async registration(
    market: MarketInfo,
    customer: CustomerRegistrationRequestDto,
    authHeader: string,
  ): Promise<CustomerLoginResponseDto> {
    const { orderId } = customer;
    const orderDetails = await this.orderDao.fetchOrder(authHeader, market, orderId);
    if (!orderDetails) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, `Order Details not found for ${orderId}`);
    }
    const {
      shippingAddress, customerEmail, customerId,
    } = orderDetails;
    if (customerId) {
      throw new ApiError(
        HttpStatusCodes.UNAUTHORIZED,
        `Order already associated with existing ${customerId}`,
      );
    }

    const fields = this.addressMapper.mapToFields(shippingAddress.custom);

    const addressDraft: AddressDraft = {
      custom: {
        type: {
          typeId: 'type',
          key: 'address-type',
        },
        fields,
      },
      country: shippingAddress.country,
      city: shippingAddress.city,
      postalCode: shippingAddress.postalCode,
      phone: shippingAddress.phone,
      firstName: shippingAddress.firstName,
      lastName: shippingAddress.lastName,
      region: shippingAddress.region,
      state: shippingAddress.state,
    };
    const currentDate = Math.floor(new Date().getTime() / DEFAULT_QUANTITY.BASE_THOUSAND);
    const email = customerEmail!.split('@')[0].replace(/\./g, '');

    const customerDraft: CustomCustomerDraft = {
      key: `${email}-${currentDate}`,
      email: customerEmail!,
      isEmailVerified: false,
      firstName: shippingAddress.firstName,
      lastName: shippingAddress.lastName,
      password: customer.password,
      addresses: [addressDraft],
      defaultShippingAddress: 0,
      defaultBillingAddress: 0,
    };
    const customerDto = await this.customerDao.create(market, customerDraft, authHeader);
    const customerLoginDraftReqDto: CustomerSignin = {
      email: customerEmail!,
      password: customer.password,
    };
    const output: LoginCustomerDto = await this.customerDao.login(market, customerLoginDraftReqDto);
    return {
      accessToken: output.access_token,
      expiresIn: output.expires_in,
      tokenType: output.token_type,
      refreshToken: output.refresh_token,
      customerId: customerDto.id,
    };
  }
}
