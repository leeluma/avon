import {
  CustomerSignin,
} from '@commercetools/platform-sdk';
import i18next from 'i18next';
import HttpStatusCodes from 'http-status-codes';
import {
  CommonResponse,
  CustomerLoginResponseDto,
  LoginCustomerDto,
  LoginDto,
  PickupPointRequestDto,
  PickupPointResponseDto,
  UpdateCartRequestDto,
} from '../dtos';
import {
  CustomerDao, CartDao, AddressDao, DefaultDao,
} from '../daos';

import { MarketInfo } from '../middlewares';
import { REGEX } from '../common/constants';
import { addressCustomTypeKey, ApiError } from '../lib';
import { config } from '../config';

export interface DefaultServiceConfig {
  customerDao: CustomerDao;
  cartDao: CartDao;
  addressDao: AddressDao;
  defaultDao: DefaultDao;
}

enum CART_ACTIONS {
  setCustomerId = 'setCustomerId',
  setCustomerEmail = 'setCustomerEmail',
  setShippingAddress = 'setShippingAddress',
}

/**
 * Default Service class
 */
export class DefaultService {
  private readonly customerDao: CustomerDao;

  private readonly cartDao: CartDao;

  private readonly addressDao: AddressDao;

  private readonly defaultDao: DefaultDao;

  constructor(serviceConfig: DefaultServiceConfig) {
    this.customerDao = serviceConfig.customerDao;
    this.cartDao = serviceConfig.cartDao;
    this.addressDao = serviceConfig.addressDao;
    this.defaultDao = serviceConfig.defaultDao;
  }

  /**
   * Use to retrive user's token data based on users credentials.
   * @param market
   * @param loginReqDto
   * @returns
   */
  public async login(
    market: MarketInfo,
    loginReqDto: LoginDto,
  ): Promise<CustomerLoginResponseDto> {
    const { email, password, cartId } = loginReqDto;

    if (!this.validateEmail(email, market.country)) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.emailShouldBeValid'));
    }

    const customerLoginDraftReqDto: CustomerSignin = {
      email,
      password,
    };
    const output: LoginCustomerDto = await this.customerDao.login(market, customerLoginDraftReqDto);
    const customerId = output.scope.split(' ')[1].split(':')[1];

    const cartResponse = await this.cartDao.getCartById(market.country, loginReqDto.cartId);

    if (cartResponse === undefined) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartNotFound'));
    } else if (cartResponse.customerId !== undefined && cartResponse.customerId !== customerId) {
      throw new ApiError(HttpStatusCodes.CONFLICT, i18next.t('error.cartIdConflict'));
    } else {
      const { version } = cartResponse;
      await this.customerDao.setCustomerIdToCart(market, cartId, version, customerId);
    }

    return {
      accessToken: output.access_token,
      expiresIn: output.expires_in,
      tokenType: output.token_type,
      refreshToken: output.refresh_token,
      customerId,
      cartId,
    };
  }

  /**
   * Refresh token
   * @param market - MarketInfo
   * @param params - Params
   * @param magnolia- MagnoliaInfo,
   * @returns HeaderDefaultResponse
   * @throws ApiError 404 if Header Default data was not found
   */
  public async refreshToken(
    market: MarketInfo,
    params,
  ): Promise<CommonResponse> {
    return this.defaultDao.refreshToken(market, params);
  }

  /**
   * Use to retrive user's token data based on users credentials.
   * @param market
   * @param loginReqDto
   * @returns
   */
  public async updateMyCartById(
    market: MarketInfo,
    updateCartRequestDto: UpdateCartRequestDto,
    authToken: string,
  ): Promise<void> {
    const {
      email, firstName, lastName, cartId,
    } = updateCartRequestDto;

    if (!authToken) {
      throw new ApiError(HttpStatusCodes.UNAUTHORIZED, i18next.t('validationError.unauthorized'));
    }

    if (!this.validateEmail(email, market.country)) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.emailShouldBeValid'));
    }

    if (!firstName) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.firstNameIsMandatory'));
    }

    const nameRegex = REGEX[market.country].name;
    if (!String(firstName).match(nameRegex)) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.firstNameShouldBeValid'));
    }

    if (!lastName) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.lastNameIsMandatory'));
    }

    if (!String(lastName).match(nameRegex)) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.lastNameShouldBeValid'));
    }
    const cartResponse = await this.cartDao.getCartById(market.country, cartId);

    if (cartResponse === undefined) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartNotFound'));
    }

    const { version, anonymousId } = cartResponse;
    if (anonymousId === undefined) {
      throw new ApiError(HttpStatusCodes.CONFLICT, i18next.t('error.cartIdConflict'));
    }

    const updateCartActionDraft = {
      version,
      actions: [{
        action: CART_ACTIONS.setCustomerEmail,
        email,
      }, {
        action: CART_ACTIONS.setShippingAddress,
        address: {
          firstName,
          lastName,
          country: market.country,
          custom: {
            type: {
              typeId: 'type',
              key: addressCustomTypeKey,
            },
            fields: {
              RecipientName: `${firstName} ${lastName}`,
            },
          },
        },
      }],
    };

    await this.cartDao.updateMyCartById(market.country, updateCartActionDraft, authToken, cartId);
  }

  public validateEmail(email, country) {
    if (!email) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.emailIsMandatory'));
    }
    const emailRegex = REGEX[country].email;
    return String(email)
      .match(
        emailRegex,
      );
  }

  /**
   * Get Pickup Detail of addresses by providing latitude and longitude.
   * @param market - MarketInfo
   * @param longitude - Longitude required for pickup of addresses
   * @param latitude - Latitude required for pickup of addresses
   * @param distance - Distance
   * @param distanceUnit - Unit of distance
   * @returns PickupPointResponseDto
   */
  public async getPickupDetail(
    market: MarketInfo,
    pickupPointRequestDto: PickupPointRequestDto,
  ): Promise<PickupPointResponseDto> {
    const { pickupPointUrl, pickupPointKey } = config;
    const url = `${pickupPointUrl}`
      .replace('{{market}}', market.localeAndCountry.toLocaleLowerCase());
    const params = {
      longitude: pickupPointRequestDto.longitude,
      latitude: pickupPointRequestDto.latitude,
      distance: pickupPointRequestDto.distance ?? config.defaultDistance,
      unit: pickupPointRequestDto.distanceUnit ?? config.defaultDistanceUnit,
    };
    const headers = {
      'x-api-key': pickupPointKey,
    };
    return this.addressDao.getPickupDetail(url, headers, params);
  }
}
