import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { randomUUID } from 'crypto';
import { CartUpdate, Customer, Product } from '@commercetools/platform-sdk';
import {
  CartDao, AddressDao, MagnoliaDao, OrderDao,
} from '../daos';
import { config } from '../config';
import {
  MagnoliaInfo, ShippingMethodsResponseDto,
  CartDto, CartResponse, CartShippingMethodDto, AddressRequestDto, CartPaymentInfoDto, PAYMENT_STATE_KEYS,
} from '../dtos';

import { ShippingMethodMapper, CartMapper, AddressMapper } from '../mappers';
import { ApiError, addressCustomTypeKey, MARKET } from '../lib';
import { MarketInfo } from '../middlewares';
import { getCartProductId, mapAddressFields, mapShippingAddress } from '../lib/cart-order';
import { DEFAULT_DELIVERY_TYPE } from '../common/constants';

interface CartServiceConfig {
  shippingMethodMapper: ShippingMethodMapper;
  cartMapper: CartMapper;
  cartDao: CartDao;
  magnoliaDao: MagnoliaDao;
  addressDao: AddressDao;
  addressMapper: AddressMapper;
  orderDao: OrderDao;
}

/**
 * `CartService` for business logic `CartService`
 */
export class CartService {
  private readonly cartDao: CartDao;

  private readonly addressDao: AddressDao;

  private readonly shippingMethodMapper: ShippingMethodMapper;

  private readonly cartMapper: CartMapper;

  private readonly cartIdNotFound = 'error.cartIdNotFound';

  private readonly magnoliaDao: MagnoliaDao;

  private readonly addressMapper: AddressMapper;

  private readonly orderDao: OrderDao;

  /**
   * Constructor for `CartService` class
   * @param configuration injects dependencies into the object
   */
  constructor(configuration: CartServiceConfig) {
    this.shippingMethodMapper = configuration.shippingMethodMapper;
    this.cartMapper = configuration.cartMapper;
    this.cartDao = configuration.cartDao;
    this.addressDao = configuration.addressDao;
    this.addressMapper = configuration.addressMapper;
    this.magnoliaDao = configuration.magnoliaDao;
    this.orderDao = configuration.orderDao;
  }

  /** Shipping Method Get by cart ID implementation * @returns shipping method Response @param market - MarketInfo */
  public getShippingMethods = async (market: MarketInfo, deliveryType: string):
    Promise<ShippingMethodsResponseDto> => {
    const shippingKind = (deliveryType === 'Pickup') ? 'Parcelshop' : DEFAULT_DELIVERY_TYPE;
    const shippingMethod = await this.cartDao.getShippingMethods(market, shippingKind);
    if (shippingMethod?.data?.shippingMethods === null) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartShippingMethodsNotFound'));
    }
    return this.shippingMethodMapper.shippingMethodCartToDto(shippingMethod?.data?.shippingMethods?.results);
  };

  /** Add cart shipping method implementation * @param market - MarketInfo * @param cartId - String
   * @param shippingMethodId - String * @param authHeader - String* @returns Cart Response */
  public addShippingMethod = async (
    market: MarketInfo,
    cartId: string,
    shippingMethodId: string,
    authHeader: string,
  ): Promise<CartShippingMethodDto> => {
    const { country } = market;
    const cartPaymentInfo = await this.checkCartPaymentInfo(market, cartId, authHeader);
    const { isPaymentInitiated } = cartPaymentInfo;
    let { cart } = cartPaymentInfo;
    if (isPaymentInitiated === false && cart === undefined) {
      cart = await this.cartDao.getCartById(country, cartId);
    }
    if (cart === undefined) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t(this.cartIdNotFound, { cartId }));
    }
    if (!cart.shippingAddress) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('error.shippingAddressNotSet', { cartId }));
    }
    const [updatedCart, priceFormatSettings] = await Promise.all([
      this.cartDao.addShippingMethod(country, cart, shippingMethodId, authHeader),
      this.magnoliaDao.getPriceFormatSettings(market, config.magnoliaBasePath as string),
    ]);
    return this.cartMapper.createCartResponseForShippingMethodAdded(updatedCart, priceFormatSettings);
  };

  /** set cart shipping address implementation * @param market - MarketInfo
   * @param cartId - String * @param addressRequestBody - AddressRequest * @param authToken - AddressRequest * @returns Cart Response */
  public setShippingAddress = async (
    market: MarketInfo,
    magnolia: MagnoliaInfo,
    cartId: string,
    authToken: string,
    customer: Customer,
    addressRequestDto: AddressRequestDto,
  ): Promise<CartDto> => {
    const { country } = market;
    const { firstName, lastName } = addressRequestDto;
    let { recipientName } = addressRequestDto;
    const addressKey = randomUUID();
    if (firstName && lastName) {
      recipientName = recipientName ?? `${firstName} ${lastName}`.trim();
    }
    if (customer?.firstName && customer?.lastName) {
      recipientName = recipientName ?? `${customer.firstName} ${customer.lastName}`.trim();
    }
    const globalSettingsForSetShipping = await this.magnoliaDao.getGlobalSettings(market, magnolia.url);
    const cartPaymentInfoForSetShipping = await this.checkCartPaymentInfo(market, cartId, authToken);
    const { isPaymentInitiated } = cartPaymentInfoForSetShipping;
    let { cart } = cartPaymentInfoForSetShipping;
    if (isPaymentInitiated === false && cart === undefined) {
      cart = await this.cartDao.getCartById(country, cartId);
    }
    if (cart === undefined) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t(this.cartIdNotFound, { cartId }));
    }
    const address = {
      custom: {
        type: {
          typeId: 'type',
          key: addressCustomTypeKey,
        },
        fields: mapAddressFields(recipientName, addressRequestDto),
      },
      ...mapShippingAddress(addressRequestDto, market.country),
      key: addressKey,
    };
    const shippingAddressDraft: CartUpdate = {
      version: cart.version,
      actions: [{
        action: 'setShippingAddress',
        address,
      },
      {
        action: 'setBillingAddress',
        address,
      },
      {
        action: 'setCustomType',
        type: { typeId: 'type', key: 'cart-type' },
        fields: {
          shippingAddressType: addressRequestDto.addressType,
        },
      }],
    };
    const updatedCartWithShippingAddress = await this.cartDao
      .setShippingAddress(country, cart, shippingAddressDraft, authToken);
    return this.cartMapper.cartToDto(updatedCartWithShippingAddress, market, globalSettingsForSetShipping.priceFormat);
  };

  /** * set cart shipping address implementation * @param market - MarketInfo  * @param cartId - String  * @param customerAddressId - String
   * @param customer - Customer Object * @param authToken - AddressRequest   * @returns Cart Response */
  public setShippingAddressFromCustomerId = async (
    market: MarketInfo,
    magnolia: MagnoliaInfo,
    cartId: string,
    authToken: string,
    customer: Customer,
    addressRequestDto: AddressRequestDto,
  ): Promise<CartDto> => {
    const { country } = market;
    const addressKey = randomUUID();
    const { addressId, addressType, recipientName } = addressRequestDto;
    const shippingAddressDetails = customer.addresses.find((item) => item.id === addressId);
    if (shippingAddressDetails === undefined) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.addressNotFound'));// NOSONAR
    }
    const globalSettings = await this.magnoliaDao.getGlobalSettings(market, magnolia.url);
    const cartPaymentInfo = await this.checkCartPaymentInfo(market, cartId, authToken);
    const { isPaymentInitiated } = cartPaymentInfo;
    let { cart } = cartPaymentInfo;
    if (isPaymentInitiated === false && cart === undefined) {
      cart = await this.cartDao.getCartById(country, cartId);
    }
    if (cart === undefined) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t(this.cartIdNotFound, { cartId }));
    }
    const address = this.addressMapper.createAddressDraftFromCustomerAddressId(
      market,
      addressRequestDto,
      shippingAddressDetails,
      addressKey,
      recipientName,
    );
    const shippingAddressDraft: CartUpdate = {
      version: cart.version,
      actions: [{
        action: 'setShippingAddress',
        address,
      },
      {
        action: 'setBillingAddress',
        address,
      },
      {
        action: 'setCustomType',
        type: { typeId: 'type', key: 'cart-type' },
        fields: { shippingAddressType: addressType },
      }],
    };
    const updatedCartWithShippingAddress = await this.cartDao
      .setShippingAddress(country, cart, shippingAddressDraft, authToken);
    return this.cartMapper.cartToDto(updatedCartWithShippingAddress, market, globalSettings.priceFormat);
  };

  /** * set cart shipping address implementation * @param market - MarketInfo * @param cartId - String * @param customerAddressId - String
   * @param authToken - AddressRequest   * @returns Cart Response   */
  public setShippingAddressFromFinder = async (
    market: MarketInfo,
    magnolia: MagnoliaInfo,
    cartId: string,
    authToken: string,
    customer: Customer,
    addressRequestDto: AddressRequestDto,
  ):
    Promise<CartDto> => {
    const { country } = market;
    const addressKey = randomUUID();
    const { addressFinderId, addressType } = addressRequestDto;
    const { addressFinderHost, addressFinderDetail } = config;
    const url = `${addressFinderHost}${addressFinderDetail}`
      .replace(MARKET, market.localeAndCountry);
    const addressDetail = await this.addressDao.addressDetail(url, addressFinderId!);
    if (addressDetail === undefined) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.addressNotFound')); // NOSONAR
    }
    addressDetail.firstName = addressRequestDto?.firstName;
    addressDetail.lastName = addressRequestDto?.lastName;
    if (customer) {
      addressDetail.firstName = customer?.firstName;
      addressDetail.lastName = customer?.lastName;
    }
    addressDetail.recipientName = addressRequestDto.recipientName
      ?? `${addressDetail.firstName} ${addressDetail.lastName}`.trim();
    addressDetail.phoneNumber = addressRequestDto.phoneNumber;
    const globalSettingsForAddressFinder = await this.magnoliaDao.getGlobalSettings(market, magnolia.url);
    const cartPaymentInfoorAddressFinder = await this.checkCartPaymentInfo(market, cartId, authToken);
    const { isPaymentInitiated } = cartPaymentInfoorAddressFinder;
    let { cart } = cartPaymentInfoorAddressFinder;
    if (isPaymentInitiated === false && cart === undefined) {
      cart = await this.cartDao.getCartById(country, cartId);
    }
    if (cart === undefined) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t(this.cartIdNotFound, { cartId }));
    }
    const address = this.addressMapper
      .createAddressDraftFromDetails(
        market,
        addressDetail,
        addressKey,
      );
    const shippingAddressDraft: CartUpdate = {
      version: cart.version,
      actions: [{
        action: 'setShippingAddress',
        address,
      },
      {
        action: 'setBillingAddress',
        address,
      },
      {
        action: 'setCustomType',
        type: { typeId: 'type', key: 'cart-type' },
        fields: { shippingAddressType: addressType },
      }],
    };
    const updatedCartWithShippingAddress = await this.cartDao
      .setShippingAddress(country, cart, shippingAddressDraft, authToken);
    return this.cartMapper.cartToDto(updatedCartWithShippingAddress, market, globalSettingsForAddressFinder.priceFormat);
  };

  /** Get Cart * @param market - MarketInfo * @param cartId - cartId * @param authHeader - authHeader * @returns List of cart Response */
  public async getCartById(market: MarketInfo, magnolia: MagnoliaInfo, cartId: string, authHeader: string):
   Promise<CartResponse | undefined> {
    // First call- get cart version, Second call- recalculates cart
    const [globalSettings, cart] = await Promise.all([
      this.magnoliaDao.getGlobalSettings(market, magnolia.url),
      this.cartDao.getCartPaymentInfo(market, cartId, authHeader),
    ]);
    const recalculatedCart = await this.cartDao.recalculateCart(market.country, cart);
    const productsIds = getCartProductId(recalculatedCart.lineItems);
    const [order, productData] = await Promise.all(
      [this.cartDao.getCartByIdGraphql(market, cartId, authHeader),
        this.orderDao.fetchProductsDetail(market, productsIds)],
    );
    if (!order) {
      return undefined;
    }
    return this.cartMapper.createCartResponse(order, globalSettings.priceFormat, productData as Product[]);
  }

  /** Check cart payment info and status * if payment initiated then Replicate the cart and return new cart data
   * @param market - MarketInfo  * @param cartId - cartId  * @param authHeader - authHeader * @returns List of cart Response  */
  public async checkCartPaymentInfo(market: MarketInfo, cartId: string, authHeader: string):
   Promise<CartPaymentInfoDto> {
    const { country } = market;
    const cart = await this.cartDao.getCartPaymentInfo(market, cartId, authHeader);
    if (!cart) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t(this.cartIdNotFound, { cartId }));
    }
    if (!cart.paymentInfo || cart.paymentInfo.payments.length === 0) {
      return { isPaymentInitiated: false };
    }
    const { payments } = cart.paymentInfo;
    const isPaymentPendingOrInitiated = payments.every((payment) => payment?.paymentStatus.state !== null
      && (payment?.paymentStatus.state.key === PAYMENT_STATE_KEYS.initial
        || payment?.paymentStatus.state.key === PAYMENT_STATE_KEYS.pending));
    if (isPaymentPendingOrInitiated) {
      const replicatedCart = await this.cartDao.replicateCartById(country, cartId, authHeader);
      return { isPaymentInitiated: true, cart: replicatedCart };
    }
    return { isPaymentInitiated: false };
  }
}
