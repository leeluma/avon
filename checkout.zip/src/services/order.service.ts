import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { MarketInfo } from '../middlewares';
import { OrderDao, MagnoliaDao } from '../daos';
import { getCartProductId } from '../lib/cart-order';
import { OrderMapper } from '../mappers';
import { OrderDto } from '../dtos/order.dto';
import { PriceFormat } from '../dtos';
import { ApiError } from '../lib';

export interface OrderServiceConfig {
  orderDao: OrderDao;
  magnoliaDao: MagnoliaDao;
  orderMapper: OrderMapper;
}

/**
 * Address Service class
 */
export class OrderService {
  private readonly orderDao: OrderDao;

  private readonly magnoliaDao: MagnoliaDao;

  private readonly orderMapper: OrderMapper;

  private readonly orderIdNotFound = 'error.orderIdNotFound';

  constructor(conf: OrderServiceConfig) {
    this.orderDao = conf.orderDao;
    this.magnoliaDao = conf.magnoliaDao;
    this.orderMapper = conf.orderMapper;
  }

  /**
   * Get API for Order details.
   * @param authHeader
   * @param market MarketInfo
   * @param orderId order id
   * @param magnolia MagnoliaInfo
   * @returns
   */
  public async orderDetails(
    authHeader: string,
    market: MarketInfo,
    orderId: string,
    priceFormat: PriceFormat,
  ): Promise<OrderDto> {
    const result = await this.orderDao.fetchOrder(authHeader, market, orderId);
    if (!result) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t(this.orderIdNotFound, { orderId }));
    }
    const productsIds = getCartProductId(result.lineItems);
    const productData = await this.orderDao.fetchProductsDetail(market, productsIds);
    // Map graphQL response as per our requirement
    return this.orderMapper.mapOrderDetails(result, market, priceFormat, productData);
  }
}
