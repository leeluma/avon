import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import {
  Cart,
  CartUpdate, CustomerUpdate, Money, MyPayment, Payment, PaymentDraft, PaymentUpdate, State,
} from '@commercetools/platform-sdk';
import {
  ApiError, AwsEventBridgeClient, AwsEventBridgeSource, logError, logger,
} from '../lib';
import { MarketInfo } from '../middlewares';
import {
  PAYMENT_TYPE, PaymentInitResponseDto, PaymentStatusResponseDto,
  ApptusRequestDto, PAYMENT_STATE_KEYS, MagnoliaInfo,
  E_PAYMENT_STATUS, CtCartPaymentInfo, TRANSACTION_STATE,
} from '../dtos';
import {
  CartDao, CustomerDao, NotificationsDao, OrderDao, PaymentDao, MagnoliaDao,
} from '../daos';

interface PaymentServiceConfig {
  paymentDao: PaymentDao;
  cartDao: CartDao;
  orderDao: OrderDao;
  returnUrl: string;
  eventBridgeClient: AwsEventBridgeClient;
  marketingEmailConsentEventBusName: string;
  notificationsDao: NotificationsDao;
  customerDao: CustomerDao;
  magnoliaDao: MagnoliaDao;
  maxRetries: number;
  minRetry: number;
  waitTimeout: number;
}

const EPAY_MAX_RETRIES = 3;

/**
 * `OrderService` for business logic `OrderService`
 */
export class PaymentService {
  private readonly paymentDao: PaymentDao;

  private readonly cartDao: CartDao;

  private readonly orderDao: OrderDao;

  private readonly magnoliaDao: MagnoliaDao;

  private readonly notificationsDao: NotificationsDao;

  private readonly returnUrl: string;

  /* Local cache for PaymentState */
  private readonly paymentStatesByMarket: Map<string, State[]> = new Map();

  private readonly eventBridgeClient: AwsEventBridgeClient;

  private readonly marketingEmailConsentEventBusName: string;

  private readonly customerDao: CustomerDao;

  private readonly maxRetries: number;

  private readonly minRetry: number;

  private readonly waitTimeout: number;

  private readonly staticInitiatePayment = 'error.cartIdNotFound';

  private readonly staticPaymentService = 'PaymentService.initiatePayment';

  /**
   * Constructor for `CartService` class
   * @param config injects dependencies into the object
   */
  constructor(config: PaymentServiceConfig) {
    this.paymentDao = config.paymentDao;
    this.cartDao = config.cartDao;
    this.orderDao = config.orderDao;
    this.magnoliaDao = config.magnoliaDao;
    this.notificationsDao = config.notificationsDao;
    this.returnUrl = config.returnUrl;
    this.eventBridgeClient = config.eventBridgeClient;
    this.marketingEmailConsentEventBusName = config.marketingEmailConsentEventBusName;
    this.customerDao = config.customerDao;
    this.maxRetries = config.maxRetries;
    this.minRetry = config.minRetry;
    this.waitTimeout = config.waitTimeout;
  }

  private async getPaymentState(
    market: MarketInfo,
    key: PAYMENT_STATE_KEYS,
  ): Promise<State> {
    const { country } = market;

    let paymentStates = this.paymentStatesByMarket.get(country);
    /* istanbul ignore else */
    if (paymentStates === undefined) {
      paymentStates = await this.paymentDao.getAllPaymentStates(market);
      this.paymentStatesByMarket.set(country, paymentStates);
    }

    return paymentStates.find((state) => state.key === key)!;
  }

  /**
   * Create a Payment CT object for online payment (paid with card)
   * @param market - MarketInfo
   * @param paymentKey - string Payment key to be stored in CT
   * @param totalPrice - Money The amount that will be paid
   */
  private async createOnlinePayment(
    market: MarketInfo,
    paymentKey: string,
    totalPrice: Money,
  ): Promise<Payment> {
    const paymentState = await this.getPaymentState(market, PAYMENT_STATE_KEYS.initial);

    const paymentDraft: PaymentDraft = {
      key: paymentKey,
      amountPlanned: totalPrice,
      paymentMethodInfo: { method: PAYMENT_TYPE.online },
      transactions: [{
        amount: totalPrice,
        state: 'Initial',
        type: 'Charge',
      }],
      paymentStatus: {
        state: { typeId: 'state', id: paymentState.id },
      },
    };

    return this.paymentDao.createPayment(market, paymentDraft);
  }

  /**
   * Create a Payment CT object for cash payment (paid on delivery)
   * @param market - MarketInfo
   * @param paymentKey - string Payment key to be stored in CT
   * @param totalPrice - Money The amount that will be paid
   */
  private async createCashPayment(
    market: MarketInfo,
    paymentKey: string,
    totalPrice: Money,
  ): Promise<MyPayment> {
    const paymentState = await this.getPaymentState(market, PAYMENT_STATE_KEYS.initial);

    const paymentDraft: PaymentDraft = {
      key: paymentKey,
      amountPlanned: totalPrice,
      paymentMethodInfo: { method: PAYMENT_TYPE.CashOnDelivery },
      paymentStatus: {
        state: { typeId: 'state', id: paymentState.id },
      },
    };

    return this.paymentDao.createPayment(market, paymentDraft);
  }

  private async updateCustomerMarketingEmailConsent(
    market: MarketInfo,
    customerId: string,
    marketingEmailConsent: boolean,
  ): Promise<void> {
    const customer = await this.customerDao.findGraphQLOne(market, customerId);
    const updateCustomerPayload: CustomerUpdate = {
      version: customer.version,
      actions: [{
        action: 'setCustomField',
        name: 'OptIn',
        value: marketingEmailConsent,
      }],
    };
    await this.customerDao.updateCustomer(market, customerId, updateCustomerPayload);
  }

  private updateCartPaymentAndOrder(
    market,
    cart: Cart,
    payment: MyPayment,
    orderNumber: string,
  ): Promise<Cart> {
    const updateCartPayload: CartUpdate = {
      version: cart.version,
      actions: [{
        action: 'addPayment',
        payment: { typeId: 'payment', id: payment.id },
      }],
    };

    if (cart.custom) {
      updateCartPayload.actions.push({
        action: 'setCustomField',
        name: 'orderNumber',
        value: orderNumber,
      });
    } else {
      updateCartPayload.actions.push({
        action: 'setCustomType',
        type: { typeId: 'type', key: 'cart-type' },
        fields: { orderNumber, privacyPolicyRead: true },
      });
    }

    return this.cartDao.updateCartById(market.country, cart.id, updateCartPayload);
  }

  /**
   * Initiate payment in CT and epay payment GW
   * @param market - MarketInfo
   * @param authorization - string Authorization header
   * @param id - string Id of cart with products for which to initiate payment
   * @param css - string CSS to send to payment gateway
   * @param type - PaymentTypeDto Payment type (online/cash)
   * @param marketingEmailConsent - boolean Whether the user consents to marketing emails from us
   * @return Promise<PaymentInitResponseDto>
   */
  public async initiatePayment(
    magnolia: MagnoliaInfo,
    market: MarketInfo,
    param,
    params: ApptusRequestDto,
  ): Promise<PaymentInitResponseDto> {
    const {
      authorization,
      id,
      css,
      type,
      marketingEmailConsent,
    } = param;
    logger.info(`${this.staticInitiatePayment} initiating payment for cart ${id}`);
    const initiatePaymentStartTime = performance.now();
    logger.info(`${this.staticInitiatePayment} marketingEmailConsent = ${marketingEmailConsent}`);

    /* Get cart information and external generators */

    const [cart, paymentKey, orderNumber, staticPageData] = await Promise.all([
      // this.cartDao.getMyCartById(market.country, authorization, id),
      this.checkCartPaymentInfo(market, authorization, id),
      this.paymentDao.getNextPaymentKey(market),
      this.paymentDao.getNextOrderSequence(market),
      type === 'CashOnDelivery' ? this.magnoliaDao.getCheckoutPageData(market, magnolia) : Promise.resolve({}),
    ]);

    if (!cart) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t(this.staticInitiatePayment, { id }));
    }
    if (type === 'CashOnDelivery' && staticPageData?.paymentSummaryTexts?.showCashOnDelivery === false) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.codNotEnabled', { id }));
    }
    const cartId = cart.id;
    const {
      customerId, anonymousId, billingAddress, shippingAddress, totalPrice,
    } = cart;

    if (!customerId && !anonymousId) {
      throw new ApiError(HttpStatusCodes.INTERNAL_SERVER_ERROR, i18next.t('error.cartCustomerIdNotFound', { cartId }));
    }
    if (!billingAddress) {
      throw new ApiError(
        HttpStatusCodes.INTERNAL_SERVER_ERROR,
        i18next.t('error.cartBillingAddressNotFound', { cartId }),
      );
    }
    if (!shippingAddress) {
      throw new ApiError(
        HttpStatusCodes.INTERNAL_SERVER_ERROR,
        i18next.t('error.cartShippingAddressNotFound', { cartId }),
      );
    }
    if (!totalPrice) {
      throw new ApiError(HttpStatusCodes.INTERNAL_SERVER_ERROR, i18next.t('error.cartTotalPriceNotFound', { cartId }));
    }

    // need to done: Passing empty payerId as a guuid payer id is causing issue at epay end due to it's size.
    // Correct it once shorter customer number is finalized.
    const payerId = ''; // (customerId || anonymousId)!.replace(/-/g, '');

    logger.info(`PaymentService.initiate generated order number: ${orderNumber}`);

    /* Create Payment in CT */

    logger.info(`PaymentService.initiate creating "${type}" Payment in CT`);
    let payment: MyPayment;
    switch (type) {
      case PAYMENT_TYPE.online:
        payment = await this.createOnlinePayment(
          market,
          paymentKey,
          totalPrice,
        );
        break;
      case PAYMENT_TYPE.CashOnDelivery:
        payment = await this.createCashPayment(
          market,
          paymentKey,
          totalPrice,
        );
        break;
      default:
        throw new ApiError(HttpStatusCodes.BAD_REQUEST, `Payment type "${type}" is not supported`);
    }

    logger.info(`PaymentService.initiate created CT Payment: ${JSON.stringify(payment)}`);

    const updatedCart = await this.updateCartPaymentAndOrder(market, cart, payment, orderNumber);

    logger.info(`PaymentService.initiate updated CT Cart: ${JSON.stringify(updatedCart)}`);

    if (!updatedCart) {
      throw new ApiError(
        HttpStatusCodes.INTERNAL_SERVER_ERROR,
        i18next.t('error.customerSupport'),
      );
    }

    const paymentStatePending = await this.getPaymentState(market, PAYMENT_STATE_KEYS.pending);

    let response: PaymentInitResponseDto = {} as PaymentInitResponseDto;
    switch (type) {
      case PAYMENT_TYPE.online: {
        /* Initiate payment transaction */
        let epayTryCount = 1;
        while (epayTryCount <= EPAY_MAX_RETRIES) {
          const epayStartTime = performance.now();
          try {
            logger.info(`${this.staticInitiatePayment} online payment attempt ${epayTryCount}/${EPAY_MAX_RETRIES}`);
            const epayParam = {
              paymentKey,
              orderNumber,
              payerId,
              totalPrice,
              billingAddress,
            };
            // eslint-disable-next-line no-await-in-loop
            response = await this.paymentDao.epayInitiate(
              market,
              epayParam,
              this.returnUrl,
              css,
            );
            const epayEndTime = performance.now();
            logger.info('*************************** Total time taken by epay call::: ', (epayEndTime - epayStartTime));
            logger.info(`${this.staticInitiatePayment} epay response ${JSON.stringify(response)}`);
            break;
          } catch (err: any) { // NOSONAR
            logError(`${this.staticInitiatePayment}`, `Failed attempt ${epayTryCount}/${EPAY_MAX_RETRIES}`, err);
            epayTryCount += 1;
            // eslint-disable-next-line no-await-in-loop
            await new Promise((resolve) => {
              setTimeout(resolve, this.waitTimeout);
            });
          }
        }
        if (epayTryCount > EPAY_MAX_RETRIES) {
          throw new ApiError(HttpStatusCodes.INTERNAL_SERVER_ERROR, i18next.t('error.epayRetryFailed'));
        }

        /* Update Transaction and Payment state to Pending */
        const updatePaymentPayload: PaymentUpdate = {
          version: payment.version,
          actions: [
            {
              action: 'changeTransactionState',
              transactionId: payment.transactions[0].id,
              state: 'Pending',
            }, {
              action: 'changeTransactionInteractionId',
              transactionId: payment.transactions[0].id,
              interactionId: response.id,
            }, {
              action: 'transitionState',
              state: { typeId: 'state', id: paymentStatePending.id },
            },
          ],
        };

        const updatedPayment = await this.paymentDao.updatePayment(market, payment.id, updatePaymentPayload);

        logger.info(`PaymentService.initiate updated CT Payment: ${JSON.stringify(updatedPayment)}`);
        break;
      }

      case PAYMENT_TYPE.CashOnDelivery: {
        /* Create Order from Cart */
        const order = await this.orderDao.createOrderFromCart(
          market,
          authorization,
          cartId,
          updatedCart.version,
          orderNumber,
        );
        /* Send a notification to apptus */
        this.notificationsDao.paymentNotifications(market, params, order);

        /* Update Transaction and Payment state to Pending */
        const updatePaymentPayload: PaymentUpdate = {
          version: payment.version,
          actions: [
            {
              action: 'transitionState',
              state: { typeId: 'state', id: paymentStatePending.id },
            },
          ],
        };

        const updatedPayment = await this.paymentDao.updatePayment(market, payment.id, updatePaymentPayload);

        logger.info(`PaymentService.initiate updated CT Payment: ${JSON.stringify(updatedPayment)}`);

        response = {
          id: order.id,
        };
        break;
      }

      default:
        throw new ApiError(HttpStatusCodes.BAD_REQUEST, `Payment type "${type}" is not supported`);
    }

    /* Events that are safe to run async */
    if (marketingEmailConsent !== undefined) {
      if (customerId) {
        /* async */
        if (marketingEmailConsent) {
          this.eventBridgeClient.putEvent(
            this.marketingEmailConsentEventBusName,
            AwsEventBridgeSource.marketingNotifications,
            {
              marketId: market.localeAndCountry,
              eventType: 'Changed',
              resourceTypeId: 'customer',
              resourceId: customerId,
            },
          ).catch((err) =>
            logError(
              `${this.staticInitiatePayment}`,
              'Failed to push marketing notification to event bus',
              err,
            ));
        }
        /* async */
        this.updateCustomerMarketingEmailConsent(market, customerId, marketingEmailConsent)
          .catch(
            (err) => logError(
              `${this.staticInitiatePayment}`,
              'Failed to update Customer MarketingEmailConsent',
              err,
            ),
          );
      } else {
        logger.error(`${this.staticInitiatePayment} got marketingEmailConsent true,
           but the payer is anonymous, there was no customerId provided`);
      }
    }

    /* Return response from PSP */
    const initiatePaymentEndTime = performance.now();
    logger.info(
      '*************************** Total time taken by initiate payment call::: ',
      (initiatePaymentEndTime - initiatePaymentStartTime),
    );
    return response;
  }

  private async checkCartPaymentInfo(

    market: MarketInfo,

    authorization: string,

    cartId: string,

  ): Promise<Cart | undefined> {
    const { country } = market;

    const cart = await this.cartDao.getMyCartById(country, authorization, cartId);

    if (!cart) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t(this.staticInitiatePayment, { cartId }));
    }

    if (!cart.paymentInfo || cart.paymentInfo.payments.length === 0) {
      return cart;
    }

    return this.cartDao.replicateCartById(country, cartId, authorization);
  }

  public async getPaymentStatus(
    market: MarketInfo,
    authorization: string,
    cartId: string,
    orderNumber: string,
    transactionId: string,
    params: ApptusRequestDto,
  ): Promise<PaymentStatusResponseDto> {
    logger.info(`PaymentService.getPaymentStatus checking payment status for orderNumber ${orderNumber}`);
    logger.info(`PaymentService.getPaymentStatus checking payment status for cart ${cartId}`);

    /* Get payment cart info */

    const cartPaymentInfo = await this.cartDao.getCartPaymentInfo(market, cartId, authorization);

    logger.info(`PaymentService.getPaymentStatus cartPaymentInfo: ${JSON.stringify(cartPaymentInfo)}`);

    const cartPaymentStatus = cartPaymentInfo.paymentInfo.payments[0].paymentStatus.state.key;

    const response: PaymentStatusResponseDto = {
      status: cartPaymentStatus,
    };
    if (cartPaymentStatus === PAYMENT_STATE_KEYS.failed) {
      return response;
    }

    if (cartPaymentStatus === PAYMENT_STATE_KEYS.pending) {
      const retryCount = 0;
      /* Get payment status from epay and payment states from ct */
      const [ePayTransaction, ctPaymentStates] = await Promise.all([
        this.paymentDao.ePayTransactionDetail(market, transactionId, retryCount),
        this.paymentDao.getAllPaymentStates(market),
      ]);

      if (ePayTransaction.status === E_PAYMENT_STATUS.failed || ePayTransaction.status === E_PAYMENT_STATUS.declined) {
        const paymentStateFailed = ctPaymentStates.find((state) => state.key === PAYMENT_STATE_KEYS.failed)!;
        response.status = PAYMENT_STATE_KEYS.failed;

        /* Update Transaction and Payment state to failure */
        await this.updatePaymentStatus(
          market,
          cartPaymentInfo,
          paymentStateFailed.id,
          transactionId,
          ePayTransaction.amount,
          ePayTransaction.currency,
          TRANSACTION_STATE.failure,
        );
        return response;
      }

      if (ePayTransaction.status === E_PAYMENT_STATUS.captured) {
        logger.info(`PaymentService.getPaymentStatus checking payment status for transactionId ${transactionId}`);

        logger.info('PaymentService.getPaymentStatus updating transaction status of cart to order');
        response.status = PAYMENT_STATE_KEYS.success;

        logger.info(`PaymentService.getPaymentStatus getting payment success state for cart ${cartId}`);
        const paymentStateSuccess = ctPaymentStates.find((state) => state.key === PAYMENT_STATE_KEYS.success)!;

        /* Update Transaction and Payment state to Success */
        await this.updatePaymentStatus(
          market,
          cartPaymentInfo,
          paymentStateSuccess.id,
          transactionId,
          ePayTransaction.amount,
          ePayTransaction.currency,
          TRANSACTION_STATE.success,
        );
      }
    }

    /* Create order from cart and Send a notification to apptus */
    response.orderId = await this.getOrderAndNotifyApptus(
      market,
      orderNumber,
      params,
    );
    return response;
  }

  private async updatePaymentStatus(
    market: MarketInfo,
    cartPaymentInfo: CtCartPaymentInfo,
    paymentStateId: string,
    transactionId: string,
    amount: number,
    currency: string,
    transactionState: string,
  ): Promise<void> {
    const paymentId = cartPaymentInfo.paymentInfo.payments[0].id;
    const paymentVersion = cartPaymentInfo.paymentInfo.payments[0].version;
    const updatePaymentPayload: PaymentUpdate = {
      version: paymentVersion,
      actions: [
        {
          action: 'transitionState',
          state: {
            typeId: 'state',
            id: paymentStateId, // success/failed id
          },
        },
        {
          action: 'setInterfaceId',
          interfaceId: transactionId,
        },
        {
          action: 'addTransaction',
          transaction: {
            type: 'Charge',
            amount: {
              centAmount: amount, // epay amount
              currencyCode: currency, // epay currency
            },
            state: transactionState as TRANSACTION_STATE.failure | TRANSACTION_STATE.success,
          },
        },
      ],
    };
    await this.paymentDao.updatePayment(market, paymentId, updatePaymentPayload);
  }

  private async getOrderAndNotifyApptus(
    market: MarketInfo,
    orderNumber: string,
    params: ApptusRequestDto,
  ): Promise<string | undefined> {
    /* Fetch order on the basis of orderNumber */
    let order;
    let TRY_COUNT = this.minRetry;

    order = await this.orderDao.fetchOrderByOrderNumber(
      market,
      orderNumber,
    );
    logger.info(`PaymentService.getPaymentStatus fetched order for cart: ${JSON.stringify(order)}`);
    if (order?.length === 0) {
      while (TRY_COUNT <= this.maxRetries) {
        try {
          logger.info(`PaymentService.getPaymentStatus fetch Order attempt ${TRY_COUNT}/${this.maxRetries}`);
          // eslint-disable-next-line no-await-in-loop
          order = await this.orderDao.fetchOrderByOrderNumber(
            market,
            orderNumber,
          );
          if (order?.length === 0) {
            throw new Error('Order not found');
          }
          logger.info(`PaymentService.getPaymentStatus fetch Order By OrderNumber: ${JSON.stringify(order)}`);
          break;
        } catch (error: any) { // NOSONAR
          logger.error(
            'PaymentService.getPaymentStatus fetch Order By OrderNumber',
            `Failed attempt ${TRY_COUNT}/${this.maxRetries}`,
            error,
          );
          TRY_COUNT += 1;
          // eslint-disable-next-line no-new
          // eslint-disable-next-line no-await-in-loop
          await new Promise((resolve) => {
            setTimeout(resolve, this.waitTimeout);
          });
        }
      }
      /*  this line will throw exception if maximum retry limit exceed */
      if (TRY_COUNT > this.maxRetries) {
        throw new ApiError(HttpStatusCodes.INTERNAL_SERVER_ERROR, i18next.t('error.orderFetchRetryFailed'));
      }
    }

    if (order?.length) {
      /* Send a notification to apptus */
      const [orderDetails] = order;
      this.notificationsDao.paymentNotifications(market, params, orderDetails);
      return orderDetails.id;
    }
    return undefined;
  }
}
