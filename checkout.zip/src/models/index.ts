import { Request } from 'express';

interface IReq extends Request {
  market: string;
  locale: string;
}

interface HttpStatus {
  readonly statusCode: number;
  readonly message: string;
  readonly timestamp: Date;
}

interface ITypeIdentifier {
  typeId: string;
  id: string;
}
interface Id {
  typeId?: string;
  id: string;
}
interface IActionArguments {
  sku?: string;
  quantity?: number;
  customer?: Id;
  lineItemId?: string;
  shoppingList?: Id;
  productId?: string;
  variantId?: string;
}

// eslint-disable-next-line no-shadow
enum ActionName {
  addLineItem = 'addLineItem',
  removeLineItem = 'removeLineItem',
}

type LineItem = {
  lineItemId: string;
  quantity?: number;
};

export {
  IReq,
  HttpStatus,
  IActionArguments,
  ActionName,
  LineItem,
  ITypeIdentifier,
};
