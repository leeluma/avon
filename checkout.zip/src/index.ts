import { Router } from 'express';
import { CtClient, AwsEventBridgeClient } from './lib';
import { LeapApp, LeapAppConfig } from './app/leap-app';
import {
  MagnoliaDao, CustomerDao, CartDao, PaymentDao, OrderDao, AddressDao, DefaultDao, NotificationsDao,
} from './daos';
import {
  AddressController,
  CartController,
  PaymentController,
  CustomerController,
  DefaultController,
  OrderController,
} from './controllers';
import {
  DefaultService, CartService, PaymentService, CustomerService, AddressService,
  OrderService,
  MagnoliaService,
} from './services';
import {
  DefaultRouter, AddressRouter, PaymentRouter, CustomerRouter, ShippingMethodRouter,
  CartRouter, OrderRouter,
} from './routers';
import {
  AddressMapper, CartMapper, ShippingMethodMapper, OrderMapper, CustomerMapper,
} from './mappers';
import { config } from './config';
import { graphql } from './graphql';

import { CheckoutController } from './controllers/checkout.controller';
import { CheckoutRouter } from './routers/checkout.router';
import {
  buildAuthMiddleware,
  makeAddressValidationSettingsMiddleware,
  makeValidationSettingsMiddleware,
} from './middlewares';

/* Build configuration */
const {
  projectName, projectVersion, apiContextPath, apiVersion, port,
  paymentApiKey, paymentApiPrefix, paymentApiInitSuffix, paymentOrderNumberGeneratorUrl, paymentKeyGeneratorUrl,
  addressFinderAutoComplete, addressFinderHost, pickupPointUrl, pickupPointKey, ctMarkets,
  awsRegion, awsEventBusNamePasswordReset, awsEventBusNameMarketingNotifications,
  apptusPaymentNotificationEndpoint, apptusClusterId, apptusEsalesMarket, apptusApiKey,
  paymentReturnUrl, uri, paymentRetryCount, paymentRetryTimeout, maxRetries,
  minRetry, waitTimeout,
} = config;

if (!projectName) {
  throw new Error('The "name" field in package.json is mandatory!');
}

if (!projectVersion) {
  throw new Error('The "version" field in package.json is mandatory!');
}

if (!apiContextPath) {
  throw new Error('The "API_CONTEXT_PATH" environment variable is mandatory! (suggested value: api)');
}

if (!apiVersion) {
  throw new Error('The "API_VERSION" environment variable is mandatory! (suggested value: v1)');
}

if (!port) {
  throw new Error('The "API_PORT" environment variable is missing or not a valid number! (suggested value: 3000)');
}

if (!ctMarkets) {
  throw new Error('The "CT_ACTIVE_MARKETS" environment variable is missing (suggested value: ["RO"])');
}
if (!paymentApiKey) {
  throw new Error('The "PAYMENT_API_KEY" environment variable is missing!');
}
if (!paymentApiPrefix) {
  throw new Error('The "PAYMENT_API_URL_PREFIX" environment variable is missing! (link to a capturenow service)');
}
if (!paymentApiInitSuffix) {
  throw new Error('The "PAYMENT_API_INIT_SUFFIX" environment variable is missing! (link to a capturenow service)');
}
if (!paymentReturnUrl) {
  throw new Error('The "PAYMENT_RETURN_URL" environment variable is missing!');
}

if (!addressFinderHost) {
  throw new Error('The "ADDRESS_FINDER_HOST" environment variable is missing!');
}

if (!addressFinderAutoComplete) {
  throw new Error('The "addressFinderAutoComplete" variable is missing!');
}

if (!pickupPointUrl) {
  throw new Error('The "PICKUP_POINT_URL" environment variable is missing!');
}

if (!pickupPointKey) {
  throw new Error('The "PICKUP_POINT_KEY" environment variable is missing!');
}

if (!paymentOrderNumberGeneratorUrl) {
  throw new Error('The "PAYMENT_ORDER_NUMBER_GENERATOR" variable is missing!');
}

if (!paymentKeyGeneratorUrl) {
  throw new Error('The "PAYMENT_KEY_GENERATOR" variable is missing!');
}

if (!awsRegion) {
  throw new Error('The "AWS_REGION" variable is missing! (you probably want eu-west-1)');
}

if (!awsEventBusNamePasswordReset) {
  throw new Error('The "AWS_EVENT_BUS_NAME_PASSWORD_RESET" variable is missing!');
}

if (!awsEventBusNameMarketingNotifications) {
  throw new Error('The "AWS_EVENT_BUS_NAME_MARKETING_NOTIFICATIONS" variable is missing!');
}

if (!apptusClusterId) {
  throw new Error('The "APPTUS_CLUSTER_ID" environment variable is missing');
}
if (!apptusApiKey) {
  throw new Error('The "APPTUS_API_KEY" environment variable is missing');
}

if (!apptusEsalesMarket) {
  throw new Error('The "APPTUS_ESALES_MARKET" environment variable is missing');
}

if (!apptusPaymentNotificationEndpoint) {
  throw new Error('The "APPTUS_BASE_URL" environment variable is missing');
}

if (!uri.magnolia.basePath) {
  throw new Error('The "MAGNOLIA_BASE_PATH" environment variable is missing');
}

if (!paymentRetryCount) {
  throw new Error('The "PAYMENT_RETRY_COUNT" environment variable is missing');
}

if (!paymentRetryTimeout) {
  throw new Error('The "PAYMENT_RETRY_TIMEOUT" environment variable is missing');
}

const appConfig: LeapAppConfig = {
  projectName,
  projectVersion,
  apiContextPath,
  apiVersion,
  port,
};

/* Initialize dependencies */

const ctClient = new CtClient(process.env as any);
const eventBridgeClient = new AwsEventBridgeClient({ region: awsRegion });

const cartDao = new CartDao({ ctClient, graphql });
const customerDao = new CustomerDao({ ctClient, graphql });
const defaultDao = new DefaultDao({ ctClient });

const paymentDao = new PaymentDao({
  ctClient,
  graphql,
  paymentApiKey,
  paymentApiPrefix,
  paymentApiInitSuffix,
  paymentOrderNumberGeneratorUrl,
  paymentKeyGeneratorUrl,
  paymentRetryCount,
  paymentRetryTimeout,
});
const magnoliaBasePath = config.uri.magnolia.basePath;

const magnoliaDao = new MagnoliaDao({ magnoliaBasePath });
const addressDao = new AddressDao();
const orderDao = new OrderDao({ ctClient, graphql });

const validationSettingsReader = magnoliaDao.getSettings.bind(magnoliaDao);
const validationSettingsMiddleware = makeValidationSettingsMiddleware(validationSettingsReader);

const shippingMethodMapper = new ShippingMethodMapper();
const addressMapper = new AddressMapper();
const orderMapper = new OrderMapper();
const cartMapper = new CartMapper({ addressMapper });
const customerMapper = new CustomerMapper({ addressMapper });

const notificationsDao = new NotificationsDao({
  apptusPaymentNotificationEndpoint,
  apptusClusterId,
  apptusApiKey,
  apptusEsalesMarket,
  orderMapper,
});

const cartService = new CartService({
  shippingMethodMapper, cartMapper, cartDao, addressDao, addressMapper, magnoliaDao, orderDao,
});
const defaultService = new DefaultService({
  addressDao, customerDao, cartDao, defaultDao,
});
const paymentService = new PaymentService({
  paymentDao,
  cartDao,
  orderDao,
  eventBridgeClient,
  marketingEmailConsentEventBusName: awsEventBusNameMarketingNotifications,
  notificationsDao,
  returnUrl: paymentReturnUrl,
  customerDao,
  magnoliaDao,
  maxRetries,
  minRetry,
  waitTimeout,
});
const customerService = new CustomerService({
  customerDao,
  addressDao,
  addressMapper,
  eventBridgeClient,
  passwordResetEventBusName: awsEventBusNamePasswordReset,
  customerMapper,
  orderDao,
});
const addressService = new AddressService({ addressDao });
const magnoliaService = new MagnoliaService({ magnoliaDao });
const orderService = new OrderService({ orderDao, orderMapper, magnoliaDao });

const cartController = new CartController({ cartService, customerService });
const paymentController = new PaymentController({ paymentService });
const customerController = new CustomerController({ customerService, cartService });
const defaultController = new DefaultController({ defaultService });
const addressController = new AddressController({ addressService });
const checkoutController = new CheckoutController({ magnoliaService });
const orderController = new OrderController({ orderService, magnoliaService });

const addressValidationSettingsReader = magnoliaDao.getSettings.bind(magnoliaDao);
const addressValidationSettingsMiddleware = makeAddressValidationSettingsMiddleware(addressValidationSettingsReader);
const authMiddleware = buildAuthMiddleware(ctClient);

const cartRouter = new CartRouter({
  cartController, Router, addressValidationSettingsMiddleware, authMiddleware,
});
const paymentRouter = new PaymentRouter({ paymentController, Router, authMiddleware });
const customerRouter = new CustomerRouter({
  customerController,
  Router,
  addressValidationSettingsMiddleware,
  authMiddleware,
  validationSettingsMiddleware,
});
const checkoutRouter = new CheckoutRouter({ checkoutController, Router });
const defaultRouter = new DefaultRouter({
  defaultController,
  Router,
  validationSettingsMiddleware,
  authMiddleware,
});
const addressRouter = new AddressRouter({ addressController, Router });
const orderRouter = new OrderRouter({ orderController, Router });
const shippingMethodRouter = new ShippingMethodRouter({ cartController, Router, ctClient });

/* Start app */

const leapApp = new LeapApp(appConfig);
leapApp.bootstrap().then(() => {
  leapApp.mount('/carts', cartRouter.buildExpressRouter(), paymentRouter.buildExpressRouter());
  leapApp.mount('/customers', customerRouter.buildExpressRouter());
  leapApp.mount('/', checkoutRouter.buildExpressRouter(), defaultRouter.buildExpressRouter());
  leapApp.mount('/shippingMethods', shippingMethodRouter.buildExpressRouter());
  leapApp.mount('/addresses', addressRouter.buildExpressRouter());
  leapApp.mount('/orders', orderRouter.buildExpressRouter());
  leapApp.listen();
});
