export interface PaymentInitResponseDto {
  id: string;
  url?: string;
}

export interface PaymentStatusResponseDto {
  orderId?: string;
  status: string;
}

// See validators/payment.validator.ts
export type PaymentTypeDto = 'online' | 'CashOnDelivery';

export enum PAYMENT_TYPE {
  online = 'online',
  CashOnDelivery = 'CashOnDelivery'
}

export enum PAYMENT_STATE_KEYS {
  initial = 'initial',
  pending = 'pending',
  success = 'success',
  failed = 'failed',
}

export enum E_PAYMENT_STATUS {
  captured = 'CAPTURED',
  declined = 'DECLINED',
  failed = 'FAILED',
  pending = 'PENDING',
}

export enum TRANSACTION_STATE {
  failure= 'Failure',
  success= 'Success',
}
export interface PaymentTransactionResponseDto {
  id: string;
  currency: string;
  amount: number;
  ordNr: string;
  payerId: string;
  paymentRefId: string;
  status: string;
  capture_now: string;
  payment_product: string;
  recurring_type: string;
}
