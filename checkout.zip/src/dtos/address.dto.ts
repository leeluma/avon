import { Address, CustomFields } from '@commercetools/platform-sdk';
import { GraphQLCustomFields } from '.';

/** Address request for BFF APIS */
export interface AddressRequestDto {
  addressId?: string;
  addressType?: string;
  addressFinderId?: string; // ID for address validation API.
  firstName?: string;
  lastName?: string;
  recipientName?: string;
  address1: string;
  address2: string;
  address3: string;
  address4: string;
  city: string;
  region: string;
  zip: string;
  county: string;
  country: string;
  key?: string;
  latitude: number;
  longitude: number;
  state?: string;
  phoneNumber?: string;
  isShippingAddress: boolean;
  isBillingAddress: boolean;
  updateCustomer?: boolean;
}

/** Address response for BFF APIS */
export interface AddressResponseDto {
  id?: string;
  email?: string;
  customerId?: string;
  firstName?: string;
  lastName?: string;
  recipientName?: string;
  address1: string;
  address2: string;
  address3: string;
  address4: string;
  city?: string;
  region?: string;
  zip?: string;
  county?: string;
  country: string;
  latitude?: number;
  longitude?: number;
  state?: string;
  isShippingAddress?: boolean;
  isBillingAddress?: boolean;
  phoneNumber?: string;
  currentAddress?: boolean;
}

export interface AddressCollectionResponseDto {
  addresses: AddressResponseDto[];
}

export interface GraphQLAddress extends Omit<Address, 'custom'> {
  custom?: GraphQLCustomFields;
}
export interface NormalizedAddress {
  id: string;
  normalizedAddress: string;
  exactMatch: boolean;
}

export interface AutocompleteResponseDto {
  suggestions: NormalizedAddress[];
}

export interface DetailResponseDto {
  firstName?: string;
  lastName?: string;
  recipientName?: string;
  phoneNumber?: string;
  country : string;
  region1 : string;
  region2 : string | null;
  city : string;
  district1 : string;
  district2 : string | null;
  zipCode : string;
  streetName : string;
  houseNumber : string;
  floor : string | null;
  flat : string | null;
  latitude : number;
  longitude : number;
  custom?: CustomFields | undefined;
}

export interface PickupPointRequestDto{
  latitude : number;
  longitude : number;
  distance: number | undefined;
  distanceUnit: string | undefined;
}

export interface PickupPointResponseDto{
  id: number;
  type: string;
  name: string;
  address1: string;
  address2: string;
  address3: string;
  address4: string;
  city: string;
  province: string;
  zipcode: string;
  openingHours: string;
  email: string;
  latitude: number;
  longitude: number;
  phone: string;
  url: string;
  cashOnDelivery: boolean;
  distributionCentreCode: string;
  country: string;
}
/**
 * @swagger
 * components:
 *   schemas:
 *     NormalizedAddress:
 *       additionalProperties: false
 *       properties:
 *         id:
 *           type: string
 *         normalizedAddress:
 *           type: string
 *       required:
 *         - id
 *         - normalizedAddress
 *       type: object

 *     AutocompleteResponseDto:
 *       additionalProperties: false
 *       properties:
 *         suggestions:
 *           items:
 *             $ref: '#/components/schemas/NormalizedAddress'
 *           type: array
 *       required:
 *         - suggestions
 *       type: object

 *     DetailResponseDto:
 *       additionalProperties: false
 *       properties:
 *         country:
 *           type: string
 *         region1:
 *           type: string
 *         region2:
 *           type: string
 *         city:
 *           type: string
 *         district1:
 *           type: string
 *         district2:
 *           type: string
 *         zipCode:
 *           type: string
 *         streetName:
 *           type: string
 *         houseNumber:
 *           type: string
 *         floor:
 *           type: string
 *         flat:
 *           type: string
 *         latitude:
 *           type: number
 *         longitude:
 *           type: number
 *       required:
 *         - country
 *         - region1
 *         - region2
 *         - city
 *         - district1
 *         - district2
 *         - zipCode
 *         - streetName
 *         - houseNumber
 *         - floor
 *         - flat
 *         - latitude
 *         - longitude
 *       type: object

 *     PickupPointRequesteDto:
 *       additionalProperties: false
 *       properties:
 *         latitude:
 *           type: number
 *         longitude:
 *           type: number
 *         distance:
 *           type: number
 *         distanceUnit:
 *           type: string
 *       required:
 *         - latitude
 *         - longitude
 *         - distance
 *         - distanceUnit
 *       type: object

 *     PickupPointResponseDto:
 *       additionalProperties: false
 *       properties:
 *         id:
 *           type: number
 *         type:
 *           type: string
 *         name:
 *           type: string
 *         address1:
 *           type: string
 *         address2:
 *           type: string
 *         address3:
 *           type: string
 *         address4:
 *           type: string
 *         city:
 *           type: string
 *         province:
 *           type: string
 *         zipCode:
 *           type: string
 *         openingHours:
 *           type: string
 *         email:
 *           type: string
 *         latitude:
 *           type: number
 *         longitude:
 *           type: number
 *         phone:
 *           type: string
 *         url:
 *           type: string
 *         cashOnDelivery:
 *           type: boolean
 *         distributionCentre:
 *           type: string
 *         country:
 *           type: string
 *       required:
 *         - id
 *         - type
 *         - name
 *         - address1
 *         - address2
 *         - address3
 *         - address4
 *         - city
 *         - province
 *         - zipCode
 *         - openingHours
 *         - email
 *         - latitude
 *         - longitude
 *         - phone
 *         - url
 *         - cashOnDelivery
 *         - distributionCentre
 *         - country
 *       type: object
 */
