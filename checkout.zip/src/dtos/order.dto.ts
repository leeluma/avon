import {
  CentPrecisionMoney, Order, Image, DiscountCode, DiscountCodeState, Payment, BaseAddress,
  Customer, PaymentStatus,
} from '@commercetools/platform-sdk';
import { GraphQLLineItem } from './checkout.dto';

export interface State {
  name: string;
}
export interface FieldRaw {
  name: string;
  value: any; // NOSONAR
}
export interface FieldType {
  name: string;
  id: any; // NOSONAR
}

export interface ImageDto {
  url: string;
  label: string;
  width: number;
  height: number;
}

export interface OffersDto {
  key: string;
  displayName: string;
  url: string;
  description: string;
}

export interface LineItemDto {
  lineItemId: string;
  productId: string;
  productKey?: string;
  name: string;
  skuCode?: string;
  images: Image[];
  listPrice: number;
  sellPrice: number;
  formattedListPrice: string;
  formattedSellPrice: string;
  unitPrice: string;
  quantity: number;
  modifiedTimeStamp?: string;
  hexCode: string;
  variantKey: string | undefined;
  variantType: string;
  variantValue: string;
  contentFill?: string;
}

export interface PromotionDto {
  promotionId: string;
  promotionCode: string;
  promotionAmount: number;
  formattedPromotionAmount: string;
  promotionState?: string;
  promotionApplied: boolean;
}

export interface ShippingInfo {
  shippingMethodName: string;
  price: {
    type: string;
    currencyCode: string;
    centAmount: number;
    fractionDigits: number;
  };
}

export interface ShippingInfoDto {
  shippingMethodName: string;
  shippingMethodPrice: string;
  shippingPrice?: number;
}

export interface ShippingMethodDto {
  id: string;
  name: string;
  isDefault: boolean;
  formattedDeliveryCharge: string;
  deliveryCharge: number;
  freeAbove: number;
}

export interface AddressResponseDto {
  name?: string;
  address?: string;
  city?: string;
  region?: string;
  zip?: string;
  country: string;
  key?: string;
  latitude?: number;
  longitude?: number;
  state?: string;
  phoneNumber?: string;
  pickupPoint?: string;
  isBillingAddress?: boolean;
}

export interface PaymentInfoDto {
  paymentStatus?: string;
  paymentType?: string;
  paymentAmount?: string;
}

export interface OrderDto {
  id: string;
  version: number;
  customerId?: string;
  anonymousId?: string;
  lineItems: LineItemDto[];
  orderState: string;
  email?: string;
  orderNumber?: string;
  totalPrice?: CentPrecisionMoney;
  shippingAddress?: AddressResponseDto;
  shippingInfo?: ShippingInfoDto;
  billingAddress?: AddressResponseDto;
  totalRetailPriceAmount: string;
  totalInvoiceAmount: number;
  currencyCode: string;
  formattedTotalPrice: string;
  formattedTotalInvoiceAmount: string;
  customerEmail?: string;
  promotion?: PromotionDto;
  paymentInfo?:PaymentInfoDto;
  addressType?: string;
}

export interface PriceCurrencyDto {
  totalPrice: number;
  currencyCode: string;
}

export interface AddressRequest {
  address1: string;
  address2?: string;
  city: string;
  postalCode: string;
  county: string;
  phoneNumber: string;
}
export interface CartDiscountRefs{
  id: string;
}
export interface GraphQLDiscountCode extends Omit<DiscountCode,
'cartDiscountRefs'> {
  cartDiscountRefs: CartDiscountRefs;
}
export interface GraphQLDiscountCodes {
  discountCode: GraphQLDiscountCode;
  state: DiscountCodeState;
}
export interface GraphQLPaymentStatus extends Omit<PaymentStatus,
'state'> {
  state?: State;
}
export interface GraphQLPayment extends Omit<Payment,
'paymentStatus'> {
  paymentStatus: GraphQLPaymentStatus;
}
export interface GraphQLPaymentInfo {
  payments: GraphQLPayment[];
}
export interface CustomFields {
  type: FieldType;
  customFieldsRaw: FieldRaw[];
}

export interface GraphQLAddress extends BaseAddress {
  custom: CustomFields;
}

export interface GraphQLOrder extends Omit<Order,
  'lineItems' | 'discountCodes' | 'paymentInfo' | 'shippingAddress'| 'billingAddress'> {
  lineItems: GraphQLLineItem[];
  totalPrice: CentPrecisionMoney;
  discountCodes: GraphQLDiscountCodes;
  paymentInfo: GraphQLPaymentInfo;
  shippingAddress: GraphQLAddress;
  billingAddress: GraphQLAddress;
  customer: Customer;
}
