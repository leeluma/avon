import {
  Cart, CartDraft, CentPrecisionMoney,
} from '@commercetools/platform-sdk';
import { AddressResponseDto } from './address.dto';
import { CtLocalizedStringDto } from './common.dto';

export interface VariantAttribute {
  name: string;
  value: any; // NOSONAR
}

export interface ImageDto {
  url: string;
  label: string;
  width: number;
  height: number;
}

export interface OffersDto {
  key: string;
  displayName: string;
  url: string;
  description: string;
}

export interface LineItemDto {
  lineItemId: string;
  productId: string;
  productKey?: string;
  name: string;
  skuCode?: string;
  images: ImageDto[];
  listPrice: number;
  sellPrice: number;
  formattedListPrice: string;
  formattedSellPrice: string;
  vatMessage: string;
  unitPrice: string;
  quantity: number;
  modifiedTimeStamp?: string;
  sequenceNumber: number;
  maxPurchasableQty: number;
  availableQuantity: number;
  hexCode: string;
  variantType: string;
  variantValue: string;
  offers: OffersDto[];
}

export interface PromotionDto {
  promotionId: string;
  promotionCode: string;
  promotionAmount: number;
  formattedPromotionAmount: string;
  promotionState?: string;
  promotionApplied: boolean;
}

export interface ShippingInfo {
  shippingMethodName: string;
  price: {
    type: string;
    currencyCode: string;
    centAmount: number;
    fractionDigits: number;
  };
}

export interface ShippingInfoDto {
  shippingMethodName: string;
  shippingMethodPrice: string;
  shippingPrice?: number;
}

export interface CartDto {
  id: string;
  version: number;
  totalRetailPriceAmount: string;
  totalInvoiceAmount: number;
  currencyCode: string;
  customerId?: string;
  anonymousId?: string;
  promotion?: PromotionDto;
  lineItems: LineItemDto[];
  shippingAddressType?: string;
  shippingAddress: AddressResponseDto;
  shippingInfo: ShippingInfoDto;
  billingAddress?: AddressResponseDto;
  totalPrice?: CentPrecisionMoney;
}

export interface LineItemsAddProductDto {
  productKey: string;
  sku: string;
  quantity: number;
}

export interface CartAddProductToCartDto {
  cartId: string;
  customerId: string;
  lineItems: LineItemsAddProductDto;
}

export interface CTLineItemDto {
  id: string;
  productId: string;
  name: CtLocalizedStringDto;
  variant: [];
  quantity: number;
  lastModifiedAt: string;
}

export interface CTCartDraftDto extends Omit<CartDraft, 'customerId' | 'country' | 'currency'> {
  id: string;
  version: number;
  customerId: number;
  totalPrice: string;
  lineItems: CTLineItemDto[];
  shippingInfo: any; // NOSONAR
  shippingAddress: any; // NOSONAR
}

export interface ShippingMethodDto {
  id: string;
  name: string;
  isDefault: boolean;
  formattedDeliveryCharge: string;
  deliveryCharge: number;
  freeAbove: number;
}

export interface ShippingMethodServiceDto {
  id: string;
  name: string;
  localizedDescription: string;
  isDefault: boolean;
  zoneRates: [
    {
      shippingRates: [
        {
          price: {
            centAmount: number;
            currencyCode: string;
            fractionDigits: number;
          };
          freeAbove: {
            centAmount: number;
            currencyCode: string;
            fractionDigits: number;
          };
        }
      ];
    }
  ];
}

export interface ShippingMethodServiceTODto {
  shippingMethod: ShippingMethodServiceDto[];
}

export interface PriceCurrencyDto {
  totalPrice: number;
  currencyCode: string;
}

export interface AddressRequest {
  address1: string;
  address2?: string;
  city: string;
  postalCode: string;
  county: string;
  phoneNumber: string;
}

export interface PaymentSummary {
  subTotalPrice: string;
  discount: string;
  deliveryPrice: string;
  totalPrice: string;
}

export interface CartShippingMethodDto {
  id: string;
  version: number;
  customerId?: string;
  paymentSummary: PaymentSummary;
}

export interface CtCartPaymentInfo {
  id: string;
  version: number;
  customerId?: string;
  anonymousId?: string;
  paymentInfo: {
    payments: {
      id: string;
      version: number;
      key: string;
      interfaceId: string;
      paymentStatus: {
        state: {
          key: string;
          name: string;
        };
      };
    } [];
  };
  custom: {
    customFieldsRaw: {
      name: string; value: any;
    } [];
  };
}

export interface CartPaymentInfoDto {
  isPaymentInitiated: boolean;
  cart?: Cart;
}
