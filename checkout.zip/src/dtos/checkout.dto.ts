import {
  Cart, Image, Price, TypedMoney, DiscountedLineItemPriceForQuantity,
} from '@commercetools/platform-sdk';
import { AddressResponseDto } from '.';
import { ShippingInfoDto } from './cart.dto';
import { GraphQLDiscountCodes } from './order.dto';

export interface CartLineItem {
  lineItemId: string;
  productId: string;
  productSlug: string;
  name: string;
  skuCode: string;
  images: Image[];
  listPrice: number;
  sellPrice: number;
  formattedListPrice: string;
  formattedSellPrice: string;
  unitPrice: string;
  quantity: number;
  totalPrice: number;
  currencyCode: string;
  hexCode: string;
  variantType: string;
  variantValue: string;
}

export interface Customer{
  email:string;
  firstName:string;
  lastName:string;
}
export interface CartResponse {
  id: string;
  version: number;
  customerId?: string;
  anonymousId?: string;
  customerEmail?: string;
  totalRetailPriceAmount: string;
  totalInvoiceAmount: number;
  formattedTotalPrice: string;
  currencyCode: string;
  lineItems: CartLineItem[];
  shippingAddress: AddressResponseDto;
  shippingInfo?: ShippingInfoDto;
  addressType?: string;
  customer?: Customer;
}

export interface LooseObject {
  [key: string]: string | number | { [key: string]: string | number };
}

interface Datum {
  [k: string]: boolean | number | string | LooseObject;
}

type Data = Datum[];

export interface GraphQLVariant {
  id: number;
  sku: string;
  key?: string;
  images: Image[];
  attributesRaw: Data;
  prices: Price[];
}

export interface GraphQLLineItem {
  id: string;
  productKey?: string;
  productId: string;
  productSlug: string;
  name: string;
  quantity: number;
  totalPrice: TypedMoney;
  variant: GraphQLVariant;
  discountedPricePerQuantity: DiscountedLineItemPriceForQuantity[];
}

export interface GraphQLCart extends Omit<Cart,
  'lineItems' | 'customLineItems' | 'shippingInfo' | 'customer' | 'discountCodes'> {
  lineItems: GraphQLLineItem[];
  customer: Customer;
  discountCodes: GraphQLDiscountCodes;
  shippingInfo :{
    shippingMethodName: string;
    price:{
      type: string;
      currencyCode: string;
      centAmount: number;
      fractionDigits: number;
    };
  };
}

/**
 * @swagger
 * components:
 *   schemas:
 *     Image:
 *       type: array
 *       items:
 *         type: object
 *         properties:
 *           label:
 *             type: string
 *             example: Gallery
 *           url:
 *             type: string
 *             example: https://www.avon.ro/assets/ro-RO/images/product/prod_1200539_1_613x613.jpg
 *           width:
 *             type: integer
 *             format: int32
 *             example: 613
 *           height:
 *             type: integer
 *             format: int32
 *             example: 613
 *     CartLineItem:
 *       properties:
 *         currencyCode:
 *           type: string
 *         images:
 *           items:
 *             $ref: '#/components/schemas/Image'
 *           type: array
 *         lineItemId:
 *           type: string
 *         name:
 *           type: string
 *         productId:
 *           type: string
 *         productSlug:
 *           type: string
 *         quantity:
 *           type: number
 *         skuCode:
 *           type: string
 *         totalPrice:
 *           type: number
 *         variantType:
 *           type: string
 *           example: variantType
 *         variantValue:
 *           type: string
 *           example: variantValue
 *         hexCode:
 *           type: string
 *           example: hexCode
 *       required:
 *         - lineItemId
 *         - productId
 *         - productSlug
 *         - name
 *         - skuCode
 *         - images
 *         - quantity
 *         - totalPrice
 *         - currencyCode
 *       type: object
 *     CartResponseGraphQL:
 *       properties:
 *         currencyCode:
 *           type: string
 *         customerId:
 *           type: string
 *         id:
 *           type: string
 *         lineItems:
 *           items:
 *             $ref: '#/components/schemas/CartLineItem'
 *           type: array
 *         totalPrice:
 *           type: number
 *         version:
 *           type: number
 *       required:
 *         - id
 *         - version
 *         - totalPrice
 *         - currencyCode
 *         - lineItems
 *       type: object
 */
