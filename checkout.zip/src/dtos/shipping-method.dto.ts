export interface ShippingMethodsResponseDto {
  id: string;
  name: string;
  formattedDeliveryCharge: string;
  formattedFreeAbove: string;
  deliveryCharge: number;
  freeAbove?: number | null;
}
export interface PriceDto {
  centAmount: number;
  currencyCode: string;
  fractionDigits: number;
}
