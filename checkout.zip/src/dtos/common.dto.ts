import { FieldContainer } from '@commercetools/platform-sdk';

export interface CtId {
  id: string;
}

/** See https://docs.commercetools.com/api/types#references */
export interface CtRef<T> extends CtId {
  typeId: string;
  obj?: T;
}

export interface CtTrackingClientDto {
  clientId: string;
  isPlatformClient: boolean;
}

export interface CtLocalizedStringDto {
  [locale: string]: string;
}

/** Common interface to extend from in most other Ct* interfaces */
export interface CtTrackingFieldsDto {
  createdAt: string;
  createdBy: CtTrackingClientDto;
  lastModifiedAt: string;
  lastModifiedBy: CtTrackingClientDto;
}

export interface CtCustomFieldsDraftDto {
  [k: string]: string;
}

/** Generic response from CommerceTools */
export interface CtResponse<T> {
  statusCode: number;
  body: T;
}
export interface GraphQLTypeResourceIdentifier {
  typeId: 'type';
  id?: string;
  key?: string;
}
export interface GraphQLCustomFields {
  type: GraphQLTypeResourceIdentifier;
  customFieldsRaw: FieldContainer;
}
export interface CommonResponse {
  [x: string]: any | unknown; // NOSONAR
}
export interface MagnoliaInfo {
  url: string;
  isPreview: boolean;
  marketPath: string;
}

export interface CommonError {
  msg: string;
  param: string;
  location: string;
}

export interface ApptusRequestDto {
  sessionKey: string;
  customerKey: string;
}
