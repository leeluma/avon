import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { OrderService, MagnoliaService } from '../services';
import { MarketInfo } from '../middlewares';
import { JsonApiResponseEntity } from '../lib';
import { CommonResponse, MagnoliaInfo } from '../dtos';

const mgnlTemplate = 'mgnl:template';

interface OrderControllerConfig {
  orderService: OrderService;
  magnoliaService: MagnoliaService;
}

export class OrderController {
  private readonly orderService: OrderService;

  private readonly magnoliaService: MagnoliaService;

  constructor(config: OrderControllerConfig) {
    this.orderService = config.orderService;
    this.magnoliaService = config.magnoliaService;
  }

  /**
   * Initiate order for a Order
   * @param req - Request
   * @param res - Response
   * @returns Order id and redirect URL
   */
  public getOrder = async (
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<CommonResponse>> => {
    const authHeader: string = req.headers.authorization!;
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;
    const { orderId } = req.params;
    const [globalSettings, staticPageData] = await Promise.all([
      this.magnoliaService.getGlobalSettingsData(market, magnolia),
      this.magnoliaService.getOrderConfirmationPageData(market, magnolia),
    ]);
    let magnoliaTemplateData = {};
    if (magnolia.isPreview && staticPageData) {
      const templateName = staticPageData[mgnlTemplate] || '';
      magnoliaTemplateData = await this.magnoliaService.getTemplateData(templateName as string, magnolia.url);
    }

    const orderConfirmation = await this.orderService.orderDetails(
      authHeader,
      market,
      orderId,
      globalSettings?.priceFormat,
    );

    const responseData = {
      ...staticPageData,
      globalSettings,
      orderConfirmation,
      templateDefinition: magnoliaTemplateData,
    };

    return {
      statusCode: HttpStatusCodes.OK,
      body: responseData,
    };
  };

  /**
   * Get order confirmation magnolia
   * @param req - Request
   * @param res - Response
   * @returns
   */
  public getOrderMagnolia = async (
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<CommonResponse>> => {
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;
    const [globalSettings, staticPageData] = await Promise.all([
      this.magnoliaService.getGlobalSettingsData(market, magnolia),
      this.magnoliaService.getOrderConfirmationPageData(market, magnolia),
    ]);
    let magnoliaTemplateData = {};
    if (magnolia.isPreview && staticPageData) {
      const templateName = staticPageData[mgnlTemplate] || '';
      magnoliaTemplateData = await this.magnoliaService.getTemplateData(templateName as string, magnolia.url);
    }

    const responseData = {
      ...staticPageData,
      globalSettings,
      templateDefinition: magnoliaTemplateData,
    };

    return {
      statusCode: HttpStatusCodes.OK,
      body: responseData,
    };
  };
}
