import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { DefaultService } from '../services';
import { MarketInfo } from '../middlewares';
import {
  CommonResponse,
  LoginDto,
  LoginResponseDto,
  PickupPointRequestDto,
  PickupPointResponseDto,
  UpdateCartRequestDto,
} from '../dtos';
import { ApiError, JsonApiResponseEntity } from '../lib';

export interface DefaultControllerConfig {
  defaultService: DefaultService;
}

export class DefaultController {
  private readonly defaultService: DefaultService;

  constructor(config: DefaultControllerConfig) {
    this.defaultService = config.defaultService;
  }

  /**
   * Login customer from CT using
   * @param request - Express request object
   * @param response - Express response object
   * @returns Customer login token if it was found
   * @throws ApiError 404 if Customer was not found
   */
  public async login(
    request: Request,
    response: Response,
  ): Promise<LoginResponseDto> {
    const market = response.locals.market as MarketInfo;
    const loginReqDto = request.body as LoginDto;
    const output = await this.defaultService.login(market, loginReqDto);
    return {
      statusCode: HttpStatusCodes.CREATED,
      body: output,
    };
  }

  /**
   * Refresh token
   * @param request - Express request object
   * @param response - Express response object
   */
  public async refreshToken(
    request: Request,
    response: Response,
  ):Promise<JsonApiResponseEntity<CommonResponse>> {
    const market = response.locals.market as MarketInfo;
    const { refreshtoken } = request.headers;
    const refreshTokenResult = await this.defaultService.refreshToken(market, refreshtoken);

    return {
      statusCode: HttpStatusCodes.OK,
      body: refreshTokenResult,
    };
  }

  /**
   * Update Cart from CT using
   * @param request - Express request object
   * @param response - Express response object
   * @returns token if it was found
   * @throws ApiError 404 if cart not found
   */
  public async updateMyCartById(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<undefined>> {
    const { locals: { customer } } = response;
    if (customer) {
      throw new ApiError(HttpStatusCodes.UNAUTHORIZED, i18next.t('validationError.unauthorized'));
    }
    const market = response.locals.market as MarketInfo;
    const authToken = String(request.headers.authorization || '');
    const updateCartRequestDto = request.body as UpdateCartRequestDto;
    await this.defaultService.updateMyCartById(market, updateCartRequestDto, authToken);
    return {
      statusCode: HttpStatusCodes.CREATED,
      body: undefined,
    };
  }

  /**
   * Get list of pickup details using latitude and longitude.
   * @param request - Express request object
   * @param response - Express response object
   */
  public async getPickupDetail(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<PickupPointResponseDto>> {
    const market = response.locals.market as MarketInfo;
    const {
      latitude, longitude, distance, distanceUnit,
    } = request.query;
    const pickupPointRequestDto: PickupPointRequestDto = {
      latitude: parseFloat(latitude as string),
      longitude: parseFloat(longitude as string),
      distance: distance as number | undefined,
      distanceUnit: distanceUnit as string | undefined,
    };
    const pickup = await this.defaultService.getPickupDetail(
      market,
      pickupPointRequestDto,
    );
    return {
      statusCode: HttpStatusCodes.OK,
      body: pickup,
    };
  }
}
