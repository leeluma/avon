import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { PaymentService } from '../services';
import { MarketInfo } from '../middlewares';
import { JsonApiResponseEntity } from '../lib';
import {
  PaymentInitResponseDto, PaymentStatusResponseDto, MagnoliaInfo, PaymentTypeDto,
} from '../dtos';

interface PaymentControllerConfig {
  paymentService: PaymentService;
}

export class PaymentController {
  private readonly paymentService: PaymentService;

  constructor(config: PaymentControllerConfig) {
    this.paymentService = config.paymentService;
  }

  /**
   * Initiate payment for a Payment
   * @param req - Request
   * @param res - Response
   * @returns Payment id and redirect URL
   */
  public initiatePayment = async (
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<PaymentInitResponseDto>> => {
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;
    const { cartId } = req.params;
    const { paymentType, marketingEmailConsent, css } = req.body;
    const { authorization, sessionkey, customerkey } = req.headers;
    const id = cartId;
    const type = paymentType as PaymentTypeDto;

    const params = {
      sessionKey: sessionkey! as string,
      customerKey: customerkey! as string,
    };
    const param = {
      authorization,
      id,
      css: css || '',
      type,
      marketingEmailConsent,
    };
    const paymentInitResponse = await this.paymentService.initiatePayment(
      magnolia,
      market,
      param,
      params,
    );

    return {
      statusCode: HttpStatusCodes.OK,
      body: paymentInitResponse,
    };
  };

  public getPaymentStatus = async (
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<PaymentStatusResponseDto>> => {
    const market = res.locals.market as MarketInfo;
    const { cartId } = req.params;
    const { authorization } = req.headers;
    const { orderNumber, transactionId } = req.body;
    const { sessionkey, customerkey } = req.headers;

    const params = {
      sessionKey: sessionkey! as string,
      customerKey: customerkey! as string,
    };

    const paymentStatusResponse = await this.paymentService.getPaymentStatus(
      market,
      authorization!,
      cartId,
      orderNumber,
      transactionId,
      params,
    );

    return {
      statusCode: HttpStatusCodes.OK,
      body: paymentStatusResponse,
    };
  };
}
