import { Request, Response } from 'express';
import i18next from 'i18next';
import HttpStatusCodes from 'http-status-codes';
import { MarketInfo } from '../middlewares';
import { ApiError, JsonApiResponseEntity } from '../lib';
import { CustomerService, CartService } from '../services';
import {
  AddressResponseDto, CommonResponse, CustomerLoginResponseDto, CustomerResponseDto,
} from '../dtos';

export interface CustomerControllerConfig {
  customerService: CustomerService;
  cartService: CartService;
}

export class CustomerController {
  private readonly customerService: CustomerService;

  private readonly cartService: CartService;

  constructor(config: CustomerControllerConfig) {
    this.customerService = config.customerService;
    this.cartService = config.cartService;
  }

  /**
   * Reset Customer's password by Token
   * @param request - Express request object
   * @param response - Express response object
   */
  public async forgotCustomersPassword(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<undefined>> {
    const market = response.locals.market as MarketInfo;
    const { email, url } = request.body;

    await this.customerService.forgotCustomersPassword(market, email, url);

    return {
      statusCode: HttpStatusCodes.ACCEPTED,
      body: undefined,
    };
  }

  /**
   * Get list of Addresses from Commerce Tool using Customer Id
   * @param request - Express request object
   * @param response - Express response object
   * @returns Customer Id with list of Addresses if it was found
   * @throws ApiError 404 if Customer id was not found
   */
  public async getDefaultAddress(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<AddressResponseDto>> {
    const market = response.locals.market as MarketInfo;
    const authHeader: string = request.headers.authorization!;
    const address = await this.customerService.getDefaultAddress(market, authHeader);
    if (!address) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.addressNotFound'));
    }

    return {
      statusCode: HttpStatusCodes.OK,
      body: address,
    };
  }

  /*
   * Get list of Addresses from Commerce Tool using Customer Id
   * @param request - Express request object
   * @param response - Express response object
   * @returns all list of Delivery Addresses  if it was found
   * @throws ApiError 404 if Delivery Addresses was not found
   */
  public async getDeliveryAddresses(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<CommonResponse>> {
    const market = response.locals.market as MarketInfo;
    const authHeader: string = request.headers.authorization!;
    const address = await this.customerService.getDeliveryAddressList(market, authHeader);
    if (!address) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.deliveryAddressNotFound'));
    }
    return {
      statusCode: HttpStatusCodes.OK,
      body: address,
    };
  }

  /**
   * Get customer details based on token from Commerce Tool
   * @param request - Express request object
   * @param response - Express response object
   * @returns Customer details
   * @throws ApiError 404 if Customer id was not found
   */
  public async getCustomerByToken(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<CustomerResponseDto>> {
    const market = response.locals.market as MarketInfo;
    const authHeader: string = request.headers.authorization!;
    const customer = await this.customerService.getCustomerDetailsByToken(market, authHeader);
    if (!customer) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.customerNotFound'));
    }

    return {
      statusCode: HttpStatusCodes.OK,
      body: customer,
    };
  }

  /**
   * Create a customer | Register user
   * @param request - Express request object
   * @param response - Express response object
   * @returns Created customer info
   */
  public async registration(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<CustomerLoginResponseDto>> {
    const { locals: { customer } } = response;
    if (customer) {
      throw new ApiError(HttpStatusCodes.UNAUTHORIZED, 'Token does not belong to anonymous session!');
    }
    const market = response.locals.market as MarketInfo;
    const customerRequestDto = request.body;
    const authHeader = request.headers.authorization!;
    const output = await this.customerService.registration(market, customerRequestDto, authHeader);
    return {
      statusCode: HttpStatusCodes.CREATED,
      body: output,
    };
  }
}
