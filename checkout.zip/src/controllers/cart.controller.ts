import { Request, Response } from 'express';
import i18next from 'i18next';
import HttpStatusCodes from 'http-status-codes';
import { CartService, CustomerService } from '../services';
import { MarketInfo } from '../middlewares';
import {
  MagnoliaInfo, ShippingMethodsResponseDto, CartDto, CartResponse, CartShippingMethodDto, AddressRequestDto,
} from '../dtos';
import { JsonApiResponseEntity, ApiError } from '../lib';

interface CartControllerConfig {
  cartService: CartService;
  customerService: CustomerService;
}

export class CartController {
  private readonly cartService: CartService;

  private readonly customerService: CustomerService;

  constructor(config: CartControllerConfig) {
    this.cartService = config.cartService;
    this.customerService = config.customerService;
  }

  /**
   * Shipping Method controller implementation
   * @param req - Request
   * @param res - Response
   * @returns shipping method body and Status code
   */
  public getShippingMethods = async (
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<ShippingMethodsResponseDto>> => {
    const market = res.locals.market as MarketInfo;
    const { deliveryType } = req.query;
    const shoppingMethodCart = await this.cartService.getShippingMethods(market, deliveryType as string);
    return {
      statusCode: HttpStatusCodes.OK,
      body: shoppingMethodCart,
    };
  };

  /**
   * Adds shipping method in cart
   * @param req Request
   * @param res Response
   * @returns Cart Data
   */
  public addShippingMethod = async (
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<CartShippingMethodDto>> => {
    const market = res.locals.market as MarketInfo;
    const { cartId } = req.params;
    const { shippingMethodId } = req.body;
    const authHeader: string = req.headers.authorization!;

    const updatedCartWithShippingMethod = await this.cartService.addShippingMethod(
      market,
      cartId,
      shippingMethodId,
      authHeader,
    );
    return {
      statusCode: HttpStatusCodes.OK,
      body: updatedCartWithShippingMethod,
    };
  };

  /**
   * Sets shipping address in cart
   * address can be updated in two entities customer and cart.
   * if cusomter object exists from auth we will add or update cart shipping address to customer.
   * addressId is a exists customer address id
   * addressFidnerId is a id provided by address validation API (address autocomplete).
   *
   * @param request Request
   * @param response Response
   * @returns Cart Data
   */
  public setShippingAddress = async (
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<CartDto>> => {
    const market = response.locals.market as MarketInfo;
    const magnolia = response.locals.magnolia as MagnoliaInfo;
    const addressRequestDto: AddressRequestDto = request.body;
    const { cartId } = request.params;
    const { customer } = response.locals;
    const {
      addressFinderId, addressId, updateCustomer,
    } = addressRequestDto;
    const authToken = String(request.headers.authorization || '');

    let cart: CartDto;
    if (addressFinderId) {
      cart = await this.cartService
        .setShippingAddressFromFinder(
          market,
          magnolia,
          cartId,
          authToken,
          customer,
          addressRequestDto,
        );
    } else if (addressId) {
      cart = await this.cartService
        .setShippingAddressFromCustomerId(
          market,
          magnolia,
          cartId,
          authToken,
          customer,
          addressRequestDto,

        );
    } else {
      cart = await this.cartService
        .setShippingAddress(
          market,
          magnolia,
          cartId,
          authToken,
          customer,
          addressRequestDto,
        );
    }

    if (customer && cart.shippingAddress && !!updateCustomer) {
      if (addressId) {
        cart.shippingAddress.id = addressId;
        await this.customerService.updateAddress(market, customer, addressId, cart.shippingAddress);
      } else {
        const customerResponse = await this.customerService.addAddress(market, customer, cart.shippingAddress);
        const address = customerResponse.addresses.find((item) => item.currentAddress === true);
        cart.shippingAddress.id = address?.id;
      }
    }

    return {
      statusCode: HttpStatusCodes.OK,
      body: cart,
    };
  };

  /**
   * Get cart by id
   * @param req - Request
   * @param res - Response
   * @returns Cart details
   */
  public getCartById = async (
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<CartResponse>> => {
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;
    const { id } = req.params;
    const authHeader: string = req.headers.authorization!;
    const cart = await this.cartService.getCartById(market, magnolia, id, authHeader);
    if (cart === undefined) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('error.cartIdNotFound', { id }));
    }
    return {
      statusCode: HttpStatusCodes.OK,
      body: cart,
    };
  };
}
