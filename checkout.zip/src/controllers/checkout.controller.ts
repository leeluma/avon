import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { MagnoliaService } from '../services/magnolia.service';
import { MarketInfo } from '../middlewares';
import { JsonApiResponseEntity } from '../lib';
import { CommonResponse, MagnoliaInfo } from '../dtos';

interface CheckoutControllerConfig {
  magnoliaService: MagnoliaService;
}

/**
 * `CheckoutController` representing `checkout`
 */
export class CheckoutController {
  private readonly magnoliaService: MagnoliaService;

  /**
   * Constructor for `ProductController` class
   * @param config injects dependencies into the object
   */
  constructor(config: CheckoutControllerConfig) {
    this.magnoliaService = config.magnoliaService;
  }

  /**
   * Get Checkout magnolia data
   * @param req - Express request object
   * @param res - Express response object
   * @returns Promise
   */
  public async getCheckoutPageData(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<CommonResponse>> {
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;
    const [globalSettings, staticPageData] = await Promise.all([
      this.magnoliaService.getGlobalSettingsData(market, magnolia),
      this.magnoliaService.getCheckoutPageData(market, magnolia),
    ]);
    let magnoliaTemplateData = {};
    if (magnolia.isPreview) {
      magnoliaTemplateData = await this.magnoliaService.getTemplateData(staticPageData
        && staticPageData['mgnl:template'], magnolia.url);
    }
    const responseData = {
      ...staticPageData,
      globalSettings,
      templateDefinition: magnoliaTemplateData,
    };
    return {
      statusCode: HttpStatusCodes.OK,
      body: responseData,
    };
  }
}
