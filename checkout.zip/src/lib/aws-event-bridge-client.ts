import AWS from 'aws-sdk';
import HttpStatusCodes from 'http-status-codes';
import { logger } from './logger';
import { logError } from './common';
import { ApiError } from './api-error';

const AWS_EVENT_BRIDGE_RESOURCE_NAME = 'leap';

export interface AwsEventBridgeClientConfig {
  region: string;
}

export enum AwsEventBridgeSource {
  passwordResetQueue = 'passwordResetQueue',
  marketingNotifications = 'marketingNotifications'
}

export class AwsEventBridgeClient {
  private readonly MAX_RETRIES = process.env.MAX_RETRIES || 3;

  private readonly region: string;

  /**
   * @example
   *    const awsClient = new AwsClient({eventBusName,region});
   * @param config Configuration variables.
   */
  constructor(config: AwsEventBridgeClientConfig) {
    this.region = config.region;
  }

  /**
   * Put a single event in aws EventBridge
   * @param eventBusName - string EventBus name
   * @param source - string Source key, e.g. passwordResetQueue
   * @param detail - any A JS object that will be stringified and sent to the EventBus
   */
  async putEvent(
    eventBusName: string,
    source: AwsEventBridgeSource,
    detail: any,
  ): Promise<void> {
    const eventBridge = new AWS.EventBridge({
      region: this.region,
    });

    let tryCount = 1;

    while (tryCount <= this.MAX_RETRIES) {
      try {
        const data: AWS.EventBridge.PutEventsRequest = {
          Entries: [
            {
              EventBusName: eventBusName,
              Source: source,
              DetailType: source,
              Resources: [AWS_EVENT_BRIDGE_RESOURCE_NAME],
              Time: new Date(),
              Detail: JSON.stringify(detail),
            },
          ],
        };

        logger.info(`EventBridge Request (attempt ${tryCount}/${this.MAX_RETRIES}): ${JSON.stringify(data)}`);

        // eslint-disable-next-line no-await-in-loop
        const result = await eventBridge.putEvents(data).promise();

        logger.info(`EventBridge Response: ${JSON.stringify(result)}`);

        if (result.FailedEntryCount === 0) {
          return;
        }
      } catch (error: any) {
        logError('AwsEventBridgeClient', 'Failed to put message', error);
      }
      tryCount += 1;
    }

    throw new ApiError(
      HttpStatusCodes.INTERNAL_SERVER_ERROR,
      `Failed to send EventBridge event after ${this.MAX_RETRIES} tries. Detail: ${JSON.stringify(detail)}`,
    );
  }
}
