export const MARKET = '{{market}}';
