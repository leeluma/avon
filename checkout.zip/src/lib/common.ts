import { inspect } from 'util';
import { logger } from './logger';
import { config } from '../config';

if (!config.logLevel) {
  throw new Error('Missing "logLevel" in config (should be read from LOG_LEVEL env var)');
}

export const addressCustomTypeKey = 'address-type';

/**
 * Log a JavaScript Error object. This function sanitizes the Error a bit
 * before printing it (removes req/res in case the Error comes from axios)
 * and supports circular references.
 * @param source - string A keyword describing the context where the error happened (eg, PaymentService)
 * @param reason - string What happened (eg, failed to initiate payment)
 * @param error - any Should be an Error object
 */
export const logError = (
  source: string,
  reason: string,
  error: any,
): void => {
  if (config.logLevel !== 'trace') {
    logger.error(`${source} ERROR: ${reason} because:\n${error}`);
    return;
  }

  const cleanError: any = {
    ...error,
    stack: error.stack,
    message: error.message,
  };

  /* Remove fields we don't care about, because many errors contain
     the HTTP request and response objects, but they are complicated,
     and we rarely care to see what's in them */
  delete cleanError.req;
  delete cleanError.res;
  delete cleanError.request;
  delete cleanError.response;

  const stringError = inspect(cleanError, { depth: 10 });

  logger.error(`${source} ERROR: ${reason} because:\n${stringError}`);
};

/**
   * It used to convert object parameters to query string.
   *
   * @param params
   * @returns
   */
export const queryString = (params: Record<string, any>): string => {
  const removeUndefined = JSON.parse(JSON.stringify(params));
  return Object.entries(removeUndefined).map(
    ([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value as string)}`,
  ).join('&');
};

export const constructUrl = (baseUrl: string, path: string): string => {
  return new URL(path, baseUrl).toString();
};
