/**
 * This is a wrapper for log4js
 */
import log4js from 'log4js';
import { config } from 'dotenv';

config();

const LOG_LEVEL = (process.env.LOG_LEVEL || 'off').toLowerCase();

log4js.configure({
  appenders: {
    console: { type: 'console' },
  },

  categories: {
    default: { appenders: ['console'], level: LOG_LEVEL },
  },
});

const logger = log4js.getLogger();

if (!process.env.LOG_LEVEL) {
  // eslint-disable-next-line no-console
  console.warn('Missing LOG_LEVEL environment variable. Defaulting to "off". You will not see any logs.');
}

export { logger };
