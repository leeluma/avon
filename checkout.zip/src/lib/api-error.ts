import HttpStatusCodes, { getReasonPhrase } from 'http-status-codes';

/* Explicitly define this type as "any" */
type ApiErrorMessage = any;

/**
 * An error that can be thrown to send a message to the user of the API.
 * Be EXTREMELY CAREFUL about what data is included in the message.
 * The message MUST be i18n.
 */
export class ApiError extends Error {
  /**
   * HTTP status code
   */
  public readonly statusCode: number;

  /**
   * The original error message provided.
   * This could be any type of object to be sent to the front-end.
   */
  // TODO Rename this to originalMessage after it's no longer being used in external code
  public readonly messagesArray: ApiErrorMessage;

  constructor(
    statusCode: number = HttpStatusCodes.INTERNAL_SERVER_ERROR,
    message: ApiErrorMessage = undefined,
  ) {
    if (!message) {
      super(getReasonPhrase(statusCode));
    } else if (typeof message === 'string') {
      super(message);
    } else {
      super(JSON.stringify(message));
    }

    this.messagesArray = message;
    this.statusCode = statusCode;
  }
}
