import {
  Cart, Product, LineItem, Price,
} from '@commercetools/platform-sdk';
import { GraphQLOrder, PromotionDto, GraphQLDiscountCode } from '../dtos/order.dto';
import {
  ATTRIBUTE_NAMES, ATTRIBUTE_VALUES, MEASUREMENT, DEFAULT_QUANTITY, CATEGORY_TYPE, VARIANT_ATTRIBUTES,
} from '../common/constants';
import {
  PriceFormat, VariantAttribute, DetailResponseDto,
  ImageDto, ShippingInfoDto, ShippingInfo, OffersDto, GraphQLLineItem, GraphQLCart, AddressRequestDto,
} from '../dtos';
import { MarketInfo } from './utils';

/**
 * function to convert number to decimal in given fraction
 * @param amount - Given amount
 * @param fraction - Given fraction
 * @returns
 */
export const priceConverter = (amount:number, fraction:number) => {
  const denominator = DEFAULT_QUANTITY.BASE_NUMBER ** fraction; // Ma th.pow(10, fraction);
  return (amount / denominator).toFixed(fraction);
};

/**
  * Get Formatted Magnolia Price
  * @param price - List of prices
  * @param priceFormat - Magnolia Price Format
  * @returns Magnolia Formatted Price
  */
export const magnoliaPriceFormatter = (price: number, priceFormat: PriceFormat): string => {
  let calculatedPrice = '';
  const numberTen = 10;
  const currency: string = priceFormat.ccy;
  const showDecimalZero = Boolean(priceFormat.showDecimalZero ?? false);
  const noOfDigitAtLast = Number(priceFormat.noOfDigit ?? 0);
  const decimalPoint: string = priceFormat.decimalPoint ?? '.';
  const thousandSeparator: string = priceFormat.thousandSeperator ?? '';
  const currencyPlacement: string = priceFormat.currencyPlacement ?? 'after';
  const lastDigitNo: number = numberTen ** noOfDigitAtLast;
  const sellPrice = (price / lastDigitNo).toFixed(noOfDigitAtLast);
  const parts = sellPrice.toString().split('.');
  const calculation = parts[1] ? decimalPoint + parts[1] : '';
  const returnPrice = showDecimalZero === true ? (parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator)
    + calculation) : parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator);
  calculatedPrice = (currencyPlacement === 'before')
    ? `${currency} ${returnPrice}` : `${returnPrice} ${currency}`;
  return calculatedPrice;
};

/**
   * @param attributes all variant attributes
   * @param sellPrice : variant sell price after discount
   * @param locale : market locale
   * @returns : string with unit price measurement
   */
export const getUnitPrice = (
  attributes:VariantAttribute[],
  sellPrice:number,
  priceFormat: PriceFormat,
):string => {
  let allBaseNodes: any[];
  let measuredValue;
  let result = '';
  let formattedPrice;
  const unitFillMeasureObj = attributes.find((value) => value.name === ATTRIBUTE_NAMES.contentFillMeasurement);
  const unitFillValueObj = attributes.find((value) => value.name === ATTRIBUTE_NAMES.contentFill);
  const unitFillMeasure = ((typeof unitFillMeasureObj !== 'undefined')
      && (ATTRIBUTE_VALUES.attributeValue in unitFillMeasureObj)) ? unitFillMeasureObj.value.key : '';
  const unitFillValue = ((typeof unitFillValueObj !== 'undefined')
      && (ATTRIBUTE_VALUES.attributeValue in unitFillValueObj)) ? unitFillValueObj.value : '';
  const allNodes: any = {};
  /* istanbul ignore else */
  if (Object.keys(priceFormat).length > 0 && (unitFillMeasure !== '') && (unitFillValue !== '')) {
    // normalizing unit price json response
    if (MEASUREMENT.baseMeasure in priceFormat) {
      if (MEASUREMENT.nodes in priceFormat.baseMeasure) {
        allBaseNodes = priceFormat.baseMeasure[MEASUREMENT.nodes];
        allBaseNodes.forEach((key) => {
          allNodes[priceFormat.baseMeasure[key].unitType] = priceFormat.baseMeasure[key];
          return allNodes;
        });
      }
    }
    // get Unit Price Measurement details
    if (unitFillMeasure in allNodes) {
      if (unitFillValue > allNodes[unitFillMeasure].containerSizeLimit) {
        measuredValue = sellPrice * (allNodes[unitFillMeasure].unitPriceBaseMeasure / unitFillValue);
        formattedPrice = magnoliaPriceFormatter(Math.round(measuredValue), priceFormat);
        result = `${formattedPrice} per ${allNodes[unitFillMeasure].unitPriceBaseMeasure}`
            + `${allNodes[unitFillMeasure].translation}`;
      }
    }
  }
  return result;
};

/**
   * Maps promotion
   * @param order GraphQLOrder
   * @returns promotion data
   */
export const promotionToDto = (
  order: GraphQLOrder | GraphQLCart,
  priceFormat: PriceFormat,
  discountCode: GraphQLDiscountCode | undefined,
): PromotionDto | undefined => {
  let promotionId = '';
  let promotionCode;
  let promotionState: string | undefined;
  let totalPromotionAmount = 0.0;
  let promotionApplied = false;
  /* istanbul ignore else */
  if (Array.isArray(order.discountCodes) && order.discountCodes[0]) {
    promotionState = order.discountCodes[0].state;
    promotionId = order.discountCodes[0].discountCode.id;
    const codes = order.discountCodes.map((discount) => discount.discountCode.code);
    promotionCode = codes.join(', ');
    /* istanbul ignore else */
    if (order.discountCodes[0].state === 'MatchesCart') {
      promotionApplied = true;
    }

    order.lineItems.forEach((lineItem) => {
      /* istanbul ignore else */
      if (
        Array.isArray(lineItem.discountedPricePerQuantity)
          && lineItem.discountedPricePerQuantity.length
      ) {
        lineItem.discountedPricePerQuantity.forEach((discount) => {
          discount.discountedPrice.includedDiscounts.forEach((element) => {
            // Comparing cart-discount id at line item level with cart-discount in discount code
            // As this code is supposed to tally savings through discount codes.
            if (element.discount.id === discountCode?.cartDiscountRefs[0].id) {
              totalPromotionAmount
                += element.discountedAmount.centAmount * discount.quantity;
            }
          });
        });
      }
    });
  }
  const promotionDto: PromotionDto = {
    promotionId,
    promotionCode,
    promotionAmount: Number(
      priceConverter(
        totalPromotionAmount,
        order.totalPrice.fractionDigits,
      ),
    ),
    formattedPromotionAmount: magnoliaPriceFormatter(totalPromotionAmount, priceFormat),
    promotionState,
    promotionApplied,
  };
  return promotionDto;
};

/**
 * Maps cart promotion
 * @param cart - any
 * @returns
 */
export const cartPromotionToDto = (
  cart: Cart,
  priceFormat: PriceFormat,
  isFormattedAmount = true,
): PromotionDto | undefined | number => {
  let promotionId = '';
  const promotionCode = '';
  let promotionState: string | undefined;
  let totalPromotionAmount = 0.0;
  let promotionApplied = false;
  /* istanbul ignore else */
  if (Array.isArray(cart.discountCodes) && cart.discountCodes[0]) {
    promotionState = cart.discountCodes[0].state;
    promotionId = cart.discountCodes[0].discountCode.id;
    if (cart.discountCodes[0].state === 'MatchesCart') {
      promotionApplied = true;
    }
    cart.lineItems.forEach((lineItem) => {
      /* istanbul ignore else */
      if (Array.isArray(lineItem.discountedPricePerQuantity) && lineItem.discountedPricePerQuantity.length) {
        lineItem.discountedPricePerQuantity.forEach((discount) => {
          discount.discountedPrice.includedDiscounts.forEach((element) => {
            totalPromotionAmount += element.discountedAmount.centAmount * discount.quantity;
          });
        });
      }
    });
  }
  if (!isFormattedAmount) {
    return totalPromotionAmount;
  }
  const promotionDto: PromotionDto = {
    promotionId,
    promotionCode,
    promotionAmount: Number(priceConverter(totalPromotionAmount, cart.totalPrice.fractionDigits)),
    formattedPromotionAmount: magnoliaPriceFormatter(totalPromotionAmount, priceFormat),
    promotionState,
    promotionApplied,
  };
  return promotionDto;
};

/**
 * function to convert number to decimal in given fraction with currency
 * @param amount - Given amount
 * @param fraction - Given fraction
 * @param fraction - Given fraction
 * @param fraction - Given fraction
 * @returns formatted amount with currency
 */
export const priceConverterWithCurrency = (
  amount:number,
  fraction:number,
  currencyCode: string,
  currencyPlacement: string,
) => {
  const denominator = DEFAULT_QUANTITY.BASE_NUMBER ** fraction;
  const price = (amount / denominator).toFixed(fraction);
  return (currencyPlacement === 'before') ? `${currencyCode} ${price}` : `${price} ${currencyCode}`;
};

/**
   * Maps Line Item to Image DTO
   * @param lineItem - any
   * @returns
   */
export const imageToDto = (lineItem): ImageDto[] => lineItem.variant.images.map((image) => {
  const imageDto: ImageDto = {
    label: image.label,
    url: image.url,
    width: image.dimensions.w,
    height: image.dimensions.h,
  };
  return imageDto;
});

/**
   * Maps shipping method info
   * @param shippingInfo - shippingInfo
   * @returns Shipping method info
   */
export const shippingInfoToDto = (
  shippingInfo: ShippingInfo,
  priceFormat: PriceFormat,
): ShippingInfoDto => {
  const shippingMethodName = shippingInfo.shippingMethodName ? shippingInfo.shippingMethodName : '';
  const shippingMethodPrice = (shippingInfo.price && shippingInfo.price.centAmount)
    ? magnoliaPriceFormatter(shippingInfo?.price?.centAmount, priceFormat) : '0';
  return { shippingMethodName, shippingMethodPrice };
};

/**
   * Maps missing offer info
   * @param productDetails - productDetails
   * @param productId - productId
   * @returns missing offer details
   */
export const getProductOffer = (productDetails: Product[], productId: string, market: MarketInfo): OffersDto[] => {
  const offerArray: OffersDto[] = [];

  // missed offer details
  /* istanbul ignore else */
  if (productDetails && productDetails.length > 0) {
    for (let index = 0; index < productDetails.length; index += 1) {
      /* istanbul ignore else */
      if (productDetails[index].id === productId) {
        let offerObj: OffersDto;
        productDetails[index].masterData.current.categories.forEach((category: any) => {
          /* istanbul ignore else */
          if (category?.custom && category?.custom.customFieldsRaw[0].value === CATEGORY_TYPE.offer) {
            offerObj = {
              key: category.key,
              displayName: category.name ? category.name : '',
              url: category.slug ? `/${market.country.toLocaleLowerCase()}/offers/${category.slug}` : '',
              description: category.description
                ? category.description : '',
            };
            offerArray.push(offerObj);
          }
        });
      }
    }
  }
  return offerArray;
};

/**
   * maps attributes
   * @param attributes
   */
export const getProductAttributes = (attributes) => {
  const variantArr = attributes.map((attribute) => {
    if (attribute.name === VARIANT_ATTRIBUTES.variantType
        || attribute.name === VARIANT_ATTRIBUTES.variantValue
        || attribute.name === VARIANT_ATTRIBUTES.hexCode
        || attribute.name === VARIANT_ATTRIBUTES.maxPurchasableQty
        || attribute.name === VARIANT_ATTRIBUTES.discontinued) {
      return { [attribute.name]: attribute?.value?.key ? attribute?.value?.label : attribute?.value };
    }
    return undefined;
  });
  return Object.assign({}, ...variantArr);
};
/**
   * maps address fields
   * @param recipientName * @param addressRequestDto
   */
export const mapAddressFields = (recipientName, addressRequestDto: AddressRequestDto) => {
  return {
    RecipientName: recipientName,
    Address1: addressRequestDto.address1,
    Address2: addressRequestDto.address2,
    Address3: addressRequestDto.address3,
    Address4: addressRequestDto.address4,
    county: addressRequestDto.county,
    Latitude: addressRequestDto.latitude,
    Longitude: addressRequestDto.longitude,
  };
};

/**
   * maps address fields
   * @param recipientName * @param addressRequestDto
   */
export const mapAddressDraftFields = (addressDetail: DetailResponseDto) => {
  return {
    RecipientName: addressDetail.recipientName,
    Address1: `${addressDetail.streetName || ''} ${addressDetail.houseNumber || ''}`.trim(),
    Address2: `${addressDetail.floor || ''} ${addressDetail.flat || ''}`.trim(),
    Address3: addressDetail.district1,
    Address4: undefined,
    county: addressDetail.region1,
    Latitude: addressDetail.latitude,
    Longitude: addressDetail.longitude,
  };
};
/**
   * maps address fields
   * @param recipientName * @param addressRequestDto
   */
export const mapShippingAddress = (addressRequestDto: AddressRequestDto, country : string) => {
  return {
    country,
    city: addressRequestDto.city,
    region: addressRequestDto.region,
    postalCode: addressRequestDto.zip,
    state: addressRequestDto.state,
    phone: addressRequestDto.phoneNumber,
    firstName: addressRequestDto.firstName,
    lastName: addressRequestDto.lastName,
  };
};

/**
   * Get shipping info data
   * @param shippingInfo ShippingInfo
   * @returns ShippingInfoDto
   */
export const getShippingInfo = (
  shippingInfo: ShippingInfo | undefined,
  priceFormat: PriceFormat,
): ShippingInfoDto | undefined => {
  if (shippingInfo === undefined || shippingInfo === null) {
    return undefined;
  }
  return {
    shippingMethodName: shippingInfo.shippingMethodName,
    shippingMethodPrice: magnoliaPriceFormatter(shippingInfo.price.centAmount, priceFormat),
    shippingPrice: shippingInfo.price.centAmount,
  };
};

/**
 * Function to return specific field value
 */
export const getCustomFieldData = (
  custom,
  fieldName: string,
): string | undefined => {
  if (custom === undefined || custom === null) {
    return undefined;
  }
  let fieldValue;
  custom.customFieldsRaw.forEach((field) => {
    if (field.name === fieldName) {
      fieldValue = field.value;
    }
  });
  return fieldValue;
};

/**
 * Map cart line item product ids in string
 * @param lineItems cart line item
 * @returns string of all product ids
 */
export const getCartProductId = (lineItems: LineItem[] | GraphQLLineItem[]): string => {
  return lineItems.map((lineItem) => {
    return `"${lineItem.productId}"`;
  }).join(', ');
};

export const calculateOfferSavings = (
  lineItem: LineItem | GraphQLLineItem,
  discountCode: GraphQLDiscountCode | undefined,
): number => {
  let totalOfferAmount = 0.0;
  let totalPromoAmount = 0.0;
  const lineItemQuantity = lineItem.quantity;
  if (Array.isArray(lineItem.discountedPricePerQuantity) && lineItem.discountedPricePerQuantity.length) {
    lineItem.discountedPricePerQuantity.forEach((discount) => {
      discount.discountedPrice.includedDiscounts.forEach((element) => {
        // Comparing cart-discount id at line item level with cart-discount in discount code
        // As this code is supposed to tally savings through discount codes.
        if (discountCode !== undefined && element.discount.id !== discountCode?.cartDiscountRefs[0].id) {
          totalOfferAmount += element.discountedAmount.centAmount * discount.quantity;
        } else {
          totalPromoAmount += element.discountedAmount.centAmount * discount.quantity;
        }
      });
    });
  } else {
    return 0.0;
  }
  const discountPerQuantity = (totalOfferAmount + totalPromoAmount) / lineItemQuantity;
  return Number(priceConverter(discountPerQuantity, lineItem.totalPrice.fractionDigits));
};
/**
   * Check if product price have discount property then return sell price after applied promotion
   * if discount property not available then return empty object
   * @param price  - All price details including promotional prices
   * @returns - sellPrice and isPromotionApplied
   */

export const checkDiscount = (
  price: Price,
) => {
  if (Object.prototype.hasOwnProperty.call(price, 'discounted') && price.discounted) {
    return {
      sellPrice: priceConverter(price.discounted.value.centAmount, price.discounted.value.fractionDigits),
      listPrice: priceConverter(price.value.centAmount, price.value.fractionDigits),
      sellPriceCT: price.discounted.value.centAmount,
      listPriceCT: price.value.centAmount,
      isPromotionApplied: true,
    };
  }
  return {
    sellPrice: priceConverter(price.value.centAmount, price.value.fractionDigits),
    listPrice: priceConverter(price.value.centAmount, price.value.fractionDigits),
    sellPriceCT: price.value.centAmount,
    listPriceCT: price.value.centAmount,
    isPromotionApplied: false,
  };
};

export const mapLineItem = (
  item: GraphQLLineItem,
  salePriceAfterOffer: number,
  listPrice: string,
  listPriceCT: number,
  priceFormat: PriceFormat,
  variantAttributes: any,
) => {
  return {
    variantKey: item.variant.key,
    lineItemId: item.id,
    productId: item.productId,
    productSlug: item.productSlug,
    name: item.name,
    skuCode: item.variant.sku,
    images: item.variant.images,
    sellPrice: salePriceAfterOffer,
    listPrice: Number(listPrice),
    formattedListPrice: magnoliaPriceFormatter(listPriceCT, priceFormat),
    formattedSellPrice: magnoliaPriceFormatter(
      (salePriceAfterOffer * (DEFAULT_QUANTITY.BASE_NUMBER ** item.totalPrice.fractionDigits)),
      priceFormat,
    ),
    unitPrice: getUnitPrice(
    item.variant.attributesRaw as [],
    Number((salePriceAfterOffer * (DEFAULT_QUANTITY.BASE_NUMBER ** item.totalPrice.fractionDigits))),
    priceFormat,
    ),
    quantity: item.quantity,
    totalPrice: (item.totalPrice.centAmount
  / (DEFAULT_QUANTITY.BASE_NUMBER ** (item.totalPrice.fractionDigits))),
    currencyCode: item.totalPrice.currencyCode,
    variantType: variantAttributes.variantType ?? '',
    variantValue: variantAttributes.variantValue ?? '',
    hexCode: variantAttributes.hexCode ?? '',
  };
};
