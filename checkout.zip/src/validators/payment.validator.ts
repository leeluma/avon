import { body } from 'express-validator';
import { validateCartId } from './cart.validation';

export const validateInitiatePayment = [
  ...validateCartId,

  body('paymentType')
    // See dtos/payment.dto.ts
    .matches(/^(online|CashOnDelivery)$/)
    .withMessage('validationError.paymentType'),

  body('marketingEmailConsent')
    .optional()
    .isBoolean({ strict: true })
    .withMessage('validationError.marketingEmailConsent'),

  body('css')
    .optional()
    .isString()
    .withMessage('validationError.css'),
];

export const validatePaymentStatus = [
  ...validateCartId,

  body('orderNumber')
    .isString()
    .withMessage('validationError.orderNumber'),

  body('transactionId')
    .isString()
    .withMessage('validationError.transactionId'),
];
