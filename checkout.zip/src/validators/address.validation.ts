import { query } from 'express-validator';

export const validateAddressId = [
  query('addressId')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.addressIdMandatory'),
];

export const validateAddress = [
  query('address')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.addressIsMandatory'),
];
