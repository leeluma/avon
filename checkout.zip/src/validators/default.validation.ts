import {
  body, header, query,
} from 'express-validator';

export const validateCustomerLogin = [
  body('cartId')
    .if(body('cartId').notEmpty())
    .isUUID()
    .withMessage('validationError.cartInvalid'),
  body('password')
    .trim()
    .notEmpty().withMessage('validationError.passwordIsMandatory'),
];

export const validatePickupDetail = [
  query('latitude')
    .exists({ checkNull: true })
    .isFloat({ min: 0, max: 360 })
    .withMessage('validationError.latitudeShouldBeValid'),
  query('longitude')
    .exists({ checkNull: true })
    .isFloat({ min: 0, max: 360 })
    .withMessage('validationError.longitudeShouldBeValid'),
  query('distance')
    .isNumeric()
    .withMessage('datatype.number')
    .isFloat({ min: 1 })
    .withMessage('validationError.distanceShouldBeValid')
    .optional(),
  query('distanceUnit')
    .isIn(['KM', 'mile'])
    .withMessage('validationError.distanceUnitShouldBeValid')
    .optional(),
];

export const validateNotifications = [
  header('sessionkey').notEmpty().withMessage('common.blank').isUUID()
    .withMessage('datatype.uuid'),
  header('customerkey').notEmpty().withMessage('common.blank').isUUID()
    .withMessage('datatype.uuid'),
];
