import { header, param } from 'express-validator';

export const validateOrderIdAndBearerToken = [
  param('orderId')
    .exists({ checkNull: true, checkFalsy: true })
    .isUUID()
    .withMessage('validationError.idMustExistAndValidUuid'),
  header('Authorization').notEmpty().withMessage('validationError.authorizationRequired'),
];
