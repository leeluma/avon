import { body, param } from 'express-validator';

export const validateAddToCart = [
  body('cartId')
    .optional({ checkFalsy: true })
    .isUUID()
    .withMessage('validationError.cartInvalid'),
  body('lineItems.sku')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.skuMandatory'),
  body('lineItems.quantity')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.lineItemQuantityMandatory'),
  body('lineItems.quantity')
    .if(body('lineItems.quantity').notEmpty())
    .isInt({ min: 1, max: 2000 })
    .withMessage('validationError.lineItemQuantityInvalid'),
];

export const validateCartId = [
  param('cartId')
    .exists({ checkNull: true, checkFalsy: true })
    .isUUID()
    .withMessage('validationError.cartInvalid'),
];

export const validateDeleteLineItem = [
  param('cartId')
    .exists({ checkNull: true, checkFalsy: true })
    .isUUID()
    .withMessage('validationError.cartInvalid'),
  param('lineItemId')
    .exists({ checkNull: true, checkFalsy: true })
    .isUUID()
    .withMessage('validationError.lineItemIdInvalid'),
];

export const validateUpdateLineItem = [
  param('cartId')
    .if(param('cartId').notEmpty())
    .isUUID()
    .withMessage('validationError.cartInvalid'),
  param('lineItemId')
    .if(param('lineItemId').notEmpty())
    .isUUID()
    .withMessage('validationError.lineItemIdInvalid'),
  body('quantity')
    .if(body('quantity').notEmpty())
    .isInt({ min: 1, max: 2000 })
    .withMessage('validationError.lineItemQuantityInvalid'),
  param('cartId')
    .exists({ checkNull: true })
    .withMessage('validationError.cartIdMandatory'),
  param('lineItemId')
    .exists({ checkNull: true })
    .withMessage('validationError.lineItemIdMandatory'),
  body('quantity')
    .exists({ checkNull: true })
    .withMessage('validationError.lineItemQuantityMandatory'),
];

export const validateAddCartPromotion = [
  param('cartId')
    .if(param('cartId').notEmpty())
    .isUUID()
    .withMessage('validationError.cartInvalid'),
  param('cartId')
    .exists({ checkNull: true })
    .withMessage('validationError.cartIdMandatory'),
  body('promotionCode')
    .if(body('action').equals('applyPromotion'))
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.promotionCodeMandatoryApplyPromotion'),
  body('promotionId')
    .if(body('action').equals('removePromotion'))
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.promotionIdMandatoryRemovePromotion'),
  body('action')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.promotionActionMandatory')
    .if(body('action').notEmpty())
    .isString()
    .withMessage('validationError.promotionActionMustBeString')
    .if(body('action').isString())
    .isIn(['applyPromotion', 'removePromotion'])
    .withMessage('validationError.promotionInvalidValue'),
];

export const validateAddShippingMethod = [
  param('cartId')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('cart.cartId')
    .isUUID()
    .withMessage('cart.cartIdUuid'),
  body('shippingMethodId')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('cart.shippingMethodId')
    .isUUID()
    .withMessage('cart.shippingMethodIdUuid'),
];

export const validateSetCartAddress = [
  param('cartId')
    .if(param('cartId').notEmpty())
    .isUUID()
    .withMessage('validationError.cartInvalid'),
  param('cartId')
    .exists({ checkNull: true })
    .withMessage('validationError.cartIdMandatory'),
  body('addressType')
    .isIn(['Pickup', 'Delivery'])
    .withMessage('validationError.addressTypeShouldBeValid')
    .optional(),
];
