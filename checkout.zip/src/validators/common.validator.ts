import { check, header, param } from 'express-validator';

export const validateId = [
  param('id')
    .exists({ checkNull: true, checkFalsy: true })
    .isUUID()
    .withMessage('validationError.idMustExistAndValidUuid'),
];

export const validateRefreshToken = [
  header('refreshtoken').notEmpty().withMessage('common.notEmpty'),
];

export const fieldValidator = (fieldName: string) => check(fieldName).custom(async (value, { req }) => {
  const {
    [fieldName]: {
      required,
      regex,
      regexMsg,
      blankMsg,
      invalidMsg,
      notMatchMsg,
    },
  } = (req as any).validationSettings;

  if (req.body.addressFinderId) {
    if (value && regex && fieldName === 'phoneNumber' && !value.match(regex)) {
      const msg = invalidMsg ?? regexMsg;
      throw new Error(msg);
    }
    return true;
  }

  if (req.body.addressId) {
    if (value && regex && fieldName === 'phoneNumber' && !value.match(regex)) {
      const msg = invalidMsg ?? regexMsg;
      throw new Error(msg);
    }
    return true;
  }

  if (!value && required) {
    throw new Error(required);
  }
  if (!value && blankMsg) {
    throw new Error(blankMsg);
  }

  if (value && regex && !value.match(regex)) {
    const msg = invalidMsg ?? regexMsg;
    throw new Error(msg);
  }

  if (value && fieldName === 'confirmPassword' && req.body.password) {
    if (value !== req.body.password) {
      throw new Error(notMatchMsg);
    }
  }
  return true;
});
