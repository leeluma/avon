import dotenv from 'dotenv';

dotenv.config();
export const config = {
  env: process.env.NODE_ENV,
  projectName: process.env.npm_package_name,
  projectVersion: process.env.npm_package_version,

  apiUrl: process.env.API_CONTEXT_PATH,
  apiContextPath: process.env.API_CONTEXT_PATH,
  apiVersion: process.env.API_VERSION,
  port: parseInt(process.env.API_PORT || '0', 10),
  logLevel: (process.env.LOG_LEVEL || 'off').toLowerCase(),

  magnoliaBasePath: process.env.MAGNOLIA_BASE_PATH,
  previewMagnoliaBasePath: process.env.PREVIEW_MAGNOLIA_BASE_PATH,

  ctRO: {
    projectKey: process.env.CT_PROJECT_KEY_RO,
    clientId: process.env.CT_CLIENT_ID_RO,
    clientSecret: process.env.CT_CLIENT_SECRET_RO,
  },
  ctPH: {
    projectKey: process.env.CT_PROJECT_KEY_PH,
    clientId: process.env.CT_CLIENT_ID_PH,
    clientSecret: process.env.CT_CLIENT_SECRET_PH,
  },
  ctMarkets: process.env.CT_ACTIVE_MARKETS,
  ctApiEndpoint: process.env.CT_API_ENDPOINT,
  ctAuthEndpoint: process.env.CT_AUTH_ENDPOINT,

  paymentApiKey: process.env.PAYMENT_API_KEY,
  paymentApiPrefix: process.env.PAYMENT_API_URL_PREFIX,
  paymentApiInitSuffix: process.env.PAYMENT_API_INIT_SUFFIX,
  paymentOrderNumberGeneratorUrl: process.env.PAYMENT_ORDER_NUMBER_GENERATOR,
  paymentKeyGeneratorUrl: process.env.PAYMENT_KEY_GENERATOR,
  paymentReturnUrl: process.env.PAYMENT_RETURN_URL,

  awsRegion: process.env.AWS_REGION,
  awsEventBusNamePasswordReset: process.env.AWS_EVENT_BUS_NAME_PASSWORD_RESET,
  awsEventBusNameMarketingNotifications: process.env.AWS_EVENT_BUS_NAME_MARKETING_NOTIFICATIONS,

  addressFinderHost: process.env.ADDRESS_FINDER_HOST,
  pickupPointUrl: process.env.PICKUP_POINT_URL,
  pickupPointKey: process.env.PICKUP_POINT_KEY,
  addressFinderAutoComplete: 'autocomplete/{{market}}',
  addressFinderDetail: 'addressdetails/{{market}}',
  defaultDistance: 5,
  defaultDistanceUnit: 'KM',
  leapBeOrder: process.env.LEAP_BE_ORDER,
  uri: {
    magnolia: {
      globalSettingUrl: '.rest/delivery/global-settings/{{country}}/settings/fieldValidators?lang={{locale}}',
      basePath: process.env.MAGNOLIA_BASE_PATH,
    },
  },
  apptusClusterId: process.env.APPTUS_CLUSTER_ID,
  apptusApiKey: process.env.APPTUS_API_KEY,
  apptusBaseUrl: process.env.APPTUS_BASE_URL,
  apptusPaymentNotificationEndpoint: `${process.env.APPTUS_BASE_URL}notifications/payment`,
  apptusEsalesMarket: process.env.APPTUS_ESALES_MARKET,
  paymentRetryCount: parseInt(process.env.PAYMENT_RETRY_COUNT || '2', 10),
  paymentRetryTimeout: parseInt(process.env.PAYMENT_RETRY_TIMEOUT || '500', 10),
  maxRetries: parseInt(process.env.ORDER_MAX_RETRIES || '5', 10),
  minRetry: 1,
  waitTimeout: parseInt(process.env.ORDER_WAIT_TIME_OUT || '3000', 10),
};
