import { Price, Product } from '@commercetools/platform-sdk';
import {
  magnoliaPriceFormatter, priceConverter, promotionToDto, getShippingInfo,
  getProductOffer, calculateOfferSavings, getProductAttributes, checkDiscount, mapLineItem,
} from '../lib/cart-order';
import { GraphQLLineItem } from '../dtos';
import {
  GraphQLOrder, OrderDto, LineItemDto, AddressResponseDto,
  GraphQLPaymentInfo, GraphQLAddress, GraphQLDiscountCode,
  PaymentInfoDto,
} from '../dtos/order.dto';
import { MarketInfo } from '../middlewares';
import { PriceFormat } from '../dtos/magnolia.dto';

export class OrderMapper {
  /**
   * Function to map graphQL response of order data
   * @param orderData
   */
  public mapOrderDetails(
    orderData: GraphQLOrder,
    market: MarketInfo,
    priceFormat: PriceFormat,
    productsData?: Product[],
  ): OrderDto {
    // Order code here
    const totalInvoiceAmount = Number(
      priceConverter(orderData.totalPrice.centAmount, orderData.totalPrice.fractionDigits),
    );
    const promotion = promotionToDto(orderData, priceFormat, orderData.discountCodes[0]?.discountCode);
    const shippingInfo = getShippingInfo(orderData.shippingInfo, priceFormat);
    let totalRetailPriceAmount = orderData.totalPrice.centAmount;
    if (shippingInfo?.shippingPrice !== undefined && Number(shippingInfo?.shippingPrice) > 0) {
      totalRetailPriceAmount -= Number(shippingInfo?.shippingPrice);
    }

    return {
      id: orderData.id,
      version: orderData.version,
      customerId: orderData.customerId,
      anonymousId: orderData.anonymousId,
      orderNumber: orderData.orderNumber,
      orderState: orderData.orderState,
      email: orderData.customer?.email ?? orderData.customerEmail,
      totalRetailPriceAmount: priceConverter(totalRetailPriceAmount, orderData.totalPrice.fractionDigits),
      totalInvoiceAmount,
      formattedTotalPrice: magnoliaPriceFormatter(totalRetailPriceAmount, priceFormat),
      formattedTotalInvoiceAmount: magnoliaPriceFormatter(orderData.totalPrice.centAmount, priceFormat),
      currencyCode: orderData.totalPrice.currencyCode,
      customerEmail: orderData.customerEmail,
      lineItems: this.getLineItems(
        market,
        orderData.lineItems,
        priceFormat,
        orderData.discountCodes[0]?.discountCode,
        productsData,
      ),
      shippingAddress: this.getAddress(orderData.shippingAddress),
      shippingInfo,
      billingAddress: this.getAddress(orderData.billingAddress),
      promotion,
      paymentInfo: this.getPaymentInfo(orderData.paymentInfo, priceFormat),
      addressType: 'delivery',
    };
  }

  /**
  * Mapping of List Items
  * @param lineItems - lineItems Array
  * @param priceFormat - Price format setting
  * @returns lineItems Array
  */
  public getLineItems(
    market: MarketInfo,
    lineItems: GraphQLLineItem[],
    priceFormat: PriceFormat,
    discountCode: GraphQLDiscountCode | undefined,
    productsData?: Product[],
  ): LineItemDto[] {
    const lineItemData: LineItemDto[] = [];
    // eslint-disable-next-line no-restricted-syntax
    for (const element of lineItems) {
      const item = element;
      const variantAttributes = getProductAttributes(item.variant.attributesRaw);
      const {
        sellPrice,
        listPrice,
        listPriceCT,
      } = this.checkChannelGraphql(item.variant.prices ?? []);
      const price = this.variantPrice(item.variant.prices ?? []);
      const offerAmount = calculateOfferSavings(item, discountCode);
      const salePriceAfterOffer = Number((Number(sellPrice) - offerAmount).toFixed(item.totalPrice.fractionDigits));
      const lineItem = {
        ...mapLineItem(item, salePriceAfterOffer, listPrice, listPriceCT, priceFormat, variantAttributes),
        contentFill: variantAttributes.contentFill ?? '',
        offers: (price?.discounted || item?.discountedPricePerQuantity?.length > 0)
          ? [] : getProductOffer(productsData as Product[], item.productId, market),
      };
      lineItemData.push(lineItem);
    }
    return lineItemData;
  }

  /**
   * Check variant prices have channel price
   * @param prices variants prices
   * @returns
   */
  public checkChannelGraphql = (prices: Price[]) => {
    const priceWithoutChannel = prices.find((attribute) => (attribute.channel === undefined
      || attribute.channel === null));
    const [firstPrice] = prices;
    return checkDiscount(priceWithoutChannel ?? firstPrice);
  };

  private readonly variantPrice = (prices: Price[]) => {
    const priceWithoutChannel = prices.find((attribute) => (attribute.channel === undefined
      || attribute.channel === null));
    const [firstPrice] = prices;
    return (priceWithoutChannel ?? firstPrice);
  };

  /**
   * function to get address data
   * @param addressData Address
   * @returns
   */
  private getAddress(addressData:GraphQLAddress | undefined): AddressResponseDto|undefined {
    if (addressData === undefined) {
      return undefined;
    }
    let recipientName = '';
    const name = (addressData.firstName != null && addressData.lastName != null)
      ? `${addressData.firstName} ${addressData.lastName}` : addressData.firstName ?? addressData.lastName;
    const addresses:Array<string> = [];
    /* istanbul ignore else */
    if (addressData.custom !== undefined && addressData.custom !== null) {
      addressData.custom.customFieldsRaw.forEach((field) => {
        if (field.name === 'recipientName' || field.name === 'RecipientName') {
          recipientName = field.value;
        } else if (field.name !== 'Latitude' && field.name !== 'Longitude') {
          addresses.push(field.value);
        }
      });
    }
    addresses.shift();
    const streets = (addresses.length > 0) ? addresses.join(', ') : undefined;
    const address: AddressResponseDto = {
      name: recipientName || name,
      address: streets,
      city: addressData.city,
      region: addressData.region,
      state: addressData.state,
      country: addressData.country,
      zip: addressData.postalCode,
      phoneNumber: addressData.mobile ?? addressData.phone,
      pickupPoint: '',
      isBillingAddress: true,
    };
    return address;
  }

  /**
   * Get payment information data
   * @param paymentInfo GraphQLPaymentInfo
   * @returns PaymentInfoDto
   */
  private getPaymentInfo(paymentInfo: GraphQLPaymentInfo, priceFormat: PriceFormat): PaymentInfoDto {
    const { payments } = paymentInfo;
    const payment = payments.filter((pay) =>
      ((pay.paymentStatus.state?.name === 'Pending' && pay.paymentMethodInfo.method === 'CashOnDelivery')
      || (pay.paymentStatus.state?.name === 'Success' && pay.paymentMethodInfo.method === 'online')));

    if (payment === undefined || payment.length === 0) {
      return {};
    }

    return {
      paymentStatus: payment[0].paymentStatus.state?.name,
      paymentType: payment[0].paymentMethodInfo.method,
      paymentAmount: magnoliaPriceFormatter(payment[0].amountPlanned.centAmount, priceFormat),
    };
  }
}
