/* eslint-disable @typescript-eslint/no-unused-vars */
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import {
  Cart, LineItem, Product, Price,
} from '@commercetools/platform-sdk';
import { ApiError, MarketInfo } from '../lib';
import {
  magnoliaPriceFormatter, priceConverter, getUnitPrice, cartPromotionToDto, getShippingInfo, getCustomFieldData,
  priceConverterWithCurrency, shippingInfoToDto, mapLineItem,
  imageToDto, getProductAttributes, getProductOffer, calculateOfferSavings, checkDiscount,
} from '../lib/cart-order';
import {
  CartDto, LineItemDto, AddressResponseDto, PromotionDto, ShippingInfoDto, CartShippingMethodDto,
  CartLineItem, CartResponse, GraphQLCart, GraphQLLineItem,
} from '../dtos';
import { DEFAULT_QUANTITY } from '../common/constants';
import { PriceFormat } from '../dtos/magnolia.dto';
import { AddressMapper } from '.';
import { GraphQLDiscountCode } from '../dtos/order.dto';

interface CartMapperConfig {
  addressMapper: AddressMapper;
}

/**
   * Maps attribute to cart DTO
   * @param res - any
   * @param locale - locale of market
   * @returns
   */
export class CartMapper {
  private readonly addressMapper: AddressMapper;

  constructor(configuration: CartMapperConfig) {
    this.addressMapper = configuration.addressMapper;
  }

  public cartToDto = (
    cart: Cart,
    market: MarketInfo,
    priceFormat: PriceFormat,
    productDetails?: Product[],
    promotionCode?: string,
  ): CartDto => {
    const totalInvoiceAmount = Number(priceConverter(cart.totalPrice.centAmount, cart.totalPrice.fractionDigits));
    let totalRetailPriceAmount = totalInvoiceAmount;
    let promotion : PromotionDto | undefined;
    if (Array.isArray(cart.discountCodes) && cart.discountCodes.length) {
      promotion = cartPromotionToDto(cart, priceFormat) as PromotionDto;
      /* istanbul ignore else */
      if (promotion) {
        totalRetailPriceAmount += promotion.promotionAmount;
        promotion.promotionCode = promotionCode || '';
        promotion.formattedPromotionAmount = `${promotion.formattedPromotionAmount}
         ${priceFormat?.ccy}`;
      }
    }

    const cartDto: CartDto = {
      id: cart.id,
      version: cart.version,
      totalRetailPriceAmount: totalRetailPriceAmount.toString(),
      totalInvoiceAmount,
      currencyCode: priceFormat?.ccy,
      promotion,
      customerId: cart.customerId,
      anonymousId: cart.anonymousId,
      lineItems: this.lineItemsToDto(cart.lineItems, market, priceFormat, productDetails),
      shippingAddressType: cart.custom?.fields.shippingAddressType,
      shippingAddress: cart.shippingAddress
        ? this.addressMapper.mapAddressResponse(cart.shippingAddress) : {} as AddressResponseDto,
      shippingInfo: cart.shippingInfo ? shippingInfoToDto(cart.shippingInfo, priceFormat) : {} as ShippingInfoDto,
    };
    return cartDto;
  };

  /**
   *
   * @param locale
   * @returns Vat message if applicable on  market
   */
  private readonly getVatText = (priceFormat: PriceFormat): string => {
    const vatMessage = priceFormat.vatIncludedMessage ?? '';
    const isVatIncluded = priceFormat.isVatIncluded ?? false;
    return isVatIncluded === 'true' ? vatMessage : '';
  };

  /**
   * Check variant prices have channel price
   * @param prices variants prices
   * @returns
   */
  private readonly checkChannel = (prices: Price) => {
    return (checkDiscount(prices));
  };

  /**
   * Maps line Item to Line Item DTO
   * @param lineItems - any
   * @param locale - string
   * @returns
   */
  private readonly lineItemsToDto = (
    lineItems: LineItem[],
    market: MarketInfo,
    priceFormat: PriceFormat,
    productDetails?: Product[],
  )
  : LineItemDto[] => {
    let maxPurchasableQty;
    let availableQuantity;
    let variantAttributes;
    if (lineItems.length !== 0 && market.locale) {
      return lineItems.map((lineItem) => {
        if (lineItem?.variant && lineItem?.variant?.attributes) {
          variantAttributes = getProductAttributes(lineItem.variant.attributes);
        } else {
          throw new ApiError(
            HttpStatusCodes.BAD_REQUEST,
            i18next.t('error.lineItemVariantAttributesNotDefined'),
          );
        }
        availableQuantity = lineItem?.variant?.availability?.availableQuantity
         ?? DEFAULT_QUANTITY.DEFAULT_MAX_AVAILABLE_QUANTITY;
        const {
          sellPrice, listPrice, sellPriceCT, listPriceCT,
        } = this.checkChannel(lineItem.price ?? []);
        maxPurchasableQty = variantAttributes?.maxPurchasableQty ?? DEFAULT_QUANTITY.DEFAULT_MAX_PURCHASABLE_QUANTITY;

        const lineItemDto: LineItemDto = {
          lineItemId: lineItem.id,
          productId: lineItem.productId,
          productKey: lineItem.productKey,
          name: lineItem.name[market.locale],
          skuCode: lineItem.variant.sku,
          images: imageToDto(lineItem),
          sellPrice: Number(sellPrice),
          listPrice: Number(listPrice),
          formattedListPrice: magnoliaPriceFormatter(listPriceCT, priceFormat),
          formattedSellPrice: magnoliaPriceFormatter(sellPriceCT, priceFormat),
          vatMessage: this.getVatText(priceFormat),
          unitPrice: getUnitPrice(lineItem.variant.attributes, Number(sellPriceCT), priceFormat),
          quantity: lineItem.quantity,
          modifiedTimeStamp: lineItem.lastModifiedAt,
          sequenceNumber: 0,
          maxPurchasableQty,
          availableQuantity,
          variantType: variantAttributes.variantType,
          variantValue: variantAttributes.variantValue,
          hexCode: variantAttributes.hexCode,
          offers: (lineItem?.price?.discounted || lineItem?.discountedPricePerQuantity?.length > 0)
            ? [] : getProductOffer(productDetails as Product[], lineItem.productId, market),
        };
        return lineItemDto;
      });
    }
    return [];
  };

  /**
   * Check variant prices have channel price
   * @param prices variants prices
   * @returns
   */
  private readonly checkChannelGraphql = (prices: Price[]) => {
    const priceWithoutChannel = prices.find((attribute) => (attribute.channel === undefined
      || attribute.channel === null));
    const [firstPrice] = prices;
    return checkDiscount(priceWithoutChannel ?? firstPrice);
  };

  /**
  * Mapping of List Items
  * @param lineItems - lineItems Array
  * @returns lineItems Array
  */
  public getLineItems(
    lineItems: GraphQLLineItem[],
    priceFormat: PriceFormat,
    productsData: Product[],
    discountCode: GraphQLDiscountCode | undefined,
  ): CartLineItem[] {
    const lineItemData: CartLineItem[] = [];
    // eslint-disable-next-line no-restricted-syntax
    for (const element of lineItems) {
      const item = element;
      const variantAttributes = getProductAttributes(item.variant.attributesRaw);
      const {
        sellPrice, listPrice, listPriceCT,
      } = this.checkChannelGraphql(item.variant.prices ?? []);
      const offerAmount = calculateOfferSavings(item, discountCode);
      const salePriceAfterOffer = Number((Number(sellPrice) - offerAmount).toFixed(item.totalPrice.fractionDigits));

      const lineItem = mapLineItem(item, salePriceAfterOffer, listPrice, listPriceCT, priceFormat, variantAttributes);
      lineItemData.push(lineItem);
    }
    return lineItemData;
  }

  /**
   * Mapping of cart response
   * @param cartData - cart Object
   * @returns cart response Object
   */
  public createCartResponse(
    cartData: GraphQLCart,
    priceFormat: PriceFormat,
    productsData: Product[],
  ):CartResponse {
    let shippingPrice = 0.0;
    let shippingPrices = 0.0;
    const totalInvoiceAmount = Number(
      priceConverter(cartData.totalPrice.centAmount, cartData.totalPrice.fractionDigits),
    );
    if (cartData?.shippingInfo) {
      shippingPrice = Number(
        priceConverter(cartData.shippingInfo.price.centAmount, cartData.shippingInfo.price.fractionDigits),
      );
      shippingPrices = cartData.shippingInfo.price.centAmount;
    }

    const totalAmount = totalInvoiceAmount - shippingPrice;
    const totalAmounts = cartData.totalPrice.centAmount - shippingPrices;
    return {
      id: cartData.id,
      version: cartData.version,
      customerId: cartData.customerId,
      anonymousId: cartData.anonymousId,
      totalRetailPriceAmount: totalAmount.toString(),
      totalInvoiceAmount: totalAmount,
      formattedTotalPrice: magnoliaPriceFormatter(totalAmounts, priceFormat),
      currencyCode: cartData.totalPrice.currencyCode,
      customerEmail: cartData.customerEmail,
      lineItems: this.getLineItems(
        cartData.lineItems,
        priceFormat,
        productsData,
        cartData.discountCodes[0]?.discountCode,
      ),
      shippingInfo: getShippingInfo(cartData.shippingInfo, priceFormat),
      addressType: getCustomFieldData(cartData.custom, 'shippingAddressType'),
      shippingAddress: this.addressMapper
        .mapGraphQLAddressResponse(cartData.shippingAddress as any), // NOSONAR
      // bug in CT Typescript Definitions
      customer: cartData.customer,
    };
  }

  /**
   * Mapping of payment summary response for shipping method added
   * @param cartData - cart Object
   * @param priceFormat - Price Format Object
   * @returns cart response Object
   */
  public createCartResponseForShippingMethodAdded(
    cartData: Cart,
    priceFormat: PriceFormat,
  ): CartShippingMethodDto {
    const { currencyCode } = cartData.totalPrice;
    const { fractionDigits } = cartData.totalPrice;
    const currencyPlacement: string = priceFormat.currencyPlacement ?? 'after';

    // will be final amount
    const totalAmount = cartData.totalPrice.centAmount;
    const deliveryAmount = cartData.shippingInfo ? cartData.shippingInfo.price.centAmount : 0;
    const totalInvoiceAmount = totalAmount - deliveryAmount;
    // will become final sub total amount
    let totalRetailPriceAmount = totalInvoiceAmount;
    // discounted amount
    let promotionAmount = 0;
    /* istanbul ignore else */
    if (Array.isArray(cartData.discountCodes) && cartData.discountCodes.length) {
      promotionAmount = cartPromotionToDto(cartData, priceFormat, false) as number;
      /* istanbul ignore else */
      if (promotionAmount) {
        totalRetailPriceAmount += promotionAmount;
      }
    }

    const totalRetailPrice = priceConverterWithCurrency(
      totalRetailPriceAmount,
      fractionDigits,
      currencyCode,
      currencyPlacement,
    );
    const promotionPrice = priceConverterWithCurrency(promotionAmount, fractionDigits, currencyCode, currencyPlacement);
    const totalPrice = priceConverterWithCurrency(totalAmount, fractionDigits, currencyCode, currencyPlacement);
    const deliveryPrice = priceConverterWithCurrency(deliveryAmount, fractionDigits, currencyCode, currencyPlacement);
    return {
      id: cartData.id,
      version: cartData.version,
      customerId: cartData.customerId,
      paymentSummary: {
        subTotalPrice: totalRetailPrice,
        discount: `-${promotionPrice}`,
        deliveryPrice,
        totalPrice,
      },
    };
  }
}
