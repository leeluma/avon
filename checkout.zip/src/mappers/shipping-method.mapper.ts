import currency from 'currency.js';
import { ShippingMethod } from '@commercetools/platform-sdk';
import { ShippingMethodsResponseDto, PriceDto } from '../dtos/shipping-method.dto';
import { DEFAULT_QUANTITY } from '../common/constants';
/**
   * Maps attribute to cart DTO
   * @param res - any
   * @param locale - locale of market
   * @returns
   */
export class ShippingMethodMapper {
  /**
   * Maps monetaryAmount to price
   * @param price - any
   * @returns
   */
  private readonly monetaryAmountToString = (price: PriceDto): string => {
    const priceString = currency(price.centAmount, {
      fromCents: true,
      precision: price.fractionDigits,
    }).toString();
    return `${priceString} ${price?.currencyCode.toString()}`;
  };

  /**
   * function to convert number to decimal in given fraction
   * @param amount - Given amount
   * @param fraction - Given fraction
   * @returns
   */
  private readonly priceConverter = (amount:number, fraction:number) => {
    const denominator = DEFAULT_QUANTITY.BASE_NUMBER ** fraction;
    return (amount / denominator).toFixed(fraction);
  };

  /**
   * Maps shipping method response
   * @param shoppingMethodCart - shoppingMethodCart
   * @returns Shipping method response
   */
  public shippingMethodCartToDto = (shoppingMethodCart: ShippingMethod[]):
   any => { // NOSONAR
    const shippingMethodCart: Array<ShippingMethodsResponseDto> = [];
    shoppingMethodCart.forEach((items) => {
      const mapPrice = (methodItems: string) => items.zoneRates.map((deliveryCharge) =>
        deliveryCharge?.shippingRates?.map((priceItem) => priceItem[methodItems]));
      const price = mapPrice('price').flat()[0];
      const freeAbove = mapPrice('freeAbove').flat()[0];
      shippingMethodCart.push({
        id: items?.id,
        name: (items.localizedDescription as unknown) as string,
        formattedDeliveryCharge: price && Object.keys(price)?.length > 0 ? this.monetaryAmountToString(price) : '',
        formattedFreeAbove: freeAbove && Object.keys(freeAbove)?.length > 0
          ? this.monetaryAmountToString(freeAbove) : '',
        deliveryCharge: price?.centAmount && price?.fractionDigits
          ? parseFloat(this.priceConverter(price.centAmount, price.fractionDigits)) : 0,
        freeAbove: freeAbove && Object.keys(freeAbove)?.length > 0
          ? parseFloat(this.priceConverter(freeAbove.centAmount, freeAbove.fractionDigits)) : null,
      });
    });
    return shippingMethodCart;
  };
}
