/* eslint-disable @typescript-eslint/no-non-null-assertion */
import {
  Address, Customer, FieldContainer,
} from '@commercetools/platform-sdk';
import {
  AddressResponseDto,
  AddressCollectionResponseDto,
  GraphQLAddress,
  GraphQLCustomerResponse,
  DetailResponseDto,
  CustomerResponseDto,
  AddressRequestDto,
} from '../dtos';
import {
  addressCustomTypeKey,
} from '../lib';
import { MarketInfo } from '../middlewares';
import { mapAddressDraftFields } from '../lib/cart-order';

export class AddressMapper {
  public mapAddressResponse(
    addressDto: Address,
    customerDto?: Customer,
    addressKey?: string,
  ): AddressResponseDto {
    return {
      id: addressDto.id,
      firstName: addressDto.firstName,
      lastName: addressDto.lastName,
      recipientName: addressDto.custom?.fields?.RecipientName,
      customerId: customerDto?.id,
      address1: addressDto.custom?.fields.Address1,
      address2: addressDto.custom?.fields?.Address2,
      address3: addressDto.custom?.fields?.Address3,
      address4: addressDto.custom?.fields?.Address4,
      county: addressDto.custom?.fields?.county,
      latitude: addressDto.custom?.fields?.Latitude,
      longitude: addressDto.custom?.fields?.Longitude,
      city: addressDto.city,
      region: addressDto?.region,
      country: addressDto.country,
      state: addressDto?.state,
      phoneNumber: addressDto.phone,
      zip: addressDto.postalCode,
      isShippingAddress: customerDto?.shippingAddressIds?.includes(addressDto.id!),
      isBillingAddress: customerDto?.billingAddressIds?.includes(addressDto.id!),
      currentAddress: (addressKey === addressDto.key),
    };
  }

  public mapToFields(
    custom: FieldContainer,
  ): FieldContainer {
    return custom.customFieldsRaw.reduce((result, customField) => {
      // eslint-disable-next-line no-param-reassign
      result[customField.name] = customField.value;
      return result;
    }, {});
  }

  public mapCustomerResponse(
    customerDto: GraphQLCustomerResponse,
  ): CustomerResponseDto {
    let customFieldsRaw;
    if (customerDto?.custom) {
      customFieldsRaw = customerDto.custom.customFieldsRaw.reduce((result, custom) => {
        // eslint-disable-next-line no-param-reassign
        result[custom.name] = custom.value;
        return result;
      }, {});
    }

    return {
      id: customerDto?.id,
      email: customerDto.email,
      firstName: customerDto?.firstName,
      lastName: customerDto?.lastName,
      optIn: customFieldsRaw?.OptIn,
    };
  }

  public mapGraphQLAddressResponse(
    addressDto: GraphQLAddress,
    customerDto?: GraphQLCustomerResponse,
  ): AddressResponseDto {
    let customFieldsRaw;
    let isShippingAddress;
    let isBillingAddress;
    if (addressDto?.custom) {
      customFieldsRaw = addressDto.custom.customFieldsRaw.reduce((result, custom) => {
        // eslint-disable-next-line no-param-reassign
        result[custom.name] = custom.value;
        return result;
      }, {});
    }

    if (addressDto?.id) {
      isShippingAddress = customerDto?.shippingAddressIds?.includes(addressDto.id);
      isBillingAddress = customerDto?.billingAddressIds?.includes(addressDto.id);
    }

    return {
      id: addressDto?.id,
      customerId: customerDto?.id,
      firstName: addressDto?.firstName,
      lastName: addressDto?.lastName,
      recipientName: customFieldsRaw?.RecipientName,
      address1: customFieldsRaw?.Address1,
      address2: customFieldsRaw?.Address2,
      address3: customFieldsRaw?.Address3,
      address4: customFieldsRaw?.Address4,
      county: customFieldsRaw?.county,
      latitude: customFieldsRaw?.Latitude,
      longitude: customFieldsRaw?.Longitude,
      city: addressDto?.city,
      region: addressDto?.region,
      country: addressDto?.country,
      state: addressDto?.state,
      phoneNumber: addressDto?.phone,
      zip: addressDto?.postalCode,
      isShippingAddress,
      isBillingAddress,
    };
  }

  public mapAddressCollectionResponse(
    customerDto: Customer,
    addressKey?: string,
  ): AddressCollectionResponseDto {
    return {
      addresses: customerDto.addresses.map((address) =>
        this.mapAddressResponse(address, customerDto, addressKey)),
    };
  }

  public createAddressDraftFromDetails(market: MarketInfo, detail: DetailResponseDto, key: string) {
    const addressDetail = JSON.parse(JSON.stringify(detail).replace(/:null/gi, ':""'));
    return {
      custom: {
        type: { typeId: 'type', key: addressCustomTypeKey },
        fields: mapAddressDraftFields(addressDetail),
      },
      country: market.country,
      city: addressDetail.city,
      region: addressDetail.region2,
      postalCode: addressDetail.zipCode,
      state: undefined,
      phone: addressDetail.phoneNumber,
      firstName: addressDetail.firstName,
      lastName: addressDetail.lastName,
      key,
    };
  }

  public createAddressDraftFromCustomerAddressId(
    market: MarketInfo,
    addressRequestDto: AddressRequestDto,
    addressDetail: Address,
    key: string,
    recipientName?: string,
  ) {
    const customAddress = this.customAddress(addressRequestDto, recipientName, addressDetail);
    return {
      customAddress,
      country: addressRequestDto.country ?? market.country,
      city: addressRequestDto.city ?? addressDetail.city,
      region: addressRequestDto.region ?? addressDetail.region,
      postalCode: addressRequestDto.zip ?? addressDetail.postalCode,
      state: addressRequestDto.state ?? addressDetail.state,
      phone: addressRequestDto.phoneNumber ?? addressDetail.phone,
      firstName: addressRequestDto.firstName ?? addressDetail.firstName,
      lastName: addressRequestDto.lastName ?? addressDetail.lastName,
      key,
    };
  }

  private customAddress(addressRequestDto, recipientName, addressDetail) {
    return {
      custom: {
        type: { typeId: 'type', key: addressCustomTypeKey },
        fields: {
          RecipientName: recipientName ?? addressDetail.custom?.fields.recipientName,
          Address1: addressRequestDto.address1 ?? addressDetail.custom?.fields.Address1,
          Address2: addressRequestDto.address2 ?? addressDetail.custom?.fields.Address2,
          Address3: addressRequestDto.address3 ?? addressDetail.custom?.fields.Address3,
          Address4: addressRequestDto.address4 ?? addressDetail.custom?.fields.Address4,
          county: addressRequestDto.county ?? addressDetail.custom?.fields.county,
          Latitude: addressRequestDto.latitude ?? addressDetail.custom?.fields.Latitude,
          Longitude: addressRequestDto.longitude ?? addressDetail.custom?.fields.Longitude,
        },
      },
    };
  }
}
