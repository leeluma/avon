import { Customer } from '@commercetools/platform-sdk';
import { CustomerResponseDto, GraphQLCustomerResponse } from '../dtos';
import { AddressMapper } from './address.mapper';

export interface CustomerMapperConfig {
  addressMapper: AddressMapper;
}

export class CustomerMapper {
  private readonly addressMapper: AddressMapper;

  constructor(config: CustomerMapperConfig) {
    this.addressMapper = config.addressMapper;
  }

  public mapCustomerResponse(
    customerDto: Customer,
  ): CustomerResponseDto {
    return {
      id: customerDto.id,
      firstName: customerDto.firstName,
      lastName: customerDto.lastName,
      email: customerDto.email,
      addresses: customerDto.addresses.map((address) =>
        this.addressMapper.mapAddressResponse(address, customerDto)),
    };
  }

  public mapGraphQLCustomerResponse(
    customerDto: GraphQLCustomerResponse,
  ): CustomerResponseDto {
    return {
      id: customerDto.id,
      firstName: customerDto.firstName,
      lastName: customerDto.lastName,
      email: customerDto.email,
      addresses: customerDto.addresses.map((address) =>
        this.addressMapper.mapGraphQLAddressResponse(address, customerDto)),
    };
  }
}
