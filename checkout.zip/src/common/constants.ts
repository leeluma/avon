/* eslint-disable no-useless-escape */
/* eslint-disable max-len */
export const DEFAULT_QUANTITY = {
  DEFAULT_MAX_PURCHASABLE_QUANTITY: 9999999,
  DEFAULT_MAX_AVAILABLE_QUANTITY: 9999999,
  DEFAULT_CENT_AMOUNT: 9999,
  BASE_NUMBER: 10,
  BASE_THOUSAND: 1000,
};

export const DEFAULT_DELIVERY_TYPE = 'Courier';

export const VARIANT_ATTRIBUTES = {
  variantType: 'variantType',
  variantValue: 'variantValue',
  hexCode: 'hexCode',
  maxPurchasableQty: 'maxPurchasableQty',
  discontinued: 'discontinued',
};

export const CATEGORY_TYPE = {
  offer: 'Offer',
};

export const ATTRIBUTE_NAMES = {
  config: 'config',
  galleryVideo: 'galleryVideo',
  badges: 'badges',
  contentFillMeasurement: 'ContentFillMeasure',
  contentFill: 'ContentFill',
  availability: 'availability',
  excludeCountDown: 'excludeCountDown',
};

export const ATTRIBUTE_VALUES = {
  attributeValue: 'value',
  availabilitySku: 'skuCode',
  assetType: 'Video Gallery',
};

export const MEASUREMENT = {
  baseMeasure: 'baseMeasure',
  nodes: '@nodes',
};

export const REGEX = {
  RO: {
    email: /^[A-Za-z0-9\\\\\\ \\\&quot;!#$%&amp;'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9\\\\\\ \\\&quot;!#$%&amp;'*+/=?^_`{|}~-]+)*@(?:[A-Za-z0-9](?:[A-Za-z0-9_-]*[A-Za-z0-9])?\.)+[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9]?){6,60}$/,
    name: /^[A-Za-z\u0103\u0102\u00C2\u00E2\u00CE\u00EE\u0218\u0219\u021A\u021B\-\\  \\?\\,\\;\\:\\>\\<\-\\+\\_\\=\\&quot;\]\\[\\(\\)\\%\\@\\#\\$\\!\\?\\&amp;\\*\\/\\ \\\\\|\\.\\~]{3,15}$/,
    phoneNumber: /^[0]{1}[7]{1}[0-9]{8,8}$/,
    address1: /^[A-Za-z0-9\\u0103\\u0102\\u00C2\\u00E2\\u00CE\\u00EE\\u0218\\u0219\\u021A\\u021B-\\.\,\/\\\ \?\,\;\:\\>\<\-\+\\=\"]\[\(\)\%\@\#\$\!\?\&\*\/\ \\|\.\~]{1,50}$/,
    address2: /^[A-Za-z0-9-\\.\,\/\\\ \?\,\;\:\\>\<\-\+\\=\"]\[\(\)\%\@\#\$\!\?\&\*\/\ \\|\.\~]{1,25}$/,
    county: /^(?=.{3,100}$)[A-Za-z\\u0103\\u0102\\u00C2\\u00E2\\u00CE\\u00EE\\u0218\\u0219\\u021A\\u021B-]+(\ [A-Za-z\\u0103\\u0102\\u00C2\\u00E2\\u00CE\\u00EE\\u0218\\u0219\\u021A\\u021B-]+)?$/,
    city: /^[A-Za-z0-9\u0103\u0102\u00C2\u00E2\u00CE\u00EE\u0218\u0219\u021A\u021B\-\\.\,\/\\\ \?\,\;\:\\>\\<\-\+\\=\"]\[\(\)\%\@\#\$\!\?\&\*\/\ \\|\.\~]{1,25}$/,
    zip: /^[0-9]{6,6}$/,
  },
};

export enum MAGNOLIA_URI {
  checkout = '.rest/delivery/pages/v1/{{country}}/checkout',
  orderConfirmation = '.rest/delivery/pages/v1/{{country}}/order-confirmation',
  checkoutPage = '.rest/delivery/pages/v1/{{country}}',
  orderConfirmationPage = '.rest/delivery/pages/v1/{{country}}',
  template = '.rest/template-definitions/v1/',
  wareHouseSetting = '.rest/delivery/global-settings/{{country}}/settings/warehouseSettings',
  globalSettings = '.rest/delivery/global-settings/{{country}}/settings',
  priceFormat = '.rest/delivery/global-settings/{{country}}/settings/priceFormat',
  AddressSettings = '.rest/delivery/global-settings/{{country}}/settings/addressSettings',
  FieldSettings = '.rest/delivery/global-settings/{{country}}/settings/fieldValidators',
}
