import { NextFunction, Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { ApiError } from '../lib';
import { config } from '../config';

export interface MarketInfo {
  country: string;
  locale: string;
  localeAndCountry: string;
  store: string;
  storeAndLocaleAndCountry: string;
}

export const marketParserMiddleware = (req: Request, res: Response, next: NextFunction): void => {
  const { locale, country } = req.params;
  const { ctMarkets } = config;
  const countries = JSON.parse(ctMarkets!).map((item) => item.toLocaleUpperCase());

  if (!countries.includes(country.toLocaleUpperCase())) {
    throw new ApiError(HttpStatusCodes.BAD_REQUEST, `The market "${locale}-${country}" is invalid.`);
  }

  res.locals.market = {
    locale: locale.toLocaleLowerCase(),
    country: country.toLocaleUpperCase(),
    localeAndCountry: `${locale.toLocaleLowerCase()}-${country.toLocaleLowerCase()}`,
  };

  // TODO Validate that this market exists, otherwise throw ApiError(400)

  next();
};
