import { NextFunction, Request, Response } from 'express';
import HttpStatusCodes, { getReasonPhrase, ReasonPhrases } from 'http-status-codes';
import { ApiError, logError } from '../lib';

export const errorHandlerMiddleware = async (
  err: any,
  req: Request,
  res: Response,
  /* The parameter below is needed here because express checks for it! */
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  next: NextFunction,
): Promise<void> => {
  logError('errorHandlerMiddleware', 'Caught error', err);

  let statusCode: number;
  let errors: any[];

  if (err instanceof ApiError) {
    statusCode = err.statusCode;
    if (Array.isArray(err.messagesArray)) {
      errors = err.messagesArray;
    } else if (typeof err.messagesArray === 'object') {
      errors = err.messagesArray;
    } else {
      errors = [{ message: err.messagesArray }];
    }
  } else {
    statusCode = HttpStatusCodes.INTERNAL_SERVER_ERROR;
    errors = [ReasonPhrases.INTERNAL_SERVER_ERROR];
  }

  res.status(statusCode).send({
    statusCode,
    message: getReasonPhrase(statusCode),
    timestamp: new Date().toISOString(),
    errors,
  });
};
