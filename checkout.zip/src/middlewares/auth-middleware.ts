import { NextFunction, Request, Response } from 'express';
import HttpStatusCodes, { getReasonPhrase } from 'http-status-codes';
import { CtClient, logError } from '../lib';

/**
 * @swagger
 * components:
 *   securitySchemes:
 *     bearerAuth:
 *       type: http
 *       scheme: bearer
 */

class AuthorizationTokenRequiredError extends Error {
}

const asyncAuthMiddleware = async (req: Request, res: Response, ctClient: CtClient): Promise<void> => {
  const { authorization } = req.headers;
  const { country } = res.locals.market;

  if (!authorization) {
    throw new AuthorizationTokenRequiredError();
  }

  const token = authorization.replace('Bearer ', '');
  const tokenInfo = await ctClient.getAuthClient(country).introspectToken(token);
  if (tokenInfo.active === false) {
    throw new Error('tokenInfo.active is false');
  }

  if (tokenInfo.scope.includes('customer_id')) {
    const customer = await ctClient.getClient(country).me().get(
      {
        headers: {
          Authorization: authorization,
        },
      },
    ).execute();
    res.locals.customer = customer.body;
  }
};

export const buildAuthMiddleware = (ctClient: CtClient) =>
  (req: Request, res: Response, next: NextFunction): void => {
    asyncAuthMiddleware(req, res, ctClient)

      .then(() => true)

      .catch((err: Error) => {
        logError('authMiddleware', 'Authentication failed', err);
        if (err instanceof AuthorizationTokenRequiredError) {
          res.status(HttpStatusCodes.UNAUTHORIZED).send({
            status: {
              statusCode: HttpStatusCodes.UNAUTHORIZED,
              message: getReasonPhrase(HttpStatusCodes.UNAUTHORIZED),
              timestamp: new Date().toISOString(),
              error: 'Authorization token is required',
            },
          });
        } else {
          res.status(HttpStatusCodes.UNAUTHORIZED).send({
            status: {
              statusCode: HttpStatusCodes.UNAUTHORIZED,
              message: getReasonPhrase(HttpStatusCodes.UNAUTHORIZED),
              timestamp: new Date().toISOString(),
              error: 'Invalid token',
            },
          });
        }
        return false;
      })

      .then((success: boolean) => {
        if (success) {
          next();
        }
      });
  };
