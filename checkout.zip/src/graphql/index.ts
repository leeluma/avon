import { readFile } from 'fs/promises';

const loadAsync = async (fileName: string): Promise<string> =>
  (await readFile(`${__dirname}/../graphql/${fileName}.graphql`, 'utf-8'))
    .toString();

export const graphql = {
  getCustomerByToken: loadAsync('get-customer-by-token'),
  getCustomerCart: loadAsync('get-customer-cart'),
  getCustomerById: loadAsync('get-customer-by-id'),
  getOrder: loadAsync('get-order'),
  getShippingMethods: loadAsync('get-shipping-methods'),
  getCartPaymentInfo: loadAsync('get-cart-payment-info'),
  getOrderByOrderNumber: loadAsync('get-order-by-order-number'),
  getProducts: loadAsync('get-products'),
};
