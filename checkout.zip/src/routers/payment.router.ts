import { RequestHandler, Router } from 'express';
import { validateInitiatePayment, validateNotifications, validatePaymentStatus } from '../validators';
import { validateRequestSchema } from '../middlewares';
import { PaymentController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import { magnoliaUrlMiddleware } from '../middlewares/magnolia-url.middleware';

export interface PaymentRouterConfig {
  paymentController: PaymentController;
  Router: typeof Router;
  authMiddleware: RequestHandler;
}

/**
 * @swagger
 * components:
 *  schemas:
 *    PaymentInitSuccess:
 *      type: object
 *      properties:
 *        id:
 *          type: string
 *          example: eb2fbbbd0fb643dd9a2086bd14a389de
 *        url:
 *          type: string
 *          example: "https://sandmgw.apexxfintech.com/mgw/payment/checkout/eb2fbbbd0fb643dd9a2086bd14a389de/page"
 *    PaymentInitRequest:
 *      type: object
 *      properties:
 *        paymentType:
 *          type: string
 *          enum: [online, CashOnDelivery]
 *          required: true
 *        marketingEmailConsent:
 *          type: boolean
 *          example: true
 */

/**
 * `PaymentRouter` for all the routes related payments
 */
export class PaymentRouter {
  private readonly paymentController: PaymentController;

  private readonly Router: typeof Router;

  private readonly authMiddleware: RequestHandler;

  /**
   * Constructor for `PaymentRouter` class
   * @param config - PaymentRouterConfig injects dependencies into the object
   */
  constructor(config: PaymentRouterConfig) {
    this.paymentController = config.paymentController;
    this.Router = config.Router;
    this.authMiddleware = config.authMiddleware;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /checkout/v1/{language}-{market}/carts/{cartId}/payment/initiate:
     *   post:
     *     summary: Initiate payment for given payment.
     *     tags: [Payment Cart Order]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *           type: string
     *         required: true
     *         description: Language.
     *         example: ro
     *       - in: path
     *         name: market
     *         schema:
     *           type: string
     *         required: true
     *         description: Market.
     *         example: RO
     *       - in: path
     *         name: cartId
     *         schema:
     *           type: string
     *           format: uuid
     *         required: true
     *         description: Cart id.
     *         example: 456c0685-d0e6-4eb3-a11d-b26273940e74
     *     requestBody:
     *       required: true
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/PaymentInitRequest'
     *     security:
     *       - bearerAuth: []
     *     responses:
     *       200:
     *         description: Payment succeeded, return order id or epay transaction id, and return url.
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/PaymentInitSuccess'
     */
    router.post(
      '/:cartId/payment/initiate',
      this.authMiddleware,
      validateInitiatePayment,
      validateNotifications,
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.paymentController.initiatePayment.bind(this.paymentController),
      ),
    );

    router.post(
      '/:cartId/payment/status',
      this.authMiddleware,
      validatePaymentStatus,
      validateNotifications,
      validateRequestSchema,
      wrapJsonApiController(
        this.paymentController.getPaymentStatus.bind(this.paymentController),
      ),
    );

    return router;
  }
}
