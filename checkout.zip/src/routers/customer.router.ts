import { RequestHandler, Router } from 'express';
import { body } from 'express-validator';
import { validateRequestSchema } from '../middlewares';
import { CustomerController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import { fieldValidator } from '../validators';

export interface CustomerRouterConfig {
  customerController: CustomerController;
  Router: typeof Router;
  addressValidationSettingsMiddleware: RequestHandler;
  authMiddleware: RequestHandler;
  validationSettingsMiddleware: RequestHandler;
}

/**
 * `CustomerRouter` for all the routes related to `/customer`
 */
export class CustomerRouter {
  private readonly customerController: CustomerController;

  private readonly Router: typeof Router;

  private readonly addressValidationSettingsMiddleware: RequestHandler;

  private readonly authMiddleware: RequestHandler;

  private readonly validationSettingsMiddleware: RequestHandler;

  constructor(config: CustomerRouterConfig) {
    this.customerController = config.customerController;
    this.Router = config.Router;
    this.addressValidationSettingsMiddleware = config.addressValidationSettingsMiddleware;
    this.authMiddleware = config.authMiddleware;
    this.validationSettingsMiddleware = config.validationSettingsMiddleware;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * components:
     *   schemas:
     *     CustomerAddressRequestDto:
     *       type: object
     *       required:
     *         - address1
     *         - city
     *         - zip
     *         - country
     *         - phoneNumber
     *       properties:
     *         address1:
     *           type: string
     *           description: The address1 of customer is required
     *         address2:
     *           type: string
     *           description: The address2 of customer
     *         address3:
     *           type: string
     *           description: The address3 of customer
     *         address4:
     *           type: string
     *           description: The address4 of customer
     *         city:
     *           type: string
     *           description: The city of customer is required
     *         zip:
     *           type: string
     *           description: The zip of customer is required
     *         country:
     *           type: string
     *           description: The country of customer is required
     *         region:
     *           type: string
     *           description: The region of customer
     *         county:
     *           type: string
     *           description: The county of customer
     *         latitude:
     *           type: number
     *           description: The latitude of customer
     *         longitude:
     *           type: number
     *           description: The longitude of customer
     *         state:
     *           type: string
     *           description: The state of customer is required
     *         isShippingAddress:
     *           type: boolean
     *           description: If this address is shipping address
     *         isBillingAddress:
     *           type: boolean
     *           description: If this address is billing address
     *         phoneNumber:
     *           type: string
     *           description: The phoneNumber of customer is required
     *       example:
     *         address1: "DRUM. TABEREI"
     *         address2: "nr. 22 bl. T8 sc. 1 et 5 ap. 71"
     *         address3: "BUCHAREST"
     *         address4: "DISTRICT 6, 061385"
     *         city: "Bucharest"
     *         region: "Bucharest"
     *         zip: "061385"
     *         county: "Bucharest County"
     *         country: "RO"
     *         latitude: 45.9432
     *         longitude: 24.9668
     *         state: "BUCHAREST"
     *         phoneNumber: "1122334455"
     *         isShippingAddress: true
     *         isBillingAddress: true
     *     CustomerAddressUpdateRequestDto:
     *       type: object
     *       required:
     *       properties:
     *         address1:
     *           type: string
     *           description: The address1 of customer is required
     *         address2:
     *           type: string
     *           description: The address2 of customer
     *         address3:
     *           type: string
     *           description: The address3 of customer
     *         address4:
     *           type: string
     *           description: The address4 of customer
     *         city:
     *           type: string
     *           description: The city of customer is required
     *         zip:
     *           type: string
     *           description: The zip of customer is required
     *         country:
     *           type: string
     *           description: The country of customer is required
     *         region:
     *           type: string
     *           description: The region of customer
     *         county:
     *           type: string
     *           description: The county of customer
     *         latitude:
     *           type: number
     *           description: The latitude of customer
     *         longitude:
     *           type: number
     *           description: The longitude of customer
     *         state:
     *           type: string
     *           description: The state of customer is required
     *         isShippingAddress:
     *           type: boolean
     *           description: If this address is shipping address
     *         isBillingAddress:
     *           type: boolean
     *           description: If this address is billing address
     *         phoneNumber:
     *           type: string
     *           description: The phoneNumber of customer is required
     *       example:
     *         address1: "DRUM. TABEREI"
     *         address2: "nr. 22 bl. T8 sc. 1 et 5 ap. 71"
     *         address3: "BUCHAREST"
     *         address4: "DISTRICT 6, 061385"
     *         city: "Bucharest"
     *         region: "Bucharest"
     *         zip: "061385"
     *         county: "Bucharest County"
     *         country: "RO"
     *         latitude: 45.9432
     *         longitude: 24.9668
     *         state: "BUCHAREST"
     *         phoneNumber: "1122334455"
     *         isShippingAddress: true
     *         isBillingAddress: true
     */

    /**
     * @swagger
     * /checkout/v1/{locale}-{country}/customers/default-delivery:
     *   get:
     *     summary: Get default Address of customer
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       200:
     *         description: Get a Default Address for Customer
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerAddressRequestDto'
     *       500:
     *         description: Something went wrong.
     */
    router.get(
      '/default-delivery',
      this.authMiddleware,
      validateRequestSchema,
      wrapJsonApiController(
        this.customerController.getDefaultAddress.bind(this.customerController),
      ),
    );

    /** @swagger
     * /checkout/v1/{locale}-{country}/customers/forgot-password:
     *   post:
     *     summary: forgot customer's password
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *      description: return token based on email
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            type: object
     *            properties:
     *              email:
     *                type: string
     *                default: example@avon.com
     *                required: true
     *              url:
     *                type: string
     *                default: http://avon.com
     *                required: true
     *     responses:
     *       202:
     *         description: Password was updated successfully
     *       401:
     *         description: The token was invalid.
     *       500:
     *         description: Something went wrong.
     */
    router
      .post(
        '/forgot-password',
        body('email').notEmpty().isEmail().withMessage('internet.email'),
        body('url').notEmpty().isURL().withMessage('internet.url'),
        validateRequestSchema,
        wrapJsonApiController(
          this.customerController.forgotCustomersPassword.bind(this.customerController),
        ),
      );
    /**
     * @swagger
     * /checkout/v1/{locale}-{country}/customers/addresses:
     *   get:
     *     summary: Get delivery Addresses of customer
     *     tags: [Customer Delivery Addresses]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       200:
     *         description: Get a Delivery Addresses for Customer
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerAddressRequestDto'
     *       500:
     *         description: Something went wrong.
     */
    router.get(
      '/addresses',
      this.authMiddleware,
      validateRequestSchema,
      wrapJsonApiController(
        this.customerController.getDeliveryAddresses.bind(this.customerController),
      ),
    );

    /**
     * @swagger
     * /checkout/v1/{locale}-{country}/customers:
     *   get:
     *     summary: Get customer based on token
     *     tags: [Customer Details]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       200:
     *         description: Get a customer details based on token
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerAddressRequestDto'
     *       500:
     *         description: Something went wrong.
     */
    router.get(
      '/',
      this.authMiddleware,
      validateRequestSchema,
      wrapJsonApiController(
        this.customerController.getCustomerByToken.bind(this.customerController),
      ),
    );
    /**
    * @swagger
    * components:
    *   securitySchemes:
    *     bearerAuth:
    *       type: http
    *       scheme: bearer
    */
    /**
     * @swagger
     * /checkout/v1/{locale}-{country}/customers/registration:
     *   post:
     *     summary: Register a customer
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *      description: Valid fields
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/CustomerRegistrationRequestDto'
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       201:
     *         description: Creates a Default Customer for Customer
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerRegistrationResponseDto'
     *       401:
     *         description: Invalid token.
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *               properties:
     *                 status:
     *                   type: object
     *                   properties:
     *                     statusCode:
     *                       type: number
     *                       example: 401
     *                     message:
     *                       type: string
     *                       example: Unauthorized
     *                     timestamp:
     *                       type: string
     *                       example: 2022-05-12T10:45:04.781Z
     *                     error:
     *                       type: string
     *                       example: Invalid token
     */
    router.post(
      '/registration',
      this.authMiddleware,
      this.validationSettingsMiddleware,
      [
        fieldValidator('password'),
        fieldValidator('confirmPassword'),
        fieldValidator('orderId'),
      ],
      validateRequestSchema,
      wrapJsonApiController(
        this.customerController.registration.bind(this.customerController),
      ),
    );

    return router;
  }
}
