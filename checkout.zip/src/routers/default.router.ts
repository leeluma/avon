import { RequestHandler, Router } from 'express';
import { validateRequestSchema } from '../middlewares';
import { DefaultController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import {
  fieldValidator,
  validateCustomerLogin,
  validatePickupDetail,
  validateRefreshToken,
} from '../validators';

export interface DefaultRouterConfig {
  defaultController: DefaultController;
  Router: typeof Router;
  validationSettingsMiddleware: RequestHandler;
  authMiddleware: RequestHandler;
}

/**
 * `DefaultRouter` for all the routes related to `/`
 */

export class DefaultRouter {
  private readonly defaultController: DefaultController;

  private readonly Router: typeof Router;

  private readonly validationSettingsMiddleware: RequestHandler;

  private readonly authMiddleware: RequestHandler;

  /**
   * Constructor for `DefaultRouter` class
   * @param config injects dependencies into the object
   */

  constructor(config: DefaultRouterConfig) {
    this.defaultController = config.defaultController;
    this.Router = config.Router;
    this.validationSettingsMiddleware = config.validationSettingsMiddleware;
    this.authMiddleware = config.authMiddleware;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /checkout/v1/{language}-{market}/login:
     *   post:
     *     summary: Customer login
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: market
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *      description: Valid fields
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/LoginReqDto'
     *     responses:
     *       201:
     *         description: Customer has logged in successfully
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerLoginResDto'
     *       404:
     *         description: Something went wrong.
     */
    router.post(
      '/login',
      validateCustomerLogin,
      validateRequestSchema,
      wrapJsonApiController(
        this.defaultController.login.bind(this.defaultController),
      ),
    );
    /**
     * @swagger
     * /header/v1/{locale}-{country}/refresh-token:
     *   post:
     *     summary: Fetch refresh token
     *     tags: [Default]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: headers
     *         name: refreshToken
     *         schema:
     *            type: string
     *            default: '*****'
     *            required: true
     *     responses:
     *       200:
     *         description: Get refresh token
     *       404:
     *         description: refresh token not found
     */

    router.post(
      '/refresh-token',
      validateRefreshToken,
      validateRequestSchema,
      wrapJsonApiController(
        this.defaultController.refreshToken.bind(this.defaultController),
      ),
    );

    /**
     * @swagger
     * components:
     *   securitySchemes:
     *     bearerAuth:
     *       type: http
     *       scheme: bearer
     */
    /**
     * @swagger
     * /checkout/v1/{language}-{market}/guest-login:
     *   post:
     *     summary: Update Cart Information
     *     tags: [Guest login]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: market
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *      description: Valid fields
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/UpdateCartRequestDto'
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       201:
     *         description: Cart information has been updated successfully
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *               properties:
     *                 statusCode:
     *                   type: number
     *                   description: 201 code if successfully created
     *                 msg:
     *                   type: string
     *                   description: Created
     *                 timestamp:
     *                   type: string
     *                   description: time of operation performed
     *               required:
     *                 - statusCode
     *                 - msg
     *                 - timestamp
     *       404:
     *         description: Something went wrong.
     */
    router.post(
      '/guest-login',
      this.authMiddleware,
      this.validationSettingsMiddleware,
      [
        fieldValidator('email'),
        fieldValidator('firstName'),
        fieldValidator('lastName'),
        fieldValidator('cartId'),
      ],
      validateRequestSchema,
      wrapJsonApiController(
        this.defaultController.updateMyCartById.bind(this.defaultController),
      ),
    );

    /**
     * @swagger
     * /checkout/v1/{language}-{market}/pickup-points:
     *   get:
     *     summary: Provides get list of available pickup points
     *     tags: [Pickup Points]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: market
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: query
     *         name: latitude
     *         schema:
     *            type: number
     *         required: true
     *       - in: query
     *         name: longitude
     *         schema:
     *            type: number
     *         required: true
     *       - in: query
     *         name: distance
     *         schema:
     *            type: number
     *         required: true
     *       - in: query
     *         name: distanceUnit
     *         schema:
     *            type: string
     *         required: true
     *       - in: header
     *         name: x-api-key
     *         schema:
     *            type: string
     *            default: fe845d9b3f48d289468bc1cb0945d9a3cad8c584f8254ffa1875457de71e5ce0
     *            required: true
     *     responses:
     *       200:
     *         description: Successful Operation
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/PickupPointResponseDto'
     *       404:
     *         description: Something went wrong.
     */
    router.get(
      '/pickup-points',
      validatePickupDetail,
      validateRequestSchema,
      wrapJsonApiController(
        this.defaultController.getPickupDetail.bind(this.defaultController),
      ),
    );
    return router;
  }
}
