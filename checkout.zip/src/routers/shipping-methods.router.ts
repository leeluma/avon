import { Router } from 'express';
import { magnoliaUrlMiddleware, validateRequestSchema } from '../middlewares';
import { CartController } from '../controllers';
import { CtClient, wrapJsonApiController } from '../lib';

export interface ShippingMethodsRouterConfig {
  cartController: CartController;
  Router: typeof Router;
  ctClient: CtClient;
}

/**
 * @swagger
 * components:
 *  schemas:
 *    LineItemRequest:
 *      type: object
 *      properties:
 *        productKey:
 *          type: string
 *        sku:
 *          type: string
 *        quantity:
 *          type: integer
 *    CartPromotionRequest:
 *      type: object
 *      properties:
 *        promotionCode:
 *          type: string
 *          example: AVON10%
 *        promotionId:
 *          type: string
 *          example: 5d06c34c-5f40-4897-abdb-99cc9adc97ff
 *        action:
 *          type: string
 *          example: applyPromotion or removePromotion
 *    ChangeLineItemQuantityRequest:
 *      type: object
 *      properties:
 *        quantity:
 *          type: integer
 *          format: int32
 *          required: true
 *          example: 5
 *          description: Quantity
 *    AddShippingAddressRequest:
 *      type: object
 *      properties:
 *        address1:
 *          type: string
 *          example: address1
 *        address2:
 *          type: string
 *          example: address2
 *        county:
 *          type: string
 *          example: county
 *        city:
 *          type: string
 *          example: city
 *        postalCode:
 *          type: string
 *          example: 80933
 *        phoneNumber:
 *          type: string
 *          example: +49 89 12345678
 *    CartRequest:
 *      type: object
 *      properties:
 *        cartId:
 *          type: string
 *        lineItems:
 *          type: object
 *          properties:
 *            productKey:
 *              type: string
 *            sku:
 *              type: string
 *            quantity:
 *              type: integer
 *    CartResponse:
 *      type: object
 *      properties:
 *        status:
 *          type: object
 *          properties:
 *            statusCode:
 *              type: integer
 *              format: int32
 *              example: 200
 *            message:
 *              type: string
 *              example: OK
 *            timestamp:
 *              type: string
 *              example: 2021-12-31T07:32:43.751Z
 *        data:
 *          type: object
 *          properties:
 *            id:
 *              type: string
 *              example: 796c0b39-0a6b-4930-a987-a762149a71d8
 *            version:
 *              type: integer
 *              format: int32
 *              example: 17
 *            totalRetailPriceAmount:
 *              type: string
 *              example: 35.16
 *            totalInvoiceAmount:
 *              type: string
 *              example: 35.16
 *            currencyCode:
 *              type: string
 *              example: RON
 *            customerId:
 *              type: integer
 *              format: int32
 *              example: 0
 *            lineItems:
 *              type: array
 *              items:
 *                type: object
 *                properties:
 *                  lineItemId:
 *                    type: string
 *                    example: 8f6dbef7-6590-4d07-bdab-51a858907970
 *                  productId:
 *                    type: string
 *                    example: 12ad8823-ce25-4978-b8c1-cd9504898c46
 *                  name:
 *                    type: string
 *                    example: Mini-apă de parfum Far Away Glamour
 *                  skuCode:
 *                    type: string
 *                    example: 77567-9161866660405752600
 *                  images:
 *                    type: array
 *                    items:
 *                      type: object
 *                      properties:
 *                        label:
 *                          type: string
 *                          example: Gallery
 *                        url:
 *                          type: string
 *                          example: https://www.avon.ro/assets/ro-RO/images/product/prod_1200539_1_613x613.jpg
 *                        width:
 *                          type: integer
 *                          format: int32
 *                          example: 613
 *                        height:
 *                          type: integer
 *                          format: int32
 *                          example: 613
 *                  sellPrice:
 *                    type: string
 *                    example: 65.98
 *                  listPrice:
 *                    type: string
 *                    example: 65.98
 *                  formattedListPrice:
 *                    type: string
 *                    example: 65.98 RON
 *                  formattedSellPrice:
 *                    type: string
 *                    example: 65.98 RON
 *                  vatMessage:
 *                    type: string
 *                    example: Vat Included
 *                  quantity:
 *                    type: integer
 *                    format: int32
 *                    example: 2
 *                  modifiedTimeStamp:
 *                    type: string
 *                    example: 2021-12-28T07:49:54.341Z
 *                  sequenceNumber:
 *                    type: integer
 *                    format: int32
 *                    example: 0
 *                  maxPurchasableQty:
 *                    type: integer
 *                    format: int32
 *                    example: 10
 *                  availableQuantity:
 *                    type: integer
 *                    format: int32
 *                    example: 12
 *                  variantType:
 *                    type: string
 *                    example: variantType
 *                  variantValue:
 *                    type: string
 *                    example: variantValue
 *                  hexCode:
 *                    type: string
 *                    example: hexCode
 *                  offers:
 *                    type: array
 *                    items:
 *                      type: object
 *                      properties:
 *                        key:
 *                          type: string
 *                          example: Oricare-2-cu-21-RON
 *                        displayName:
 *                          type: string
 *                          example: Oricare 2 cu 21 RON!
 *                        url:
 *                          type: string
 *                          example: /c/oricare-2-cu-21-ron
 *                        description:
 *                          type: string
 *                          example: Oricare 2 cu 21 RON!
 *            promotion:
 *              type: object
 *              properties:
 *                promotionId:
 *                  type: string
 *                  example: 032295d2-ed3a-48c5-9f07-3f2e15d384a9
 *                promotionCode:
 *                  type: string
 *                  example: discoun
 *                promotionAmount:
 *                  type: integer
 *                  format: int32
 *                  example: 0
 *                promotionDescription:
 *                  type: string
 *                  example: This is a test discount which is applied on cart if total is less than 10 RON
 *            shippingAddress:
 *              type: object
 *              properties:
 *                address1:
 *                  type: string
 *                  example: address1
 *                address2:
 *                  type: string
 *                  example: address2
 *                postalCode:
 *                  type: string
 *                  example: 80933
 *                city:
 *                  type: string
 *                  example: city
 *                county:
 *                  type: string
 *                  example: county
 *                phoneNumber:
 *                  type: string
 *                  example: +49 89 12345678
 *            shippingInfo:
 *              type: object
 *              properties:
 *                shippingMethodName:
 *                  type: string
 *                  example: Default shipping method
 *                shippingMethodPrice:
 *                  type: number
 *                  example: 100
 *    CartShippingMethodsResponse:
 *      type: object
 *      properties:
 *        statusCode:
 *          type: integer
 *          format: int32
 *          example: 200
 *        message:
 *          type: string
 *          example: OK
 *        timestamp:
 *          type: string
 *          example: 2021-12-31T07:32:43.751Z
 *        data:
 *          type: object
 *          properties:
 *            id:
 *              type: string
 *              example: 796c0b39-0a6b-4930-a987-a762149a7123
 *            name:
 *              type: string
 *              example: Next day delivery
 *            deliveryCharge:
 *              type: string
 *              example: 7.00 RON
 *            freeAbove:
 *              type: string
 *              example: 87.00 RON
 *    shippingMethodResponse:
 *      type: object
 *      properties:
 *        statusCode:
 *          type: integer
 *          format: int32
 *          example: 200
 *        message:
 *          type: string
 *          example: OK
 *        timestamp:
 *          type: string
 *          example: 2021-12-31T07:32:43.751Z
 *        data:
 *          type: object
 *          properties:
 *            id:
 *              type: string
 *              example: 796c0b39-0a6b-4930-a987-a762149a7123
 *            name:
 *              type: string
 *              example: Next day delivery
 *            isDefault:
 *              type: boolean
 *              example: true
 *            formattedDeliveryCharge:
 *              type: string
 *              example: 7.00 RON
 *            deliveryCharge:
 *              type: string
 *              example: 7.00
 *            freeAbove:
 *              type: string
 *              example: 87.00
 */

/**
 * `ShippingMethodsRouter` for all the routes related to `/carts`
 */

export class ShippingMethodRouter {
  private readonly cartController: CartController;

  private readonly Router: typeof Router;

  private readonly ctClient: CtClient;

  /**
   * Constructor for `CartRouter` class
   * @param config injects dependencies into the object
   */

  constructor(config: ShippingMethodsRouterConfig) {
    this.cartController = config.cartController;
    this.Router = config.Router;
    this.ctClient = config.ctClient;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /checkout/v1/{language}-{market}/shippingMethods:
     *   get:
     *     summary: Get the shipping-methods
     *     tags: [Cart Shipping Method]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *           type: string
     *         required: true
     *         description: language
     *         example: ro
     *       - in: path
     *         name: market
     *         schema:
     *           type: string
     *         required: true
     *         description: Market
     *         example: RO
     *     responses:
     *       200:
     *         description: The list of shipping-methods details
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CartShippingMethodsResponse'
     */
    router.get(
      '/',
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.cartController.getShippingMethods.bind(this.cartController),
      ),
    );
    return router;
  }
}
