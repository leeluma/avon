import { Router } from 'express';
import { CheckoutController } from '../controllers/checkout.controller';
import { wrapJsonApiController } from '../lib';
import { validateRequestSchema, magnoliaUrlMiddleware } from '../middlewares';

interface CheckoutRouterConfig {
  checkoutController: CheckoutController;
  Router: typeof Router;
}

/**
 * `CheckoutRouter` for all the routes related to `/checkout`
 */
export class CheckoutRouter {
  private readonly checkoutController: CheckoutController;

  private readonly Router: typeof Router;

  constructor(config: CheckoutRouterConfig) {
    this.checkoutController = config.checkoutController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /checkout/v1/{language}-{market}/:
     *   get:
     *     summary: Get the checkout magnolia page data for particular language and market
     *     operationId: getCheckoutPageData
     *     tags: [Checkout]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *           type: string
     *         required: true
     *         description: The language
     *         example: ro
     *       - in: path
     *         name: market
     *         schema:
     *           type: string
     *         required: true
     *         description: The market
     *         example: Ro
     *       - in: query
     *         name: isPreview
     *         enum: [true, false]
     *         default: false
     *         description: The preview
     *         required: false
     *     responses:
     *       200:
     *         description: checkout response
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/HttpResponseProductsDto'
     *       500:
     *         description: checkout data not found
     */
    router.get(
      '/',
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.checkoutController.getCheckoutPageData.bind(this.checkoutController),
      ),
    );

    return router;
  }
}
