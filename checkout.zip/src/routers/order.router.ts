import { Router } from 'express';
import { validateOrderIdAndBearerToken } from '../validators';
import { validateRequestSchema } from '../middlewares';
import { magnoliaUrlMiddleware } from '../middlewares/magnolia-url.middleware';
import { OrderController } from '../controllers';
import { wrapJsonApiController } from '../lib';

export interface OrderRouterConfig {
  orderController: OrderController;
  Router: typeof Router;
}

/**
 * @swagger
 * components:
 *  schemas:
 *    OrderConfirmation:
 *      type: object
 *      properties:
 *       statusCode:
 *         type: integer
 *         format: int32
 *         example: 200
 *       message:
 *         type: string
 *         example: OK
 *       timestamp:
 *         type: string
 *         example: 2021-12-31T07:32:43.751Z
 *       data:
 *         type: object
 *         properties:
 *           id:
 *             type: string
 *             example: 796c0b39-0a6b-4930-a987-a762149a71d8
 *           version:
 *             type: integer
 *             format: int32
 *             example: 17
 *           totalRetailPriceAmount:
 *             type: string
 *             example: 35.16
 *           totalInvoicedAmount:
 *             type: string
 *             example: 35.16
 *           currencyCode:
 *             type: string
 *             example: RON
 *           customerId:
 *             type: integer
 *             format: int32
 *             example: 0
 *           anonymousId:
 *             type: integer
 *             format: int32
 *             example: 0
 *           orderNumber:
 *             type: string
 *             example: LP87596
 *           orderState:
 *             type: string
 *             example: open
 *           lineItems:
 *             type: array
 *             items:
 *               type: object
 *               properties:
 *                 lineItemId:
 *                   type: string
 *                   example: 8f6dbef7-6590-4d07-bdab-51a858907970
 *                 productId:
 *                   type: string
 *                   example: 12ad8823-ce25-4978-b8c1-cd9504898c46
 *                 productName:
 *                   type: string
 *                   example: Mini-apă de parfum Far Away Glamour
 *                 skuCode:
 *                   type: string
 *                   example: 77567-9161866660405752600
 *                 images:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       label:
 *                         type: string
 *                         example: Gallery
 *                       url:
 *                         type: string
 *                         example: https://www.avon.ro/assets/ro-RO/images/product      /prod_1200539_1_613x613.jpg
 *                       width:
 *                         type: integer
 *                         format: int32
 *                         example: 613
 *                       height:
 *                         type: integer
 *                         format: int32
 *                         example: 613
 *                 listPriceAmount:
 *                   type: string
 *                   example: 17.58
 *                 unitPriceAmount:
 *                   type: string
 *                   example: 17.58
 *                 quantity:
 *                   type: integer
 *                   format: int32
 *                   example: 2
 *                 modifiedTimeStamp:
 *                   type: string
 *                   example: 2021-12-28T07:49:54.341Z
 *                 variantType:
 *                   type: string
 *                   example: variantType
 *                 variantValue:
 *                   type: string
 *                   example: variantValue
 *                 hexCode:
 *                   type: string
 *                   example: hexCode
 *                 offers:
 *                   type: array
 *                   items:
 *                     type: object
 *                     properties:
 *                       key:
 *                         type: string
 *                         example: Oricare-2-cu-21-RON
 *                       displayName:
 *                         type: string
 *                         example: Oricare 2 cu 21 RON!
 *                       url:
 *                         type: string
 *                         example: /c/oricare-2-cu-21-ron
 *                       description:
 *                         type: string
 *                         example: Oricare 2 cu 21 RON!
 *           promotion:
 *             type: object
 *             properties:
 *               promotionId:
 *                 type: string
 *                 example: 032295d2-ed3a-48c5-9f07-3f2e15d384a9
 *               promotionCode:
 *                 type: string
 *                 example: discoun
 *               promotionAmount:
 *                 type: integer
 *                 format: int32
 *                 example: 0
 *               promotionDescription:
 *                 type: string
 *                 example: This is a test discount
 *           shippingAddress:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: John Deo
 *               address:
 *                 type: string
 *                 example: addresses
 *               postalCode:
 *                 type: string
 *                 example: 80933
 *               city:
 *                 type: string
 *                 example: city
 *               county:
 *                 type: string
 *                 example: county
 *               region:
 *                 type: string
 *                 example: region
 *               state:
 *                 type: string
 *                 example: state
 *               phoneNumber:
 *                 type: string
 *                 example: +49 89 12345678
 *           billingAddress:
 *             type: object
 *             properties:
 *               name:
 *                 type: string
 *                 example: John Deo
 *               address:
 *                 type: string
 *                 example: addresses
 *               postalCode:
 *                 type: string
 *                 example: 80933
 *               city:
 *                 type: string
 *                 example: city
 *               county:
 *                 type: string
 *                 example: county
 *               region:
 *                 type: string
 *                 example: region
 *               state:
 *                 type: string
 *                 example: state
 *               phoneNumber:
 *                 type: string
 *                 example: +49 89 12345678
 *           shippingInfo:
 *             type: object
 *             properties:
 *               shippingMethodName:
 *                 type: string
 *                 example: Default shipping method
 *               shippingMethodPrice:
 *                 type: number
 *                 example: 100
 *           paymentInfo:
 *             type: object
 *             properties:
 *               paymentType:
 *                 type: string
 *                 example: Cash
 *               paymentAmount:
 *                 type: number
 *                 example: 100
 */

/**
 * `OrderRouter` for all the routes related orders
 */
export class OrderRouter {
  private readonly orderController: OrderController;

  private readonly Router: typeof Router;

  /**
   * Constructor for `OrderRouter` class
   * @param config - OrderRouterConfig injects dependencies into the object
   */
  constructor(config: OrderRouterConfig) {
    this.orderController = config.orderController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /v1/{language}-{market}/orders/{orderId}:
     *   get:
     *     summary: Initiate order for given order.
     *     tags: [Order]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *           type: string
     *         required: true
     *         description: Language.
     *         example: ro
     *       - in: path
     *         name: market
     *         schema:
     *           type: string
     *         required: true
     *         description: Market.
     *         example: RO
     *       - in: path
     *         name: orderId
     *         schema:
     *           type: string
     *           format: uuid
     *         required: true
     *         description: Order id.
     *         example: 456c0685-d0e6-4eb3-a11d-b26273940e74
     *     responses:
     *       200:
     *         description: Order succeeded, return order confirmation data.
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/OrderConfirmation'
     */
    router.get(
      '/:orderId',
      validateOrderIdAndBearerToken,
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.orderController.getOrder.bind(this.orderController),
      ),
    );

    /**
     * @swagger
     * /v1/{language}-{market}/orders:
     *   get:
     *     summary: Magnolia data for order confirmation.
     *     tags: [Order]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *           type: string
     *         required: true
     *         description: Language.
     *         example: ro
     *       - in: path
     *         name: market
     *         schema:
     *           type: string
     *         required: true
     *         description: Market.
     *         example: RO
     *     responses:
     *       200:
     *         description: Order succeeded, return order confirmation magnolia data.
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/OrderConfirmationMagnolia'
     */
    router.get(
      '/',
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.orderController.getOrderMagnolia.bind(this.orderController),
      ),
    );

    return router;
  }
}
