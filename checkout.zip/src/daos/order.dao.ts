import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import {
  Order, ClientResponse, GraphQLResponse, Product,
} from '@commercetools/platform-sdk';
import {
  ApiError, CtClient, logError, logger,
} from '../lib';
import { MarketInfo } from '../middlewares';
import { graphql } from '../graphql';
import { GraphQLOrder } from '../dtos/order.dto';

interface OrderDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

const errorLogMsg = 'Failed to fetch order';
const orderDao = 'OrderDao.fetchOrder';

/**
 * `CtOrderDao` data access class for CommerceTools `Order`
 */
export class OrderDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `OrderDao` class
   * @param config injects dependencies into the object
   */
  constructor(config: OrderDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
   * Create Order from Cart in CT
   * @param market - MarketInfo
   * @param authorization - string Authorization header
   * @param cartId - string Id of source cart
   * @param cartVersion - number Cart version number
   * @param orderNumber - string Payment order number
   * @returns Newly created Order
   */
  public createOrderFromCart = async (
    market: MarketInfo,
    authorization: string,
    cartId: string,
    cartVersion: number,
    orderNumber: string,
  ): Promise<Order> => {
    try {
      const createdOrder = await this.ctClient.getClient(market.country)
        .orders()
        .post({
          body: {
            id: cartId,
            version: cartVersion,
            orderNumber,
          },
          headers: { authorization },
        })
        .execute();
      return createdOrder.body;
    } catch (err: unknown) {
      logError('OrderDao.createOrderFromCart', 'Failed to create order from cart', err);
      throw err;
    }
  };

  /**
   * Fetch order details data based on order id using GraphQL
   * @param authHeader
   * @param market - Market info
   * @param orderId - Order id
   * @returns - Order details
   */
  public async fetchOrder(
    authHeader: string,
    market: MarketInfo,
    orderId: string,
  ): Promise<GraphQLOrder> {
    const body = {
      query: await this.graphql.getOrder,
      variables: {
        orderId,
        locale: market.locale,
      },
    };
    let ctResponse: ClientResponse<GraphQLResponse>;

    try {
      ctResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          headers: {
            Authorization: authHeader,
          },
          body,
        })
        .execute();
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logError(orderDao, errorLogMsg, err);
      if (err.body?.statusCode) {
        throw new ApiError(err.body.statusCode, err.body.errors);
      }
      throw err;
    }
    return ctResponse?.body?.data?.me?.order;
  }

  /**
   * Fetch products data based on provided ids using GraphQL
   * @param market - Market info
   * @param productIds - multiple product ids as comma separated
   * @returns - product details
   */
  public async fetchProductsDetail(
    market: MarketInfo,
    productIds: string,
  ): Promise<Product[] | undefined> {
    const body = {
      query: await this.graphql.getProducts,
      variables: {
        where: `id in (${productIds})`,
        locale: market.locale,
      },
    };

    let ctResponse: ClientResponse<GraphQLResponse>;

    try {
      ctResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body })
        .execute();
      if (ctResponse.body?.data === null && ctResponse.body?.errors?.length !== undefined) {
        throw new ApiError(
          HttpStatusCodes.BAD_REQUEST,
          i18next.t('error.productsInvalidUuid'),
        );
      }
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
        + ` GraphQL returned: ${JSON.stringify(err.body?.errors)}.`);
      throw err;
    }
    return ctResponse.body?.data?.products.results ?? undefined;
  }

  /**
   * Fetch order details data based on order number using GraphQL
   * @param authHeader
   * @param market - Market info
   * @param orderId - Order Number
   * @returns - Order details
   */
  public async fetchOrderByOrderNumber(
    market: MarketInfo,
    orderNumber: string,
  ): Promise<Order[]> {
    const body = {
      query: await this.graphql.getOrderByOrderNumber,
      variables: {
        where: `orderNumber = "${orderNumber}"`,
      },
    };
    let ctResponse: ClientResponse<GraphQLResponse>;

    try {
      ctResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          body,
        })
        .execute();
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logError(orderDao, errorLogMsg, err);
      if (err.body?.statusCode) {
        throw new ApiError(err.body.statusCode, err.body.errors);
      }
      throw err;
    }
    return ctResponse?.body?.data?.orders?.results;
  }
}
