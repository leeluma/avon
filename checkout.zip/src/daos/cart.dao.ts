import {
  GraphQLResponse, Cart, CartUpdate, Update, ClientResponse,
} from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { CtCartPaymentInfo, GraphQLCart } from '../dtos';
import { graphql } from '../graphql';
import {
  ApiError, CtClient, logError, logger,
} from '../lib';
import { MarketInfo } from '../middlewares';

interface CartDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

const errorInvalidToken = 'error.invalidToken';
const cartNotFound = 'error.cartIdNotFound';

/**
 * `CtCartDao` data access class for CommerceTools `Cart`
 */
export class CartDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `CartDao` class
   * @param config injects dependencies into the object
   */
  constructor(config: CartDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /** * Shipping Method get by cart Id from CommerceTools * @param country - string * @returns Shipping Method from the commercetools */
  public getShippingMethods = async (market: MarketInfo, shippingKind: string): Promise<GraphQLResponse | undefined> => {
    try {
      const body = {
        query: await this.graphql.getShippingMethods,
        variables: {
          where: `custom(fields(ShippingKind="${shippingKind}"))`,
          locale: market.locale,
        },
      };
      const shippingMethods = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body }).execute();
      return shippingMethods.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to retrieve shipping methods from CT, because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        return undefined;
      }
      throw err;
    }
  };

  /** Add shipping method to cart * @param market - string
   * @param cart - Cart * @param shippingMethodId - string * @returns Updated cart after adding the shipping method */
  public addShippingMethod = async (market: string, cart: Cart, shippingMethodId: string, authHeader: string): Promise<Cart> => {
    try {
      const updatedCart = await this
        .ctClient.getClient(market).me().carts().withId({ ID: cart.id })
        .post({
          body: {
            version: cart.version,
            actions: [{
              action: 'setShippingMethod',
              shippingMethod: {
                id: shippingMethodId,
                typeId: 'shipping-method',
              },
            }],
          },
          headers: {
            Authorization: authHeader,
          },
        })
        .execute();
      return updatedCart.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to add shipping method to cart because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.UNAUTHORIZED) {
        throw new ApiError(HttpStatusCodes.UNAUTHORIZED, i18next.t(errorInvalidToken));
      }
      if (err.statusCode === HttpStatusCodes.BAD_REQUEST) {
        throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('error.shippingMethodNotFound'));
      }
      throw err;
    }
  };

  /** * Get cart by Id from CommerceTools * @param country - string * @param cartId - string * @returns cart from the commercetools  */
  public getCartById = async (country: string, cartId: string): Promise<Cart | undefined> => {
    try {
      const cart = await this.ctClient.getClient(country).carts().withId({ ID: cartId }).get()
        .execute();
      return cart.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to retrieve cart id "${cartId}" from CT, because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        return undefined;
      }
      throw err;
    }
  };

  /** Get cart by Id from CT  * @param country - string  * @param authorization * @param cartId - string * @returns cart from the CT */
  public getMyCartById = async (country: string, authorization: string, cartId: string): Promise<Cart | undefined> => {
    try {
      const cart = await this.ctClient.getClient(country)
        .me()
        .carts()
        .withId({ ID: cartId })
        .get({ headers: { authorization } })
        .execute();
      return cart.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logError('CartDao.getMyCartById', `Failed to retrieve cart id "${cartId}" from CT`, err);
      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        return undefined;
      }
      throw err;
    }
  };

  /** * Get cart by Id from CommerceTools * @param country - string * @param cartId - string * @param payload - CartUpdate
   * @returns cart from the commercetools  */
  public updateCartById = async (country: string, cartId: string, payload: CartUpdate): Promise<Cart> => {
    try {
      const cart = await this.ctClient.getClient(country)
        .carts()
        .withId({ ID: cartId })
        .post({ body: payload })
        .execute();
      return cart.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to update cart id "${cartId}" from CT, because:\n${err.stack}`);
      throw err;
    }
  };

  /** * set shipping address to cart * @param market - string  * @param cart - Cart  * @param shippingAddressDetails - Base address details
   * @param authToken - AuthToken  * @returns Updated cart after setting the shipping address */
  public setShippingAddress = async (market: string, cart: Cart, address: Update, authToken: string): Promise<Cart> => {
    try {
      const updatedCart = await this
        .ctClient.getClient(market)
        .carts()
        .withId({ ID: cart.id })
        .post({
          body: address as CartUpdate,
          headers: {
            Authorization: authToken,
          },
        })
        .execute();
      return updatedCart.body;
    } catch (err) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to set shipping address to cart because:\n${(err as Error).stack}`);
      throw err;
    }
  };

  /** * Use to update cart information. * @param country * @param cart * @param authToken * @param cartId */
  public async updateMyCartById(country: string, cart: Update, authToken: string, cartId: string): Promise<void> {
    try {
      await this.ctClient.getClient(country)
        .carts()
        .withId({ ID: cartId })
        .post({
          body: cart as CartUpdate,
          headers: {
            Authorization: authToken,
          },
        })
        .execute();
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, error.errors);
      }
      throw error;
    }
  }

  /** * Get cart by id from CommerceTools using graphql
   * @param market - MarketInfo * @param cartId - Id of Commerce tool cart to retrieve
   * @param authHeader - access token of customer  * @returns Fetched cartDao (or undefined if the cart don't exist) */
  public async getCartByIdGraphql(market: MarketInfo, cartId: string, authHeader: string): Promise<GraphQLCart> {
    try {
      const locale = market.locale.toLocaleUpperCase();
      const body = {
        query: await this.graphql.getCustomerCart,
        variables: {
          cartId,
          locale,
        },
      };
      const cart: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          headers: {
            Authorization: authHeader,
          },
          body,
        })
        .execute();
      return cart.body.data.me.cart;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`from Commerce tool, because:\n${err.stack}`);
      if (err.body?.statusCode) {
        throw new ApiError(err.body.statusCode, err.body.errors);
      }
      throw err;
    }
  }

  /** * Get cart payment information from CommerceTools using graphql
   * @param market - MarketInfo  * @param cartId - Id of Commerce tool cart to retrieve
   * @param authHeader - access token of customer  * @returns Fetched cartDao (or undefined if the cart don't exist)
   */
  public async getCartPaymentInfo(market: MarketInfo, cartId: string, authHeader: string): Promise<CtCartPaymentInfo> {
    try {
      const locale = market.locale.toLocaleUpperCase();
      const body = {
        query: await this.graphql.getCartPaymentInfo,
        variables: {
          cartId,
          locale,
        },
      };
      const cartPaymentInfo: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          headers: {
            Authorization: authHeader,
          },
          body,
        })
        .execute();
      return cartPaymentInfo.body.data?.cart;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logError('CartDao.getCartPaymentInfo', 'Error reading cart payment info', err);
      if (err.statusCode === HttpStatusCodes.UNAUTHORIZED) {
        throw new ApiError(HttpStatusCodes.UNAUTHORIZED, i18next.t(errorInvalidToken));
      }
      if (err.body?.statusCode) {
        throw new ApiError(err.body.statusCode, err.body.errors);
      }
      throw err;
    }
  }

  /** * replicate cart by cart id * @param country - string  * @param cartId - cartId
   * @param authHeader - access token of customer  * @returns replicated new cart using old cart id */
  public replicateCartById = async (
    country: string,
    cartId: string,
    authHeader: string,
  ): Promise<Cart> => {
    try {
      const updatedCart = await this
        .ctClient.getClient(country).carts().replicate()
        .post({
          headers: {
            Authorization: authHeader,
          },
          body: {
            reference: {
              typeId: 'cart',
              id: cartId,
            },
          },
        })
        .execute();
      return updatedCart.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to replicate cart because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.UNAUTHORIZED) {
        throw new ApiError(HttpStatusCodes.UNAUTHORIZED, i18next.t(errorInvalidToken));
      }
      if (err.statusCode === HttpStatusCodes.BAD_REQUEST) {
        throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t(cartNotFound, { cartId }));
      }
      throw err;
    }
  };

  /** Recalculate cart * @param country - string * @param cart - Cart * @returns recalculated */
  public recalculateCart = async (country: string, cart: CtCartPaymentInfo): Promise<Cart> => {
    try {
      const recalculatedCart = await this.ctClient.getClient(country).carts().withId({ ID: cart.id }).post({
        body: {
          version: cart.version,
          actions: [{
            action: 'recalculate',
            updateProductData: true,
          }],
        },
      })
        .execute();
      return recalculatedCart.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to recalculate cart because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.BAD_REQUEST) {
        throw new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t(cartNotFound, { cartId: cart.id }));
      }
      throw err;
    }
  };
}
