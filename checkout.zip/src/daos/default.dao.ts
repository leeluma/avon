import { CommonResponse } from '../dtos';
import {
  ApiError, CtClient, logger,
} from '../lib';
import { MarketInfo } from '../middlewares';

export interface DefaultDaoConfig {
  ctClient: CtClient;
}

/**
 * `defaultDao` data access class for Header
 */
export class DefaultDao {
  private readonly ctClient: CtClient;

  /**
   * Constructor for `DefaultDao` class
   * @param configuration - Injects dependencies into the object
   */
  constructor(configuration: DefaultDaoConfig) {
    this.ctClient = configuration.ctClient;
  }

  /**
   * Get result from Commerce Tool
   * @param market - MarketInfo
   * @param params - Params
   * @returns result
   */
  public async refreshToken(
    market: MarketInfo,
    params,
  ): Promise<CommonResponse> {
    try {
      return await this.ctClient.getAuthClient(market.country).refreshTokenFlow(params);
    } catch (error: any) { // NOSONAR
      logger.error(`Failed to generate refreshToken from Commerce Tool because:\n${error}`);
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, error.errors);
      }
      throw error;
    }
  }
}
