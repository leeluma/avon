/* eslint-disable max-len */
import { Order } from '@commercetools/platform-sdk';
import axios from 'axios';
import { ApptusRequestDto } from '../dtos';
import { GraphQLOrder } from '../dtos/order.dto';
import { queryString, logger, logError } from '../lib';
import { OrderMapper } from '../mappers';
import { MarketInfo } from '../middlewares';

export interface NotificationsDaoConfig {
  apptusPaymentNotificationEndpoint: string;
  apptusClusterId: string;
  apptusApiKey: string;
  apptusEsalesMarket: string;
  orderMapper: OrderMapper;
}

/**
 * `CtNotificationsDao` data access class for CommerceTools `Product`
 */
export class NotificationsDao {
  private readonly apptusPaymentNotificationEndpoint: string;

  private readonly apptusClusterId: string;

  private readonly apptusApiKey: string;

  private readonly apptusEsalesMarket: string;

  private readonly orderMapper: OrderMapper;

  /**
   * Constructor for `CtNotificationsDao` class
   * @param config Injects dependencies into the object
   */
  constructor(config: NotificationsDaoConfig) {
    this.apptusPaymentNotificationEndpoint = config.apptusPaymentNotificationEndpoint;
    this.apptusClusterId = config.apptusClusterId;
    this.apptusApiKey = config.apptusApiKey;
    this.apptusEsalesMarket = config.apptusEsalesMarket;
    this.orderMapper = config.orderMapper;
  }

  /**
   * Send notification to apptus once order has been created
   * @param market - MarketInfo
   * @param id - Product id
   * @returns Product | undefined
   */
  public async paymentNotifications(
    market: MarketInfo,
    params: ApptusRequestDto,
    order: GraphQLOrder | Order,
  ): Promise<boolean> {
    try {
      const currentMarket = `${this.apptusEsalesMarket}${market.locale.toUpperCase()}-${market.country}`;
      const apptusQueryParams = {
        'esales.market': currentMarket,
        'esales.customerKey': params.customerKey,
        'esales.sessionKey': params.sessionKey,
      };

      const queryParams = queryString(apptusQueryParams);
      const url = `${this.apptusPaymentNotificationEndpoint.replace('{{CLUSTER_ID}}', this.apptusClusterId)}?${queryParams}`;
      const lines = order.lineItems.map((item) => {
        const {
          sellPrice,
          listPrice,
        } = this.orderMapper.checkChannelGraphql(item.variant.prices);
        return {
          productKey: `${item.productKey}_${currentMarket}`,
          variantKey: `${item.variant.key}_${currentMarket}`,
          quantity: item.quantity,
          sellingPrice: sellPrice,
          cost: listPrice,
        };
      });
      const payload = { lines };
      logger.debug(`apptus payment notification url ${url}`);
      logger.debug(`apptus payment notification body ${JSON.stringify(payload)}`);
      await axios.post(url, payload, {
        headers: {
          'API-key': this.apptusApiKey,
        },
      });
    } catch (error: any) { // NOSONAR
      /* istanbul ignore next */
      logError('NotificationsDao.paymentNotifications', 'Failed to notify Apptus', error);
    }

    return true;
  }
}
