import {
  Payment, PaymentDraft, PaymentUpdate, State,
} from '@commercetools/platform-sdk';
import axios from 'axios';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { axiosOptions } from '../lib/axios-options';
import {
  ApiError, constructUrl, CtClient, logError, logger,
} from '../lib';
import { MarketInfo } from '../middlewares';
import {
  E_PAYMENT_STATUS, PaymentInitResponseDto, PaymentStatusResponseDto, PaymentTransactionResponseDto,
} from '../dtos';
import { graphql } from '../graphql';

interface PaymentDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
  paymentApiPrefix: string;
  paymentApiInitSuffix: string;
  paymentApiKey: string;
  paymentOrderNumberGeneratorUrl: string;
  paymentKeyGeneratorUrl: string;
  paymentRetryCount: number;
  paymentRetryTimeout: number;
}

const country = '{{country}}';
const locale = '{{locale}}';
const EPAY_CHANNEL = 'Leap';

/**
 * `CtPaymentDao` data access class for CommerceTools `Payment`
 */
export class PaymentDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  private readonly paymentApiPrefix: string;

  private readonly paymentApiInitSuffix: string;

  private readonly paymentApiKey: string;

  private readonly paymentOrderNumberGeneratorUrl: string;

  private readonly paymentKeyGeneratorUrl: string;

  private readonly paymentRetryCount: number;

  private readonly paymentRetryTimeout: number;

  /**
   * Constructor for `PaymentDao` class
   * @param config injects dependencies into the object
   */
  constructor(config: PaymentDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
    this.paymentApiPrefix = config.paymentApiPrefix;
    this.paymentApiInitSuffix = config.paymentApiInitSuffix;
    this.paymentApiKey = config.paymentApiKey;
    this.paymentOrderNumberGeneratorUrl = config.paymentOrderNumberGeneratorUrl;
    this.paymentKeyGeneratorUrl = config.paymentKeyGeneratorUrl;
    this.paymentRetryCount = config.paymentRetryCount;
    this.paymentRetryTimeout = config.paymentRetryTimeout;
  }

  /**
   * Create Payment in CT
   * @param market - MarketInfo
   * @param paymentDraft - PaymentDraft
   * @returns Newly created Payment
   */
  public createPayment = async (
    market: MarketInfo,
    paymentDraft: PaymentDraft,
  ): Promise<Payment> => {
    try {
      const createdPayment = await this.ctClient.getClient(market.country)
        .payments()
        .post({ body: paymentDraft })
        .execute();
      return createdPayment.body;
    } catch (err: any) { // NOSONAR
      logError('PaymentService', 'Failed to create payment', err); // NOSONAR
      throw err;
    }
  };

  /**
   * Update Transaction in CT
   * @param market - MarketInfo
   * @param paymentId - string
   * @param payload - PaymentUpdate
   * @returns Newly created Payment
   */
  public updatePayment = async (
    market: MarketInfo,
    paymentId: string,
    payload: PaymentUpdate,
  ): Promise<Payment> => {
    try {
      const updatedTransaction = await this.ctClient.getClient(market.country)
        .payments()
        .withId({ ID: paymentId })
        .post({ body: payload })
        .execute();
      return updatedTransaction.body;
    } catch (err: any) { // NOSONAR
      logError('PaymentDao', 'Failed to create payment', err); // NOSONAR
      throw err;
    }
  };

  public epayInitiate = async (
    market: MarketInfo,
    param,
    returnUrl: string,
    css: string,
  ): Promise<PaymentInitResponseDto> => {
    const {
      paymentRefId,
      orderNumber,
      payerId,
      totalPrice,
      billingAddress,
    } = param;
    const url = `${this.paymentApiPrefix}${this.paymentApiInitSuffix}`
      .replace(country, market.country)
      .replace(locale, market.locale);

    logger.info(`PaymentService.initiate PSP request URL is: ${url}`);
    logger.info(`PaymentService.initiate PSP return URL is: ${returnUrl}`);

    let response;
    try {
      response = await axios({
        ...axiosOptions,
        url,
        method: 'POST',
        headers: { 'x-api-key': this.paymentApiKey },
        data: {
          ordNr: orderNumber,
          paymentRefId,
          payerType: 'CUST',
          payerId,
          amount: totalPrice.centAmount,
          returnUrl,
          css,
          channel: EPAY_CHANNEL,
          threeDSReqd: true,
          billingInfo: {
            firstName: billingAddress.firstName,
            lastName: billingAddress.lastName,
            emailAddress: billingAddress.email,
            address: billingAddress.streetName,
            city: billingAddress.city,
            state: billingAddress.state,
            zip: billingAddress.postalCode,
            country: billingAddress.country,
            phone: billingAddress.phone,
          },
        },
      });
    } catch (err: any) { // NOSONAR
      // -- only two possibilities of types in case of error i.e. any|unknown
      logError('PaymentDao', 'Failed to initiate payment in payment gateway', err);
      throw err;
    }

    logger.info(`PaymentService.initiate response from PSP: ${JSON.stringify(response.data)}`);

    if (!('data' in response)) {
      throw new Error('Payment GW response is missing "data" field');
    }
    if (typeof response.data.id !== 'string') {
      throw new Error('Payment GW response is missing data "id" field');
    }
    if (typeof response.data.url !== 'string') {
      throw new Error('Payment GW response is missing data "url" field');
    }

    return { id: response.data.id, url: response.data.url };
  };

  public getAllPaymentStates = async (market: MarketInfo): Promise<State[]> => {
    try {
      const paymentStates = await this.ctClient.getClient(market.country)
        .states()
        .get({
          queryArgs: {
            limit: 100, // default is 20 when querying States
            where: 'type = "PaymentState"',
          },
        })
        .execute();
      return paymentStates.body.results;
    } catch (err: any) { // NOSONAR
      //  -- only two possibilities of types in case of error i.e. any|unknown
      logError('PaymentDao', 'Failed to retrieve payment states from CT', err); // NOSONAR
      throw err;
    }
  };

  public getNextOrderSequence = async (market: MarketInfo): Promise<string> => {
    const url = this.paymentOrderNumberGeneratorUrl
      .replace(country, market.country);

    const orderNumber = await axios({
      ...axiosOptions,
      url,
      method: 'post',
      headers: { Accept: 'text/plain' }, // NOSONAR
    });
    return String(orderNumber.data);
  };

  public getNextPaymentKey = async (market: MarketInfo): Promise<string> => {
    const url = this.paymentKeyGeneratorUrl
      .replace(country, market.country);

    const orderNumber = await axios({
      ...axiosOptions,
      url,
      method: 'post',
      headers: { Accept: 'text/plain' }, // NOSONAR
    });
    return String(orderNumber.data);
  };

  public getMyPaymentStatus = async (
    market: MarketInfo,
    authorization: string,
    cartId: string,
  ): Promise<PaymentStatusResponseDto> => {
    const body = {
      query: await this.graphql.getCartPaymentInfo,
      variables: { cartId },
    };

    try {
      const ctResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          headers: { Authorization: authorization },
          body,
        })
        .execute();

      const { state } = ctResponse.body.data.me.cart.paymentInfo.payments[0].paymentStatus;

      return {
        status: state.key,
      };
    } catch (err: any) { // NOSONAR
      logError('PaymentDao', 'Failed to fetch payment status', err);
      if (err.body?.statusCode) {
        throw new ApiError(err.body.statusCode, err.body.errors);
      }
      throw err;
    }
  };

  /**
   * Get payment status from PSP
   * @param market - MarketInfo
   * @param transactionId - string
   * @param retry - number
   * @returns Payment status against transaction id
   */
  public ePayTransactionDetail = async (
    market: MarketInfo,
    transactionId: string,
    retry: number,
  ): Promise<PaymentTransactionResponseDto> => {
    const paymentApiPrefixUrl = this.paymentApiPrefix.replace(country, market.country)
      .replace(locale, market.locale);
    const url = constructUrl(paymentApiPrefixUrl, `transaction/${transactionId}`);
    logger.info(`ePay transaction url: ${url}`);

    let response;
    try {
      response = await axios({
        ...axiosOptions, url, method: 'GET', headers: { 'x-api-key': this.paymentApiKey },
      });
    } catch (err: any) { // NOSONAR
      // -- only two possibilities of types in case of error i.e. any|unknown
      if (err?.response?.status === HttpStatusCodes.BAD_REQUEST) {
        throw new ApiError(err.response.status, err.response.data.message);
      }
      logError('PaymentDao', 'Failed to get transaction status from payment gateway', err);
      throw err;
    }

    logger.info(`PaymentService.getPaymentStatus response from PSP: ${JSON.stringify(response.data)}`);

    if (!('data' in response)) {
      throw new Error(i18next.t('error.paymentStatusDataFieldMissing'));
    }
    if (typeof response.data.status !== 'string') {
      throw new Error(i18next.t('error.paymentStatusStatusFieldMissing'));
    }
    if (typeof response.data.ordNr !== 'string') {
      throw new Error(i18next.t('error.paymentStatusOrdNrFieldMissing'));
    }
    if (Object.values(E_PAYMENT_STATUS).includes(response.data.status)) {
      await this.checkEPayTransactionStatus(market, transactionId, retry, response.data);
    } else {
      throw new ApiError(
        HttpStatusCodes.PAYMENT_REQUIRED,
        i18next.t('error.paymentStatusNotExpected', response.data.status),
      );
    }
    return response.data;
  };

  private readonly checkEPayTransactionStatus = async (
    market: MarketInfo,
    transactionId: string,
    retry: number,
    ePayTransaction: PaymentTransactionResponseDto,
  ) => {
    /* Retry no. of times if status is pending */
    if (ePayTransaction.status === E_PAYMENT_STATUS.pending) {
      if (retry > this.paymentRetryCount) {
        throw new ApiError(
          HttpStatusCodes.INTERNAL_SERVER_ERROR,
          i18next.t('error.paymentIsPendingForTransId', transactionId),
        );
      }
      logger.info(`PaymentService.ePayTransactionDetail get trans status attempt ${retry}/${this.paymentRetryCount}`);

      // eslint-disable-next-line no-param-reassign
      retry += 1;
      logger.info('retry setTimeout: >>', this.paymentRetryTimeout);
      await new Promise((resolve) => {
        setTimeout(resolve, this.paymentRetryTimeout);
      });
      await this.ePayTransactionDetail(market, transactionId, retry);
    }
  };
}
