import axios from 'axios';
import {
  DetailResponseDto, NormalizedAddress, PickupPointResponseDto,
} from '../dtos';
import { logger } from '../lib';

/**
 * `AddressDao` data access class for CommerceTools `addresses`
 */
export class AddressDao {
  /**
   * Constructor for `AddressDaoConfig`
   * @param config injects dependencies into the object
   */
  /**
   * Get Address Autocomplete
   * @param url
   * @param address
   */
  public async addressAutocomplete(
    url: string,
    address: string | undefined,
  ): Promise<NormalizedAddress[]> {
    try {
      const result = await axios.get(url, {
        params: {
          address,
        },
      });
      return result.data.suggestions.filter((item) => item.exactMatch === true);
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to get autocomplete details from url ${url}, because: ${err}`);
      throw err;
    }
  }

  /**
   * Get Address Detail
   * @param url
   * @param address
   */
  public async addressDetail(
    url: string,
    addressId: string,
  ): Promise<DetailResponseDto> {
    try {
      const result = await axios.get(url, {
        params: {
          addressId,
        },
      });
      return result.data;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to get address details from url ${url}, because: ${err}`);
      throw err;
    }
  }

  /**
   * Get Pickup Details
   * @param url
   * @param params
   */
  public async getPickupDetail(
    url: string,
    headers,
    params,
  ): Promise<PickupPointResponseDto> {
    logger.debug(`Getting pickup details from ${url} with params ${JSON.stringify(params)}`);
    try {
      const result = await axios.get(url, { headers, params });
      return result.data;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to get pickup details from url ${url}, because: ${err}`);
      throw err;
    }
  }
}
