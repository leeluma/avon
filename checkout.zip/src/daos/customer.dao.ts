import {
  CartUpdate,
  CustomerSignin,
  GraphQLResponse,
  ClientResponse,
  Customer,
  CustomerUpdate,
  CustomerDraft,
  MyCustomerDraft,
} from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { LoginCustomerDto, CustomerForgotPassword, GraphQLCustomerResponse } from '../dtos';
import { ApiError, CtClient, logger } from '../lib';
import { MarketInfo } from '../middlewares';
import { graphql } from '../graphql';

export interface CustomerDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

enum CART_ACTIONS {
  setCustomerId = 'setCustomerId',
}

/**
 * `CustomerDao` data access class for CommerceTools `customer`
 */
export class CustomerDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `customerDraftDto` class
   * @param config injects dependencies into the object
   */
  constructor(config: CustomerDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
   * Reads a Customer from CommerceTools
   * @param market - MarketInfo
   * @param authHeader - customer auth token
   * @returns Fetched customerDao (or undefined if the Customer doesn't exist)
   */
  public async getCustomerDetailsGraphQL(
    market: MarketInfo,
    authHeader: string,
    getDefaultAddress?: boolean,
  ): Promise<GraphQLCustomerResponse> {
    try {
      const body = {
        query: await this.graphql.getCustomerByToken,
      };
      const result: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          headers: {
            Authorization: authHeader,
          },
          body,
        })
        .execute();

      const { body: { data: { me: { customer } } } } = result;
      if (!customer) {
        throw new ApiError(
          HttpStatusCodes.NOT_FOUND,
          i18next.t('error.customerNotFound'),
        );
      }

      if (getDefaultAddress && customer && Array.isArray(customer.addresses) && !customer.addresses.length) {
        throw new ApiError(
          HttpStatusCodes.NOT_FOUND,
          i18next.t('error.addressNotFound'),
        );
      }
      return customer;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`from Commerce tool, because:\n${error.stack}`);
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, (error?.messageArray) ? error.messageArray : error.message);
      }
      throw error;
    }
  }

  /**
   * Use to retrive customer's login reponse from commercetool.
   * @param market - MarketInfo
   * @param customerSignin - CustomerSignin
   */
  public async login(
    market: MarketInfo,
    customerSignin: CustomerSignin,
  ): Promise<LoginCustomerDto> {
    try {
      return await this.ctClient.getAuthClient(market.country)
        .customerPasswordFlow({
          username: customerSignin.email,
          password: customerSignin.password,
        }, {
          disableRefreshToken: false,
        });
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to retrieve auth login info from CT because:\n${error.stack}`);
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, i18next.t('error.customerNotFound'));
      }
      throw error;
    }
  }

  /**
   * Use to set customer id to anonymous cart.
   * @param market - MarketInfo
   * @param cartId - string Cart id
   * @param version - number Cart version
   * @param customerId - string Customer id
   * */
  public async setCustomerIdToCart(
    market: MarketInfo,
    cartId: string,
    version: number,
    customerId: string,
  ): Promise<void> {
    const body: CartUpdate = {
      version,
      actions: [{
        action: CART_ACTIONS.setCustomerId,
        customerId,
      }],
    };

    try {
      await this.ctClient.getClient(market.country)
        .carts()
        .withId({ ID: cartId })
        .post({ body })
        .execute();
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to retrieve auth login info from CT because:\n${error.stack}`);
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, error.errors);
      }
      throw error;
    }
  }

  /**
   * Update Customer Address Dao
   * @param market - MarketInfo
   * @param customerId - Customer Id
   * @param payload - Payload to be sent to Commerce Tool
   * @returns Updated Address response
   */
  public async updateCustomer(
    market: MarketInfo,
    customerId: string,
    payload: CustomerUpdate,
  ): Promise<Customer> {
    const response: ClientResponse<Customer> = await this.ctClient.getClient(market.country)
      .customers()
      .withId({ ID: customerId })
      .post({
        body: payload,
      })
      .execute();

    return response.body;
  }

  /**
 * Reads a Customer from CommerceTools
 * @param market - MarketInfo
 * @param customerId - Id of Commerce Tool Customer to retrieve
 * @returns Fetched customerDao (or undefined if the Customer doesn't exist)
 */
  public async findGraphQLOne(
    market: MarketInfo,
    customerId: string,
  ): Promise<GraphQLCustomerResponse> {
    const body = {
      query: await this.graphql.getCustomerById,
      variables: {
        id: customerId,
      },
    };
    const result: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
      .graphql()
      .post({ body })
      .execute();
    const { customer } = result.body.data;
    return customer;
  }

  /** Forgot a Customer's password in CommerceTools
   * @param market - MarketInfo
   * @param email - email
   * @param Url - url
   */
  public async forgotCustomersPassword(
    market: MarketInfo,
    email: string,
  ): Promise<CustomerForgotPassword> {
    const forgotPasswordResult = await this.ctClient.getClient(market.country)
      .customers()
      .passwordToken()
      .post({ body: { email } })
      .execute();
    return forgotPasswordResult.body;
  }

  /**
   * Creates a customerDao for Customer
   * @param market - MarketInfo
   * @param customerDraft - Draft for customerDraft to be created
   * @returns customerResponse
   */
  public async create(
    market: MarketInfo,
    customerDraft: CustomerDraft,
    authHeader: string,
  ): Promise<Customer> {
    try {
      const country = market.country.toLocaleUpperCase();

      const response = await this.ctClient
        .getClient(country)
        .me()
        .signup()
        .post({
          headers: {
            Authorization: authHeader,
          },
          body: customerDraft as MyCustomerDraft,
        })
        .execute();

      return response.body.customer;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`from Commerce Tool, because:\n${err.stack}`);
      if (err.body?.statusCode) {
        throw new ApiError(err.body.statusCode, err.body.errors);
      }
      throw err;
    }
  }
}
