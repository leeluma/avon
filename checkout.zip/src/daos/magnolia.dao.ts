import axios, { Axios, AxiosResponse } from 'axios';
import { axiosOptions } from '../lib/axios-options';
import { MarketInfo } from '../middlewares';
import { MAGNOLIA_URI } from '../common/constants';
import {
  CommonResponse, MagnoliaDto, MagnoliaInfo, PriceFormat,
} from '../dtos';
import { config as configValues } from '../config';

export interface MagnoliaDaoConfig {
  magnoliaBasePath : string | undefined;
}

const country = '{{country}}';

/**
 * `MagnoliaDao` data access class for Magnolia
 */
export class MagnoliaDao {
  /**
   * Get Checkout page data From Magnolia
   * @param market - MarketInfo
   * @param magnoliaBasePath - string Magnolia API URL base path
   * @returns Return checkout data from Magnolia
   */
  private readonly magnoliaBasePath: string | undefined;

  /**
    * Constructor for `customerDraftDto` class
    * @param config injects dependencies into the object
    */
  constructor(config: MagnoliaDaoConfig) {
    this.magnoliaBasePath = config.magnoliaBasePath;
  }

  public async getCheckoutPageData(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ): Promise<CommonResponse> {
    const queryParam = `lang=${market.locale}-${market.country}`;
    const page = (magnolia.isPreview === true && magnolia.marketPath !== market.country.toLocaleLowerCase())
      ? MAGNOLIA_URI.checkoutPage : MAGNOLIA_URI.checkout;
    let checkoutUrl = `${magnolia.url}${page}?${queryParam}`;
    checkoutUrl = checkoutUrl.replace(country, `${magnolia.marketPath}`);
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: checkoutUrl,
    };
    try {
      const result = await axios(config);
      return result.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch checkout data from Magnolia, because: ${error.stack}`);
    }
  }

  public async getOrderConfirmationPageData(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ): Promise<MagnoliaDto> {
    const queryParam = `lang=${market.locale}-${market.country}`;
    const page = (magnolia.isPreview === true && magnolia.marketPath !== market.country.toLocaleLowerCase())
      ? MAGNOLIA_URI.orderConfirmationPage : MAGNOLIA_URI.orderConfirmation;
    let checkoutUrl = `${magnolia.url}${page}?${queryParam}`;
    checkoutUrl = checkoutUrl.replace(country, `${magnolia.marketPath}`);
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: checkoutUrl,
    };
    try {
      const result = await axios(config);
      return result.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch order confirmation data from Magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get template data from Magnolia
   * @param templateName magnolia template name
   * @param magnoliaBasePath - string Magnolia API URL base path
   * @returns return template data from Magnolia
   */
  public async getTemplateDataFromMagnolia(
    templateName: string,
    magnoliaBasePath: string,
  ): Promise<Axios> {
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: `${magnoliaBasePath}${MAGNOLIA_URI.template}${templateName}`,
    };
    try {
      const howToLook = await axios(config);
      return howToLook.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch template data from Magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get warehouse data
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   */
  public async getDefaultWarehouse(
    market: MarketInfo,
    magnoliaBasePath: string,
  ): Promise<AxiosResponse> {
    try {
      const queryParams = `lang=${market.locale}-${market.country}`;
      let wareHouseSettingUrl = `${magnoliaBasePath}${MAGNOLIA_URI.wareHouseSetting}?${queryParams}`;
      wareHouseSettingUrl = wareHouseSettingUrl.replace(country, `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: wareHouseSettingUrl,
      };
      const result = await axios(config);
      return result.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch warehouse data from magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get global settings data
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   */
  public async getGlobalSettings(
    market: MarketInfo,
    magnoliaBasePath?: string | undefined,
  ): Promise<CommonResponse> {
    try {
      const queryParams = `lang=${market.locale}-${market.country}`;
      const magnoliaUri = magnoliaBasePath || this.magnoliaBasePath;
      let globalSettingsUrl = `${magnoliaUri}${MAGNOLIA_URI.globalSettings}?${queryParams}`;
      globalSettingsUrl = globalSettingsUrl.replace(country, `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: globalSettingsUrl,
      };
      const result = await axios(config);
      return result.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch global settings data from magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get price format settings data from magnolia
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   */
  public async getPriceFormatSettings(
    market: MarketInfo,
    magnoliaBasePath: string,
  ) : Promise<PriceFormat> {
    try {
      const queryParams = `lang=${market.locale}-${market.country}`;
      let priceFormatSettingsUrl = `${magnoliaBasePath}${MAGNOLIA_URI.priceFormat}?${queryParams}`;
      priceFormatSettingsUrl = priceFormatSettingsUrl.replace(country, `${market.country.toLocaleLowerCase()}`);

      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: priceFormatSettingsUrl,
      };
      const result = await axios(config);

      return result.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch price format settings data from magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get address validation settings data from magnolia
   * @param market - MarketInfo
   */
  public async getSettings(
    market: MarketInfo,
    apiPath: string,
  ) : Promise<MagnoliaDto> {
    try {
      const queryParams = `lang=${market.locale}-${market.country}`;
      let settingsUrl = `${configValues.magnoliaBasePath}${apiPath}?${queryParams}`;
      settingsUrl = settingsUrl.replace(country, `${market.country.toLocaleLowerCase()}`);

      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: settingsUrl,
      };
      const result = await axios(config);

      return result.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch address validation settings data from magnolia, because: ${error.stack}`);
    }
  }
}
