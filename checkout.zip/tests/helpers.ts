import i18next, { TFunction } from 'i18next';
import i18nextMiddleware from 'i18next-http-middleware';
import i18nextBackend from 'i18next-fs-backend';

export const bootstrapI18next = async (): Promise<TFunction> => {
  const options = {
    order: ['path'],
    lookupPath: 'locale',
    caches: false,
  };
  return i18next
    .use(i18nextMiddleware.LanguageDetector)
    .use(i18nextBackend)
    .init({
      preload: ['en', 'ro'],
      ns: ['translation'],
      defaultNS: 'translation',
      detection: options,
      fallbackLng: 'en',
      backend: {
        loadPath: `${__dirname}/../src/locale/{{lng}}/translation.json`,
      },
    });
};
