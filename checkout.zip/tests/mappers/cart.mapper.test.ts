import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { AddressMapper, CartMapper } from '../../src/mappers';
import {
  stubCartServiceToMapper,
  stubCartMapperResult,
  stubCartServiceToMapper1,
  stubCartServiceToMapper2,
  stubCartServiceToMapper8,
  stubCartServiceToMapper9,
  stubGraphQLCart,
  stubPriceFormatSettings,
  stubGlobalSettings,
  stubMarket,
} from '../__stubs__';
import { CartDto, GraphQLCart } from '../../src/dtos';

describe('CartMapper', () => {
  let market: MarketInfo;
  let cartMapper: CartMapper;
  let addressMapper: AddressMapper;
  let cart: any;
  let cartExpected: CartDto;
  let cart1: any;
  let cart2: any;
  let graphQLCart: GraphQLCart;
  let globalSettings;
  beforeEach(() => {
    market = stubMarket();
    graphQLCart = stubGraphQLCart();
    addressMapper = new AddressMapper();
    cartMapper = new CartMapper({ addressMapper });
    cart = stubCartServiceToMapper();
    cartExpected = stubCartMapperResult();
    cart1 = stubCartServiceToMapper1();
    cart2 = stubCartServiceToMapper2();
    globalSettings = stubGlobalSettings();
    market.locale = 'ro';
  });

  test('cartToDto', () => {
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart, market, globalSettings.priceFormat, undefined, 'AVON10%');

    /* Verify */
    expect(result).toMatchObject(cartExpected);
  });

  test('cartToDto to cover shippingAddress', () => {
    /* Execute */
    cart.shippingAddress = { id: faker.datatype.uuid() };
    cart.shippingInfo = { id: faker.datatype.uuid() };
    const result = (cartMapper as CartMapper).cartToDto(cart, market, globalSettings.priceFormat, undefined, 'AVON10%');

    /* Verify */
    expect(result).toMatchObject(cartExpected);
  });

  test('cartToDto for maxPurchasableQty undefined', () => {
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart1, market, globalSettings.priceFormat);

    /* Verify */
    expect(result.lineItems[0].maxPurchasableQty).toBe(9999999);
  });

  test('cartToDto for availableQuantity undefined', () => {
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart2, market, globalSettings.priceFormat);

    /* Verify */
    expect(result.lineItems[0].availableQuantity).toBe(9999999);
  });

  test('cart mapper with no lineItems', () => {
    const cart8 = stubCartServiceToMapper8();
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart8, market, globalSettings.priceFormat);

    /* Verify */
    expect(result.lineItems.length).toBe(0);
  });

  test('cart mapper discount DoesNotMatchCart', () => {
    const cart9 = stubCartServiceToMapper9();
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart9, market, globalSettings.priceFormat);

    /* Verify */
    expect(result.promotion?.promotionState).toBe('DoesNotMatchCart');
  });

  // test('checkDiscount mapper', () => {
  //   /* Setup */
  //   const price = {
  //     id: faker.datatype.uuid(),
  //     value: {
  //       type: 'centPrecision',
  //       currencyCode: 'RON',
  //       centAmount: faker.datatype.number(),
  //       fractionDigits: 2,
  //     },
  //     discounted: {
  //       value: {
  //         type: 'centPrecision',
  //         currencyCode: 'RON',
  //         centAmount: faker.datatype.number(),
  //         fractionDigits: 2,
  //       },
  //       discount: {
  //         typeId: faker.datatype.string(),
  //         id: faker.datatype.uuid(),
  //       },
  //     },
  //   };
  //   const expectedRes = true;
  //   /* Execute */
  //   const result = (cartMapper as any).checkDiscount(price);

  //   /* Verify */
  //   expect(result.isPromotionApplied).toBe(expectedRes);
  // });

  describe('createCartResponse()', () => {
    test('responds with the mapped CartResponse', () => {
      /** prepare */
      const result = cartMapper.createCartResponse(graphQLCart, globalSettings.priceFormat, []);
      expect(graphQLCart).toBeTruthy();
      expect(result).toBeTruthy();
    });
  });

  describe('getLineItems()', () => {
    test('responds with the mapped CartLineItem', () => {
      const result = cartMapper.getLineItems(
        graphQLCart.lineItems,
        globalSettings.priceFormat,
        [],
        undefined,
      );
      expect(result).toBeTruthy();
    });
  });

  describe('createCartResponseForShippingMethodAdded()', () => {
    test('responds with the mapped CartResponse of shipping method', () => {
      /** prepare */
      const result = cartMapper.createCartResponseForShippingMethodAdded(cart, stubPriceFormatSettings as any);
      expect(cart).toBeTruthy();
      expect(result).toBeTruthy();
    });
  });
  describe('getVatText()', () => {
    test('getVatText()', () => {
      /* Prepare */
      const priceFormat = {
        vatIncludedMessage: 'test',
        isVatIncluded: 'true',
      };
      /* Execute */
      const result = (cartMapper as any).getVatText(priceFormat);

      /* Verify */
      expect(result).toEqual('test');
    });

    test('getVatText() for false scenario', () => {
      /* Execute */
      const result = (cartMapper as any).getVatText({});

      /* Verify */
      expect(result).toEqual('');
    });
  });
});
