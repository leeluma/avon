import faker from '@faker-js/faker';
import { ShippingMethodMapper } from '../../src/mappers/shipping-method.mapper';
import { stubGlobalSettings, stubShippingMethodDto } from '../__stubs__';

describe('shippingMapper', () => {
  let shippingMapper: ShippingMethodMapper;
  let globalSettings;

  beforeEach(() => {
    shippingMapper = new ShippingMethodMapper();
    globalSettings = stubGlobalSettings();
  });

  test('get shippingMethodToDto mapper', () => {
    /* Prepare */
    const shippingMapperCartInfo = stubShippingMethodDto();
    const shippingInfoExpected = {
      id: shippingMapperCartInfo.id,
      name: shippingMapperCartInfo.localizedDescription,
      formattedDeliveryCharge: '50.00 RON',
      formattedFreeAbove: '200.00 RON',
      deliveryCharge: 50.00,
      freeAbove: 200.00,
    };
    /* Execute */
    const result = (shippingMapper as any).shippingMethodCartToDto(
      [shippingMapperCartInfo],
      globalSettings.priceFormat,
    );
    /* Verify */
    expect(result).toMatchObject([shippingInfoExpected]);
  });

  test('get shippingMethodToDto mapper for empty keys', () => {
    /* Prepare */
    const shippingMapperCartInfo = {
      id: faker.datatype.uuid(),
      name: faker.datatype.string(),
      localizedDescription: faker.datatype.string(),
      isDefault: true,
      zoneRates: [
        {
          shippingRates: [
            {
            },
          ],
        },
      ],
    };
    const shippingInfoExpected = {
      id: shippingMapperCartInfo.id,
      name: shippingMapperCartInfo.localizedDescription,
      formattedDeliveryCharge: '',
      formattedFreeAbove: '',
      deliveryCharge: 0,
      freeAbove: null,
    };
    /* Execute */
    const result = (shippingMapper as any).shippingMethodCartToDto(
      [shippingMapperCartInfo],
      globalSettings.priceFormat,
    );
    /* Verify */
    expect(result).toMatchObject([shippingInfoExpected]);
  });
});
