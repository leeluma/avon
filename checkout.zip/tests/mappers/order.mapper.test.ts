import currency from 'currency.js';
import faker from '@faker-js/faker';
import { OrderMapper } from '../../src/mappers';
import { MarketInfo } from '../../src/middlewares';
import {
  stubGlobalSettings,
  stubGraphQLOrder,
  stubOrderDto,
  stubMarket,
  AddressStub,
} from '../__stubs__';
import { OrderDto, GraphQLOrder } from '../../src/dtos/order.dto';

describe('OrderMapper', () => {
  let orderMapper: OrderMapper;
  let orderExpected: OrderDto;
  let address: any;
  let graphQLOrder: GraphQLOrder;
  let market: MarketInfo;
  let globalSettings;

  beforeEach(() => {
    market = stubMarket();
    globalSettings = stubGlobalSettings();
    graphQLOrder = stubGraphQLOrder();
    orderMapper = new OrderMapper();
    orderExpected = stubOrderDto();
    address = AddressStub();
  });

  test('mapOrderDetails', () => {
    /* Execute */
    const result = (orderMapper as OrderMapper).mapOrderDetails(graphQLOrder, market, globalSettings.priceFormat);

    /* Verify */
    expect(graphQLOrder).toBeTruthy();
    expect(result).toBeTruthy();
  });

  describe('getLineItems()', () => {
    test('responds with the mapped OrderLineItem', () => {
      const result = orderMapper.getLineItems(
        market,
        graphQLOrder.lineItems,
        globalSettings.priceFormat,
        graphQLOrder.discountCodes[0].discountCode,
      );
      expect(result).toBeTruthy();
    });
  });

  /**
   * Check discount function in order mapper
   */
  // test('checkDiscount mapper', () => {
  //   /* Setup */
  //   const price = {
  //     id: faker.datatype.uuid(),
  //     value: {
  //       type: 'centPrecision',
  //       currencyCode: 'RON',
  //       centAmount: faker.datatype.number(),
  //       fractionDigits: 2,
  //     },
  //     discounted: {
  //       value: {
  //         type: 'centPrecision',
  //         currencyCode: 'RON',
  //         centAmount: faker.datatype.number(),
  //         fractionDigits: 2,
  //       },
  //       discount: {
  //         typeId: faker.datatype.string(),
  //         id: faker.datatype.uuid(),
  //       },
  //     },
  //   };
  //   const expectedRes = true;
  //   /* Execute */
  //   const result = (orderMapper as any).checkDiscount(price);

  //   /* Verify */
  //   expect(result.isPromotionApplied).toBe(expectedRes);
  // });

  // test('checkDiscount without discounted', () => {
  //   /* Setup */
  //   const price = {
  //     id: faker.datatype.uuid(),
  //     value: {
  //       type: 'centPrecision',
  //       currencyCode: 'RON',
  //       centAmount: faker.datatype.number(),
  //       fractionDigits: 2,
  //     },
  //   };
  //   const expectedRes = false;
  //   /* Execute */
  //   const result = (orderMapper as any).checkDiscount(price);

  //   /* Verify */
  //   expect(result.isPromotionApplied).toBe(expectedRes);
  // });

  test('getAddress()', () => {
    /* Execute */
    const result = (orderMapper as any).getAddress(address);

    /* Verify */
    expect(result).toBeTruthy();
  });

  test('getAddress() in case of mobile undefined', () => {
    /* Execute */
    delete address.mobile;
    delete address.streetNumber;
    delete address.streetName;
    delete address.apartment;
    delete address.building;
    address.firstName = null;
    const result = (orderMapper as any).getAddress(address);

    /* Verify */
    expect(result).toBeTruthy();
  });

  test('if address data is undefined in getAddress()', () => {
    /* Execute */
    const result = (orderMapper as any).getAddress(undefined);

    /* Verify */
    expect(result).toBe(undefined);
  });

  test('getPaymentInfo()', () => {
    /* Setup */
    const paymentInfo = {
      payments: [
        {
          paymentStatus: {
            state: {
              name: 'Pending',
            },
          },
          key: null,
          paymentMethodInfo: {
            method: 'CashOnDelivery',
            name: null,
          },
          amountPlanned: {
            type: 'centPrecision',
            currencyCode: 'RON',
            centAmount: 17822,
            fractionDigits: 2,
          },
        },
      ],
    };
    /* Execute */
    const result = (orderMapper as any).getPaymentInfo(paymentInfo, globalSettings.priceFormat);

    /* Verify */
    expect(result).toMatchObject({ paymentType: 'CashOnDelivery', paymentAmount: 'RON 178.22' });
  });
  test('getPaymentInfo() without success or pending status', () => {
    /* Setup */
    const paymentInfo = {
      payments: [
        {
          paymentStatus: {
            state: {
              name: 'Failed',
            },
          },
          key: null,
          paymentMethodInfo: {
            method: 'CashOnDelivery',
            name: null,
          },
          amountPlanned: {
            type: 'centPrecision',
            currencyCode: 'RON',
            centAmount: 17822,
            fractionDigits: 2,
          },
        },
      ],
    };
    const matchObj = {};
    /* Execute */
    const result = (orderMapper as any).getPaymentInfo(paymentInfo);

    /* Verify */
    expect(result).toBeDefined();
    expect(result).toMatchObject(matchObj);
  });
});
