import { Address, Customer, FieldContainer } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import {
  AddressResponseDto, GraphQLAddress, GraphQLCustomerResponse, DetailResponseDto,
  AddressRequestDto,
  CustomerResponseDto,
} from '../../src/dtos';
import { AddressMapper } from '../../src/mappers';
import { MarketInfo } from '../../src/middlewares';
import {
  stubAddressDto, stubGraphQLAddressDto, stubAddressResponseDto,
  stubCustomerDto, stubGraphQLCustomerDto, stubMarket, stubAddressRequestDto, stubCustomerResponseDto,
} from '../__stubs__';

describe('AddressMapper', () => {
  /** start testing address mapper */
  let addressMapper: AddressMapper;
  let addressDto: Address;
  let graphQLAddressDto: GraphQLAddress;
  let addressResponseDto: AddressResponseDto;
  let customerResponseDto: CustomerResponseDto;
  let addressRequestDto: AddressRequestDto;
  let customerDto: Customer;
  let graphQLcustomerDto: GraphQLCustomerResponse;
  let customFields: FieldContainer;
  let market: MarketInfo;
  let addressDetail: DetailResponseDto;

  let id: string;
  let key: string;
  let address1: string;
  let address2: string;
  let address3: string;
  let address4: string;
  let country: string;
  let county: string;
  let city: string;
  let latitude: number;
  let longitude: number;
  let region: string;
  let postalCode: string;
  let state: string;
  let phone: string;

  let isShippingAddress: boolean;
  let isBillingAddress: boolean;

  beforeEach(() => {
    key = faker.datatype.uuid();
    address1 = faker.address.streetAddress();
    address2 = faker.address.streetAddress();
    address3 = faker.address.streetAddress();
    address4 = faker.address.streetAddress();
    country = faker.address.countryCode();
    county = faker.address.county();
    latitude = +faker.address.latitude();
    longitude = +faker.address.longitude();
    state = faker.address.state();
    postalCode = faker.address.zipCode();
    phone = faker.phone.phoneNumber();
    city = faker.address.cityName();
    id = faker.datatype.uuid();
    market = stubMarket({
      locale: 'ro',
      country,
    });
    addressRequestDto = stubAddressRequestDto({
      address1,
      phoneNumber: phone,
      zip: postalCode,
      city,
      country,
      addressType: 'Delivery',
    });
    isShippingAddress = faker.datatype.boolean();
    isBillingAddress = faker.datatype.boolean();
    addressDetail = {
      country: 'RO',
      region1: county,
      region2: region,
      city,
      district1: address3,
      district2: null,
      zipCode: postalCode,
      streetName: '',
      houseNumber: '',
      floor: null,
      flat: null,
      latitude,
      longitude,
    };
    customFields = {
      customFieldsRaw:
      [
        {
          name: faker.datatype.string(),
          value: faker.random.word(),
        },
      ],
    };
    addressDto = stubAddressDto({
      id,
      custom: {
        type: {
          id: 'address-type',
          typeId: 'type',
        },
        fields: {
          Address1: address1,
          Address2: address2,
          Address3: address3,
          Address4: address4,
          Latitude: latitude,
          Longitude: longitude,
          county,
        },
      },
      city,
      region,
      country,
      state,
      phone,
      postalCode,
    });

    customerDto = stubCustomerDto({
      addresses: [addressDto],
      shippingAddressIds: isShippingAddress ? [id] : [],
      billingAddressIds: isBillingAddress ? [id] : [],
    });

    graphQLAddressDto = stubGraphQLAddressDto({
      id,
      custom: {
        type: {
          id: 'address-type',
          typeId: 'type',
        },
        customFieldsRaw: [
          {
            name: 'Address1',
            value: address1,
          }, {
            name: 'Address2',
            value: address2,
          }, {
            name: 'Address3',
            value: address3,
          }, {
            name: 'Address4',
            value: address4,
          }, {
            name: 'Latitude',
            value: latitude,
          }, {
            name: 'Longitude',
            value: longitude,
          },
          {
            name: 'county',
            value: county,
          },

        ],
      },
      city,
      region,
      country,
      state,
      phone,
      postalCode,
    });

    graphQLcustomerDto = stubGraphQLCustomerDto({
      id: customerDto.id,
      custom: {
        type: {
          typeId: 'type',
          id: faker.datatype.uuid(),
        },
        fields: {
          optIn: true,
        },
        customFieldsRaw: [{
          optIn: true,
        }],
      },
      addresses: [graphQLAddressDto],
      shippingAddressIds: isShippingAddress ? [id] : [],
      billingAddressIds: isBillingAddress ? [id] : [],
    });

    addressResponseDto = stubAddressResponseDto({
      customerId: customerDto.id,
      phoneNumber: phone,
      zip: postalCode,
      address1,
      address2,
      address3,
      address4,
      county,
      latitude,
      longitude,
      city,
      region,
      country,
      state,
      isShippingAddress,
      isBillingAddress,
    });
    customerResponseDto = stubCustomerResponseDto({
      id: graphQLcustomerDto.id,
      firstName: graphQLcustomerDto.firstName,
      lastName: graphQLcustomerDto.lastName,
      email: graphQLcustomerDto.email,
      optIn: graphQLcustomerDto.custom?.customFieldsRaw.optIn,
    });

    addressMapper = new AddressMapper();
  });

  describe('mapAddressResponse', () => {
    test('maps Address to AddressResponseDto', () => {
      const result = addressMapper.mapAddressResponse(addressDto, customerDto);
      expect(result).toMatchObject(addressResponseDto);
    });
  });

  describe('mapCustomerResponse', () => {
    test('maps Address to AddressResponseDto', () => {
      const result = addressMapper.mapCustomerResponse(graphQLcustomerDto);
      expect(result).toMatchObject(customerResponseDto);
    });
  });

  describe('mapToFields', () => {
    test('maps Address to CustomerResponseDto', () => {
      const result = addressMapper.mapToFields(customFields);
      expect(result).toBeTruthy();
    });
  });

  describe('mapGraphQLAddressResponse', () => {
    test('maps GraphQL Address to AddressResponseDto', () => {
      const result = addressMapper.mapGraphQLAddressResponse(graphQLAddressDto, graphQLcustomerDto);
      expect(result).toMatchObject(addressResponseDto);
    });
  });

  describe('mapAddressCollectionResponse', () => {
    test('maps Customer Address to AddressCollectionResponseDto', () => {
      const result = addressMapper.mapAddressCollectionResponse(customerDto);
      expect(customerDto.addresses).toHaveLength(1);
      expect(result).toMatchObject({
        addresses: [addressResponseDto],
      });
    });
  });
  describe('createAddressDraftFromDetails', () => {
    test('maps Customer Address to AddressCollectionResponseDto', () => {
      const result = addressMapper.createAddressDraftFromDetails(market, addressDetail, key);
      expect(customerDto.addresses).toHaveLength(1);
      expect(result?.country).toMatch(addressResponseDto.country);
      expect(result?.postalCode).toMatch(addressResponseDto.zip as string);
    });
  });
  describe('createAddressDraftFromCustomerAddressId', () => {
    test('maps Customer Address to AddressCollectionResponseDto', () => {
      addressRequestDto = stubAddressRequestDto({
        address1: undefined,
        address2: undefined,
        address3: undefined,
        address4: undefined,
        county: undefined,
        phoneNumber: undefined,
        zip: undefined,
        city: undefined,
        country: undefined,
        addressType: undefined,
        latitude: undefined,
        longitude: undefined,
        region: undefined,
        state: undefined,
        firstName: undefined,
        lastName: undefined,
      });
      const result = addressMapper.createAddressDraftFromCustomerAddressId(
        market,
        addressRequestDto,
        addressDetail,
        key,
      );
      expect(customerDto.addresses).toHaveLength(1);
      expect(result?.country).toMatch(addressResponseDto.country);
    });
  });
});
