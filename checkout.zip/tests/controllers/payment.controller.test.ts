import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubMagnoliaInfo,
} from '../__stubs__';
import { PaymentController } from '../../src/controllers';
import { PaymentService } from '../../src/services';
import { PaymentTypeDto, ApptusRequestDto, MagnoliaInfo } from '../../src/dtos';

describe('PaymentController', () => {
  /* System Under Test */
  let paymentController: PaymentController;

  /* Dependencies */
  let paymentService: PaymentService;
  let market: MarketInfo;
  let authorization: string;
  let magnolia: MagnoliaInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  let param: ApptusRequestDto;

  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();
    authorization = `Bearer ${faker.random.word()}`;
    param = {
      customerKey: faker.datatype.uuid(),
      sessionKey: faker.datatype.uuid(),
    };

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes({ locals: { market } });

    /* Dependencies */
    paymentService = {} as any;

    /* SUT */
    paymentController = new PaymentController({ paymentService });
  });

  describe('initiatePayment()', () => {
    let css: string;
    let marketingEmailConsent: boolean;
    beforeEach(() => {
      res.locals.magnolia = magnolia;
      css = `/* ${faker.random.word()} */`;
      marketingEmailConsent = faker.datatype.boolean();
    });

    test('reads request parameters', async () => {
      const cartId = faker.datatype.uuid();
      const paymentType: PaymentTypeDto = faker.random.arrayElement(['online', 'CashOnDelivery']);
      req.params.cartId = cartId;
      req.body = { paymentType, marketingEmailConsent, css };
      (paymentService as any).initiatePayment = jest.fn();
      req.headers = {
        customerkey: param.customerKey,
        sessionkey: param.sessionKey,
        authorization,
      };
      const id = cartId;
      const type = paymentType;

      await paymentController.initiatePayment(req, res);
      const params = {
        authorization,
        id,
        css,
        type,
        marketingEmailConsent,
      };
      expect(paymentService.initiatePayment).toHaveBeenCalledTimes(1);
      expect(paymentService.initiatePayment).toHaveBeenNthCalledWith(
        1,
        magnolia,
        market,
        params,
        param,
      );
    });

    test('returns response from service', async () => {
      const paymentInitResponse = { id: faker.datatype.uuid() };

      (paymentService as any).initiatePayment = jest.fn()
        .mockReturnValueOnce(paymentInitResponse);

      const response = await paymentController.initiatePayment(req, res);

      expect(response).toEqual({
        statusCode: HttpStatusCodes.OK,
        body: paymentInitResponse,
      });
    });
  });

  describe('getPaymentStatus()', () => {
    let sessionkey: string;
    let customerkey: string;
    let cartId: string;
    let orderNumber: string;
    let transactionId: string;

    beforeEach(() => {
      sessionkey = faker.datatype.uuid();
      customerkey = faker.datatype.uuid();
      cartId = faker.datatype.uuid();
      orderNumber = faker.datatype.uuid();
      transactionId = faker.datatype.uuid();

      req.headers = { authorization, sessionkey, customerkey };
      req.params = { cartId };
      req.body = { orderNumber, transactionId };
    });

    test('reads request parameters', async () => {
      /* Prepare */
      paymentService.getPaymentStatus = jest.fn();

      /* Execute */
      await paymentController.getPaymentStatus(req, res);

      /* Verify */
      expect(paymentService.getPaymentStatus).toHaveBeenCalledTimes(1);
      expect(paymentService.getPaymentStatus).toHaveBeenNthCalledWith(
        1,
        market,
        authorization!,
        cartId,
        orderNumber,
        transactionId,
        { sessionKey: sessionkey, customerKey: customerkey },
      );
    });

    test('returns response from service', async () => {
      /* Prepare */
      const orderId = faker.datatype.uuid();
      const status = faker.random.arrayElement(['initial', 'pending', 'success']);
      const paymentStatusResponse = { orderId, status };
      paymentService.getPaymentStatus = jest.fn().mockReturnValueOnce(paymentStatusResponse);

      /* Execute */
      const response = await paymentController.getPaymentStatus(req, res);

      /* Verify */

      expect(response).toEqual({
        statusCode: HttpStatusCodes.OK,
        body: paymentStatusResponse,
      });
    });
  });
});
