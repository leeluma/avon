import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubAddressResponseDto, stubCustomerResponseDto, stubCustomerRequestDto,
} from '../__stubs__';
import { CustomerController } from '../../src/controllers';
import { CustomerService, CartService } from '../../src/services';
import {
  AddressResponseDto, CustomerRegistrationRequestDto, CustomerResponseDto,
} from '../../src/dtos';
import Mock = jest.Mock;
import { ApiError } from '../../src/lib';

describe('CustomerController', () => {
  /* System Under Test */
  let defaultAddressResponse: AddressResponseDto[];
  let customerDetailsByTokernResponse: CustomerResponseDto;
  let customerController: CustomerController;
  let customerRequestDto: CustomerRegistrationRequestDto;
  let customerResponseDto: CustomerResponseDto;
  /* Dependencies */
  let customerService: CustomerService;
  let market: MarketInfo;
  let cartService: CartService;

  /* Stubs */
  let req: Request;
  let res: Response;
  let authHeader: string;

  beforeEach(() => {
    market = stubMarket();
    defaultAddressResponse = [stubAddressResponseDto()];
    customerDetailsByTokernResponse = stubCustomerResponseDto();
    cartService = { getCartById: jest.fn() } as any;
    customerRequestDto = stubCustomerRequestDto();
    customerResponseDto = stubCustomerResponseDto();
    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes({ locals: { market } });

    /* Dependencies */
    customerService = {
      getDefaultAddress: jest.fn(),
      getDeliveryAddressList: jest.fn(),
      getCustomerDetailsByToken: jest.fn(),
      registration: jest.fn(),
    } as any;

    /* SUT */
    customerController = new CustomerController({ customerService, cartService });
    customerService.getDefaultAddress = jest.fn();
    customerService.getDeliveryAddressList = jest.fn();
    customerService.registration = jest.fn();
    authHeader = `Bearer ${faker.random.randomWord()}`;
    req.headers.authorization = authHeader;
  });

  describe('resetCustomersPassword()', () => {
    test('reads request parameters', async () => {
      /* Prepare */
      const email = faker.internet.email();
      const url = faker.internet.password();

      req.body = { email, url };
      (customerService.forgotCustomersPassword as Mock) = jest.fn();

      /* Execute */
      await customerController.forgotCustomersPassword(req, res);

      /* Verify */
      expect(customerService.forgotCustomersPassword).toHaveBeenCalledTimes(1);
      expect(customerService.forgotCustomersPassword).toHaveBeenNthCalledWith(
        1,
        market,
        email,
        url,
      );
    });

    test('returns static response', async () => {
      /* Prepare */
      (customerService.forgotCustomersPassword as Mock) = jest.fn();

      /* Execute */
      const response = await customerController.forgotCustomersPassword(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: HttpStatusCodes.ACCEPTED,
        body: undefined,
      });
    });
  });

  describe('getDefaultAddress()', () => {
    test('fetches defaultAddress', async () => {
      /* Prepare */
      (customerService.getDefaultAddress as Mock).mockReturnValueOnce(defaultAddressResponse);

      /* Execute */
      await customerController.getDefaultAddress(req, res);

      /* Verify */
      expect(customerService.getDefaultAddress).toHaveBeenCalledTimes(1);
      expect(customerService.getDefaultAddress).toHaveBeenNthCalledWith(1, market, authHeader);
    });

    test('returns defaultAddress as JsonApiResponseEntity', async () => {
      /* Prepare */
      (customerService.getDefaultAddress as Mock).mockReturnValueOnce(defaultAddressResponse);

      /* Execute */
      const response = await customerController.getDefaultAddress(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: defaultAddressResponse,
      });
    });

    test('throws ApiError(NOT_FOUND) if address do not exist', async () => {
      /* Prepare */
      (customerService.getDefaultAddress as Mock).mockReturnValueOnce(undefined);
      /* Execute */
      await expect(() => customerController.getDefaultAddress(req, res))
        .rejects.toThrow('Not Found');
    });
  });

  describe('getDeliveryAddresses()', () => {
    test('fetches getDeliveryAddresses', async () => {
      /* Prepare */
      (customerService.getDeliveryAddressList as Mock).mockReturnValueOnce(defaultAddressResponse);

      /* Execute */
      await customerController.getDeliveryAddresses(req, res);

      /* Verify */
      expect(customerService.getDeliveryAddressList).toHaveBeenCalledTimes(1);
      expect(customerService.getDeliveryAddressList).toHaveBeenNthCalledWith(1, market, authHeader);
    });

    test('returns getDeliveryAddresses as JsonApiResponseEntity', async () => {
      /* Prepare */
      (customerService.getDeliveryAddressList as Mock).mockReturnValueOnce(defaultAddressResponse);

      /* Execute */
      const response = await customerController.getDeliveryAddresses(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: defaultAddressResponse,
      });
    });

    test('throws ApiError(NOT_FOUND) if address do not exist', async () => {
      /* Prepare */
      (customerService.getDeliveryAddressList as Mock).mockReturnValueOnce(undefined);
      /* Execute */
      await expect(() => customerController.getDeliveryAddresses(req, res))
        .rejects.toThrow('Not Found');
    });
  });

  describe('getCustomerByToken()', () => {
    test('fetches getCustomerByToken', async () => {
      /* Prepare */
      (customerService.getCustomerDetailsByToken as Mock).mockReturnValueOnce(customerDetailsByTokernResponse);

      /* Execute */
      await customerController.getCustomerByToken(req, res);

      /* Verify */
      expect(customerService.getCustomerDetailsByToken).toHaveBeenCalledTimes(1);
      expect(customerService.getCustomerDetailsByToken).toHaveBeenNthCalledWith(1, market, authHeader);
    });

    test('returns getCustomerDetails as JsonApiResponseEntity', async () => {
      /* Prepare */
      (customerService.getCustomerDetailsByToken as Mock).mockReturnValueOnce(customerDetailsByTokernResponse);

      /* Execute */
      const response = await customerController.getCustomerByToken(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: customerDetailsByTokernResponse,
      });
    });

    test('throws ApiError(NOT_FOUND) if address do not exist', async () => {
      /* Prepare */
      (customerService.getCustomerDetailsByToken as Mock).mockReturnValueOnce(undefined);
      /* Execute */
      await expect(() => customerController.getCustomerByToken(req, res))
        .rejects.toThrow('Not Found');
    });
  });

  describe('registration()', () => {
    beforeEach(() => {
      req.body = customerRequestDto;
      customerService.registration = jest.fn();
    });

    test('forwards request parameters to service', async () => {
      /* Execute */
      await customerController.registration(req, res);

      /* Verify */
      expect(customerService.registration).toHaveBeenCalledTimes(1);
      expect(customerService.registration).toHaveBeenNthCalledWith(
        1,
        market,
        customerRequestDto,
        authHeader,
      );
    });

    test('returns customerResponseDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (customerService.registration as Mock).mockReturnValueOnce(customerResponseDto);

      /* Execute */
      const response = await customerController.registration(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 201,
        body: customerResponseDto,
      });
    });

    test('throws if customer already exist', async () => {
      /* Prepare */
      res.locals.customer = customerResponseDto;
      /* Execute */
      const result = expect(() => customerController.registration(req, res));
      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.UNAUTHORIZED, 'Token does not belong to anonymous session!'),
      );
    });
  });
});
