import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import HttpStatusCodes from 'http-status-codes';
import { CustomerSignin } from '@commercetools/platform-sdk';
import i18next from 'i18next';
import { ApiError } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubCustomerLoginRequestDto,
  stubCustomerLoginResponseDto,
  stubUpdateCartRequestDto,
  stubPickupPointRequestDto,
  stubPickupPointResponseDto,
} from '../__stubs__';
import { DefaultController } from '../../src/controllers';
import { DefaultService } from '../../src/services';

import Mock = jest.Mock;
import {
  CustomerLoginResponseDto, UpdateCartRequestDto, PickupPointRequestDto, PickupPointResponseDto,
} from '../../src/dtos';

describe('DefaultController', () => {
  /* System Under Test */
  let defaultController: DefaultController;

  /* Dependencies */
  let defaultService: DefaultService;
  let market: MarketInfo;

  /* Stubs */
  let request: Request;
  let response: Response;

  beforeEach(() => {
    market = stubMarket();

    /* Stubs */
    request = stubExpressReq();
    response = stubExpressRes({ locals: { market } });

    /* Dependencies */
    defaultService = {} as any;

    /* SUT */
    defaultController = new DefaultController({ defaultService });
  });

  describe('default controller', () => {
    let customerRequestDto: CustomerSignin;
    let updateCartRequestDto: UpdateCartRequestDto;
    let customerResponseDto: CustomerLoginResponseDto;
    let authToken = faker.datatype.uuid();
    let pickupPointRequestDto: PickupPointRequestDto;
    let pickupPointResponseDto: PickupPointResponseDto;

    beforeEach(() => {
      customerRequestDto = stubCustomerLoginRequestDto();
      updateCartRequestDto = stubUpdateCartRequestDto();
      customerResponseDto = stubCustomerLoginResponseDto();
      pickupPointRequestDto = stubPickupPointRequestDto();
      pickupPointResponseDto = stubPickupPointResponseDto();
      request.headers.authorization = authToken;
    });

    describe('login', () => {
      beforeEach(() => {
        request.body = customerRequestDto;
        defaultService.login = jest.fn();
      });

      test('forward request payload to login service', async () => {
        await defaultController.login(request, response);
        expect(defaultService.login).toHaveBeenCalledTimes(1);
        expect(defaultService.login).toHaveBeenNthCalledWith(
          1,
          market,

          customerRequestDto,
        );
      });

      test('return login Response from Service', async () => {
        (defaultService.login as Mock).mockReturnValueOnce(customerResponseDto);
        const resultData = await defaultController.login(request, response);
        expect(resultData.statusCode).toEqual(201);
      });
    });

    describe('refreshToken()', () => {
      test('reads request parameters', async () => {
      /* Prepare */
        const refreshtoken = faker.datatype.string();

        request.headers = { refreshtoken };
        (defaultService.refreshToken as Mock) = jest.fn();

        /* Execute */
        await defaultController.refreshToken(request, response);

        /* Verify */
        expect(defaultService.refreshToken).toHaveBeenCalledTimes(1);
        expect(defaultService.refreshToken).toHaveBeenNthCalledWith(
          1,
          market,
          refreshtoken,
        );
      });
    });

    describe('updateMyCartById', () => {
      beforeEach(() => {
        request.body = updateCartRequestDto;
        defaultService.updateMyCartById = jest.fn();
      });

      test('forward request payload to updateMyCartById service', async () => {
        await defaultController.updateMyCartById(request, response);
        expect(defaultService.updateMyCartById).toHaveBeenCalledTimes(1);
        expect(defaultService.updateMyCartById).toHaveBeenNthCalledWith(
          1,
          market,
          updateCartRequestDto,
          authToken,
        );
      });

      test('validate if authToken is empty', async () => {
        authToken = '';
        request.headers.authorization = authToken;
        await defaultController.updateMyCartById(request, response);
        expect(defaultService.updateMyCartById).toHaveBeenCalledTimes(1);
        expect(defaultService.updateMyCartById).toHaveBeenNthCalledWith(
          1,
          market,
          updateCartRequestDto,
          authToken,
        );
      });

      test('validate if authToken is not valid', async () => {
        request.headers.authorization = authToken;
        response.locals.customer = customerResponseDto;
        /* Execute */
        const result = expect(() => defaultController.updateMyCartById(request, response));

        /* Verify */
        await result.rejects.toThrow(
          new ApiError(HttpStatusCodes.UNAUTHORIZED, i18next.t('validationError.unauthorized')),
        );
      });

      test('return updateMyCartById Response from Service', async () => {
        (defaultService.updateMyCartById as Mock).mockReturnValueOnce(customerResponseDto);
        const resultData = await defaultController.updateMyCartById(request, response);
        expect(resultData.statusCode).toEqual(201);
      });

      describe('getPickupDetail()', () => {
        beforeEach(() => {
          request.query = pickupPointRequestDto as any;
          defaultService.getPickupDetail = jest.fn();
        });

        test('forward request payload to pickupDetail service', async () => {
          /* Execute */
          await defaultController.getPickupDetail(request, response);
          /* Verify */
          expect(defaultService.getPickupDetail).toHaveBeenCalledTimes(1);
          expect(defaultService.getPickupDetail).toHaveBeenNthCalledWith(
            1,
            market,
            pickupPointRequestDto,
          );
        });

        test('return pickupPoint Response from Service', async () => {
          (defaultService.getPickupDetail as Mock).mockReturnValueOnce(pickupPointResponseDto);
          const result = await defaultController.getPickupDetail(request, response);
          expect(result.statusCode).toEqual(200);
        });
      });
    });
  });
});
