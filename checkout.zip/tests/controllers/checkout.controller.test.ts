import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { MagnoliaInfo } from '../../src/dtos';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubMagnoliaData, stubMagnoliaHome, stubMagnoliaInfo,
} from '../__stubs__';
import { CheckoutController } from '../../src/controllers/checkout.controller';
import { MagnoliaService } from '../../src/services/magnolia.service';
import { MagnoliaData } from '../../src/dtos/magnolia.dto';

import Mock = jest.Mock;

describe('LeapApp', () => {
  /* System Under Test */
  let checkoutController: CheckoutController;

  /* Dependencies */
  let magnoliaService: MagnoliaService;
  let market: MarketInfo;
  let magnolia: MagnoliaInfo;
  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes({ locals: { market } });

    /* Dependencies */
    magnoliaService = {} as any;

    /* SUT */
    checkoutController = new CheckoutController({ magnoliaService });
  });

  /**
   * Unit test case for getCheckoutPageData
   */
  describe('getCheckoutPageData()', () => {
    let magnoliaHome: any;
    let magnoliaData: MagnoliaData;

    beforeEach(() => {
      magnoliaService.getCheckoutPageData = jest.fn();
      magnoliaService.getGlobalSettingsData = jest.fn();
      magnoliaService.getTemplateData = jest.fn();

      magnoliaHome = stubMagnoliaHome();
      magnoliaData = stubMagnoliaData();

      res.locals.magnolia = magnolia;
    });

    test('fetches data from productService', async () => {
      /* Prepare */
      (magnoliaService.getCheckoutPageData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getGlobalSettingsData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);

      /* Execute */
      const result = await checkoutController.getCheckoutPageData(req, res);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaService.getGlobalSettingsData).toHaveBeenCalledTimes(1);
      expect(magnoliaService.getCheckoutPageData).toHaveBeenCalledTimes(1);
    });

    test('fetches data from productService if isPreview is true', async () => {
      /* Prepare */
      res.locals.magnolia.isPreview = true;
      (magnoliaService.getCheckoutPageData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getGlobalSettingsData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(stubMagnoliaHome);

      /* Execute */
      const result = await checkoutController.getCheckoutPageData(req, res);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaService.getGlobalSettingsData).toHaveBeenCalledTimes(1);
      expect(magnoliaService.getCheckoutPageData).toHaveBeenCalledTimes(1);
    });

    test('returns empty template if not preview', async () => {
      /* Prepare */
      const staticData = { staticField: faker.datatype.uuid() };
      (magnoliaService.getCheckoutPageData as Mock).mockReturnValueOnce(staticData);
      (magnoliaService.getGlobalSettingsData as Mock).mockReturnValueOnce(magnoliaData);
      magnolia.isPreview = false;
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);

      /* Execute */
      const result = await checkoutController.getCheckoutPageData(req, res);

      /* Verify */
      expect(result).toEqual({
        statusCode: 200,
        body: {
          staticField: staticData.staticField,
          globalSettings: magnoliaData,
          templateDefinition: {},
        },
      });
      expect(magnoliaService.getTemplateData).not.toHaveBeenCalled();
    });

    test('returns template from magnolia if preview', async () => {
      /* Prepare */
      const staticData = { staticField: faker.datatype.uuid() };
      (magnoliaService.getCheckoutPageData as Mock).mockReturnValueOnce(staticData);
      (magnoliaService.getGlobalSettingsData as Mock).mockReturnValueOnce(magnoliaData);
      magnolia.isPreview = true;
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);

      /* Execute */
      const result = await checkoutController.getCheckoutPageData(req, res);

      /* Verify */
      expect(result).toEqual({
        statusCode: 200,
        body: {
          staticField: staticData.staticField,
          globalSettings: magnoliaData,
          templateDefinition: magnoliaHome,
        },
      });
      expect(magnoliaService.getTemplateData).toHaveBeenCalledTimes(1);
      expect(magnoliaService.getTemplateData).toHaveBeenNthCalledWith(
        1,
        staticData['mgnl:template'],
        magnolia.url,
      );
    });
  });
});
