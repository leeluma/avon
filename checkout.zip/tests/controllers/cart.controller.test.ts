import { Request, Response } from 'express';
import i18next from 'i18next';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes,
  stubShippingMethodsForCartResponseDto, stubMagnoliaInfo, stubCtCartDto, stubCustomerDto, stubAddressRequestDto,
} from '../__stubs__';
import { CartController } from '../../src/controllers';
import { CartService, CustomerService } from '../../src/services';

import Mock = jest.Mock;
import {
  CartDto, ShippingMethodsResponseDto,
  AddressRequestDto, MagnoliaInfo,
} from '../../src/dtos';

import { ApiError } from '../../src/lib';

describe('CartController', () => {
  /* System Under Test */
  let cartController: CartController;
  let magnolia: MagnoliaInfo;

  /* Dependencies */
  let cartService: CartService;
  let customerService: CustomerService;
  let market: MarketInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes({ locals: { market } });

    /* Dependencies */
    cartService = { getCartById: jest.fn() } as any;
    customerService = {
      addAddress: jest.fn(),
      updateAddress: jest.fn(),
    } as any;

    /* SUT */
    cartController = new CartController({ cartService, customerService });
  });

  describe('getShippingMethodsByCartId()', () => {
    let shippingMethodCartDto: ShippingMethodsResponseDto[];
    beforeEach(() => {
      cartService.getShippingMethods = jest.fn();
      shippingMethodCartDto = stubShippingMethodsForCartResponseDto();
      req.params.id = shippingMethodCartDto[0].id;
      res.locals.magnolia = magnolia;
    });
    test('fetches data from cartService for shippingMethod', async () => {
      /* Prepare */
      const { shippingKind } = req.query;
      (cartService.getShippingMethods as Mock).mockReturnValueOnce(shippingMethodCartDto);

      /* Execute */
      await cartController.getShippingMethods(req, res);

      /* Verify */
      expect(cartService.getShippingMethods).toHaveBeenCalledTimes(1);
      expect(cartService.getShippingMethods).toHaveBeenNthCalledWith(
        1,
        market,
        shippingKind,
      );
    });
    test('throws ApiError(NOT_FOUND) if cart does not exist', async () => {
      /* Prepare */
      // ApiError(NOT_FOUND) if cart does not exist
      const expectedError = new ApiError(404, `Cart with id "${shippingMethodCartDto[0].id}" not found.`);
      (cartService.getShippingMethods as Mock).mockReturnValueOnce(expectedError);

      /* Execute */
      const result = await cartController.getShippingMethods(req, res);

      expect(result.body).toEqual(expectedError);
    });
  });

  describe('addShippingMethod()', () => {
    let cartDto: CartDto;

    beforeEach(() => {
      cartService.addShippingMethod = jest.fn();
      cartDto = stubCtCartDto();
      req.params.cartId = cartDto.id;
      res.locals.magnolia = magnolia;
      req.body.shippingMethodId = faker.datatype.uuid();
    });

    test('fetches data from cartService', async () => {
      /* Prepare */
      (cartService.addShippingMethod as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartController.addShippingMethod(req, res);

      /* Verify */
      expect(cartService.addShippingMethod).toHaveBeenCalledTimes(1);
      expect(cartService.addShippingMethod).toHaveBeenNthCalledWith(
        1,
        market,
        cartDto.id,
        req.body.shippingMethodId,
        undefined,
      );
    });

    test('returns cartDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (cartService.addShippingMethod as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartController.addShippingMethod(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: cartDto,
      });
    });

    test('throws ApiError(NOT_FOUND) if cart does not exist', async () => {
      /* Prepare */
      // ApiError(NOT_FOUND) if cart does not exist
      const expectedError = new ApiError(404, `Cart with id "${cartDto.id}" not found.`);
      (cartService.addShippingMethod as Mock).mockReturnValueOnce(expectedError);

      /* Execute */
      const result = await cartController.addShippingMethod(req, res);

      /* Verify */
      expect(result.body).toEqual(expectedError);
    });
  });

  describe('setShippingAddress()', () => {
    let cartDto: CartDto;
    let addressRequestDto: AddressRequestDto;
    let authToken: string;
    beforeEach(() => {
      cartService.setShippingAddress = jest.fn();
      cartService.setShippingAddressFromCustomerId = jest.fn();
      cartService.setShippingAddressFromFinder = jest.fn();
      cartDto = stubCtCartDto();
      req.params.cartId = cartDto.id;
      addressRequestDto = stubAddressRequestDto();
      req.body = addressRequestDto;
      res.locals.customer = stubCustomerDto();
      authToken = faker.datatype.string();
      req.headers.authorization = authToken;
      res.locals.magnolia = magnolia;
    });

    test('fetches data from cartService if manual address is received in request body', async () => {
      /* Prepare */
      delete req.headers.authorization;
      (cartService.setShippingAddress as Mock).mockReturnValueOnce(cartDto);
      (customerService.addAddress as Mock).mockReturnValueOnce(res.locals.customer);

      /* Execute */
      await cartController.setShippingAddress(req, res);
      /* Verify */
      expect(cartService.setShippingAddress).toHaveBeenCalledTimes(1);
      expect(cartService.setShippingAddress).toHaveBeenNthCalledWith(
        1,
        market,
        magnolia,
        cartDto.id,
        '',
        res.locals.customer,
        addressRequestDto,
      );

      expect(customerService.addAddress).toHaveBeenCalledTimes(1);
      expect(customerService.addAddress).toHaveBeenNthCalledWith(
        1,
        market,
        res.locals.customer,
        cartDto.shippingAddress,
      );
    });

    test('fetches data from cartService if customerAddressId is received in request body', async () => {
      /* Prepare */
      addressRequestDto = stubAddressRequestDto({
        addressId: faker.datatype.uuid(),
      });
      req.body.addressId = addressRequestDto.addressId;
      (cartService.setShippingAddressFromCustomerId as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartController.setShippingAddress(req, res);
      /* Verify */
      expect(cartService.setShippingAddressFromCustomerId).toHaveBeenCalledTimes(1);
      expect(cartService.setShippingAddressFromCustomerId).toHaveBeenNthCalledWith(
        1,
        market,
        magnolia,
        cartDto.id,
        authToken,
        res.locals.customer,
        req.body,
      );

      expect(customerService.updateAddress).toHaveBeenCalledTimes(1);
      expect(customerService.updateAddress).toHaveBeenNthCalledWith(
        1,
        market,
        res.locals.customer,
        req.body.addressId,
        cartDto.shippingAddress,
      );
    });

    test('fetches data from cartService if addressFinderId is received in request body', async () => {
      /* Prepare */
      addressRequestDto = stubAddressRequestDto({
        addressFinderId: faker.datatype.uuid(),
      });
      req.body.addressFinderId = addressRequestDto.addressFinderId;
      (cartService.setShippingAddressFromFinder as Mock).mockReturnValueOnce(cartDto);

      (customerService.addAddress as Mock).mockReturnValueOnce(res.locals.customer);
      /* Execute */

      await cartController.setShippingAddress(req, res);
      /* Verify */
      expect(cartService.setShippingAddressFromFinder).toHaveBeenCalledTimes(1);
      expect(cartService.setShippingAddressFromFinder).toHaveBeenNthCalledWith(
        1,
        market,
        magnolia,
        cartDto.id,
        authToken,
        res.locals.customer,
        req.body,
      );
    });

    test('returns cartDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (cartService.setShippingAddress as Mock).mockReturnValueOnce(cartDto);

      (customerService.addAddress as Mock).mockReturnValueOnce(res.locals.customer);

      /* Execute */
      const response = await cartController.setShippingAddress(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: cartDto,
      });
    });

    test('throws ApiError(NOT_FOUND) if cart does not exist', async () => {
      /* Prepare */
      // ApiError(NOT_FOUND) if cart does not exist
      const expectedError = new ApiError(404, `Cart with id "${cartDto.id}" not found.`);
      (cartService.setShippingAddress as Mock).mockReturnValueOnce(expectedError);

      /* Execute */
      const result = await cartController.setShippingAddress(req, res);

      /* Verify */
      expect(result.body).toEqual(expectedError);
    });
  });

  describe('getCartById()', () => {
    let cartDto: CartDto;

    beforeEach(() => {
      cartDto = stubCtCartDto();
      res.locals.magnolia = magnolia;
    });

    test('fetches Cart By Id', async () => {
      /* Prepare */
      (cartService.getCartById as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartController.getCartById(req, res);

      /* Verify */
      expect(cartService.getCartById).toHaveBeenCalledTimes(1);
      expect(cartService.getCartById).toHaveBeenNthCalledWith(1, market, magnolia, undefined, undefined);
    });

    test('returns cart as JsonApiResponseEntity', async () => {
      /* Prepare */
      (cartService.getCartById as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartController.getCartById(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: cartDto,
      });
    });

    test('throws ApiError(NOT_FOUND) if cart does not exist', async () => {
      /* Prepare */
      (cartService.getCartById as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(400, i18next.t(
        'error.cartIdNotFound',
        { cartId: cartDto.id },
      ));
      /* Execute */
      await expect(() => cartController.getCartById(req, res))
        .rejects.toThrow(expectedError);
    });
  });
});
