import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { AddressController } from '../../src/controllers';
import { AddressService } from '../../src/services';

import Mock = jest.Mock;
import {
  stubAutocompleteResponseDto, stubDetailResponseDto, stubExpressReq, stubExpressRes,
} from '../__stubs__';
import { MarketInfo } from '../../src/middlewares';

describe('addressController', () => {
  /* System Under Test */
  let addressController: AddressController;

  /* Dependencies */
  let addressService: AddressService;
  let market: MarketInfo;

  /* Stubs */
  let request: Request;
  let response: Response;

  beforeEach(() => {
    /* Stubs */
    request = stubExpressReq();
    response = stubExpressRes({ locals: { market } });
    /* Dependencies */
    addressService = {} as any;

    addressController = new AddressController({ addressService });
  });

  describe('address methods', () => {
    describe('addressAutocomplete()', () => {
      beforeEach(() => {
        addressService.addressAutocomplete = jest.fn();
        const address = faker.datatype.string();
        request.query = { address };
      });

      test('reads request parameters', async () => {
        /* Prepare */
        const addressAutocompleteDto = [stubAutocompleteResponseDto()];
        (addressService.addressAutocomplete as Mock).mockReturnValueOnce({ addressAutocompleteDto });
        const address = faker.datatype.string();
        request.query = { address };

        /* Execute */
        await addressController.addressAutocomplete(request, response);
        /* Verify */
        expect(addressService.addressAutocomplete).toHaveBeenCalledTimes(1);
        expect(addressService.addressAutocomplete).toHaveBeenNthCalledWith(1, market, address);
      });
    });
  });

  describe('addressDetail()', () => {
    beforeEach(() => {
      addressService.addressDetail = jest.fn();
      const addressId = faker.datatype.string();
      request.query = { addressId };
    });

    test('reads request parameters', async () => {
      /* Prepare */
      const addressDetailDto = [stubDetailResponseDto()];
      (addressService.addressDetail as Mock).mockReturnValueOnce({ addressDetailDto });
      const addressId = faker.datatype.string();
      request.query = { addressId };

      /* Execute */
      await addressController.addressDetail(request, response);
      /* Verify */
      expect(addressService.addressDetail).toHaveBeenCalledTimes(1);
      expect(addressService.addressDetail).toHaveBeenNthCalledWith(1, market, addressId);
    });
  });
});
