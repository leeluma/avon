import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { MagnoliaInfo } from '../../src/dtos';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubOrderDto, stubMagnoliaInfo,
  stubMagnoliaData, stubMagnoliaHome, stubGlobalSettings,
} from '../__stubs__';
import { OrderController } from '../../src/controllers';
import { OrderService, MagnoliaService } from '../../src/services';
import { MagnoliaData } from '../../src/dtos/magnolia.dto';

import Mock = jest.Mock;

describe('OrderController', () => {
  /* System Under Test */
  let orderController: OrderController;

  /* Dependencies */
  let orderService: OrderService;
  let magnoliaService: MagnoliaService;
  let market: MarketInfo;
  let magnolia: MagnoliaInfo;
  let authHeader: string;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();
    authHeader = faker.datatype.string();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes({ locals: { market } });
    req.headers.authorization = authHeader;
    /* Dependencies */
    orderService = {} as any;
    magnoliaService = {} as any;

    /* SUT */
    orderController = new OrderController({ orderService, magnoliaService });
  });

  describe('getOrder()', () => {
    let magnoliaData: MagnoliaData;
    let globalSettings;
    const magnoliaHome = stubMagnoliaHome();
    beforeEach(() => {
      magnolia.isPreview = true;
      res.locals.magnolia = magnolia;
      magnoliaService.getOrderConfirmationPageData = jest.fn();
      magnoliaService.getTemplateData = jest.fn();
      magnoliaService.getGlobalSettingsData = jest.fn();

      magnoliaData = stubMagnoliaData();
      globalSettings = stubGlobalSettings();
    });
    test('reads request parameters', async () => {
      const orderId = faker.datatype.uuid();
      req.params.orderId = orderId;

      (orderService as any).orderDetails = jest.fn();
      (magnoliaService.getOrderConfirmationPageData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);
      (magnoliaService.getGlobalSettingsData as Mock).mockReturnValueOnce(globalSettings);

      await orderController.getOrder(req, res);

      expect(orderService.orderDetails).toHaveBeenCalledTimes(1);
      expect(orderService.orderDetails).toHaveBeenNthCalledWith(
        1,
        authHeader,
        market,
        orderId,
        globalSettings.priceFormat,
      );
    });

    test('returns response from service', async () => {
      const orderResponse = stubOrderDto();
      magnolia.isPreview = false;
      res.locals.magnolia = magnolia;
      (orderService as any).orderDetails = jest.fn()
        .mockReturnValueOnce(orderResponse);
      (magnoliaService.getOrderConfirmationPageData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);

      const response = await orderController.getOrder(req, res);
      expect(response.body.orderConfirmation).toEqual(orderResponse);
    });
  });

  describe('getOrderMagnolia()', () => {
    let magnoliaData: MagnoliaData;
    let globalSettings;
    const magnoliaHome = stubMagnoliaHome();
    beforeEach(() => {
      magnolia.isPreview = true;
      res.locals.magnolia = magnolia;
      magnoliaService.getOrderConfirmationPageData = jest.fn();
      magnoliaService.getTemplateData = jest.fn();
      magnoliaService.getGlobalSettingsData = jest.fn();

      magnoliaData = stubMagnoliaData();
      globalSettings = stubGlobalSettings();
    });
    test('reads request parameters', async () => {
      (magnoliaService.getOrderConfirmationPageData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);
      (magnoliaService.getGlobalSettingsData as Mock).mockReturnValueOnce(globalSettings);

      await orderController.getOrderMagnolia(req, res);

      expect(magnoliaService.getOrderConfirmationPageData).toHaveBeenCalledTimes(1);
      expect(magnoliaService.getGlobalSettingsData).toHaveBeenCalledTimes(1);
      expect(magnoliaService.getOrderConfirmationPageData).toHaveBeenNthCalledWith(
        1,
        market,
        magnolia,
      );
    });

    test('returns response from service', async () => {
      magnolia.isPreview = false;
      res.locals.magnolia = magnolia;
      (magnoliaService.getOrderConfirmationPageData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);
      (magnoliaService.getGlobalSettingsData as Mock).mockReturnValueOnce(globalSettings);

      const response = await orderController.getOrderMagnolia(req, res);
      expect(response.body.globalSettings).toEqual(globalSettings);
    });
  });
});
