import faker from '@faker-js/faker';
import { CtClient } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';

import { stubMarket } from '../__stubs__';
import Mock = jest.Mock;
import { DefaultDao } from '../../src/daos';

jest.mock('axios');

describe('DefaultDao', () => {
  let defaultDao: DefaultDao;
  let ctClient: CtClient;
  let market: MarketInfo;

  let refreshTokenFlow: Mock;

  beforeEach(() => {
    market = stubMarket();
    refreshTokenFlow = jest.fn();
    ctClient = {
      getAuthClient: jest.fn().mockReturnValueOnce({ refreshTokenFlow }),
    } as any;

    defaultDao = new DefaultDao({ ctClient });
  });

  describe('refreshToken()', () => {
    const params = faker.datatype.string();
    test('queries ctClient with refreshToken', async () => {
      await defaultDao.refreshToken(market, params);
      /* Verify */
      expect(refreshTokenFlow).toHaveBeenCalledTimes(1);
      expect(refreshTokenFlow).toHaveBeenNthCalledWith(
        1,
        params,
      );
    });

    test('returns response from CT', async () => {
      /* Execute */
      refreshTokenFlow.mockReturnValueOnce({ access_token: faker.datatype.string() });

      const response = await defaultDao.refreshToken(market, params);

      /* Verify */
      expect(response).toBeTruthy();
    });

    test('forwards CT errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.string());
      refreshTokenFlow.mockRejectedValueOnce(err);

      /* Execute */
      const refreshToken = () => defaultDao.refreshToken(market, params);

      /* Verify */
      await expect(refreshToken).rejects.toThrow(err);
    });
    test('re-throws non-500  ctClient errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 500,
      };

      refreshTokenFlow.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => defaultDao.refreshToken(market, params));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });
});
