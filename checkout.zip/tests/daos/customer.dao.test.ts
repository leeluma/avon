import faker from '@faker-js/faker';
import {
  CartUpdate, Customer, CustomerDraft, CustomerSignin,
} from '@commercetools/platform-sdk';
import { CtClient } from '../../src/lib';
import { graphql } from '../../src/graphql';
import { MarketInfo } from '../../src/middlewares';
import {
  stubCustomerDto,
  stubMarket,
  stubCtCustomerClient,
  stubCustomerLoginResponseDto, stubGraphql, stubCustomerDraftDto,
} from '../__stubs__';
import Mock = jest.Mock;
import { CustomerDao } from '../../src/daos';

describe('CustomerDao', () => {
  let customerDao: CustomerDao;
  let ctClient: CtClient;
  let gql: typeof graphql;
  let market: MarketInfo;
  let execute: Mock;
  let get: Mock;
  let post: Mock;
  let withId: Mock;
  let password: Mock;
  let signup: Mock;
  let passwordReset: Mock;
  let customerPasswordFlow: Mock;
  let passwordToken: Mock;
  let authHeader: string;
  let graphQLCustomerResponse: Customer;
  let customerDraftDto: CustomerDraft;

  beforeEach(() => {
    market = stubMarket();
    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    password = jest.fn().mockReturnValueOnce({ post });
    signup = jest.fn().mockReturnValueOnce({ post });
    passwordReset = jest.fn().mockReturnValueOnce({ post });
    customerPasswordFlow = jest.fn();
    customerDraftDto = stubCustomerDraftDto();
    passwordToken = jest.fn().mockReturnValueOnce({ post });
    ctClient = stubCtCustomerClient(market.country, {
      graphql: jest.fn().mockReturnValueOnce({ post }),
      shippingMethods: jest.fn().mockReturnValueOnce({ get }),
      customers: jest.fn().mockReturnValueOnce({
        passwordToken, passwordReset, withId, post,
      }),
      carts: jest.fn().mockReturnValueOnce({ withId, post }),
      me: jest.fn().mockReturnValueOnce({ signup, password, post }),
      customerPasswordFlow,
    });

    gql = stubGraphql();
    customerDao = new CustomerDao({ ctClient, graphql: gql });
    graphQLCustomerResponse = stubCustomerDto();
    authHeader = `Bearer ${faker.random.randomWord()}`;
  });

  describe('login()', () => {
    let customerLoginRequestDto: CustomerSignin;

    beforeEach(() => {
      customerLoginRequestDto = {
        email: faker.internet.email(),
        password: faker.internet.password(),
      };
    });

    test('queries ctClient with email and Password', async () => {
      /* Execute */
      await customerDao.login(market, customerLoginRequestDto);

      /* Verify */
      expect(customerPasswordFlow).toHaveBeenCalledTimes(1);
      expect(customerPasswordFlow).toHaveBeenNthCalledWith(
        1,
        {
          username: customerLoginRequestDto.email,
          password: customerLoginRequestDto.password,
        },

        {
          disableRefreshToken: false,
        },
      );
    });

    test('returns response from CT', async () => {
      /* Execute */
      const customerLoginResDto = stubCustomerLoginResponseDto();
      customerPasswordFlow.mockReturnValueOnce(customerLoginResDto);

      const response = await customerDao.login(market, customerLoginRequestDto);

      /* Verify */
      expect(response).toBe(customerLoginResDto);
    });

    test('forwards CT errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.uuid());
      customerPasswordFlow.mockRejectedValueOnce(err);

      /* Execute */
      const login = () => customerDao.login(market, customerLoginRequestDto);

      /* Verify */
      await expect(login).rejects.toThrow(err);
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 400,
        status: {
          statusCode: 400,
          msg: faker.datatype.string(),
          timestamp: faker.datatype.datetime(),
        },
        errors: [
          {
            code: faker.datatype.string(),
            message: faker.datatype.string(),
          },
        ],
      };

      customerPasswordFlow.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => customerDao.login(market, customerLoginRequestDto));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  describe('setCustomerIdToCart()', () => {
    let cartId: string;
    let version: number;
    let customerId: string;
    let bodyDraft: CartUpdate;

    enum CART_ACTIONS {
      setCustomerId = 'setCustomerId',
    }

    beforeEach(() => {
      cartId = faker.datatype.uuid();
      customerId = faker.datatype.uuid();
      version = faker.datatype.number();
      bodyDraft = {
        version,
        actions: [{
          action: CART_ACTIONS.setCustomerId,
          customerId,
        }],
      };
    });

    test('queries ctClient with version, cartId and customerId', async () => {
      /* Execute */
      await customerDao.setCustomerIdToCart(market, cartId, version, customerId);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: cartId },
      );
    });

    test('post the setCustomerId action', async () => {
      /* Execute */
      await customerDao.setCustomerIdToCart(market, cartId, version, customerId);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1, { body: bodyDraft });
    });

    test('forwards CT errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.uuid());
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const setCustomerIdToCart = () => customerDao.setCustomerIdToCart(market, cartId, version, customerId);

      /* Verify */
      await expect(setCustomerIdToCart).rejects.toThrow(err);
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 400,
        status: {
          statusCode: 400,
          msg: faker.datatype.string(),
          timestamp: faker.datatype.datetime(),
        },
        errors: [
          {
            code: faker.datatype.string(),
            message: faker.datatype.string(),
          },
        ],
      };

      execute.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => customerDao.setCustomerIdToCart(market, cartId, version, customerId));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  describe('findGraphQLOne()', () => {
    let customerDto: Customer;

    beforeEach(() => {
      customerDto = stubCustomerDto(market);
    });

    test('returns client response body', async () => {
      /* Prepare */
      const body = {
        query: 'query () { customer {} }',
        variables: {
          id: customerDto.id,
        },
      };
      execute.mockReturnValueOnce({ body: { data: { customer: customerDto } } });

      /* Execute */
      const result = await customerDao.findGraphQLOne(market, customerDto.id);

      /* Verify */
      expect(result).toBe(customerDto);

      expect(execute).toHaveBeenCalledTimes(1);

      expect(post).toHaveBeenCalledTimes(1);

      expect(post).toHaveBeenNthCalledWith(
        1,

        { body },
      );
    });

    test('returns undefined response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: { data: { customer: undefined } } });

      /* Execute */
      const result = await customerDao.findGraphQLOne(market, customerDto.id);

      /* Verify */
      expect(result).toBe(undefined);
    });
  });

  describe('forgotCustomersPassword()', () => {
    const email = faker.internet.email();
    test('queries ctClient with email', async () => {
      /* Execute */
      execute.mockReturnValueOnce({ body: { value: faker.datatype.string() } });
      await customerDao.forgotCustomersPassword(market, email);

      /* Verify */
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: { email } },
      );

      expect(execute).toHaveBeenCalledTimes(1);
    });

    test('returns true if CT returns response', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: { value: faker.datatype.string() } });
      /* Execute */
      const response = await customerDao.forgotCustomersPassword(market, email);

      /* Verify */
      expect(response).toBeTruthy();
    });
  });
  describe('getCustomerDetailsGraphQL()', () => {
    test('returns client response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            me: {
              customer: {
                results: graphQLCustomerResponse,
              },
            },
          },
        },
      });

      /* Execute */
      const result = await customerDao.getCustomerDetailsGraphQL(market, authHeader);

      /* Verify */
      expect(result).toEqual({ results: graphQLCustomerResponse });
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('re-throws non-404 ctClient errors if address length is zero', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            me: {
              customer: {
                results: graphQLCustomerResponse,
                addresses: [],
              },
            },
          },
        },
      });

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader, true));

      /* Verify */
      await result.rejects.toBeTruthy();
    });

    test('re-throws non-404 ctClient errors if customer not found', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            me: {},
          },
        },
      });

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader));

      /* Verify */
      await result.rejects.toBeTruthy();
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const err = {
        statusCode: 401,
        message: 'Unauthorized',
        messageArray: [],
        timestamp: faker.time.recent(),
        errors: [
          null,
        ],
      };
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader));
      /* Verify */
      await result.rejects.toBeTruthy();
    });

    test('re-throws API-Error ctClient errors if statusCode is not present in error', async () => {
      /* Prepare */
      const err = {
        message: 'Unauthorized',
        timestamp: faker.time.recent(),
        errors: [
          null,
        ],
      };
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader));
      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });
  describe('addAddress()', () => {
    let customerId: string;
    let payload: any;

    beforeEach(() => {
      customerId = faker.datatype.uuid();
      payload = [{ action: 'some action...' }];
    });

    test('queries client with the customerId', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await customerDao.updateCustomer(market, customerId, payload);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: customerId },
      );
    });

    test('queries client with the payload', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await customerDao.updateCustomer(market, customerId, payload);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: payload },
      );
    });
  });

  describe('create()', () => {
    test('queries ctClient with the CustomerDraft', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: { customer: undefined } });

      /* Execute */
      await customerDao.create(market, customerDraftDto, authHeader);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: customerDraftDto, headers: { Authorization: authHeader } },
      );
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      const customerResponse = {
        customer: {
          id: faker.datatype.uuid(),
          email: customerDraftDto.email,
        },
      };
      execute.mockReturnValueOnce({ body: customerResponse });

      /* Execute */
      const result = await customerDao.create(market, customerDraftDto, authHeader);

      /* Verify */
      expect(result).toBe(customerResponse.customer);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => customerDao.create(market, customerDraftDto, authHeader));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const err = { body: { statusCode: 400, errors: [] } };
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const result = expect(() => customerDao.create(market, customerDraftDto, authHeader));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });
});
