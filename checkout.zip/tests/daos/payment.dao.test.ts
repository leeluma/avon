import faker from '@faker-js/faker';
import {
  Address,
  ClientResponse,
  GraphQLResponse,
  Money,
  Payment,
  PaymentUpdate,
  State,
  StateDraft,
} from '@commercetools/platform-sdk';
import axios from 'axios';
import i18next from 'i18next';
import HttpStatusCodes from 'http-status-codes';
import { axiosOptions } from '../../src/lib/axios-options';
import { ApiError, CtClient } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket,
  stubCtClient,
  stubPayment,
  stubMoney,
  stubAddress,
  stubPaymentTypeDto,
  stubState, stubGraphql, stubPaymentTransactionResponse,
} from '../__stubs__';
import Mock = jest.Mock;
import { PaymentDao } from '../../src/daos';
import { E_PAYMENT_STATUS, PaymentTransactionResponseDto, PaymentTypeDto } from '../../src/dtos';
import { graphql } from '../../src/graphql';
import * as constructUrl from '../../src/lib/common';

jest.mock('axios');

const RETURN_URL = 'https://www.avon.uk.com/directdelivery/returnfromepayments';

describe('PaymentDao', () => {
  let ctClient: CtClient;
  let gql: typeof graphql;
  let market: MarketInfo;
  let post: Mock;
  let withId: Mock;
  let get: Mock;
  let execute: Mock;

  let paymentApiKey: string;
  let paymentApiPrefix: string;
  let paymentApiInitSuffix: string;
  let paymentOrderNumberGeneratorUrl: string;
  let paymentKeyGeneratorUrl: string;
  let paymentRetryCount: number;
  let paymentRetryTimeout: number;

  let payment: Payment;
  let paymentDao: PaymentDao;
  let paymentType: PaymentTypeDto;
  let ePayTransaction: PaymentTransactionResponseDto;

  beforeEach(() => {
    market = stubMarket();

    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    ctClient = stubCtClient(market.country, {
      payments: jest.fn().mockReturnValueOnce({ withId, post }),
      states: jest.fn().mockReturnValueOnce({ get }),
      graphql: jest.fn().mockReturnValueOnce({ post }),
    });
    gql = stubGraphql();

    paymentApiKey = faker.datatype.uuid();
    paymentApiPrefix = `${faker.internet.domainName()}/{{country}}-{{locale}}`;
    paymentApiInitSuffix = `${faker.internet.domainName()}/{{country}}-{{locale}}`;
    paymentOrderNumberGeneratorUrl = `${faker.internet.url()}/{{country}}`;
    paymentKeyGeneratorUrl = `${faker.internet.url()}/{{country}}`;
    paymentRetryCount = 5;
    paymentRetryTimeout = 1000;
    ePayTransaction = stubPaymentTransactionResponse();

    paymentType = stubPaymentTypeDto();
    paymentDao = new PaymentDao({
      ctClient,
      graphql: gql,
      paymentApiKey,
      paymentApiPrefix,
      paymentApiInitSuffix,
      paymentOrderNumberGeneratorUrl,
      paymentKeyGeneratorUrl,
      paymentRetryCount,
      paymentRetryTimeout,
    });

    payment = stubPayment();
  });

  describe('createPayment()', () => {
    test('creates Payment object in CT', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: payment });

      /* Execute */
      const result = await paymentDao.createPayment(market, stubPayment());

      /* Verify */
      expect(result).toBe(payment);
    });

    test('rethrows CT errors', async () => {
      /* Prepare */
      const expectedError = new Error('Something went wrong in CT');
      execute.mockRejectedValueOnce(expectedError);

      /* Execute */
      const result = () => paymentDao.createPayment(market, stubPayment());

      /* Verify */
      await expect(result).rejects.toThrow(expectedError);
    });
  });

  describe('updatePayment()', () => {
    test('updates a Payment object in CT', async () => {
      /* Prepare */
      const payload: PaymentUpdate = { version: faker.datatype.number(), actions: [] };
      const updatedPayment = stubPayment();
      execute.mockReturnValueOnce({ body: updatedPayment });

      /* Execute */
      const result = await paymentDao.updatePayment(market, payment.id, payload);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(1, { ID: payment.id });
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1, { body: payload });
      expect(result).toBe(updatedPayment);
    });

    test('rethrows CT errors', async () => {
      /* Prepare */
      const payload: PaymentUpdate = { version: faker.datatype.number(), actions: [] };
      const expectedError = new Error('Something went wrong in CT');
      execute.mockRejectedValueOnce(expectedError);

      /* Execute */
      const result = () => paymentDao.updatePayment(market, payment.id, payload);

      /* Verify */
      await expect(result).rejects.toThrow(expectedError);
    });
  });

  describe('epayInitiate()', () => {
    let css: string;
    let orderNumber: string;
    let payerId: string;
    let totalPrice: Money;
    let billingAddress: Address;
    let paymentKey: string;

    beforeEach(() => {
      css = `/* ${faker.random.word()} */`;
      orderNumber = faker.datatype.number().toString();
      payerId = faker.datatype.uuid();
      totalPrice = stubMoney();
      billingAddress = stubAddress();
      paymentKey = faker.datatype.string();
    });

    test('calls the payment gateway API', async () => {
      const mockResponse = { data: { id: faker.datatype.uuid(), url: faker.internet.url() } };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      const expectedUrl = `${paymentApiPrefix}${paymentApiInitSuffix}`
        .replace('{{country}}', market.country)
        .replace('{{locale}}', market.locale);

      const billingInfo = {
        firstName: billingAddress.firstName,
        lastName: billingAddress.lastName,
        emailAddress: billingAddress.email,
        address: billingAddress.streetName,
        city: billingAddress.city,
        state: billingAddress.state,
        zip: billingAddress.postalCode,
        country: billingAddress.country,
        phone: billingAddress.phone,
      };
      const param = {
        paymentKey,
        orderNumber,
        payerId,
        totalPrice,
        billingAddress,
      };
      await paymentDao.epayInitiate(
        market,
        param,
        RETURN_URL,
        css,
      );

      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(1, {
        ...axiosOptions,
        url: expectedUrl,
        method: 'POST',
        headers: { 'x-api-key': paymentApiKey },
        data: {
          ordNr: orderNumber,
          payerType: 'CUST',
          payerId,
          amount: totalPrice.centAmount,
          returnUrl: RETURN_URL,
          css,
          threeDSReqd: true,
          billingInfo,
          channel: 'Leap',
        },
      });
    });

    test('rethrows payment gateway errors', async () => {
      const err = new Error('payment gateway error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      const param = {
        paymentKey,
        orderNumber,
        payerId,
        totalPrice,
        billingAddress,
      };
      const result = () => paymentDao.epayInitiate(
        market,
        param,
        RETURN_URL,
        css,
      );

      await expect(result).rejects.toThrow(err);
    });

    test('asserts response schema is correct', async () => {
      /* Check data field */

      (axios as unknown as Mock).mockResolvedValueOnce({});
      const param = {
        paymentKey,
        orderNumber,
        payerId,
        totalPrice,
        billingAddress,
      };
      await expect(
        () => paymentDao.epayInitiate(
          market,
          param,
          paymentType,
          css,
        ),
      ).rejects.toThrow(
        new Error('Payment GW response is missing "data" field'),
      );

      /* Check data.id field */

      (axios as unknown as Mock).mockResolvedValueOnce({ data: {} });

      await expect(
        () => paymentDao.epayInitiate(
          market,
          param,
          paymentType,
          css,
        ),
      ).rejects.toThrow(
        new Error('Payment GW response is missing data "id" field'),
      );

      /* Check data.url field */

      (axios as unknown as Mock).mockResolvedValueOnce({ data: { id: faker.datatype.uuid() } });

      await expect(
        () => paymentDao.epayInitiate(
          market,
          param,
          paymentType,
          css,
        ),
      ).rejects.toThrow(
        new Error('Payment GW response is missing data "url" field'),
      );
    });

    test('returns payment gateway response', async () => {
      const data = {
        id: faker.datatype.uuid(),
        url: faker.internet.url(),
      };
      (axios as unknown as Mock).mockResolvedValueOnce({ data });
      const param = {
        paymentKey,
        orderNumber,
        payerId,
        totalPrice,
        billingAddress,
      };
      const response = await paymentDao.epayInitiate(
        market,
        param,
        paymentType,
        css,
      );

      expect(response).toEqual(data);
    });
  });

  describe('getAllPaymentStates()', () => {
    let states: State[];

    beforeEach(() => {
      states = [
        stubState({ type: 'PaymentState' }),
        stubState({ type: 'PaymentState' })];
    });

    test('returns all the payment States from CT', async () => {
      execute.mockReturnValueOnce({ body: { results: states } });

      const response = await paymentDao.getAllPaymentStates(market);

      expect(response).toBe(states);
    });

    test('re-throws CT errors', async () => {
      const err = new Error('some CT error');
      execute.mockRejectedValueOnce(err);

      const response = () => paymentDao.getAllPaymentStates(market);

      await expect(response).rejects.toThrow(err);
    });
  });

  describe('getNextOrderSequence()', () => {
    test('uses the country code in the service URL', async () => {
      (axios as unknown as Mock).mockResolvedValueOnce({ data: 123 });

      await paymentDao.getNextOrderSequence(market);

      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(
        1,
        {
          ...axiosOptions,
          url: paymentOrderNumberGeneratorUrl.replace('{{country}}', market.country),
          method: 'post',
          headers: { Accept: 'text/plain' },
        },
      );
    });

    test('returns the value as string', async () => {
      const orderNumber = faker.datatype.number();
      (axios as unknown as Mock).mockResolvedValueOnce({ data: orderNumber });

      const result = await paymentDao.getNextOrderSequence(market);

      expect(result).toBe(`${orderNumber}`);
    });
  });

  describe('getNextPaymentKey()', () => {
    test('uses the country code in the service URL', async () => {
      (axios as unknown as Mock).mockResolvedValueOnce({ data: 123 });

      await paymentDao.getNextPaymentKey(market);

      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(
        1,
        {
          ...axiosOptions,
          url: paymentKeyGeneratorUrl.replace('{{country}}', market.country),
          method: 'post',
          headers: { Accept: 'text/plain' },
        },
      );
    });

    test('returns the value as string', async () => {
      const paymentKey = faker.datatype.number();
      (axios as unknown as Mock).mockResolvedValueOnce({ data: paymentKey });

      const result = await paymentDao.getNextPaymentKey(market);

      expect(result).toBe(`${paymentKey}`);
    });
  });

  describe('getMyPaymentStatus()', () => {
    let ctResponse: ClientResponse<GraphQLResponse>;
    let state: StateDraft;
    let authorization: string;
    let cartId: string;

    beforeEach(() => {
      state = {
        type: 'PaymentState',
        key: faker.random.arrayElement(['initial', 'pending', 'success']),
      };

      ctResponse = {
        body: {
          data: {
            me: {
              cart: {
                paymentInfo: {
                  payments: [{
                    paymentStatus: { state },
                  }],
                },
              },
            },
          },
        },
      };

      authorization = faker.datatype.uuid();
      cartId = faker.datatype.uuid();
    });

    test('queries CT client graphql', async () => {
      /* Prepare */
      execute.mockReturnValueOnce(ctResponse);

      /* Execute */
      await paymentDao.getMyPaymentStatus(market, authorization, cartId);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1, {
        headers: {
          Authorization: authorization,
        },
        body: {
          query: 'query () { paymentInfo {} }',
          variables: { cartId },
        },
      });
      expect(execute).toHaveBeenCalledTimes(1);
    });

    test('rethrows CT errors as ApiError', async () => {
      /* Prepare */
      const err = new Error('ct error');
      Object.assign(err, { body: { statusCode: 404, errors: ['ct errors'] } });
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const result = () => paymentDao.getMyPaymentStatus(market, authorization, cartId);

      /* Verify */
      await expect(result).rejects.toThrow(new ApiError(404, ['ct errors']));
    });

    test('re-throws CT errors', async () => {
      const err = new Error('some CT error');
      execute.mockRejectedValueOnce(err);

      const response = () => paymentDao.getMyPaymentStatus(market, authorization, cartId);

      await expect(response).rejects.toThrow(err);
    });
  });

  describe('ePayTransactionDetail()', () => {
    let transactionId: string;

    beforeEach(() => {
      transactionId = faker.datatype.number().toString();
      (constructUrl.constructUrl as Mock) = jest.fn();
      // constructUrl
    });

    test('calls the payment gateway transaction API', async () => {
      ePayTransaction.status = E_PAYMENT_STATUS.captured;
      const mockResponse = {
        data: ePayTransaction,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      const expectedUrl = `${paymentApiPrefix}transaction/${transactionId}`
        .replace('{{country}}', market.country)
        .replace('{{locale}}', market.locale);
      (constructUrl.constructUrl as Mock).mockResolvedValueOnce(expectedUrl);
      const data = await paymentDao.ePayTransactionDetail(
        market,
        transactionId,
        0,
      );

      expect(axios).toHaveBeenCalledTimes(1);
      // expect(axios).toHaveBeenNthCalledWith(1, {
      //   ...axiosOptions,
      //   url: expectedUrl,
      //   method: 'GET',
      //   headers: { 'x-api-key': paymentApiKey },
      // });
    });

    test('rethrows payment gateway errors', async () => {
      const err = new Error('payment gateway error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);

      const result = () => paymentDao.ePayTransactionDetail(
        market,
        transactionId,
        0,
      );

      await expect(result).rejects.toThrow(err);
    });

    test('asserts response schema for errors', async () => {
      /* Check data field */

      (axios as unknown as Mock).mockResolvedValueOnce({});

      await expect(
        () => paymentDao.ePayTransactionDetail(
          market,
          transactionId,
          0,
        ),
      ).rejects.toThrow(
        new Error(i18next.t('error.paymentStatusDataFieldMissing')),
      );
      /* Check data.status field */

      (axios as unknown as Mock).mockResolvedValueOnce({ data: {} });

      await expect(
        () => paymentDao.ePayTransactionDetail(
          market,
          transactionId,
          0,
        ),
      ).rejects.toThrow(
        new Error(i18next.t('error.paymentStatusStatusFieldMissing')),
      );

      /* Check data.ordNr field */

      (axios as unknown as Mock).mockResolvedValueOnce({ data: { status: E_PAYMENT_STATUS.captured } });

      await expect(
        () => paymentDao.ePayTransactionDetail(
          market,
          transactionId,
          0,
        ),
      ).rejects.toThrow(
        new Error(i18next.t('error.paymentStatusOrdNrFieldMissing')),
      );

      // /* Check E_PAYMENT_STATUS.declined */

      // (axios as unknown as Mock).mockResolvedValueOnce({
      //   data: {
      //     status: E_PAYMENT_STATUS.declined,
      //     ordNr: faker.datatype.string(),
      //   },
      // });

      // await expect(
      //   () => paymentDao.ePayTransactionDetail(
      //     market,
      //     transactionId,
      //     0,
      //   ),
      // ).rejects.toThrow(
      //   new Error(i18next.t('error.paymentDeclinedByPSP')),
      // );

      // /* Check E_PAYMENT_STATUS.failed */

      // (axios as unknown as Mock).mockResolvedValueOnce({
      //   data: {
      //     status: E_PAYMENT_STATUS.failed,
      //     ordNr: faker.datatype.string(),
      //   },
      // });

      // await expect(
      //   () => paymentDao.ePayTransactionDetail(
      //     market,
      //     transactionId,
      //     0,
      //   ),
      // ).rejects.toThrow(
      //   new Error(i18next.t('error.paymentFailedByPSP')),
      // );

      /* Check E_PAYMENT_STATUS is not as per expectation */

      (axios as unknown as Mock).mockResolvedValueOnce({
        data: {
          status: 'REFUND',
          ordNr: faker.datatype.string(),
        },
      });

      await expect(
        () => paymentDao.ePayTransactionDetail(
          market,
          transactionId,
          0,
        ),
      ).rejects.toThrow(
        new ApiError(
          HttpStatusCodes.PAYMENT_REQUIRED,
          i18next.t('error.paymentStatusNotExpected', 'REFUND'),
        ),
      );
    });

    test('returns payment gateway transaction response', async () => {
      ePayTransaction.status = E_PAYMENT_STATUS.captured;

      const data = ePayTransaction;
      (axios as unknown as Mock).mockResolvedValueOnce({ data });

      const response = await paymentDao.ePayTransactionDetail(
        market,
        transactionId,
        0,
      );

      expect(response).toEqual(data);
    });

    test('rethrows payment errors as ApiError', async () => {
      /* Prepare */
      const err = new Error('ct error');
      Object.assign(err, {
        response: {
          status: 400,
          data: { message: 'The original transaction was not found.' },
        },
      });
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const result = () => paymentDao.ePayTransactionDetail(market, transactionId, 0);

      /* Verify */
      await expect(result).rejects.toThrow(new ApiError(400, 'The original transaction was not found.'));
    });

    test('checkEPayTransactionStatus retry for pending status', async () => {
      // ePayTransaction.status = E_PAYMENT_STATUS.captured;
      // (paymentDao.ePayTransactionDetail as Mock).mockResolvedValueOnce({ data: ePayTransaction });
      ePayTransaction.status = E_PAYMENT_STATUS.pending;
      // const data = ePayTransaction;
      (axios as unknown as Mock).mockResolvedValueOnce({ data: ePayTransaction });

      const response = (paymentDao as any).checkEPayTransactionStatus(
        market,
        transactionId,
        6,
        ePayTransaction,
      );

      await expect(response).rejects.toThrow(new ApiError(500, 'Internal Server Error'));
    });
  });
});
