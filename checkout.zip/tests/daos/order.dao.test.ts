import faker from '@faker-js/faker';
import i18next from 'i18next';
import { ApiError, CtClient } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubCtClient, stubOrderDto, stubOrder, stubGraphql, stubCtProductDto,
} from '../__stubs__';
import Mock = jest.Mock;
import { OrderDao } from '../../src/daos';
import { OrderDto } from '../../src/dtos/order.dto';
import { graphql } from '../../src/graphql';

describe('OrderDao', () => {
  let orderDao: OrderDao;
  let orderDto: OrderDto;
  let ctClient: CtClient;
  let market: MarketInfo;
  let authorization: string;
  let gql: typeof graphql;
  let get: Mock;
  let post: Mock;
  let execute: Mock;
  beforeEach(() => {
    market = stubMarket();
    authorization = faker.datatype.uuid();
    orderDto = stubOrderDto();
    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    ctClient = stubCtClient(market.country, {
      orders: jest.fn().mockReturnValueOnce({ post }),
      graphql: jest.fn().mockReturnValueOnce({ get, post }),
      shippingMethods: jest.fn().mockReturnValueOnce({ get }),
    });
    gql = stubGraphql();
    orderDao = new OrderDao({ ctClient, graphql: gql });
  });
  describe('createOrderFromCart()', () => {
    let cartId: string;
    let version: number;
    let orderNumber: string;
    beforeEach(() => {
      cartId = faker.datatype.uuid();
      version = faker.datatype.number();
      orderNumber = faker.datatype.number().toString();
    });
    test('reads the order from CommerceTools', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });
      /* Execute */
      await orderDao.createOrderFromCart(market, authorization, cartId, version, orderNumber);
      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        {
          body: { id: cartId, version, orderNumber },
          headers: { authorization },
        },
      );
      expect(execute).toHaveBeenCalledTimes(1);
    });
    test('returns the response from CommerceTools', async () => {
      /* Prepare */
      const order = stubOrder();
      execute.mockReturnValueOnce({ body: order });
      /* Execute */
      const result = await orderDao.createOrderFromCart(market, authorization, cartId, version, orderNumber);
      /* Verify */
      expect(result).toBe(order);
    });
    test('re-throws ctClient errors', async () => {
      /* Prepare */
      const ctError = new Error('CommerceTools Error');
      execute.mockRejectedValueOnce(ctError);
      /* Execute */
      const result = expect(() =>
        orderDao.createOrderFromCart(market, authorization, cartId, version, orderNumber));
      /* Verify */
      await result.rejects.toThrow(ctError);
    });
  });
  describe('fetchOrder()', () => {
    let orderId: string;
    let authHeader: string;
    beforeEach(() => {
      orderId = faker.datatype.uuid();
      authHeader = faker.datatype.string();
    });
    test('fetch order detail using graphQL', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            me: {
              order: orderDto,
            },
          },
        },
      });
      /* Execute */
      const result = await orderDao.fetchOrder(authHeader, market, orderId);
      /* Verify */
      expect(result).toBe(orderDto);
    });
    test('fetch Order By OrderNumber using graphQL', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            orders: {
              results: [orderDto],
            },
          },
        },
      });
      /* Execute */
      const result = await orderDao.fetchOrderByOrderNumber(market, 'LPRO0002FL');
      /* Verify */
      expect(result).toBeTruthy();
    });
    test('forwards GraphQL errors for fetch Order By OrderNumber', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.uuid());
      execute.mockRejectedValueOnce(err);
      execute.mockReturnValueOnce({ body: undefined });
      /* Execute */
      const order = () => orderDao.fetchOrderByOrderNumber(market, orderId);
      /* Verify */
      await expect(order).rejects.toThrow(err);
    });
    test('re-throws GraphQL errors, fetch Order By OrderNumber', async () => {
      /* Prepare */
      const error = {
        body: {
          statusCode: 400,
          status: {
            statusCode: 400,
            msg: faker.datatype.string(),
            timestamp: faker.datatype.datetime(),
          },
          errors: [
            {
              code: faker.datatype.string(),
              message: faker.datatype.string(),
            },
          ],
        },
      };
      execute.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => orderDao.fetchOrderByOrderNumber(market, orderId));
      /* Verify */
      await result.rejects.toBeTruthy();
    });
    test('forwards GraphQL errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.uuid());
      execute.mockRejectedValueOnce(err);
      execute.mockReturnValueOnce({ body: undefined });
      /* Execute */
      const order = () => orderDao.fetchOrder(authHeader, market, orderId);
      /* Verify */
      await expect(order).rejects.toThrow(err);
    });
    test('re-throws non-404 GraphQL errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);
      /* Execute */
      const result = expect(() => orderDao.fetchOrder(authHeader, market, orderId));
      /* Verify */
      await result.rejects.toThrow(iseError);
    });
    test('re-throws GraphQL errors', async () => {
      /* Prepare */
      const error = {
        body: {
          statusCode: 400,
          status: {
            statusCode: 400,
            msg: faker.datatype.string(),
            timestamp: faker.datatype.datetime(),
          },
          errors: [
            {
              code: faker.datatype.string(),
              message: faker.datatype.string(),
            },
          ],
        },
      };
      execute.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => orderDao.fetchOrder(authHeader, market, orderId));
      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });
  /**
   * Unit test case for fetchProduct function of product.dao
   */
  describe('fetchProductsDetail()', () => {
    let condition;
    let ctResponse: any;
    let multiProductDto;
    beforeEach(() => {
      multiProductDto = stubCtProductDto({ id: faker.datatype.uuid() });
      condition = `id in ("${multiProductDto.id}")`;
      ctResponse = {
        body: {
          data: {
            products: {
              results: [multiProductDto],
            },
          },
        },
      };
    });
    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      execute.mockReturnValueOnce(ctResponse);
      /* Execute */
      await orderDao.fetchProductsDetail(market, `"${multiProductDto.id}"`);
      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
    });
    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);
      const result = await orderDao.fetchProductsDetail(market, multiProductDto.id);
      expect(result).toBe(ctResponse.body.data.products.results);
    });
    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {
        data: null,
        errors: ['msg'],
      };
      execute.mockRejectedValueOnce(err);
      const result = orderDao.fetchProductsDetail(market, multiProductDto.id);
      await expect(result).rejects.toThrow(err);
    });
    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);
      /* Execute */
      const result = expect(() => orderDao.fetchProductsDetail(market, multiProductDto.id));
      /* Verify */
      await result.rejects.toThrow(isError);
    });
    test('re-throws ApiError ctClient errors', async () => {
      /* Prepare */
      const errBody = {
        body: {
          data: null,
          errors: ['msg'],
        },
      };
      execute.mockReturnValueOnce(errBody);
      /* Execute */
      const call = () => orderDao.fetchProductsDetail(market, multiProductDto.id);
      /* Verify */
      await expect(call).rejects.toThrow(
        new ApiError(400, i18next.t('error.inventoryInvalidUuid')),
      );
    });
    test('returns the result undefined', async () => {
      const errBody = {
        body: {
          data: null,
        },
      };
      execute.mockReturnValueOnce(errBody);
      const result = await orderDao.fetchProductsDetail(market, multiProductDto.id);
      expect(result).toBe(undefined);
    });
  });
});
