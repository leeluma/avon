import faker from '@faker-js/faker';
import i18next from 'i18next';
import HttpStatusCodes from 'http-status-codes';
import { CartUpdate } from '@commercetools/platform-sdk';
import { CtClient, ApiError } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubCtCartDto, stubCtClient, setShippingAddressDto, stubGraphql,
} from '../__stubs__';
import Mock = jest.Mock;
import { CartDao } from '../../src/daos';

import { CartDto } from '../../src/dtos';
import { graphql } from '../../src/graphql';

describe('CartDao', () => {
  let cartDao: CartDao;
  let cartDto: CartDto;
  let ctClient: CtClient;
  let market: MarketInfo;
  let post: Mock;
  let withId: Mock;
  let get: Mock;
  let execute: Mock;
  let gql: typeof graphql;
  let carts: Mock;
  let authHeader;
  let replicate: Mock;
  let shippingKind: string;

  beforeEach(() => {
    market = stubMarket();
    cartDto = stubCtCartDto();
    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    carts = jest.fn().mockReturnValueOnce({ withId });
    replicate = jest.fn().mockReturnValueOnce({ post });
    ctClient = stubCtClient(market.country, {
      carts: jest.fn().mockReturnValueOnce({ withId, post, replicate }),
      shippingMethods: jest.fn().mockReturnValueOnce({ get }),
      graphql: jest.fn().mockReturnValueOnce({ get, post }),
      me: jest.fn().mockReturnValueOnce({ carts, withId, post }),

    });
    gql = stubGraphql();
    cartDao = new CartDao({ ctClient, graphql: gql });
    authHeader = faker.datatype.string();
    shippingKind = 'Courier';
  });

  describe('getShippingMethodsByCartId()', () => {
    test('get data from shipping method by cart id by graphql query', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });
      /* Execute */
      await cartDao.getShippingMethods(market, shippingKind);
      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
    });

    test('getShippingMethodsByCartId() returns undefined if CtClient throws 404', async () => {
      /* Prepare */
      const notFoundError = new Error('Not Found');
      (notFoundError as any).statusCode = 404;
      execute.mockRejectedValueOnce(notFoundError);
      /* Execute */
      const result = await cartDao.getShippingMethods(market, shippingKind);
      /* Verify */
      expect(result).toBe(undefined);
    });

    test('getShippingMethodsByCartId() re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);
      /* Execute */
      const result = expect(() => cartDao.getShippingMethods(market, shippingKind));
      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('addShippingMethod()', () => {
    let cart: any;
    let shippingMethodId: string;
    let shippingMethodBody: any;
    beforeEach(() => {
      cart = stubCtCartDto();
      shippingMethodId = faker.datatype.uuid();
      shippingMethodBody = {
        version: cart.version,
        actions: [{
          action: 'setShippingMethod',
          shippingMethod: { id: shippingMethodId, typeId: 'shipping-method' },

        }],
      };
    });

    test('queries ctClient with cart and shipping method id', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.addShippingMethod(market.country, cart, shippingMethodId, authHeader);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        {
          body: shippingMethodBody,
          headers: {
            Authorization: authHeader,
          },
        },
      );
    });

    test('returns ctClient response body for add shipping method', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.addShippingMethod(market.country, cart, shippingMethodId, authHeader);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('returns 400 if shipping method id is not found', async () => {
      /* Prepare */
      const iseError = new ApiError(400, i18next.t('error.shippingMethodNotFound'));
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.addShippingMethod(market.country, cart, shippingMethodId, authHeader));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('returns 401 if auth token invalid', async () => {
      /* Prepare */
      const iseError = new ApiError(401, i18next.t('error.invalidToken'));
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.addShippingMethod(market.country, cart, shippingMethodId, authHeader));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.addShippingMethod(market.country, cart, shippingMethodId, authHeader));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('getCartById()', () => {
    let cartId: string;
    beforeEach(() => {
      cartId = faker.datatype.uuid();
    });

    test('queries ctClient with cart id', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.getCartById(market.country, cartId);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: cartId },
      );
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.getCartById(market.country, cartId);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('returns undefined if CtClient throws 404', async () => {
      /* Prepare */
      const notFoundError = new Error('Not Found');
      (notFoundError as any).statusCode = 404;
      execute.mockRejectedValueOnce(notFoundError);

      /* Execute */
      const result = await cartDao.getCartById(market.country, cartId);

      /* Verify */
      expect(result).toBe(undefined);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.getCartById(market.country, cartId));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('setShippingAddress()', () => {
    let cart: any;
    let shippingAddressDetails: any;
    let shippingAddressBody: any;
    let authToken: string;
    beforeEach(() => {
      cart = stubCtCartDto();
      authToken = faker.datatype.uuid();
      shippingAddressDetails = setShippingAddressDto();
      shippingAddressBody = {
        version: cart.version,
        actions: [{
          action: 'setShippingAddress',
          address: {
            custom: {
              type: {
                typeId: 'type',
                key: 'address-type',
              },
              fields: {
                Address1: shippingAddressDetails.address1,
                Address2: shippingAddressDetails.address2,
                county: shippingAddressDetails.county,
              },
            },
            postalCode: shippingAddressDetails.postalCode,
            city: shippingAddressDetails.city,
            phone: shippingAddressDetails.phoneNumber,
            country: market.country,
          },
        }],
      };
    });

    test('queries ctClient with cart and set shipping address', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.setShippingAddress(market.country, cart, shippingAddressBody, authToken);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        {
          body: shippingAddressBody,
          headers: {
            Authorization: authToken,
          },
        },
      );
    });

    test('returns ctClient response body for set shipping address', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.setShippingAddress(market.country, cart, shippingAddressDetails, authToken);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.setShippingAddress(market.country, cart, shippingAddressDetails, authToken));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('getCartByIdGraphql()', () => {
    const cartId = faker.datatype.uuid();
    test('returns client response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            me: {
              cart: cartDto,
            },
          },
        },
      });

      /* Execute */
      const result = await cartDao.getCartByIdGraphql(market, cartId, authHeader);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('forwards CT errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.uuid());
      execute.mockRejectedValueOnce(err);
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      const createOrderFromCart = () => cartDao.getCartByIdGraphql(market, cartId, authHeader);

      /* Verify */
      await expect(createOrderFromCart).rejects.toThrow(err);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.getCartByIdGraphql(market, cartId, authHeader));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const error = {
        body: {
          statusCode: 400,
          status: {
            statusCode: 400,
            msg: faker.datatype.string(),
            timestamp: faker.datatype.datetime(),
          },
          errors: [
            {
              code: faker.datatype.string(),
              message: faker.datatype.string(),
            },
          ],
        },
      };

      execute.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => cartDao.getCartByIdGraphql(market, cartId, authHeader));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  describe('updateMyCartById()', () => {
    let cartId: string;
    let version: number;
    let authToken: string;
    let updateCartActionDraft: CartUpdate;
    beforeEach(() => {
      cartId = faker.datatype.uuid();
      authToken = faker.datatype.uuid();
      version = faker.datatype.number();
      updateCartActionDraft = {
        version,
        actions: [{
          action: 'setCustomerEmail',
          email: faker.internet.email(),
        }, {
          action: 'setShippingAddress',
          address: {
            firstName: faker.internet.userName(),
            lastName: faker.internet.userName(),
            country: market.country,
          },
        }],
      };
    });

    test('queries ctClient with bodyDraft, authToken and cartId', async () => {
      /* Execute */
      await cartDao.updateMyCartById(market.country, updateCartActionDraft, authToken, cartId);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: cartId },
      );
    });

    test('post the updateMyCartById action', async () => {
      /* Execute */
      await cartDao.updateMyCartById(market.country, updateCartActionDraft, authToken, cartId);
      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1, {
        body: updateCartActionDraft,
        headers: {
          Authorization: authToken,
        },
      });
    });

    test('forwards CT errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.uuid());
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const updateMyCartById = () => cartDao.updateMyCartById(market.country, updateCartActionDraft, authToken, cartId);

      /* Verify */
      await expect(updateMyCartById).rejects.toThrow(err);
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 400,
        status: {
          statusCode: 400,
          msg: faker.datatype.string(),
          timestamp: faker.datatype.datetime(),
        },
        errors: [
          {
            code: faker.datatype.string(),
            message: faker.datatype.string(),
          },
        ],
      };

      execute.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => cartDao.updateMyCartById(market.country, updateCartActionDraft, authToken, cartId));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  describe('updateCartById()', () => {
    let cartId: string;
    let version: number;
    let updateCartPayload: CartUpdate;
    let orderNumber: any;
    beforeEach(() => {
      cartId = faker.datatype.uuid();
      version = faker.datatype.number();
      orderNumber = Date.now().toString().slice(-9);
      updateCartPayload = {
        version,
        actions: [
          {
            action: 'addPayment',
            payment: { typeId: 'payment', id: faker.datatype.uuid() },
          }, {
            action: 'setCustomType',
            type: { typeId: 'type', key: 'cart-orderNumber' },
            fields: { orderNumber },
          },
        ],
      };
    });

    test('queries ctClient with bodyDraft and cartId', async () => {
      /* Execute */
      execute.mockReturnValueOnce({ body: undefined });
      await cartDao.updateCartById(market.country, cartId, updateCartPayload);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: cartId },
      );
    });

    test('post the updateCartById action', async () => {
      /* Execute */
      execute.mockReturnValueOnce({ body: undefined });
      await cartDao.updateCartById(market.country, cartId, updateCartPayload);
      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1, {
        body: updateCartPayload,
      });
    });

    test('forwards CT errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.uuid());
      execute.mockRejectedValueOnce(err);
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      const updateCartById = () => cartDao.updateCartById(market.country, cartId, updateCartPayload);

      /* Verify */
      await expect(updateCartById).rejects.toThrow(err);
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 400,
        status: {
          statusCode: 400,
          msg: faker.datatype.string(),
          timestamp: faker.datatype.datetime(),
        },
        errors: [
          {
            code: faker.datatype.string(),
            message: faker.datatype.string(),
          },
        ],
      };

      execute.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => cartDao.updateCartById(market.country, cartId, updateCartPayload));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  describe('getCartPaymentInfo()', () => {
    let ctResponse: any;
    const cartId = faker.datatype.uuid();
    beforeEach(() => {
      ctResponse = {
        body: {
          data: {
            cart: {
              ...cartDto,
            },
          },
        },
      };
    });

    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      const locale = market.locale.toLocaleUpperCase();
      const expectedBody = {
        query: 'query () { paymentInfo {} }',
        variables: {
          cartId,
          locale,
        },
      };
      execute.mockReturnValueOnce(ctResponse);

      /* Execute */
      await cartDao.getCartPaymentInfo(market, cartId, authHeader);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        {
          body: expectedBody,
          headers: {
            Authorization: authHeader,
          },
        },
      );
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await cartDao.getCartPaymentInfo(market, cartId, authHeader);

      expect(result).toBe(ctResponse.body.data.cart);
    });

    test('returns the result data NULL from the GraphQL server', async () => {
      const ctResponses = {
        body: {
          statusCode: 500,
          data: null,
          errors: {
            error: 'Malformed parameter: UUID string is invalid',
          },
        },
      };
      execute.mockReturnValueOnce(ctResponses);

      const result = await cartDao.getCartPaymentInfo(market, cartId, authHeader);

      expect(result).toBeUndefined();
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {};
      execute.mockRejectedValueOnce(err);

      const result = cartDao.getCartPaymentInfo(market, cartId, authHeader);

      await expect(result).rejects.toThrow(err);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);
      /* Execute */
      const result = expect(() => cartDao.getCartPaymentInfo(market, cartId, authHeader));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('returns 401 if auth token invalid', async () => {
      /* Prepare */
      const iseError = new ApiError(401, i18next.t('error.invalidToken'));
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.replicateCartById(market.country, cartId, authHeader));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('returns error with body', async () => {
      /* Prepare */
      const iseError = new ApiError(403, i18next.t('error.invalidToken'));
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.replicateCartById(market.country, cartId, authHeader));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('rethrows UNAUTHORIZED ApiError', async () => {
      /* Prepare */
      const err = new Error('ct error');
      Object.assign(err, {
        statusCode: HttpStatusCodes.UNAUTHORIZED,
        data: { message: i18next.t('error.invalidToken') },
      });
      execute.mockRejectedValueOnce(err);
      /* Execute */
      const result = () => cartDao.replicateCartById(market.country, cartId, authHeader);

      /* Verify */
      await expect(result).rejects.toThrow(new ApiError(HttpStatusCodes.UNAUTHORIZED, i18next.t('error.invalidToken')));
    });

    test('rethrows status code ApiError', async () => {
      /* Prepare */
      const err = new Error('Bad Request');
      Object.assign(err, {
        body: {
          statusCode: HttpStatusCodes.BAD_REQUEST,
          errors: { message: 'Bad Request' },
        },
      });
      execute.mockRejectedValueOnce(err);
      /* Execute */
      const result = () => cartDao.replicateCartById(market.country, cartId, authHeader);

      /* Verify */
      await expect(result).rejects.toThrow(new ApiError(HttpStatusCodes.BAD_REQUEST, 'Bad Request'));
    });
  });

  describe('replicateCartById()', () => {
    const cartId = faker.datatype.uuid();
    let cart: any;
    let cartReference: any;
    beforeEach(() => {
      cart = stubCtCartDto();
      cartReference = {
        reference: {
          typeId: 'cart',
          id: cartId,
        },
      };
    });

    test('post cart reference to replicate', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.replicateCartById(market.country, cartId, authHeader);

      /* Verify */
      expect(replicate).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        {
          body: cartReference,
          headers: {
            Authorization: authHeader,
          },
        },
      );
    });

    test('returns ctClient response body for replicate cart', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.replicateCartById(market.country, cartId, authHeader);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.replicateCartById(market.country, cartId, authHeader));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('returns 400 if CtClient throws 400 for replicate cart', async () => {
      /* Prepare */
      const iseError = new ApiError(400, i18next.t('error.cartIdNotFound', { cartId: cart.id }));
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.replicateCartById(market.country, cartId, authHeader));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('recalculateCart()', () => {
    let cart: any;
    let recalculateCartBody: any;

    beforeEach(() => {
      cart = {
        id: faker.datatype.uuid(),
        version: faker.datatype.number(),
      };
      recalculateCartBody = {
        version: cart.version,
        actions: [{
          action: 'recalculate',
          updateProductData: true,
        }],
      };
    });

    test('queries ctClient to recalculate cart', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.recalculateCart(market.country, cart);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        {
          body: recalculateCartBody,
        },
      );
    });

    test('returns ctClient response body for recalculated cart', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.recalculateCart(market.country, cart);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('returns 400 if CtClient throws 400 for recalculated cart', async () => {
      /* Prepare */
      const iseError = new ApiError(400, i18next.t('error.cartIdNotFound', { cartId: cart.id }));
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.recalculateCart(market.country, cart));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.recalculateCart(market.country, cart));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('getMyCartById()', () => {
    let cartId: string;
    beforeEach(() => {
      cartId = faker.datatype.uuid();
    });

    test('queries ctClient with cart id', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.getMyCartById(market.country, authHeader, cartId);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: cartId },
      );
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.getMyCartById(market.country, authHeader, cartId);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('returns undefined if CtClient throws 404', async () => {
      /* Prepare */
      const notFoundError = new Error('Not Found');
      (notFoundError as any).statusCode = 404;
      execute.mockRejectedValueOnce(notFoundError);

      /* Execute */
      const result = await cartDao.getMyCartById(market.country, authHeader, cartId);

      /* Verify */
      expect(result).toBe(undefined);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.getMyCartById(market.country, authHeader, cartId));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });
});
