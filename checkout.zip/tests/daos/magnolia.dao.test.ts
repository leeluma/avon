import faker from '@faker-js/faker';
import axios from 'axios';
import { axiosOptions } from '../../src/lib/axios-options';
import { MarketInfo } from '../../src/middlewares';
import { stubMarket } from '../__stubs__';
import { MagnoliaDao } from '../../src/daos';
import { MAGNOLIA_URI } from '../../src/common/constants';
import Mock = jest.Mock;
import { MagnoliaInfo } from '../../src/dtos';

jest.mock('axios');

describe('Magnolia Dao testing Suit', () => {
  let magnoliaDao: MagnoliaDao;
  let market: MarketInfo;
  const templateName = faker.datatype.string();

  let magnolia: MagnoliaInfo;
  let magnoliaBasePath: string;
  const mockResponse = {
    data: {
      name: faker.datatype.string(),
      path: faker.datatype.string(),
      id: faker.datatype.uuid(),
      nodeType: faker.datatype.string(),
      title: faker.datatype.string(),
      facebook: {
        name: faker.datatype.string(),
        path: faker.datatype.string(),
      },
      twitter: {
        name: faker.datatype.string(),
        path: faker.datatype.string(),
      },
    },
  };

  beforeEach(() => {
    market = stubMarket();
    magnoliaBasePath = faker.internet.url();
    magnolia = {
      url: faker.internet.url(),
      isPreview: faker.datatype.boolean(),
      marketPath: faker.internet.userName(),
    };
    /* Stubs */

    magnoliaDao = new MagnoliaDao({ magnoliaBasePath });
  });

  // Unite test case for getCheckoutPageData() method
  describe('getCheckoutPageData()', () => {
    test('returns magnolia response body', async () => {
      /* Prepare */
      const page = (magnolia.isPreview === true && magnolia.marketPath !== market.country.toLocaleLowerCase())
        ? MAGNOLIA_URI.checkoutPage : MAGNOLIA_URI.checkout;
      let checkoutUrl = `${magnolia.url}${page}?lang=${market.locale}-${market.country}`;
      checkoutUrl = checkoutUrl.replace('{{country}}', `${magnolia.marketPath}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: checkoutUrl,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getCheckoutPageData(market, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(1, config);
    });

    test('Failed to fetch magnolia data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getCheckoutPageData(market, magnolia));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch checkout data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getOrderConfirmationPageData()', () => {
    test('returns magnolia response body', async () => {
      /* Prepare */
      const page = (magnolia.isPreview === true && magnolia.marketPath !== market.country.toLocaleLowerCase())
        ? MAGNOLIA_URI.orderConfirmationPage : MAGNOLIA_URI.orderConfirmation;
      let checkoutUrl = `${magnolia.url}${page}?lang=${market.locale}-${market.country}`;
      checkoutUrl = checkoutUrl.replace('{{country}}', `${magnolia.marketPath}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: checkoutUrl,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getOrderConfirmationPageData(market, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(1, config);
    });

    test('Failed to fetch magnolia data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getOrderConfirmationPageData(market, magnolia));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch order confirmation data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getTemplateDataFromMagnolia()', () => {
    test('returns magnolia template response body', async () => {
      /* Prepare */
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: `${magnoliaBasePath}${MAGNOLIA_URI.template}${templateName}`,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getTemplateDataFromMagnolia(templateName, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(1, config);
    });

    test('Failed to fetch magnolia template data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getTemplateDataFromMagnolia(templateName, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch template data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getDefaultWarehouse()', () => {
    test('returns magnolia default warehouse response body', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getDefaultWarehouse(market, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia default warehouse data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getDefaultWarehouse(market, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch warehouse data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getGlobalSettings()', () => {
    test('returns magnolia global setting response body', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getGlobalSettings(market, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('returns magnolia global setting response body in case of magnoliaBasePath undeifned', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getGlobalSettings(market, undefined);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia global setting data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getGlobalSettings(market, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch global settings data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getPriceFormatSettings()', () => {
    test('returns price format response body', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getPriceFormatSettings(market, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia price format data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getPriceFormatSettings(market, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch price format settings data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getSettings()', () => {
    const apiPath = faker.internet.url();
    test('returns address validation response body', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getSettings(market, apiPath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia address validation data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getSettings(market, apiPath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch address validation settings data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
});
