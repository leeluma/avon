import faker from '@faker-js/faker';
import axios from 'axios';
import Mock = jest.Mock;
import { AddressDao } from '../../src/daos';
import { stubDetailResponseDto, stubPickupPointRequestDto, stubPickupPointResponseDto } from '../__stubs__';
import { config } from '../../src/config';

jest.mock('axios');

describe('addressDao', () => {
  let addressDao: AddressDao;
  let url: string;
  let address: string;
  let addressId: string;
  let detailResponseDto;
  let pickupPointRequestDto;
  let pickupPointResponseDto;
  let params;
  let headers;

  beforeEach(() => {
    url = faker.datatype.string();
    address = faker.datatype.string();
    addressId = faker.datatype.string();
    detailResponseDto = stubDetailResponseDto;
    pickupPointRequestDto = stubPickupPointRequestDto;
    pickupPointResponseDto = stubPickupPointResponseDto;
    params = {
      longitude: pickupPointRequestDto.longitude,
      latitude: pickupPointRequestDto.latitude,
      distance: pickupPointRequestDto.distance ?? config.defaultDistance,
      unit: pickupPointRequestDto.distanceUnit ?? config.defaultDistanceUnit,
    };
    headers = {
      'x-api-key': 'xxxxxxx',
    };
    addressDao = {} as any;

    /* SUT */
    addressDao = new AddressDao();
  });

  describe('addressAutocomplete()', () => {
    test('mocking axios', async () => {
      /* Prepare */
      (axios.get as unknown as Mock).mockResolvedValueOnce({
        data: {
          suggestions: [
            {
              exactMatch: true,
              addressId: faker.datatype.uuid(),
            },
            {
              exactMatch: false,
              addressId: faker.datatype.uuid(),
            },
          ],
        },
      });

      /* Execute */
      await (addressDao).addressAutocomplete(url, address);

      /* Verify */
      expect(axios.get).toHaveBeenCalledTimes(1);
    });
    test('Failed to fetch address autocomplete data', async () => {
      const err = new Error(`Failed to get autocomplete details from url ${url}, because:`);
      (axios.get as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (addressDao).addressAutocomplete(url, address));
      /* Verify */
      await response.rejects.toThrow(err);
      expect(axios.get).toHaveBeenCalledTimes(1);
    });
  });

  describe('addressDetail()', () => {
    test('mocking axios', async () => {
      /* Prepare */
      (axios.get as unknown as Mock).mockResolvedValueOnce({
        data: {
          detailResponseDto,
        },
      });

      /* Execute */
      const response = await (addressDao).addressDetail(url, addressId);

      /* Verify */
      expect(response).toBeTruthy();
      expect(axios.get).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch address details data', async () => {
      const err = new Error(`Failed to get address details from url ${url}, because: `);
      (axios.get as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (addressDao).addressDetail(url, addressId));
      /* Verify */
      await response.rejects.toThrow(err);
      expect(axios.get).toHaveBeenCalledTimes(1);
    });
  });

  describe('getPickupDetail()', () => {
    test('mocking axios', async () => {
      /* Prepare */
      (axios.get as unknown as Mock).mockResolvedValueOnce({
        data: {
          pickupPointResponseDto,
        },
      });

      /* Execute */
      const response = await (addressDao).getPickupDetail(url, headers, params);

      /* Verify */
      expect(response).toEqual({ pickupPointResponseDto });
      expect(axios.get).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia data', async () => {
      const err = new Error(`Failed to get pickup details from url ${url}`);
      (axios.get as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (addressDao).getPickupDetail(url, headers, params));
      /* Verify */
      await response.rejects.toThrow(err);
      expect(axios.get).toHaveBeenCalledTimes(1);
    });
  });
});
