import faker from '@faker-js/faker';
import axios from 'axios';
import { Order } from '@commercetools/platform-sdk';
import { MarketInfo } from '../../src/middlewares';
import { stubGraphQLLineItem, stubMarket, stubOrder } from '../__stubs__';
import Mock = jest.Mock;
import { NotificationsDao } from '../../src/daos/notifications.dao';
import { config } from '../../src/config';
import { OrderMapper } from '../../src/mappers';

const {
  apptusPaymentNotificationEndpoint,
} = config;
jest.mock('axios');
describe('NotificationsDao testing Suit', () => {
  let notificationsDao: NotificationsDao;
  let market: MarketInfo;
  let orderMapper: OrderMapper;
  let order: Order;
  let apptusClusterId: string;
  let apptusEsalesMarket: string;
  let apptusApiKey: string;
  let params;
  let lineItems;
  beforeEach(() => {
    market = stubMarket();
    apptusClusterId = faker.datatype.uuid();
    apptusApiKey = faker.datatype.uuid();
    apptusEsalesMarket = 'AVONSHOP_';
    orderMapper = {
      checkChannelGraphql: jest.fn(),
    } as any;
    notificationsDao = new NotificationsDao({
      apptusPaymentNotificationEndpoint,
      apptusClusterId,
      apptusApiKey,
      apptusEsalesMarket,
      orderMapper,
    });
    params = {
      sessionKey: faker.datatype.uuid(),
      customerKey: faker.datatype.uuid(),
    };
    lineItems = [stubGraphQLLineItem()];
    order = stubOrder({ lineItems });
  });
  describe('paymentNotifications()', () => {
    const mockResponse = {
      data: true,
    };
    test('returns apptus response body', async () => {
      /* Prepare */
      (orderMapper.checkChannelGraphql as unknown as Mock).mockResolvedValueOnce({
        sellPrice: 123,
        listPrice: 125,
      });
      (axios.post as unknown as Mock).mockResolvedValueOnce(mockResponse);
      /* Execute */
      const result = await notificationsDao.paymentNotifications(market, params, order);
      /* Verify */
      expect(result).toBeTruthy();
      expect(axios.post).toHaveBeenCalledTimes(1);
    });
  });
});
