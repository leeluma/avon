import { graphql } from '../../src/graphql';

export const stubGraphql = (
  config: Partial<typeof graphql> = {},
): typeof graphql => {
  return {
    getCustomerByToken: Promise.resolve('query () { customer {} }'),
    getCustomerCart: Promise.resolve('query () { cart {} }'),
    getCustomerById: Promise.resolve('query () { customer {} }'),
    getOrder: Promise.resolve('query () { order {} }'),
    getShippingMethods: Promise.resolve('query () { shippingMethods {} }'),
    getCartPaymentInfo: Promise.resolve('query () { paymentInfo {} }'),
    getOrderByOrderNumber: Promise.resolve('query () { orders {} }'),
    getProducts: Promise.resolve('query () { products {} }'),
    ...config,
  };
};
