import { Address, AddressDraft } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import {
  AutocompleteResponseDto, NormalizedAddress, GraphQLAddress,
  DetailResponseDto, PickupPointResponseDto, PickupPointRequestDto,
} from '../../src/dtos';

export const stubAddressDto = (
  config: Partial<Address> = {},
): Address => {
  return {
    id: faker.datatype.uuid(),
    custom: {
      type: {
        id: 'address-type',
        typeId: 'type',
      },
      fields: {
        Address1: faker.address.streetAddress(),
        Address2: faker.address.streetAddress(),
        Address3: faker.address.secondaryAddress(),
        Address4: faker.address.secondaryAddress(),
        Latitude: +faker.address.latitude(),
        Longitude: +faker.address.longitude(),
      },
    },
    city: faker.address.city(),
    region: faker.address.county(),
    country: faker.address.country(),
    state: faker.address.state(),
    phone: faker.phone.phoneNumber(),
    postalCode: faker.address.zipCode(),
    ...config,
  };
};

export const stubAddressDraftDto = (
  config: Partial<AddressDraft> = {},
): AddressDraft => {
  return {
    id: faker.datatype.uuid(),
    custom: {
      type: {
        id: 'address-type',
        typeId: 'type',
      },
      fields: {
        Address1: faker.address.streetAddress(),
        Address2: faker.address.streetAddress(),
        Address3: faker.address.secondaryAddress(),
        Address4: faker.address.secondaryAddress(),
        Latitude: +faker.address.latitude(),
        Longitude: +faker.address.longitude(),
      },
    },
    city: faker.address.city(),
    region: faker.address.county(),
    country: faker.address.country(),
    state: faker.address.state(),
    phone: faker.phone.phoneNumber(),
    postalCode: faker.address.zipCode(),
    ...config,
  };
};

export const stubNormalizedAddress = (
  config: Partial<NormalizedAddress> = {},
): NormalizedAddress => {
  return {
    id: faker.datatype.string(),
    normalizedAddress: faker.datatype.string(),
    exactMatch: faker.datatype.boolean(),
    ...config,
  };
};

export const stubAutocompleteResponseDto = (
  config: Partial<AutocompleteResponseDto> = {},
): AutocompleteResponseDto => {
  return {
    suggestions: [stubNormalizedAddress()],
    ...config,
  };
};

export const stubGraphQLAddressDto = (
  config: Partial<GraphQLAddress> = {},
): GraphQLAddress => {
  return {
    id: faker.datatype.uuid(),
    custom: {
      type: {
        id: 'address-type',
        typeId: 'type',
      },
      customFieldsRaw: [
        {
          name: 'Address1',
          value: faker.address.streetAddress(),
        }, {
          name: 'Address2',
          value: faker.address.streetAddress(),
        }, {
          name: 'Address3',
          value: faker.address.secondaryAddress(),
        }, {
          name: 'Address4',
          value: faker.address.secondaryAddress(),
        }, {
          name: 'Latitude',
          value: +faker.address.latitude(),
        }, {
          name: 'Longitude',
          value: +faker.address.longitude(),
        },
      ],
    },
    city: faker.address.city(),
    region: faker.address.county(),
    country: faker.address.country(),
    state: faker.address.state(),
    phone: faker.phone.phoneNumber(),
    postalCode: faker.address.zipCode(),
    ...config,
  };
};

export const stubDetailResponseDto = (
  config: Partial<DetailResponseDto> = {},
): DetailResponseDto => {
  return {
    country: faker.datatype.string(),
    region1: faker.datatype.string(),
    region2: null,
    city: faker.datatype.string(),
    district1: faker.datatype.string(),
    district2: null,
    zipCode: faker.datatype.string(),
    streetName: faker.datatype.string(),
    houseNumber: faker.datatype.string(),
    floor: null,
    flat: null,
    latitude: faker.datatype.number(),
    longitude: faker.datatype.number(),
    ...config,
  };
};

export const stubPickupPointResponseDto = (
  config: Partial<PickupPointResponseDto> = {},
): PickupPointResponseDto => {
  return {
    id: faker.datatype.number(),
    type: faker.datatype.string(),
    name: faker.datatype.string(),
    address1: faker.address.streetAddress(),
    address2: faker.address.streetAddress(),
    address3: faker.address.streetAddress(),
    address4: faker.address.streetAddress(),
    city: faker.address.city(),
    province: faker.datatype.string(),
    zipcode: faker.address.zipCode(),
    openingHours: faker.datatype.string(),
    email: faker.internet.email(),
    latitude: +faker.address.latitude(),
    longitude: +faker.address.longitude(),
    phone: faker.phone.phoneNumber(),
    url: faker.internet.url(),
    cashOnDelivery: faker.datatype.boolean(),
    distributionCentreCode: faker.datatype.string(),
    country: faker.address.country(),
    ...config,
  };
};

export const stubPickupPointRequestDto = (
  config: Partial<PickupPointRequestDto> = {},
): PickupPointRequestDto => {
  return {
    latitude: +faker.address.latitude(),
    longitude: +faker.address.longitude(),
    distance: faker.datatype.boolean() ? faker.datatype.number() : undefined,
    distanceUnit: faker.datatype.boolean() ? faker.datatype.string() : undefined,
    ...config,
  };
};
