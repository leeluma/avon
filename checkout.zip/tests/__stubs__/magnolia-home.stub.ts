import faker from '@faker-js/faker';

export const stubMagnoliaHome = (
  config: Partial<any> = {},
): any => {
  const product = {
    definitionName: faker.datatype.string(),
    connectionName: faker.datatype.string(),
    categoryId: faker.datatype.uuid(),
    productId: faker.datatype.uuid(),
  };

  return {
    '@name': faker.datatype.string(),
    '@path': faker.datatype.string(),
    '@id': faker.datatype.uuid(),
    '@nodeType': faker.datatype.string(),
    'mgnl:template': faker.datatype.string(),
    'mgnl:created': faker.datatype.string(),
    title: faker.datatype.string(),
    main: {
      '01': {
        '@name': faker.datatype.string(),
        '@path': faker.datatype.string(),
        '@id': faker.datatype.uuid(),
        ProductCarousel: {
          '@name': faker.datatype.string(),
          '@path': faker.datatype.string(),
          '@id': faker.datatype.uuid(),
          ProductCarousel0: {
            '@name': faker.datatype.string(),
            '@path': faker.datatype.string(),
            '@id': faker.datatype.uuid(),
            product: JSON.stringify(product),
          },
          '@nodes': [
            'ProductCarousel0',
          ],
        },
        '@nodes': [
          'ProductCarousel',
        ],
      },
      '@nodes': [
        '01',
      ],
    },
    ...config,
  };
};
export const stubMagnoliaOrderConfirmation = (
  config: Partial<any> = {},
): any => {
  return {
    '@name': 'order-confirmation',
    '@path': '/ro/order-confirmation',
    '@id': 'cb53bf87-3ade-4bf4-ba77-3a3a632e5ba8',
    '@nodeType': 'mgnl:page',
    'mgnl:template': 'spa-lm:pages/order-confirmation',
    'mgnl:created': '2022-05-12T10:58:45.702Z',
    title: 'Order Confirmation',
    'mgnl:lastModified': '2022-07-06T10:00:13.295Z',
    orderConfirmationTexts: {
      '@name': 'orderConfirmationTexts',
      '@path': '/ro/order-confirmation/orderConfirmationTexts',
      '@id': '780b37e7-1b1c-4961-8d80-9e5cd9d100fe',
      '@nodeType': 'mgnl:contentNode',
      cardText: 'Card',
      chargeOnCashOnDeliveryText: '{amount} must be paid upon receipt of the order',
      deliveryCostsText: 'Delivery costs',
      deliveryAddressText: 'Delivery address',
      chargeOnCardText: '{amount} has been charged to your card',
      purchaseThankYouText: 'Thank you for your purchase!',
      standardDeliveryDaysText: 'Up to 5 working days ',
      deliveryText: 'Delivery',
      cashPaymentText: 'Cash on delivery',
      'mgnl:created': '2022-05-12T10:58:45.704Z',
      cashOnDeliveryText: 'Cash on delivery',
      orderFasterSubTitle: 'Create a password and save your details, to speed up your checkout process.',
      paymentMethodTitle: 'Payment method',
      notifyMessageText: 'We will notify you when it’s been sent',
      confirmationText: 'Confirmation',
      quantityText: 'Quantity',
      incVatText: 'inc VAT',
      deliveryDaysText: 'Up to {days} working days ',
      continueShoppingUrl: '/',
      expressDeliveryDaysText: 'Next Day Delivery: Order Before 5pm',
      continueShoppingText: 'Continue shopping',
      standardDeliveryText: 'Standard delivery',
      totalText: 'Total ',
      savingsAndCodesText: 'Savings & Codes',
      confirmationMessageText: 'A confirmation has been sent to your email: {email}',
      orderNoText: 'Order no.',
      offerText: 'Offer',
      'mgnl:lastModified': '2022-07-06T10:00:13.295Z',
      orderFasterTitle: 'Order faster next time!',
      subtotalText: 'Subtotal',
      accountCreated: 'Done. Your account has been successfully created',
      orderSummaryTitle: 'Order summary',
      '@nodes': [],
    },
    main: {
      '@name': 'main',
      '@path': '/ro/order-confirmation/main',
      '@id': 'e9b32685-07fd-49f0-8483-d946edc79f16',
      '@nodeType': 'mgnl:area',
      'mgnl:lastModified': '2022-05-13T06:05:49.813Z',
      'mgnl:created': '2022-05-13T06:05:49.813Z',
      '@nodes': [],
    },
    bottomArea: {
      '@name': 'bottomArea',
      '@path': '/ro/order-confirmation/bottomArea',
      '@id': '936a99b1-24d2-4c99-a925-c6c3e09663ec',
      '@nodeType': 'mgnl:area',
      'mgnl:lastModified': '2022-05-13T06:05:49.813Z',
      'mgnl:created': '2022-05-13T06:05:49.813Z',
      '@nodes': [],
    },
    '@nodes': [
      'orderConfirmationTexts',
      'main',
      'bottomArea',
    ],
    ...config,
  };
};
