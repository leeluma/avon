import faker from '@faker-js/faker';
import {
  stubGraphQLLineItem,
  stubTrackingFields,
  stubCartLineItem,
} from '.';
import { CartResponse } from '../../src/dtos';
import { GraphQLOrder } from '../../src/dtos/order.dto';

export const AddressStub = (): any => {
  return {
    id: faker.datatype.uuid(),
    firstName: faker.datatype.string(),
    lastName: faker.datatype.string(),
    streetName: faker.datatype.string(),
    streetNumber: faker.datatype.number(),
    additionalStreetInfo: faker.datatype.string(),
    city: faker.datatype.string(),
    region: faker.datatype.string(),
    state: faker.datatype.string(),
    postalCode: faker.datatype.string(),
    country: faker.datatype.string(),
    company: faker.datatype.string(),
    department: faker.datatype.string(),
    building: faker.datatype.string(),
    apartment: faker.datatype.string(),
    pOBox: faker.datatype.string(),
    additionalAddressInfo: faker.datatype.string(),
    phone: faker.datatype.string(),
    mobile: faker.datatype.string(),
    email: faker.datatype.string(),
    custom: {
      type: {
        id: faker.datatype.uuid(),
        name: faker.datatype.string(),
      },
      customFieldsRaw: [
        {
          name: faker.datatype.string(),
          value: faker.datatype.string(),
        },
        {
          name: faker.datatype.string(),
          value: faker.datatype.string(),
        },
        {
          name: faker.datatype.string(),
          value: faker.datatype.string(),
        },
        {
          name: 'recipientName',
          value: faker.datatype.string(),
        },
      ],
    },
  };
};

export const stubGraphQLOrder = (
  config: Partial<GraphQLOrder> = {},
): any => {
  return {
    customerEmail: faker.internet.email(),
    customerId: faker.datatype.uuid(),
    anonymousId: faker.datatype.uuid(),
    lineItems: [stubGraphQLLineItem()],
    shippingAddress: AddressStub(),
    billingAddress: AddressStub(),
    paymentInfo: {
      payments: [
        {
          paymentStatus: {
            state: {
              name: 'Success',
            },
          },
          key: faker.datatype.string(),
          paymentMethodInfo: {
            method: 'online',
            name: faker.datatype.string(),
          },
          amountPlanned: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.number(),
            fractionDigits: 2,
          },
        },
      ],
    },
    paymentState: faker.datatype.string(),
    shippingInfo: {
      shippingMethodName: faker.datatype.string(),
      deliveries: [],
      price: {
        currencyCode: faker.datatype.string(),
        centAmount: faker.datatype.number(),
        fractionDigits: 2,
      },
      discountedPrice: null,
    },
    totalPrice: {
      type: faker.datatype.string(),
      currencyCode: faker.datatype.string(),
      centAmount: faker.datatype.number(),
      fractionDigits: 2,
    },
    discountCodes: [
      {
        state: 'MatchesCart',
        discountCode: {
          id: faker.datatype.uuid(),
          code: faker.datatype.string(),
          cartDiscountRefs: [
            {
              id: '7aa45012-690a-4ec7-9c75-66f5e194f44c',
            },
          ],
        },
      },
    ],
    orderState: faker.datatype.string(),
    shipmentState: faker.datatype.string(),
    custom: {
      type: {
        name: faker.datatype.string(),
      },
      customFieldsRaw: [
        {
          name: faker.datatype.string(),
          value: faker.datatype.string(),
        },
      ],
    },
    ...config,
  };
};

/* export const stubOrderResponse = (
  config: Partial<CartResponse> = {},
): CartResponse => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    lineItems: [stubCartLineItem()],
    totalRetailPriceAmount: faker.commerce.price(),
    totalInvoiceAmount: faker.datatype.number(),
    formattedTotalPrice: faker.commerce.price(),
    currencyCode: 'RON',
    ...stubTrackingFields(),
    ...config,
  };
}; */
