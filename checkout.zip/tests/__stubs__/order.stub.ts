import faker from '@faker-js/faker';
import { Order } from '@commercetools/platform-sdk';
import {
  stubCentPrecisionMoney, stubTrackingFields,
} from '.';

export const stubOrder = (
  config: Partial<Order> = {},
): Order => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    totalPrice: stubCentPrecisionMoney(),
    orderState: faker.random.arrayElement(['Open', 'Confirmed', 'Complete', 'Cancelled']),
    origin: faker.random.arrayElement(['Customer', 'Merchant']),
    lineItems: [],
    customLineItems: [],
    lastMessageSequenceNumber: 1,
    syncInfo: [],
    refusedGifts: [],
    ...stubTrackingFields(),
    ...config,
  };
};
