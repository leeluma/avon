import faker from '@faker-js/faker';
import {
  stubGraphQLLineItem,
  stubTrackingFields,
  stubCartLineItem,
} from '.';
import { CartResponse, GraphQLCart } from '../../src/dtos';

export const stubGraphQLCart = (
  config: Partial<GraphQLCart> = {},
): any => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    lineItems: [stubGraphQLLineItem()],
    totalPrice: {
      type: 'centPrecision',
      currencyCode: 'RON',
      centAmount: faker.datatype.number(),
      fractionDigits: 2,
    },
    discountCodes: [
      {
        state: 'MatchesCart',
        discountCode: {
          id: faker.datatype.uuid(),
          code: faker.datatype.string(),
          cartDiscountRefs: [
            {
              id: '7aa45012-690a-4ec7-9c75-66f5e194f44c',
            },
          ],
        },
      },
    ],
    shippingInfo: {
      price: {
        type: 'centPrecision',
        currencyCode: 'RON',
        centAmount: faker.datatype.number(),
        fractionDigits: 2,
      },
    },
    shippingAddress: {
      id: faker.datatype.uuid(),
      city: faker.address.city(),
      state: faker.address.state(),
      country: 'RO',
      phone: null,
      custom: {
        type: {
          key: 'address-type',
        },
        customFieldsRaw: [
          {
            name: 'Address2',
            value: faker.address.streetAddress(),
          },
          {
            name: 'Latitude',
            value: faker.address.latitude(),
          },
          {
            name: 'Longitude',
            value: faker.address.longitude(),
          },
          {
            name: 'RecipientName',
            value: faker.datatype.string(),
          },
          {
            name: 'Address3',
            value: faker.address.streetAddress(),
          },
          {
            name: 'Address1',
            value: faker.address.streetAddress(),
          },
        ],
      },
    },
    ...config,
  };
};

export const stubCartResponse = (
  config: Partial<CartResponse> = {},
): CartResponse => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    lineItems: [stubCartLineItem()],
    totalRetailPriceAmount: faker.commerce.price(),
    totalInvoiceAmount: faker.datatype.number(),
    formattedTotalPrice: faker.commerce.price(),
    currencyCode: 'RON',
    shippingAddress: {
      address1: faker.address.streetAddress(),
      address2: faker.address.streetAddress(),
      address3: faker.address.streetAddress(),
      address4: faker.address.streetAddress(),
      country: faker.address.streetAddress(),
    },
    ...stubTrackingFields(),
    ...config,
  };
};
