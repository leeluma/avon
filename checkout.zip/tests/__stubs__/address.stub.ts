import { Address } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';

export const stubAddress = (
  config: Partial<Address> = {},
): Address => {
  return {
    country: faker.address.country(),
    ...config,
  };
};
