import faker from '@faker-js/faker';
import { CartLineItem, GraphQLLineItem } from '../../src/dtos';

export const stubGraphQLLineItem = (
  config: any = {},
): GraphQLLineItem => {
  return {
    id: faker.datatype.uuid(),
    productId: faker.datatype.uuid(),
    productSlug: `p/${faker.datatype.uuid()}`,
    name: faker.name.firstName(),
    quantity: faker.datatype.number(),
    totalPrice: {
      type: 'centPrecision',
      currencyCode: 'RON',
      centAmount: faker.datatype.number(),
      fractionDigits: 2,
    },
    variant: {
      id: faker.datatype.number(),
      sku: faker.datatype.uuid(),
      images: [],
      attributesRaw: [{ name: 'maxPurchasableQty', value: 1 },
        { name: 'discontinued', value: true }],
      prices: [
        {
          value: {
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.number(),
            fractionDigits: 2,
          },
          id: faker.datatype.uuid(),
          channel: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
          discounted: {
            value: {
              currencyCode: faker.datatype.string(),
              centAmount: faker.datatype.string(),
              fractionDigits: 2,
            },
            discount: {
              typeId: faker.datatype.string(),
              id: faker.datatype.uuid(),
            },
          },
        },
      ],
    },
    discountedPricePerQuantity: [
      {
        quantity: 1,
        discountedPrice: {
          includedDiscounts: [
            {
              discount: {
                id: '7aa45012-690a-4ec7-9c75-66f5e194f44c', // faker.datatype.uuid(),
              },
              discountedAmount: {
                currencyCode: 'RON',
                centAmount: 237,
                fractionDigits: 2,
              },
            },
          ],
        },
      },
    ],
    ...config,
  };
};

export const stubCartLineItem = (
  config: Partial<CartLineItem> = {},
): CartLineItem => {
  return {
    lineItemId: faker.datatype.uuid(),
    productId: faker.datatype.uuid(),
    productSlug: faker.datatype.uuid(),
    name: faker.name.firstName(),
    skuCode: faker.datatype.uuid(),
    images: [],
    listPrice: faker.datatype.number(),
    sellPrice: faker.datatype.number(),
    formattedListPrice: faker.datatype.string(),
    formattedSellPrice: faker.datatype.string(),
    unitPrice: faker.datatype.string(),
    quantity: faker.datatype.number(),
    totalPrice: faker.datatype.number(),
    currencyCode: 'RON',
    hexCode: faker.datatype.string(),
    variantType: faker.datatype.string(),
    variantValue: faker.datatype.string(),
    ...config,
  };
};
