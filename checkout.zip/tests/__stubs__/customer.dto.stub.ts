import { Customer, CustomerDraft } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import { stubAddressDto } from '.';
import {
  CustomerLoginResponseDto, LoginDto, UpdateCartRequestDto,
  GraphQLCustomerResponse, CustomerResponseDto, CustomerRegistrationRequestDto,
} from '../../src/dtos';

export const stubCustomerLoginRequestDto = (
  config: Partial<LoginDto> = {},
): LoginDto => {
  return {
    email: faker.internet.email(),
    password: faker.internet.password(),
    cartId: faker.datatype.uuid(),
    ...config,
  };
};
export const stubCustomerRegisterRequestDto = (
  config: Partial<CustomerRegistrationRequestDto> = {},
): CustomerRegistrationRequestDto => {
  return {
    password: faker.internet.password(),
    confirmPassword: faker.internet.password(),
    orderId: faker.datatype.uuid(),
    ...config,
  };
};

export const stubUpdateCartRequestDto = (
  config: Partial<UpdateCartRequestDto> = {},
): UpdateCartRequestDto => {
  return {
    email: faker.internet.email(),
    firstName: 'Jhon',
    lastName: 'Doe',
    cartId: faker.datatype.uuid(),
    ...config,
  };
};

export const stubCustomerLoginResponseDto = (
  config: Partial<CustomerLoginResponseDto> = {},
): CustomerLoginResponseDto => {
  return {
    accessToken: faker.datatype.string(),
    expiresIn: faker.datatype.number(),
    tokenType: faker.datatype.uuid(),
    refreshToken: faker.datatype.uuid(),
    customerId: faker.datatype.uuid(),
    cartId: faker.datatype.uuid(),
    scope: `'manage_project:avonshop-ct-ro-dev customer_id:${faker.datatype.uuid()}'`,
    ...config,
  };
};

export const stubCtCustomerClient = (
  expectedCountry: string,
  requestBuilderConfig: any = {},
): any => {
  return {
    getClient: (country) => {
      expect(country).toEqual(expectedCountry);
      return {
        ...requestBuilderConfig,
      };
    },
    getAuthClient: (country) => {
      expect(country).toEqual(expectedCountry);
      return {
        ...requestBuilderConfig,
      };
    },
  } as any;
};

export const stubCustomerDto = (
  config: Partial<Customer> = {},
): Customer => {
  const defaultAddressId : string = faker.datatype.uuid();
  return <Customer>{
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    email: faker.internet.email(),
    password: faker.internet.password(),
    addresses: [
      {
        id: defaultAddressId,
        customerId: faker.datatype.uuid(),
        address1: faker.address.streetAddress(),
        address2: faker.address.streetAddress(),
        city: faker.address.city(),
        region: faker.address.streetName(),
        zip: faker.address.zipCode(),
        county: faker.address.county(),
        country: faker.address.country(),
        latitude: parseInt(faker.address.latitude(), 10),
        longitude: parseInt(faker.address.longitude(), 10),
        address3: faker.address.streetAddress(),
        address4: faker.address.streetAddress(),
        state: faker.address.state(),
        phoneNumber: faker.address.state(),
        isBillingAddress: faker.datatype.boolean(),
        isShippingAddress: faker.datatype.boolean(),
      },
    ],
    shippingAddressIds: [defaultAddressId],
    defaultShippingAddressId: defaultAddressId,
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName(),
    customerId: faker.datatype.string(),
    isEmailVerified: faker.datatype.boolean(),
    billingAddressIds: [],
    ...config,
  };
};

export const stubCustomerWithoutAddressDto = (
  config: Partial<Customer> = {},
): Customer => {
  const defaultAddressId : string = faker.datatype.uuid();
  return <Customer>{
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    email: faker.internet.email(),
    password: faker.internet.password(),
    addresses: [],
    shippingAddressIds: [defaultAddressId],
    defaultShippingAddressId: defaultAddressId,
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName(),
    customerId: faker.datatype.string(),
    isEmailVerified: faker.datatype.boolean(),
    billingAddressIds: [],
    ...config,
  };
};

export const stubGraphQLCustomerDto = (
  config: Partial<GraphQLCustomerResponse> = {},
): GraphQLCustomerResponse => {
  return <GraphQLCustomerResponse>{
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    isEmailVerified: faker.datatype.boolean(),
    email: faker.internet.email(),
    password: faker.internet.password(),
    customerId: faker.datatype.string(),
    addresses: [],
    billingAddressIds: [],
    shippingAddressIds: [],
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName(),
    ...config,
  };
};

export const stubCustomerResponseDto = (
  config: Partial<CustomerResponseDto> = {},
): CustomerResponseDto => {
  return {
    id: faker.datatype.uuid(),
    email: faker.internet.email(),
    firstName: faker.datatype.string(),
    lastName: faker.datatype.string(),
    optIn: faker.datatype.boolean(),
    ...config,
  };
};

export const stubCustomerRequestDto = (
  config: Partial<CustomerRegistrationRequestDto> = {},
): CustomerRegistrationRequestDto => {
  return {
    password: faker.internet.password(),
    confirmPassword: faker.internet.password(),
    orderId: faker.datatype.uuid(),
    ...config,
  };
};

export const stubCustomerDraftDto = (
  config: Partial<CustomerDraft> = {},
): CustomerDraft => {
  return {
    isEmailVerified: faker.datatype.boolean(),
    email: faker.internet.email(),
    password: faker.internet.password(),
    addresses: [stubAddressDto(), stubAddressDto()],
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName(),
    ...config,
  };
};
