import faker from '@faker-js/faker';
import { stubAddress, stubCentPrecisionMoney, OrderAddressDto } from '.';
import { ShippingInfo, ShippingMethodServiceDto } from '../../src/dtos';
import { OrderDto } from '../../src/dtos/order.dto';

export const stubOrderDto = (
  config: Partial<OrderDto> = {},
): OrderDto => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    totalRetailPriceAmount: faker.commerce.price(),
    totalInvoiceAmount: faker.datatype.number(),
    formattedTotalPrice: faker.datatype.string(),
    formattedTotalInvoiceAmount: faker.datatype.string(),
    currencyCode: faker.datatype.string(),
    customerId: faker.datatype.string(),
    anonymousId: faker.datatype.string(),
    orderState: faker.datatype.string(),
    lineItems: [{
      lineItemId: faker.datatype.string(),
      variantKey: faker.datatype.string(),
      productId: faker.datatype.string(),
      productKey: faker.datatype.string(),
      name: faker.datatype.string(),
      skuCode: faker.datatype.uuid(),
      images: [{
        url: faker.datatype.string(),
        label: faker.datatype.string(),
        dimensions: {
          w: faker.datatype.number(),
          h: faker.datatype.number(),
        },
      }],
      listPrice: faker.datatype.number(),
      sellPrice: faker.datatype.number(),
      formattedListPrice: faker.datatype.string(),
      formattedSellPrice: faker.datatype.string(),
      unitPrice: faker.datatype.string(),
      quantity: faker.datatype.number(),
      modifiedTimeStamp: faker.datatype.string(),
      variantType: faker.datatype.string(),
      variantValue: faker.datatype.string(),
      hexCode: faker.datatype.string(),
    }],
    totalPrice: stubCentPrecisionMoney(),
    promotion: {
      promotionId: faker.datatype.string(),
      promotionCode: faker.datatype.string(),
      promotionAmount: 10,
      promotionState: 'MatchesCart',
      promotionApplied: true,
      formattedPromotionAmount: '10 RON',
    },
    shippingInfo: {
      shippingMethodName: faker.datatype.string(),
      shippingMethodPrice: faker.finance.amount(),
      shippingPrice: faker.datatype.number(),
    },
    billingAddress: stubAddress(),
    shippingAddress: OrderAddressDto(),
    paymentInfo: {
      paymentStatus: faker.datatype.string(),
      paymentType: faker.datatype.string(),
      paymentAmount: faker.datatype.string(),
    },
    ...config,
  };
};
