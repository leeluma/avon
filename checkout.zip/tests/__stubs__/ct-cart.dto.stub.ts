import faker from '@faker-js/faker';
import { stubTrackingFields } from './trackingfields.stub';
import {
  AddressRequest,
  CTCartDraftDto, CTLineItemDto,
} from '../../src/dtos';
import { AddressResponseDto } from '../../src/dtos/order.dto';

export const stubCtCartDraftDto = (
  config: Partial<CTCartDraftDto> = {},
): CTCartDraftDto => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    totalPrice: faker.commerce.price(),
    customerId: faker.datatype.number(),
    lineItems: [],
    discountCodes: [],
    shippingAddress: {},
    shippingInfo: {},
    ...stubTrackingFields(),
    ...config,
  };
};

export const stubCtCartLineItemDraftDto = (
  config: Partial<CTLineItemDto> = {},
): CTLineItemDto => {
  return {
    id: faker.datatype.string(),
    productId: faker.datatype.string(),
    name: { ro: faker.datatype.string() },
    variant: [],
    quantity: faker.datatype.number(),
    lastModifiedAt: faker.datatype.string(),
    ...config,
  };
};

export const setShippingAddressDto = (): AddressRequest => {
  return {
    address1: faker.datatype.string(),
    address2: faker.datatype.string(),
    postalCode: faker.datatype.string(),
    city: faker.datatype.string(),
    county: faker.datatype.string(),
    phoneNumber: faker.datatype.string(),
  };
};

export const shippingAddressCtRes = () => {
  return {
    postalCode: faker.datatype.string(),
    city: faker.datatype.string(),
    phone: faker.datatype.string(),
    county: faker.datatype.string(),
    custom: {
      fields: {
        Address1: faker.datatype.string(),
        Address2: faker.datatype.string(),
        county: faker.datatype.string(),
      },
    },
  };
};

export const OrderAddressDto = (): AddressResponseDto => {
  return {
    name: faker.datatype.string(),
    address: faker.datatype.string(),
    region: faker.datatype.string(),
    zip: faker.datatype.string(),
    city: faker.datatype.string(),
    state: faker.datatype.string(),
    country: faker.datatype.string(),
    phoneNumber: faker.datatype.string(),
  };
};
