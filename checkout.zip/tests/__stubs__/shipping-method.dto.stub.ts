import faker from '@faker-js/faker';
import { ShippingMethodsResponseDto, ShippingMethodServiceDto } from '../../src/dtos';

export const stubShippingMethodDto = (
  config: Partial<ShippingMethodServiceDto> = {},
): ShippingMethodServiceDto => {
  return {
    id: faker.datatype.uuid(),
    name: faker.datatype.string(),
    localizedDescription: faker.datatype.string(),
    isDefault: true,
    zoneRates: [
      {
        shippingRates: [
          {
            price: {
              centAmount: 5000,
              currencyCode: 'RON',
              fractionDigits: 2,
            },
            freeAbove: {
              centAmount: 20000,
              currencyCode: 'RON',
              fractionDigits: 2,
            },
          },
        ],
      },
    ],
  };
};

export const stubShippingMethodsForCartResponseDto = (
  config: Partial<ShippingMethodsResponseDto> = {},
): ShippingMethodsResponseDto[] => {
  return [{
    id: faker.datatype.uuid(),
    name: faker.datatype.string(),
    formattedDeliveryCharge: faker.datatype.string(),
    formattedFreeAbove: faker.datatype.string(),
    deliveryCharge: faker.datatype.number(),
    freeAbove: faker.datatype.number(),
    ...config,
  }];
};
