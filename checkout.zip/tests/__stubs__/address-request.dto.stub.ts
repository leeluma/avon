import faker from '@faker-js/faker';
import { AddressRequestDto } from '../../src/dtos';

export const stubAddressRequestDto = (
  config: Partial<AddressRequestDto> = {},
): AddressRequestDto => {
  const firstName = faker.name.firstName();
  const lastName = faker.name.lastName();
  const recipientName = `${firstName} ${lastName}`;
  return {
    firstName,
    lastName,
    recipientName,
    // addressId: faker.datatype.uuid(),
    address1: faker.address.streetAddress(),
    address2: faker.address.streetAddress(),
    city: faker.address.city(),
    region: faker.address.streetName(),
    zip: '077191',
    county: faker.address.county(),
    country: faker.address.country(),
    latitude: parseInt(faker.address.latitude(), 10),
    longitude: parseInt(faker.address.longitude(), 10),
    address3: faker.address.streetAddress(),
    address4: faker.address.streetAddress(),
    state: faker.address.state(),
    phoneNumber: '0723628562',
    isShippingAddress: true,
    isBillingAddress: faker.datatype.boolean(),
    updateCustomer: true,
    ...config,
  };
};
