import faker from '@faker-js/faker';
import { stubCentPrecisionMoney } from '.';
import { CartDto, ShippingInfo, ShippingMethodServiceDto } from '../../src/dtos';
import { stubAddressResponseDto } from './address-response.dto.stub';

export const stubCtCartDto = (
  config: Partial<CartDto> = {},
): CartDto => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    totalRetailPriceAmount: faker.commerce.price(),
    totalInvoiceAmount: faker.datatype.number(),
    currencyCode: faker.datatype.string(),
    customerId: faker.datatype.string(),
    anonymousId: faker.datatype.string(),
    lineItems: [{
      lineItemId: faker.datatype.string(),
      productId: faker.datatype.string(),
      productKey: faker.datatype.string(),
      name: faker.datatype.string(),
      skuCode: faker.datatype.uuid(),
      images: [{
        url: faker.datatype.string(),
        label: faker.datatype.string(),
        width: faker.datatype.number(),
        height: faker.datatype.number(),
      }],
      listPrice: faker.datatype.number(),
      sellPrice: faker.datatype.number(),
      formattedListPrice: faker.datatype.string(),
      formattedSellPrice: faker.datatype.string(),
      vatMessage: faker.datatype.string(),
      unitPrice: faker.datatype.string(),
      quantity: faker.datatype.number(),
      modifiedTimeStamp: faker.datatype.string(),
      sequenceNumber: faker.datatype.number(),
      maxPurchasableQty: faker.datatype.number(),
      availableQuantity: faker.datatype.number(),
      variantType: faker.datatype.string(),
      variantValue: faker.datatype.string(),
      hexCode: faker.datatype.string(),
      offers: [
        {
          key: faker.datatype.string(),
          displayName: faker.datatype.string(),
          url: faker.datatype.string(),
          description: faker.datatype.string(),
        },
      ],
    }],
    totalPrice: stubCentPrecisionMoney(),
    promotion: {
      promotionId: faker.datatype.string(),
      promotionCode: faker.datatype.string(),
      promotionAmount: 10,
      promotionState: 'MatchesCart',
      promotionApplied: true,
      formattedPromotionAmount: '10 RON',
    },
    shippingAddress: stubAddressResponseDto(),
    shippingInfo: {
      shippingMethodName: faker.datatype.string(),
      shippingMethodPrice: faker.finance.amount(),
    },
    billingAddress: stubAddressResponseDto(),
    ...config,
  };
};

export const stubCartServiceToMapper8 = (): any => {
  return {
    type: 'Cart',
    id: '5f31c3cb-0bf3-455d-8f34-065f1ebe5ccb',
    version: 3,
    lastMessageSequenceNumber: 1,
    createdAt: '2022-01-24T19:44:41.500Z',
    lastModifiedAt: '2022-01-24T19:45:19.072Z',
    lastModifiedBy: {
      clientId: 'JmO2yShXYnCr0R59WmdX8A8x',
      isPlatformClient: false,
    },
    createdBy: {
      clientId: 'JmO2yShXYnCr0R59WmdX8A8x',
      isPlatformClient: false,
    },
    anonymousId: '8f930777-1ede-4da0-ac8c-9decf8bf5209',
    lineItems: [],
    cartState: 'Active',
    totalPrice: {
      type: 'centPrecision',
      currencyCode: 'RON',
      centAmount: 0,
      fractionDigits: 2,
    },
    customLineItems: [],
    discountCodes: [],
    inventoryMode: 'None',
    taxMode: 'Disabled',
    taxRoundingMode: 'HalfEven',
    taxCalculationMode: 'LineItemLevel',
    refusedGifts: [],
    origin: 'Customer',
    itemShippingAddresses: [],
  };
};
export const stubCartServiceToMapper9 = (): any => {
  return {
    type: 'Cart',
    id: '5f31c3cb-0bf3-455d-8f34-065f1ebe5ccb',
    version: 5,
    lastMessageSequenceNumber: 1,
    createdAt: '2022-01-24T19:44:41.500Z',
    lastModifiedAt: '2022-01-24T19:51:49.919Z',
    lastModifiedBy: {
      clientId: 'JmO2yShXYnCr0R59WmdX8A8x',
      isPlatformClient: false,
    },
    createdBy: {
      clientId: 'JmO2yShXYnCr0R59WmdX8A8x',
      isPlatformClient: false,
    },
    anonymousId: '8f930777-1ede-4da0-ac8c-9decf8bf5209',
    lineItems: [],
    cartState: 'Active',
    totalPrice: {
      type: 'centPrecision',
      currencyCode: 'RON',
      centAmount: 0,
      fractionDigits: 2,
    },
    customLineItems: [],
    discountCodes: [
      {
        discountCode: {
          typeId: 'discount-code',
          id: '5d06c34c-5f40-4897-abdb-99cc9adc97ff',
          obj: {
            id: '5d06c34c-5f40-4897-abdb-99cc9adc97ff',
            version: 5,
            createdAt: '2022-01-24T11:08:08.160Z',
            lastModifiedAt: '2022-01-24T11:30:17.962Z',
            lastModifiedBy: {
              isPlatformClient: true,
              user: {
                typeId: 'user',
                id: 'c0bbd43f-0262-4ac6-8c84-9953491f564b',
              },
            },
            createdBy: {
              isPlatformClient: true,
              user: {
                typeId: 'user',
                id: 'c0bbd43f-0262-4ac6-8c84-9953491f564b',
              },
            },
            code: 'AVON10%',
            name: {
              ro: 'AVONTESTDISCOUNT',
            },
            description: {
              ro: 'This is a 10 Percent relative discount which is applied on cart if total is greater than 40 RON',
            },
            cartDiscounts: [
              {
                typeId: 'cart-discount',
                id: '8eff47c2-5fa8-481d-b172-d4e6c0162a48',
              },
            ],
            isActive: true,
            maxApplications: 50,
            maxApplicationsPerCustomer: 78,
            cartPredicate: '',
            references: [],
            attributeTypes: {},
            cartFieldTypes: {},
            lineItemFieldTypes: {},
            customLineItemFieldTypes: {},
            groups: [],
          },
        },
        state: 'DoesNotMatchCart',
      },
    ],
    inventoryMode: 'None',
    taxMode: 'Disabled',
    taxRoundingMode: 'HalfEven',
    taxCalculationMode: 'LineItemLevel',
    refusedGifts: [],
    origin: 'Customer',
    itemShippingAddresses: [],
  };
};
export const stubCartServiceToMapper = (): any => {
  return {
    type: 'Cart',
    id: 'd4223b0e-3b24-4818-a92e-923497ab67f3',
    version: 131,
    lastMessageSequenceNumber: 1,
    createdAt: '2022-01-24T07:33:25.271Z',
    lastModifiedAt: '2022-01-24T18:27:02.091Z',
    lastModifiedBy: {
      clientId: 'JmO2yShXYnCr0R59WmdX8A8x',
      isPlatformClient: false,
    },
    createdBy: {
      clientId: 'JmO2yShXYnCr0R59WmdX8A8x',
      isPlatformClient: false,
    },
    anonymousId: '512bf1c7-5092-4afc-a56d-bab97a287558',
    lineItems: [
      {
        id: '8b8fb4ed-de0e-42ab-9aaf-48381e74bb92',
        productId: 'f2ff5243-69c5-4516-8d41-0511df232766',
        productKey: '106826',
        name: {
          ro: 'Difuzor cu aromă de păstaie de vanilie',
        },
        productType: {
          typeId: 'product-type',
          id: '9886ed24-a370-49c9-847f-6d5d64b3aceb',
        },
        productSlug: {
          ro: 'product_106826_difuzor-cu-aroma-de-pastaie-de-vanilie',
        },
        variant: {
          id: 1,
          sku: '106826-9161866660405752377',
          key: '106826-9161866660405752377',
          prices: [
            {
              id: '71f547ea-fac9-4980-915d-a370998b3f4d',
              value: {
                type: 'centPrecision',
                currencyCode: 'RON',
                centAmount: 9999,
                fractionDigits: 2,
              },
              channel: {
                typeId: 'channel',
                id: '0b708030-d62d-458a-8021-e73d07676ae6',
              },
              discounted: {
                value: {
                  type: 'centPrecision',
                  currencyCode: 'RON',
                  centAmount: 8999,
                  fractionDigits: 2,
                },
                discount: {
                  typeId: 'product-discount',
                  id: 'fcf70f30-fbd5-4d09-a1e2-7f2a3df2ab86',
                },
              },
            },
            {
              id: '462bf851-cd86-461f-84fd-b75adc5b2c72',
              value: {
                type: 'centPrecision',
                currencyCode: 'RON',
                centAmount: 9999,
                fractionDigits: 2,
              },
              discounted: {
                value: {
                  type: 'centPrecision',
                  currencyCode: 'RON',
                  centAmount: 8999,
                  fractionDigits: 2,
                },
                discount: {
                  typeId: 'product-discount',
                  id: 'fcf70f30-fbd5-4d09-a1e2-7f2a3df2ab86',
                },
              },
            },
          ],
          images: [
            {
              url: 'https://www.avon.ro/assets/ro-RO/images/product/prod_5539383_1_613x613.jpg',
              label: 'Gallery',
              dimensions: {
                w: 613,
                h: 613,
              },
            },
            {
              url: 'https://www.avon.ro/assets/ro-RO/images/product/prod_5539383_1_185x185.jpg',
              label: 'Thumbnail',
              dimensions: {
                w: 185,
                h: 185,
              },
            },
          ],
          attributes: [
            {
              name: 'startDate',
              value: '2021-12-01T00:00:00.000Z',
            },
            {
              name: 'endDate',
              value: '2022-01-01T00:00:00.000Z',
            },
            {
              name: 'finishedStockCode',
              value: '1400818',
            },
            {
              name: 'maxPurchasableQty',
              value: 8,
            },
            {
              name: 'variantType',
              value: {
                key: 'Version',
                label: 'Version',
              },
            },
            {
              name: 'ratingCount',
              value: 4,
            },
            {
              name: 'badges',
              value: [
                [
                  {
                    name: 'side',
                    value: {
                      key: 'TOP-RIGHT',
                      label: 'TOP-RIGHT',
                    },
                  },
                  {
                    name: 'type',
                    value: {
                      key: 'BESTSELLER',
                      label: 'BESTSELLER',
                    },
                  },
                ],
              ],
            },
          ],
          assets: [],
          availability: {
            isOnStock: true,
            availableQuantity: 5,
            version: 2,
            id: '8de36722-bf73-49a7-9e0c-7064068f09f2',
          },
        },
        price: {
          id: '462bf851-cd86-461f-84fd-b75adc5b2c72',
          value: {
            type: 'centPrecision',
            currencyCode: 'RON',
            centAmount: 2300,
            fractionDigits: 2,
          },
        },
        quantity: 2,
        discountedPrice: {
          value: {
            type: 'centPrecision',
            currencyCode: 'RON',
            centAmount: 2070,
            fractionDigits: 2,
          },
          includedDiscounts: [
            {
              discount: {
                typeId: 'cart-discount',
                id: '8eff47c2-5fa8-481d-b172-d4e6c0162a48',
              },
              discountedAmount: {
                type: 'centPrecision',
                currencyCode: 'RON',
                centAmount: 230,
                fractionDigits: 2,
              },
            },
          ],
        },
        discountedPricePerQuantity: [
          {
            quantity: 2,
            discountedPrice: {
              value: {
                type: 'centPrecision',
                currencyCode: 'RON',
                centAmount: 2070,
                fractionDigits: 2,
              },
              includedDiscounts: [
                {
                  discount: {
                    typeId: 'cart-discount',
                    id: '8eff47c2-5fa8-481d-b172-d4e6c0162a48',
                  },
                  discountedAmount: {
                    type: 'centPrecision',
                    currencyCode: 'RON',
                    centAmount: 230,
                    fractionDigits: 2,
                  },
                },
              ],
            },
          },
        ],
        addedAt: '2022-01-24T07:33:25.266Z',
        lastModifiedAt: '2022-01-24T12:08:48.304Z',
        state: [
          {
            quantity: 2,
            state: {
              typeId: 'state',
              id: '398fcbca-fb79-4042-82fa-c02b4c0bd586',
            },
          },
        ],
        priceMode: 'Platform',
        totalPrice: {
          type: 'centPrecision',
          currencyCode: 'RON',
          centAmount: 4140,
          fractionDigits: 2,
        },
        lineItemMode: 'Standard',
      },
    ],
    cartState: 'Active',
    totalPrice: {
      type: 'centPrecision',
      currencyCode: 'RON',
      centAmount: 4140,
      fractionDigits: 2,
    },
    customLineItems: [],
    discountCodes: [
      {
        discountCode: {
          typeId: 'discount-code',
          id: '5d06c34c-5f40-4897-abdb-99cc9adc97ff',
          obj: {
            id: '5d06c34c-5f40-4897-abdb-99cc9adc97ff',
            version: 5,
            createdAt: '2022-01-24T11:08:08.160Z',
            lastModifiedAt: '2022-01-24T11:30:17.962Z',
            lastModifiedBy: {
              isPlatformClient: true,
              user: {
                typeId: 'user',
                id: 'c0bbd43f-0262-4ac6-8c84-9953491f564b',
              },
            },
            createdBy: {
              isPlatformClient: true,
              user: {
                typeId: 'user',
                id: 'c0bbd43f-0262-4ac6-8c84-9953491f564b',
              },
            },
            code: 'AVON10%',
            name: {
              ro: 'AVONTESTDISCOUNT',
            },
            description: {
              ro: 'This is a 10 Percent relative discount which is applied on cart if total is greater than 40 RON',
            },
            cartDiscounts: [
              {
                typeId: 'cart-discount',
                id: '8eff47c2-5fa8-481d-b172-d4e6c0162a48',
              },
            ],
            isActive: true,
            maxApplications: 50,
            maxApplicationsPerCustomer: 78,
            cartPredicate: '',
            references: [],
            attributeTypes: {},
            cartFieldTypes: {},
            lineItemFieldTypes: {},
            customLineItemFieldTypes: {},
            groups: [],
          },
        },
        state: 'MatchesCart',
      },
    ],
    inventoryMode: 'None',
    taxMode: 'Disabled',
    taxRoundingMode: 'HalfEven',
    taxCalculationMode: 'LineItemLevel',
    refusedGifts: [],
    origin: 'Customer',
    itemShippingAddresses: [],
  };
};

export const stubCartMapperResult = (): any => {
  return {
    id: 'd4223b0e-3b24-4818-a92e-923497ab67f3',
    version: 131,
    totalRetailPriceAmount: '46',
    totalInvoiceAmount: 41.4,
    currencyCode: 'RON',
    promotion: {
      promotionId: '5d06c34c-5f40-4897-abdb-99cc9adc97ff',
      promotionCode: 'AVON10%',
      promotionAmount: 4.6,
      promotionState: 'MatchesCart',
    },
    customerId: undefined,
    anonymousId: '512bf1c7-5092-4afc-a56d-bab97a287558',
    lineItems: [
      {
        lineItemId: '8b8fb4ed-de0e-42ab-9aaf-48381e74bb92',
        productId: 'f2ff5243-69c5-4516-8d41-0511df232766',
        name: 'Difuzor cu aromă de păstaie de vanilie',
        skuCode: '106826-9161866660405752377',
        images: [
          {
            label: 'Gallery',
            url: 'https://www.avon.ro/assets/ro-RO/images/product/prod_5539383_1_613x613.jpg',
            width: 613,
            height: 613,
          },
          {
            label: 'Thumbnail',
            url: 'https://www.avon.ro/assets/ro-RO/images/product/prod_5539383_1_185x185.jpg',
            width: 185,
            height: 185,
          },
        ],
        sellPrice: 23.00,
        listPrice: 23.00,
        formattedListPrice: 'RON 23.00',
        formattedSellPrice: 'RON 23.00',
        vatMessage: 'Vat Include',
        unitPrice: '',
        quantity: 2,
        modifiedTimeStamp: '2022-01-24T12:08:48.304Z',
        sequenceNumber: 0,
        maxPurchasableQty: 8,
        availableQuantity: 5,
      },
    ],
  };
};

export const stubCartServiceToMapper1 = (): any => {
  return {
    type: 'Cart',
    id: 'd4223b0e-3b24-4818-a92e-923497ab67f3',
    version: 131,
    lastMessageSequenceNumber: 1,
    createdAt: '2022-01-24T07:33:25.271Z',
    lastModifiedAt: '2022-01-24T18:27:02.091Z',
    lastModifiedBy: {
      clientId: 'JmO2yShXYnCr0R59WmdX8A8x',
      isPlatformClient: false,
    },
    createdBy: {
      clientId: 'JmO2yShXYnCr0R59WmdX8A8x',
      isPlatformClient: false,
    },
    anonymousId: '512bf1c7-5092-4afc-a56d-bab97a287558',
    lineItems: [
      {
        id: '8b8fb4ed-de0e-42ab-9aaf-48381e74bb92',
        productId: 'f2ff5243-69c5-4516-8d41-0511df232766',
        productKey: '106826',
        name: {
          ro: 'Difuzor cu aromă de păstaie de vanilie',
        },
        productType: {
          typeId: 'product-type',
          id: '9886ed24-a370-49c9-847f-6d5d64b3aceb',
        },
        productSlug: {
          ro: 'product_106826_difuzor-cu-aroma-de-pastaie-de-vanilie',
        },
        variant: {
          id: 1,
          sku: '106826-9161866660405752377',
          key: '106826-9161866660405752377',
          prices: [
            {
              id: '71f547ea-fac9-4980-915d-a370998b3f4d',
              value: {
                type: 'centPrecision',
                currencyCode: 'RON',
                centAmount: 9999,
                fractionDigits: 2,
              },
              channel: {
                typeId: 'channel',
                id: '0b708030-d62d-458a-8021-e73d07676ae6',
              },
              discounted: {
                value: {
                  type: 'centPrecision',
                  currencyCode: 'RON',
                  centAmount: 8999,
                  fractionDigits: 2,
                },
                discount: {
                  typeId: 'product-discount',
                  id: 'fcf70f30-fbd5-4d09-a1e2-7f2a3df2ab86',
                },
              },
            },
            {
              id: '462bf851-cd86-461f-84fd-b75adc5b2c72',
              value: {
                type: 'centPrecision',
                currencyCode: 'RON',
                centAmount: 9999,
                fractionDigits: 2,
              },
              discounted: {
                value: {
                  type: 'centPrecision',
                  currencyCode: 'RON',
                  centAmount: 8999,
                  fractionDigits: 2,
                },
                discount: {
                  typeId: 'product-discount',
                  id: 'fcf70f30-fbd5-4d09-a1e2-7f2a3df2ab86',
                },
              },
            },
          ],
          images: [
            {
              url: 'https://www.avon.ro/assets/ro-RO/images/product/prod_5539383_1_613x613.jpg',
              label: 'Gallery',
              dimensions: {
                w: 613,
                h: 613,
              },
            },
            {
              url: 'https://www.avon.ro/assets/ro-RO/images/product/prod_5539383_1_185x185.jpg',
              label: 'Thumbnail',
              dimensions: {
                w: 185,
                h: 185,
              },
            },
          ],
          attributes: [
            {
              name: 'startDate',
              value: '2021-12-01T00:00:00.000Z',
            },
            {
              name: 'endDate',
              value: '2022-01-01T00:00:00.000Z',
            },
            {
              name: 'finishedStockCode',
              value: '1400818',
            },
            {
              name: 'variantType',
              value: {
                key: 'Version',
                label: 'Version',
              },
            },
            {
              name: 'ratingCount',
              value: 4,
            },
            {
              name: 'badges',
              value: [
                [
                  {
                    name: 'side',
                    value: {
                      key: 'TOP-RIGHT',
                      label: 'TOP-RIGHT',
                    },
                  },
                  {
                    name: 'type',
                    value: {
                      key: 'BESTSELLER',
                      label: 'BESTSELLER',
                    },
                  },
                ],
              ],
            },
          ],
          assets: [],
          availability: {
            isOnStock: true,
            availableQuantity: 5,
            version: 2,
            id: '8de36722-bf73-49a7-9e0c-7064068f09f2',
          },
        },
        price: {
          id: '462bf851-cd86-461f-84fd-b75adc5b2c72',
          value: {
            type: 'centPrecision',
            currencyCode: 'RON',
            centAmount: 2300,
            fractionDigits: 2,
          },
        },
        quantity: 2,
        discountedPrice: {
          value: {
            type: 'centPrecision',
            currencyCode: 'RON',
            centAmount: 2070,
            fractionDigits: 2,
          },
          includedDiscounts: [
            {
              discount: {
                typeId: 'cart-discount',
                id: '8eff47c2-5fa8-481d-b172-d4e6c0162a48',
              },
              discountedAmount: {
                type: 'centPrecision',
                currencyCode: 'RON',
                centAmount: 230,
                fractionDigits: 2,
              },
            },
          ],
        },
        discountedPricePerQuantity: [
          {
            quantity: 2,
            discountedPrice: {
              value: {
                type: 'centPrecision',
                currencyCode: 'RON',
                centAmount: 2070,
                fractionDigits: 2,
              },
              includedDiscounts: [
                {
                  discount: {
                    typeId: 'cart-discount',
                    id: '8eff47c2-5fa8-481d-b172-d4e6c0162a48',
                  },
                  discountedAmount: {
                    type: 'centPrecision',
                    currencyCode: 'RON',
                    centAmount: 230,
                    fractionDigits: 2,
                  },
                },
              ],
            },
          },
        ],
        addedAt: '2022-01-24T07:33:25.266Z',
        lastModifiedAt: '2022-01-24T12:08:48.304Z',
        state: [
          {
            quantity: 2,
            state: {
              typeId: 'state',
              id: '398fcbca-fb79-4042-82fa-c02b4c0bd586',
            },
          },
        ],
        priceMode: 'Platform',
        totalPrice: {
          type: 'centPrecision',
          currencyCode: 'RON',
          centAmount: 4140,
          fractionDigits: 2,
        },
        lineItemMode: 'Standard',
      },
    ],
    cartState: 'Active',
    totalPrice: {
      type: 'centPrecision',
      currencyCode: 'RON',
      centAmount: 4140,
      fractionDigits: 2,
    },
    customLineItems: [],
    discountCodes: [
      {
        discountCode: {
          typeId: 'discount-code',
          id: '5d06c34c-5f40-4897-abdb-99cc9adc97ff',
          obj: {
            id: '5d06c34c-5f40-4897-abdb-99cc9adc97ff',
            version: 5,
            createdAt: '2022-01-24T11:08:08.160Z',
            lastModifiedAt: '2022-01-24T11:30:17.962Z',
            lastModifiedBy: {
              isPlatformClient: true,
              user: {
                typeId: 'user',
                id: 'c0bbd43f-0262-4ac6-8c84-9953491f564b',
              },
            },
            createdBy: {
              isPlatformClient: true,
              user: {
                typeId: 'user',
                id: 'c0bbd43f-0262-4ac6-8c84-9953491f564b',
              },
            },
            code: 'AVON10%',
            name: {
              ro: 'AVONTESTDISCOUNT',
            },
            description: {
              ro: 'This is a 10 Percent relative discount which is applied on cart if total is greater than 40 RON',
            },
            cartDiscounts: [
              {
                typeId: 'cart-discount',
                id: '8eff47c2-5fa8-481d-b172-d4e6c0162a48',
              },
            ],
            isActive: true,
            maxApplications: 50,
            maxApplicationsPerCustomer: 78,
            cartPredicate: '',
            references: [],
            attributeTypes: {},
            cartFieldTypes: {},
            lineItemFieldTypes: {},
            customLineItemFieldTypes: {},
            groups: [],
          },
        },
        state: 'MatchesCart',
      },
    ],
    inventoryMode: 'None',
    taxMode: 'Disabled',
    taxRoundingMode: 'HalfEven',
    taxCalculationMode: 'LineItemLevel',
    refusedGifts: [],
    origin: 'Customer',
    itemShippingAddresses: [],
  };
};

export const stubCartServiceToMapper2 = (): any => {
  return {
    type: 'Cart',
    id: 'd4223b0e-3b24-4818-a92e-923497ab67f3',
    version: 131,
    lastMessageSequenceNumber: 1,
    createdAt: '2022-01-24T07:33:25.271Z',
    lastModifiedAt: '2022-01-24T18:27:02.091Z',
    lastModifiedBy: {
      clientId: 'JmO2yShXYnCr0R59WmdX8A8x',
      isPlatformClient: false,
    },
    createdBy: {
      clientId: 'JmO2yShXYnCr0R59WmdX8A8x',
      isPlatformClient: false,
    },
    anonymousId: '512bf1c7-5092-4afc-a56d-bab97a287558',
    lineItems: [
      {
        id: '8b8fb4ed-de0e-42ab-9aaf-48381e74bb92',
        productId: 'f2ff5243-69c5-4516-8d41-0511df232766',
        productKey: '106826',
        name: {
          ro: 'Difuzor cu aromă de păstaie de vanilie',
        },
        productType: {
          typeId: 'product-type',
          id: '9886ed24-a370-49c9-847f-6d5d64b3aceb',
        },
        productSlug: {
          ro: 'product_106826_difuzor-cu-aroma-de-pastaie-de-vanilie',
        },
        variant: {
          id: 1,
          sku: '106826-9161866660405752377',
          key: '106826-9161866660405752377',
          prices: [
            {
              id: '71f547ea-fac9-4980-915d-a370998b3f4d',
              value: {
                type: 'centPrecision',
                currencyCode: 'RON',
                centAmount: 9999,
                fractionDigits: 2,
              },
              channel: {
                typeId: 'channel',
                id: '0b708030-d62d-458a-8021-e73d07676ae6',
              },
              discounted: {
                value: {
                  type: 'centPrecision',
                  currencyCode: 'RON',
                  centAmount: 8999,
                  fractionDigits: 2,
                },
                discount: {
                  typeId: 'product-discount',
                  id: 'fcf70f30-fbd5-4d09-a1e2-7f2a3df2ab86',
                },
              },
            },
            {
              id: '462bf851-cd86-461f-84fd-b75adc5b2c72',
              value: {
                type: 'centPrecision',
                currencyCode: 'RON',
                centAmount: 9999,
                fractionDigits: 2,
              },
              discounted: {
                value: {
                  type: 'centPrecision',
                  currencyCode: 'RON',
                  centAmount: 8999,
                  fractionDigits: 2,
                },
                discount: {
                  typeId: 'product-discount',
                  id: 'fcf70f30-fbd5-4d09-a1e2-7f2a3df2ab86',
                },
              },
            },
          ],
          images: [
            {
              url: 'https://www.avon.ro/assets/ro-RO/images/product/prod_5539383_1_613x613.jpg',
              label: 'Gallery',
              dimensions: {
                w: 613,
                h: 613,
              },
            },
            {
              url: 'https://www.avon.ro/assets/ro-RO/images/product/prod_5539383_1_185x185.jpg',
              label: 'Thumbnail',
              dimensions: {
                w: 185,
                h: 185,
              },
            },
          ],
          attributes: [
            {
              name: 'startDate',
              value: '2021-12-01T00:00:00.000Z',
            },
            {
              name: 'endDate',
              value: '2022-01-01T00:00:00.000Z',
            },
            {
              name: 'finishedStockCode',
              value: '1400818',
            },
            {
              name: 'maxPurchasableQty',
              value: 8,
            },
            {
              name: 'variantType',
              value: {
                key: 'Version',
                label: 'Version',
              },
            },
            {
              name: 'ratingCount',
              value: 4,
            },
            {
              name: 'badges',
              value: [
                [
                  {
                    name: 'side',
                    value: {
                      key: 'TOP-RIGHT',
                      label: 'TOP-RIGHT',
                    },
                  },
                  {
                    name: 'type',
                    value: {
                      key: 'BESTSELLER',
                      label: 'BESTSELLER',
                    },
                  },
                ],
              ],
            },
          ],
          assets: [],
          availability: {
            isOnStock: true,
            version: 2,
            id: '8de36722-bf73-49a7-9e0c-7064068f09f2',
          },
        },
        price: {
          id: '462bf851-cd86-461f-84fd-b75adc5b2c72',
          value: {
            type: 'centPrecision',
            currencyCode: 'RON',
            centAmount: 2300,
            fractionDigits: 2,
          },
        },
        quantity: 2,
        discountedPrice: {
          value: {
            type: 'centPrecision',
            currencyCode: 'RON',
            centAmount: 2070,
            fractionDigits: 2,
          },
          includedDiscounts: [
            {
              discount: {
                typeId: 'cart-discount',
                id: '8eff47c2-5fa8-481d-b172-d4e6c0162a48',
              },
              discountedAmount: {
                type: 'centPrecision',
                currencyCode: 'RON',
                centAmount: 230,
                fractionDigits: 2,
              },
            },
          ],
        },
        discountedPricePerQuantity: [
          {
            quantity: 2,
            discountedPrice: {
              value: {
                type: 'centPrecision',
                currencyCode: 'RON',
                centAmount: 2070,
                fractionDigits: 2,
              },
              includedDiscounts: [
                {
                  discount: {
                    typeId: 'cart-discount',
                    id: '8eff47c2-5fa8-481d-b172-d4e6c0162a48',
                  },
                  discountedAmount: {
                    type: 'centPrecision',
                    currencyCode: 'RON',
                    centAmount: 230,
                    fractionDigits: 2,
                  },
                },
              ],
            },
          },
        ],
        addedAt: '2022-01-24T07:33:25.266Z',
        lastModifiedAt: '2022-01-24T12:08:48.304Z',
        state: [
          {
            quantity: 2,
            state: {
              typeId: 'state',
              id: '398fcbca-fb79-4042-82fa-c02b4c0bd586',
            },
          },
        ],
        priceMode: 'Platform',
        totalPrice: {
          type: 'centPrecision',
          currencyCode: 'RON',
          centAmount: 4140,
          fractionDigits: 2,
        },
        lineItemMode: 'Standard',
      },
    ],
    cartState: 'Active',
    totalPrice: {
      type: 'centPrecision',
      currencyCode: 'RON',
      centAmount: 4140,
      fractionDigits: 2,
    },
    customLineItems: [],
    discountCodes: [
      {
        discountCode: {
          typeId: 'discount-code',
          id: '5d06c34c-5f40-4897-abdb-99cc9adc97ff',
          obj: {
            id: '5d06c34c-5f40-4897-abdb-99cc9adc97ff',
            version: 5,
            createdAt: '2022-01-24T11:08:08.160Z',
            lastModifiedAt: '2022-01-24T11:30:17.962Z',
            lastModifiedBy: {
              isPlatformClient: true,
              user: {
                typeId: 'user',
                id: 'c0bbd43f-0262-4ac6-8c84-9953491f564b',
              },
            },
            createdBy: {
              isPlatformClient: true,
              user: {
                typeId: 'user',
                id: 'c0bbd43f-0262-4ac6-8c84-9953491f564b',
              },
            },
            code: 'AVON10%',
            name: {
              ro: 'AVONTESTDISCOUNT',
            },
            description: {
              ro: 'This is a 10 Percent relative discount which is applied on cart if total is greater than 40 RON',
            },
            cartDiscounts: [
              {
                typeId: 'cart-discount',
                id: '8eff47c2-5fa8-481d-b172-d4e6c0162a48',
              },
            ],
            isActive: true,
            maxApplications: 50,
            maxApplicationsPerCustomer: 78,
            cartPredicate: '',
            references: [],
            attributeTypes: {},
            cartFieldTypes: {},
            lineItemFieldTypes: {},
            customLineItemFieldTypes: {},
            groups: [],
          },
        },
        state: 'MatchesCart',
      },
    ],
    inventoryMode: 'None',
    taxMode: 'Disabled',
    taxRoundingMode: 'HalfEven',
    taxCalculationMode: 'LineItemLevel',
    refusedGifts: [],
    origin: 'Customer',
    itemShippingAddresses: [],
  };
};
export const stubCtCartShippingInfo = (
  config: Partial<ShippingInfo> = {},
): ShippingInfo => {
  return {
    shippingMethodName: faker.datatype.string(),
    price: {
      type: faker.datatype.string(),
      currencyCode: faker.finance.currencyCode(),
      centAmount: faker.datatype.number(),
      fractionDigits: faker.datatype.number({
        min: 0,
        max: 2,
      }),
    },
    ...config,
  };
};
export const shippingMethodDto = (
  config: Partial<ShippingMethodServiceDto> = {},
): ShippingMethodServiceDto => {
  return {
    id: faker.datatype.uuid(),
    name: faker.datatype.string(),
    localizedDescription: faker.datatype.string(),
    isDefault: true,
    zoneRates: [
      {
        shippingRates: [
          {
            price: {
              centAmount: 5000,
              currencyCode: 'RON',
              fractionDigits: 2,
            },
            freeAbove: {
              centAmount: 20000,
              currencyCode: 'RON',
              fractionDigits: 2,
            },
          },
        ],
      },
    ],
    ...config,
  };
};
