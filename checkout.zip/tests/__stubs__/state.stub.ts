import faker from '@faker-js/faker';
import { State } from '@commercetools/platform-sdk';
import { stubTrackingFields } from './trackingfields.stub';

export const stubState = (
  config: Partial<State> = {},
): State => {
  return {
    id: faker.datatype.uuid(),
    key: faker.random.word(),
    builtIn: faker.random.boolean(),
    type: faker.random.arrayElement([
      'PaymentState',
      'OrderState',
      'ProductState',
      'ReviewState',
      'LineItemState']),
    version: faker.datatype.number(),
    initial: faker.datatype.boolean(),
    ...stubTrackingFields(),
    ...config,
  };
};
