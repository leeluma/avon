import {
  CentPrecisionMoney, Money, Payment, Transaction,
} from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import { PAYMENT_TYPE, PaymentTypeDto, PaymentTransactionResponseDto } from '../../src/dtos';

export const stubMoney = (
  config: Partial<Money> = {},
): Money => {
  return {
    centAmount: faker.datatype.number(),
    currencyCode: faker.finance.currencyCode(),
    ...config,
  };
};

export const stubCentPrecisionMoney = (
  config: Partial<CentPrecisionMoney> = {},
): CentPrecisionMoney => {
  return {
    centAmount: faker.datatype.number(),
    currencyCode: faker.finance.currencyCode(),
    type: 'centPrecision',
    fractionDigits: faker.datatype.number({ min: 0, max: 4 }),
    ...config,
  };
};

export const stubTransaction = (
  config: Partial<Transaction> = {},
): Transaction => {
  return {
    id: faker.datatype.uuid(),
    type: faker.random.arrayElement(['Authorization', 'Charge', 'CancelAuthorization', 'Chargeback', 'Refund']),
    amount: stubCentPrecisionMoney(),
    ...config,
  };
};

export const stubPayment = (
  config: Partial<Payment> = {},
): Payment => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    transactions: [
      stubTransaction(),
    ],
    amountAuthorized: {
      type: 'centPrecision',
      centAmount: faker.datatype.number(),
      fractionDigits: 2,
      currencyCode: faker.finance.currencyCode(),
    },
    amountPlanned: {
      type: 'centPrecision',
      centAmount: faker.datatype.number(),
      fractionDigits: 2,
      currencyCode: faker.finance.currencyCode(),
    },
    paymentStatus: {},
    paymentMethodInfo: {},
    createdAt: faker.date.past().toString(),
    lastModifiedAt: faker.date.past().toString(),
    interfaceInteractions: [],
    ...config,
  };
};

export const stubPaymentTypeDto = (): PaymentTypeDto =>
  faker.random.arrayElement([PAYMENT_TYPE.online, PAYMENT_TYPE.CashOnDelivery]);

export const stubPaymentTransactionResponse = (
  config: Partial<PaymentTransactionResponseDto> = {},
): PaymentTransactionResponseDto => {
  return {
    id: faker.datatype.uuid(),
    currency: faker.finance.currencyCode(),
    amount: faker.datatype.number(),
    ordNr: faker.datatype.number().toString(),
    payerId: faker.datatype.string(),
    paymentRefId: faker.datatype.string(),
    status: faker.random.arrayElement(['CAPTURED', 'DECLINED', 'FAILED', 'PENDING']),
    capture_now: faker.datatype.string(),
    payment_product: faker.datatype.string(),
    recurring_type: faker.datatype.string(),
    ...config,
  };
};
