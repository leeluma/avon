import i18next from 'i18next';
import faker from '@faker-js/faker';
import {
  Cart, CentPrecisionMoney, CustomerUpdate, Order, Payment, State,
} from '@commercetools/platform-sdk';
import { PaymentService } from '../../src/services';
import {
  CartDao, OrderDao, PaymentDao, NotificationsDao, CustomerDao, MagnoliaDao,
} from '../../src/daos';
import { MarketInfo } from '../../src/middlewares';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import {
  stubAddressResponseDto,
  stubCentPrecisionMoney,
  stubCtCartDto,
  stubMarket,
  stubOrder,
  stubPayment,
  stubPaymentTypeDto,
  stubState,
  stubMagnoliaInfo,
  stubPaymentTransactionResponse,
} from '../__stubs__';
import Mock = jest.Mock;
import { ApiError, AwsEventBridgeClient } from '../../src/lib';
import { bootstrapI18next } from '../helpers';
import {
  PaymentInitResponseDto, PaymentTypeDto, AddressResponseDto,
  ApptusRequestDto,
  PaymentTransactionResponseDto,
  E_PAYMENT_STATUS,
  PAYMENT_STATE_KEYS,
} from '../../src/dtos';

describe('PaymentService', () => {
  let market: MarketInfo;
  let magnolia: MagnoliaInfo;
  let authorization: string;
  let paymentService: PaymentService;

  let cartDao: CartDao;
  let paymentDao: PaymentDao;
  let orderDao: OrderDao;
  let magnoliaDao: MagnoliaDao;
  let notificationsDao: NotificationsDao;
  let customerDao: CustomerDao;

  let cart: Cart;
  let customerId: string;
  let anonymousId: string;
  let billingAddress: AddressResponseDto;
  let totalPrice: CentPrecisionMoney;
  let paymentInitResponse: PaymentInitResponseDto;
  let paymentType: PaymentTypeDto;
  let payment: Payment;
  const magnoliaData = {
    paymentSummaryTexts: {
      showCashOnDelivery: false,
    },
  };
  let order: Order;
  let marketingEmailConsent: boolean;
  let paymentStateInitial: State;
  let paymentStatePending: State;
  let paymentStateSuccess: State;
  let paymentStateFailed: State;
  let eventBridgeClient: AwsEventBridgeClient;
  let marketingEmailConsentEventBusName: string;
  let param: ApptusRequestDto;
  let returnUrl: string;
  let ePayTransaction: PaymentTransactionResponseDto;

  let maxRetries: number;
  let minRetry: number;
  let waitTimeout: number;

  beforeAll(async () => {
    await bootstrapI18next();
    magnolia = stubMagnoliaInfo();
  });

  beforeEach(() => {
    market = stubMarket();
    authorization = `Bearer ${faker.random.word()}`;
    payment = stubPayment();
    customerId = faker.datatype.uuid();
    anonymousId = faker.datatype.uuid();
    billingAddress = stubAddressResponseDto();
    totalPrice = stubCentPrecisionMoney();
    // TODO Remove 'as any' after CartDto is removed from this project
    cart = stubCtCartDto({
      customerId, billingAddress, totalPrice, anonymousId,
    }) as any;
    paymentType = stubPaymentTypeDto();
    marketingEmailConsent = faker.datatype.boolean();

    paymentInitResponse = {
      id: faker.datatype.uuid(),
      url: faker.internet.url(),
    };

    order = stubOrder();
    ePayTransaction = stubPaymentTransactionResponse();

    cartDao = {
      getMyCartById: jest.fn().mockReturnValueOnce(cart),
      replicateCartById: jest.fn().mockReturnValueOnce(cart),
      updateCartById: jest.fn(),
      getCartPaymentInfo: jest.fn(),
    } as any;
    orderDao = {
      createOrderFromCart: jest.fn().mockReturnValueOnce(order),
      fetchOrderByOrderNumber: jest.fn(),
    } as any;
    notificationsDao = {
      paymentNotifications: jest.fn(),
    } as any;
    customerDao = {
      findGraphQLOne: jest.fn(),
      updateCustomer: jest.fn(),
    } as any;

    paymentStateInitial = stubState({ type: 'PaymentState', key: 'initial' });
    paymentStatePending = stubState({ type: 'PaymentState', key: 'pending' });
    paymentStateSuccess = stubState({ type: 'PaymentState', key: 'success' });
    paymentStateFailed = stubState({ type: 'PaymentState', key: 'failed' });
    magnoliaDao = {
      getCheckoutPageData: jest.fn().mockReturnValueOnce(magnoliaData),
    } as any;
    paymentDao = {
      createPayment: jest.fn(),
      updatePayment: jest.fn(),
      epayInitiate: jest.fn().mockReturnValueOnce(paymentInitResponse),
      getAllPaymentStates: jest.fn().mockReturnValueOnce([paymentStateInitial, paymentStatePending,
        paymentStateSuccess, paymentStateFailed]),
      getNextOrderSequence: jest.fn(),
      getNextPaymentKey: jest.fn(),
      ePayTransactionDetail: jest.fn(),
    } as any;

    eventBridgeClient = {
      putEvent: jest.fn().mockReturnValueOnce(Promise.resolve(undefined)),
    } as any;

    marketingEmailConsentEventBusName = `arn:123:/event-bus/${faker.random.word().toLowerCase()}`;
    returnUrl = faker.internet.url();

    maxRetries = 5;
    minRetry = 1;
    waitTimeout = 5000;
    paymentService = new PaymentService({
      cartDao,
      paymentDao,
      orderDao,
      eventBridgeClient,
      marketingEmailConsentEventBusName,
      notificationsDao,
      returnUrl,
      customerDao,
      magnoliaDao,
      maxRetries,
      minRetry,
      waitTimeout,
    });
    param = {
      customerKey: faker.datatype.uuid(),
      sessionKey: faker.datatype.uuid(),
    };
  });

  describe('createOnlinePayment()', () => {
    test('creates the CT Payment', async () => {
      (paymentDao.createPayment as Mock).mockReturnValueOnce(payment);
      const paymentKey = faker.datatype.uuid();

      const response = await (paymentService as any).createOnlinePayment(
        market,
        paymentKey,
        totalPrice,
        customerId,
        anonymousId,
      );

      expect(paymentDao.createPayment).toHaveBeenCalledTimes(1);
      expect(paymentDao.createPayment).toHaveBeenNthCalledWith(
        1,
        market,
        {
          key: paymentKey,
          amountPlanned: totalPrice,
          paymentMethodInfo: { method: 'online' },
          paymentStatus: { state: { typeId: 'state', id: paymentStateInitial.id } },
          transactions: [{
            amount: totalPrice,
            state: 'Initial',
            type: 'Charge',
          }],
        },
      );

      expect(response).toBe(payment);
    });
  });

  describe('initiatePayment()', () => {
    let updatedCart: Cart;
    let css: string;

    beforeEach(() => {
      css = `/* ${faker.random.word()} */`;
      updatedCart = stubCtCartDto() as any; // TODO Remove 'any' after removing CartDto from the project

      (paymentService as any).createOnlinePayment = jest.fn().mockReturnValueOnce(payment);
      (paymentService as any).createCashPayment = jest.fn().mockReturnValueOnce(payment);
      (cartDao as any).updateCartById = jest.fn().mockReturnValueOnce(updatedCart);
    });

    test('reads the cart by id', async () => {
      (magnoliaDao as any).getCheckoutPageData = jest.fn().mockReturnValueOnce(undefined);
      const { id } = cart;
      const type = 'online';
      const params = {
        authorization,
        id,
        css,
        type,
        marketingEmailConsent,
      };
      await paymentService.initiatePayment(
        magnolia,
        market,
        params,
        param,
      );

      expect(cartDao.getMyCartById).toHaveBeenCalledTimes(1);
      expect(cartDao.getMyCartById).toHaveBeenNthCalledWith(
        1,
        market.country,
        authorization,
        cart.id,
      );
    });

    test('reads the cart by id cash on delivery', async () => {
      (magnoliaDao as any).getCheckoutPageData = jest.fn().mockReturnValueOnce(undefined);
      const { id } = cart;
      const type = 'CashOnDelivery';
      const params = {
        authorization,
        id,
        css,
        type,
        marketingEmailConsent,
      };

      await paymentService.initiatePayment(
        magnolia,
        market,
        params,
        param,
      );

      expect(cartDao.getMyCartById).toHaveBeenCalledTimes(1);
      expect(cartDao.getMyCartById).toHaveBeenNthCalledWith(
        1,
        market.country,
        authorization,
        cart.id,
      );
    });

    test('reads the cart and replicate it if payment exist', async () => {
      const cartWithPayment = {
        ...cart,
        paymentInfo: {
          payments: [
            {
              typeId: 'payment',
              id: '534f5f5b-a2d4-4dc8-a02e-a0f60e462dbe',
            },
          ],
        },
      };
      (cartDao as any).getMyCartById = jest.fn().mockReturnValueOnce(cartWithPayment);
      const { id } = cart;
      const type = 'online';
      const params = {
        authorization,
        id,
        css,
        type,
        marketingEmailConsent,
      };
      await paymentService.initiatePayment(
        magnolia,
        market,
        params,
        param,
      );

      expect(cartDao.getMyCartById).toHaveBeenCalledTimes(1);
      expect(cartDao.getMyCartById).toHaveBeenNthCalledWith(
        1,
        market.country,
        authorization,
        cart.id,
      );
      expect(cartDao.replicateCartById).toHaveBeenCalledTimes(1);
      expect(cartDao.replicateCartById).toHaveBeenNthCalledWith(
        1,
        market.country,
        cart.id,
        authorization,
      );
    });

    test('throws error if cart is not found', async () => {
      (magnoliaDao as any).getCheckoutPageData = jest.fn().mockReturnValueOnce(undefined);

      (cartDao as any).getMyCartById = jest.fn().mockReturnValueOnce(undefined);
      const { id } = cart;
      const type = paymentType;
      const params = {
        authorization,
        id,
        css,
        type,
        marketingEmailConsent,
      };
      const call = () => paymentService.initiatePayment(
        magnolia,
        market,
        params,
        param,
      );

      await expect(call).rejects.toThrow(
        new ApiError(404, i18next.t('error.cartIdNotFound', { cartId: cart.id })),
      );
    });

    test('throws error if customerId and anonymousId are missing', async () => {
      (magnoliaDao as any).getCheckoutPageData = jest.fn().mockReturnValueOnce(undefined);

      (cart.customerId as any) = undefined;
      (cart.anonymousId as any) = undefined;
      const { id } = cart;
      const type = 'online';
      const params = {
        authorization,
        id,
        css,
        type,
        marketingEmailConsent,
      };
      const call = () => paymentService.initiatePayment(
        magnolia,
        market,
        params,
        param,
      );

      await expect(call).rejects.toThrow(
        new ApiError(500, i18next.t('error.cartCustomerIdNotFound', { cartId: cart.id })),
      );
    });

    test('throws error if billingAddress is missing', async () => {
      (magnoliaDao as any).getCheckoutPageData = jest.fn().mockReturnValueOnce(undefined);

      (cart.billingAddress as any) = undefined;
      const { id } = cart;
      const type = 'online';
      const params = {
        authorization,
        id,
        css,
        type,
        marketingEmailConsent,
      };
      const call = () => paymentService.initiatePayment(
        magnolia,
        market,
        params,
        param,
      );

      await expect(call).rejects.toThrow(
        new ApiError(500, `The cart with ID ${cart.id} does not have a billing address set.`),
      );
    });

    test('throws error if shippingAddress is missing', async () => {
      (magnoliaDao as any).getCheckoutPageData = jest.fn().mockReturnValueOnce(undefined);

      (cart.shippingAddress as any) = undefined;
      const { id } = cart;
      const type = 'online';
      const params = {
        authorization,
        id,
        css,
        type,
        marketingEmailConsent,
      };
      const call = () => paymentService.initiatePayment(
        magnolia,
        market,
        params,
        param,
      );

      await expect(call).rejects.toThrow(
        new ApiError(500, `The cart with ID ${cart.id} does not have a shipping address set.`),
      );
    });

    test('throws error if totalPrice is missing', async () => {
      (magnoliaDao as any).getCheckoutPageData = jest.fn().mockReturnValueOnce(undefined);

      (cart.totalPrice as any) = undefined;
      const { id } = cart;
      const type = 'online';
      const params = {
        authorization,
        id,
        css,
        type,
        marketingEmailConsent,
      };
      const call = () => paymentService.initiatePayment(
        magnolia,
        market,
        params,
        param,
      );

      await expect(call).rejects.toThrow(
        new ApiError(500, `The cart with ID ${cart.id} does not have any items set.`),
      );
    });

    test('error of default case', async () => {
      const type = '' as any;
      (paymentService as any).createOnlinePayment.mockReturnValueOnce(payment);
      const paymentKey = faker.datatype.uuid();
      (paymentDao.getNextPaymentKey as Mock).mockReturnValueOnce(paymentKey);
      const { id } = cart;

      const params = {
        authorization,
        id,
        css,
        type,
        marketingEmailConsent,
      };
      const call = paymentService.initiatePayment(
        magnolia,
        market,
        params,
        param,
      );
      await expect(call).rejects.toThrow(
        new ApiError(500, `Payment type "${type}" is not supported`),
      );
    });

    test('creates the Payment in CT', async () => {
      const type = 'online';
      (paymentService as any).createOnlinePayment.mockReturnValueOnce(payment);
      const paymentKey = faker.datatype.uuid();
      (paymentDao.getNextPaymentKey as Mock).mockReturnValueOnce(paymentKey);
      const cartId = cart.id;
      const parameters = {
        authorization,
        cartId,
        css,
        type,
        marketingEmailConsent,
      };

      await paymentService.initiatePayment(
        magnolia,
        market,
        parameters,
        param,
      );

      expect((paymentService as any).createOnlinePayment).toHaveBeenCalledTimes(1);
      expect((paymentService as any).createOnlinePayment).toHaveBeenNthCalledWith(
        1,
        market,
        paymentKey,
        totalPrice,
      );
    });

    test('throws error if cod not enabled', async () => {
      (magnoliaDao as any).getCheckoutPageData = jest.fn().mockReturnValueOnce(magnoliaData);
      const cartId = cart.id;
      const { id } = cart;
      const type = 'CashOnDelivery';
      const params = {
        authorization,
        id,
        css,
        type,
        marketingEmailConsent,
      };
      const call = () => paymentService.initiatePayment(
        magnolia,
        market,
        params,
        param,
      );

      await expect(call).rejects.toThrow(
        new ApiError(404, i18next.t('error.codNotEnabled', { id: cart.id })),
      );
    });

    test('createCashPayment', async () => {
      const paymentKey = faker.datatype.string();
      (paymentService as any).getPaymentState = jest.fn().mockReturnValueOnce({ id: faker.datatype.uuid() });
      (paymentDao.createPayment as Mock).mockReturnValueOnce(payment);

      const orderId = await (paymentService as any).createCashPayment(
        market,
        paymentKey,
        totalPrice,
      );

      expect(orderId).toBeTruthy();
    });
  });
  describe('updateCustomerMarketingEmailConsent()', () => {
    test('OptIn field is set to true', async () => {
      const updateCustomerPayload: CustomerUpdate = {
        version: 1,
        actions: [{
          action: 'setCustomField',
          name: 'OptIn',
          value: true,
        }],
      };
      (customerDao.findGraphQLOne as Mock).mockReturnValueOnce({ version: 1 });

      await (paymentService as any).updateCustomerMarketingEmailConsent(market, customerId, true);

      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(1, market, customerId, updateCustomerPayload);
    });
  });

  // getPaymentStatus

  describe('getPaymentStatus()', () => {
    let cartPaymentInfo: any;
    let orderNumber: string;
    let transactionId: string;
    beforeEach(() => {
      orderNumber = ePayTransaction.ordNr;
      transactionId = ePayTransaction.id;
      cartPaymentInfo = {
        paymentInfo: {
          payments: [
            {
              id: faker.datatype.uuid(),
              version: faker.datatype.number(),
              paymentStatus: {
                state: {
                  key: faker.random.arrayElement(['pending', 'success', 'failed']),
                },
              },
            },
          ],
        },
      };
      (paymentDao.ePayTransactionDetail as Mock) = jest.fn().mockReturnValueOnce(ePayTransaction);
      (cartDao.getCartPaymentInfo as Mock) = jest.fn().mockReturnValueOnce(cartPaymentInfo);
      (orderDao.fetchOrderByOrderNumber as Mock) = jest.fn().mockReturnValueOnce([{ id: faker.datatype.uuid() }]);
    });

    test('reads the cart payment by id', async () => {
      ePayTransaction.status = E_PAYMENT_STATUS.captured;
      cartPaymentInfo.paymentInfo.payments[0].paymentStatus.state.key = PAYMENT_STATE_KEYS.failed;
      (magnoliaDao as any).getCheckoutPageData = jest.fn().mockReturnValueOnce(undefined);
      await paymentService.getPaymentStatus(
        market,
        authorization,
        cart.id,
        orderNumber,
        transactionId,
        param,
      );

      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(paymentDao.ePayTransactionDetail).not.toHaveBeenCalledTimes(1);
      expect(paymentDao.getAllPaymentStates).not.toHaveBeenCalledTimes(1);
    });

    test('transaction captured and cart payment pending', async () => {
      ePayTransaction.status = E_PAYMENT_STATUS.captured;
      cartPaymentInfo.paymentInfo.payments[0].paymentStatus.state.key = PAYMENT_STATE_KEYS.pending;
      await paymentService.getPaymentStatus(
        market,
        authorization,
        cart.id,
        orderNumber,
        transactionId,
        param,
      );

      expect(paymentDao.ePayTransactionDetail).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(paymentDao.getAllPaymentStates).toHaveBeenCalledTimes(1);
      expect(orderDao.fetchOrderByOrderNumber).toHaveBeenCalledTimes(1);
      expect(notificationsDao.paymentNotifications).toHaveBeenCalledTimes(1);
      expect(paymentDao.ePayTransactionDetail).toHaveBeenNthCalledWith(
        1,
        market,
        transactionId,
        0,
      );
      expect(orderDao.fetchOrderByOrderNumber).toHaveBeenNthCalledWith(
        1,
        market,
        orderNumber,
      );
    });

    test('transaction failed and cart payment pending', async () => {
      ePayTransaction.status = E_PAYMENT_STATUS.failed;
      cartPaymentInfo.paymentInfo.payments[0].paymentStatus.state.key = PAYMENT_STATE_KEYS.pending;
      await paymentService.getPaymentStatus(
        market,
        authorization,
        cart.id,
        orderNumber,
        transactionId,
        param,
      );

      expect(paymentDao.ePayTransactionDetail).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(paymentDao.getAllPaymentStates).toHaveBeenCalledTimes(1);
      expect(orderDao.fetchOrderByOrderNumber).not.toHaveBeenCalledTimes(1);
    });

    test('cart payment success', async () => {
      cartPaymentInfo.paymentInfo.payments[0].paymentStatus.state.key = PAYMENT_STATE_KEYS.success;
      await paymentService.getPaymentStatus(
        market,
        authorization,
        cart.id,
        orderNumber,
        transactionId,
        param,
      );

      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(paymentDao.ePayTransactionDetail).not.toHaveBeenCalledTimes(1);
      expect(paymentDao.getAllPaymentStates).not.toHaveBeenCalledTimes(1);
      expect(orderDao.fetchOrderByOrderNumber).toHaveBeenCalledTimes(1);
    });

    test('fetchOrderByOrderNumber res arr is empty', async () => {
      (orderDao.fetchOrderByOrderNumber as Mock) = jest.fn().mockReturnValueOnce([]);

      const orderId = await (paymentService as any).getOrderAndNotifyApptus(
        market,
        orderNumber,
        param,
      );

      expect(orderDao.fetchOrderByOrderNumber).toHaveBeenCalledTimes(2);
      expect(notificationsDao.paymentNotifications).not.toHaveBeenCalledTimes(1);
      expect(orderDao.fetchOrderByOrderNumber).toHaveBeenNthCalledWith(
        1,
        market,
        orderNumber,
      );
      expect(orderId).toBe(undefined);
    });

    // test('transaction captured and cart payment pending', async () => {
    //   ePayTransaction.status = E_PAYMENT_STATUS.captured;
    //   cartPaymentInfo.paymentInfo.payments[0].paymentStatus.state.key = PAYMENT_STATE_KEYS.pending;
    //   orderNumber = '';
    //   const orderError = await paymentService.getPaymentStatus(
    //     market,
    //     authorization,
    //     cart.id,
    //     orderNumber,
    //     transactionId,
    //     param,
    //   );

    //   await expect(orderError).rejects.toThrow(
    //     new ApiError(500, `The cart with ID ${cart.id} does not have a billing address set.`),
    //   );
    //   expect(paymentDao.ePayTransactionDetail).toHaveBeenCalledTimes(1);
    //   expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
    //   expect(paymentDao.ePayTransactionDetail).toHaveBeenNthCalledWith(
    //     1,
    //     market,
    //     transactionId,
    //     0,
    //   );
    // });
  });
});
