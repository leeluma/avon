import i18next from 'i18next';
import faker from '@faker-js/faker';

import { OrderService } from '../../src/services';
import { OrderDao } from '../../src/daos';
import { MagnoliaDao } from '../../src/daos/magnolia.dao';
import { MarketInfo } from '../../src/middlewares';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import { OrderMapper } from '../../src/mappers';
import {
  stubGlobalSettings,
  stubMagnoliaInfo, stubMarket, stubOrderDto,
} from '../__stubs__';
import Mock = jest.Mock;
import { ApiError } from '../../src/lib';
import { bootstrapI18next } from '../helpers';
import { OrderDto } from '../../src/dtos/order.dto';

describe('OrderService', () => {
  let market: MarketInfo;
  let magnolia: MagnoliaInfo;
  let orderService: OrderService;

  let orderDao: OrderDao;
  let magnoliaDao: MagnoliaDao;

  let orderMapper: OrderMapper;

  let orderDto: OrderDto;

  beforeAll(async () => {
    await bootstrapI18next();
  });

  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();

    orderDao = {
      orderDetails: jest.fn(),
    } as any;

    orderDao = {} as any;
    magnoliaDao = {} as any;
    orderDto = stubOrderDto();

    orderMapper = {
      mapOrderDetails: jest.fn(),
    } as any;

    orderService = new OrderService({ orderDao, magnoliaDao, orderMapper });
  });

  describe('orderDetails()', () => {
    let orderId;
    let graphQlResponse;
    let globalSettings;
    let authHeader;
    beforeEach(() => {
      orderId = faker.datatype.uuid();
      authHeader = faker.datatype.string();
      orderDao.fetchOrder = jest.fn();
      orderDao.fetchProductsDetail = jest.fn();
      magnoliaDao.getGlobalSettings = jest.fn();
      orderMapper.mapOrderDetails = jest.fn();

      globalSettings = stubGlobalSettings();
      graphQlResponse = {
        // code here
        lineItems: [{
          // code here
        }],
      };
    });

    test('reads the order by id', async () => {
      /* (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings); */
      const productsData = [{
        id: faker.datatype.uuid(),
        name: faker.datatype.string(),
      }];
      (orderDao.fetchOrder as Mock).mockReturnValueOnce(graphQlResponse);
      (orderDao.fetchProductsDetail as Mock).mockReturnValueOnce(productsData);
      (orderMapper.mapOrderDetails as Mock).mockReturnValueOnce(orderDto);

      await orderService.orderDetails(authHeader, market, orderId, globalSettings.priceFormat);

      // expect(magnoliaDao.getGlobalSettings).toHaveBeenCalledTimes(1);
      expect(orderDao.fetchOrder).toHaveBeenCalledTimes(1);
      expect(orderMapper.mapOrderDetails).toHaveBeenCalledTimes(1);
    });

    test('throws error if order is not found', async () => {
      /* (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings); */
      (orderDao as any).fetchOrder = jest.fn().mockReturnValueOnce(undefined);
      (orderMapper.mapOrderDetails as Mock).mockReturnValueOnce(undefined);

      const expectedError = new ApiError(404, i18next.t('error.orderIdNotFound', { orderId }));
      /* Execute */
      await expect(
        orderService.orderDetails(
          authHeader,
          market,
          orderId,
          globalSettings.priceFormat,
        ),
      ).rejects.toThrow(expectedError);

      expect(orderMapper.mapOrderDetails).not.toHaveBeenCalled();
    });
  });
});
