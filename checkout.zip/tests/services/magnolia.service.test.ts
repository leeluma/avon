import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { MagnoliaInfo } from '../../src/dtos';
import {
  stubMarket, stubMagnoliaInfo, stubMagnoliaHome, stubMagnoliaData,
} from '../__stubs__';
import { MagnoliaDao } from '../../src/daos';
import { MagnoliaService } from '../../src/services/magnolia.service';
import Mock = jest.Mock;

describe('LeapApp', () => {
  /* System Under Test */
  let magnoliaService: MagnoliaService;

  /* Dependencies */
  let magnoliaDao: MagnoliaDao;
  let market: MarketInfo;
  let magnolia: MagnoliaInfo;
  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();

    /* Dependencies */
    magnoliaDao = {} as any;

    /* SUT */
    magnoliaService = new MagnoliaService({ magnoliaDao });
  });

  /**
   * Unit test case for Get Magnolia Data
   */
  describe('Get Magnolia Data', () => {
    beforeEach(() => {
      magnoliaDao.getCheckoutPageData = jest.fn();
      magnoliaDao.getDefaultWarehouse = jest.fn();
      magnoliaDao.getGlobalSettings = jest.fn();
      magnoliaDao.getTemplateDataFromMagnolia = jest.fn();
      magnoliaDao.getOrderConfirmationPageData = jest.fn();
    });

    test('fetches Checkout data from Magnolia', async () => {
      /* Prepare */
      (magnoliaDao.getCheckoutPageData as Mock).mockReturnValueOnce(stubMagnoliaHome);
      /* Execute */
      const result = await magnoliaService.getCheckoutPageData(market, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaDao.getCheckoutPageData).toHaveBeenCalledTimes(1);
    });

    test('fetches template data from Magnolia', async () => {
      /* Prepare */
      const templateName = faker.datatype.string();
      const magnoliaBasePath = faker.datatype.string();
      (magnoliaDao.getTemplateDataFromMagnolia as Mock).mockReturnValueOnce(stubMagnoliaHome);

      /* Execute */
      const result = await magnoliaService.getTemplateData(templateName, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaDao.getTemplateDataFromMagnolia).toHaveBeenCalledTimes(1);
    });

    test('fetches global settings from Magnolia', async () => {
      /* Prepare */
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(stubMagnoliaHome);
      /* Execute */
      const result = await magnoliaService.getGlobalSettingsData(market, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaDao.getGlobalSettings).toHaveBeenCalledTimes(1);
    });

    test('fetches order data from Magnolia', async () => {
      /* Prepare */
      (magnoliaDao.getOrderConfirmationPageData as Mock).mockReturnValueOnce(stubMagnoliaData());
      /* Execute */
      const result = await magnoliaService.getOrderConfirmationPageData(market, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaDao.getOrderConfirmationPageData).toHaveBeenCalledTimes(1);
    });
  });
});
