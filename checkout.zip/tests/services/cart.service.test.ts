import faker from '@faker-js/faker';
import i18next from 'i18next';
import { Customer } from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import { MarketInfo } from '../../src/middlewares';
import { ShippingMethodMapper, CartMapper, AddressMapper } from '../../src/mappers';
import {
  stubMarket, stubCtCartDto, stubShippingMethodsForCartResponseDto,
  stubCtCartLineItemDraftDto, stubCtCartDraftDto, stubGlobalSettings, stubMagnoliaInfo,
  stubPriceFormatSettings, stubCustomerDto, stubDetailResponseDto, stubAddressRequestDto,
  stubMagnoliaHome,
} from '../__stubs__';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import {
  CartDao, AddressDao, MagnoliaDao, OrderDao,
} from '../../src/daos';
import { CartService } from '../../src/services';
import Mock = jest.Mock;
import {
  ShippingMethodsResponseDto,
  CartDto,
  CTCartDraftDto,
  CTLineItemDto,
  CartShippingMethodDto,
  AddressRequestDto,
  DetailResponseDto,
} from '../../src/dtos';
import { ApiError } from '../../src/lib';

describe('LeapApp', () => {
  /* System Under Test */
  let cartService: CartService;
  let magnoliaInfo: MagnoliaInfo;
  /* Dependencies */
  let cartDao: CartDao;
  let addressDao: AddressDao;
  let shippingMethodMapper: ShippingMethodMapper;
  let cartMapper: CartMapper;
  let addressMapper: AddressMapper;
  let market: MarketInfo;
  let authHeader;
  let magnoliaDao: MagnoliaDao;
  let globalSettings;
  let orderDao: OrderDao;

  beforeEach(() => {
    market = stubMarket();
    authHeader = faker.datatype.string();
    globalSettings = stubGlobalSettings();
    magnoliaInfo = stubMagnoliaInfo();
    /* Dependencies */
    cartDao = { getCartPaymentInfo: jest.fn(), recalculateCart: jest.fn() } as any;
    addressDao = {
      addressDetail: jest.fn(),
      getPickupDetail: jest.fn(),
    } as any;
    shippingMethodMapper = { cartToDto: jest.fn() } as any;
    magnoliaDao = { getPriceFormatSettings: jest.fn() } as any;

    /* SUT */
    cartMapper = {
      cartToDto: jest.fn(),
      createCartResponse: jest.fn(),
      createCartResponseForShippingMethodAdded: jest.fn(),
    } as any;
    addressMapper = {
      createAddressDraftFromDetails: jest.fn(),
      createAddressDraftFromCustomerAddressId: jest.fn(),
    } as any;
    orderDao = { fetchProductsDetail: jest.fn() } as any;

    /* SUT */
    cartService = new CartService({
      shippingMethodMapper, cartMapper, cartDao, addressDao, addressMapper, magnoliaDao, orderDao,
    });
  });

  describe('setShippingAddress()', () => {
    let cartDto: CartDto;
    let cartDraftDto: CTCartDraftDto;
    let addressRequestDto: AddressRequestDto;
    let lineItemDraftDto: CTLineItemDto;
    let authToken: string;
    let addressType: string;
    let recipientName: string;
    let customer: Customer;
    let cartPaymentInfoData: any;
    beforeEach(() => {
      addressRequestDto = stubAddressRequestDto();
      magnoliaDao.getGlobalSettings = jest.fn();
      customer = stubCustomerDto();
      cartDao.getCartById = jest.fn();
      cartDao.setShippingAddress = jest.fn();
      cartDto = stubCtCartDto();
      authToken = faker.datatype.uuid();
      addressType = faker.datatype.string();
      recipientName = faker.datatype.string();
      lineItemDraftDto = stubCtCartLineItemDraftDto();
      cartDraftDto = stubCtCartDraftDto({
        lineItems: [lineItemDraftDto],
        shippingAddress: addressRequestDto,
      });
      cartPaymentInfoData = {
        isPaymentInitiated: false,
      };
    });

    test('add shipping address from cartDao', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);

      /* Execute */
      await cartService.setShippingAddress(
        market,
        globalSettings.priceFormat,
        cartDto.id,
        authToken,
        customer,
        addressRequestDto,
      );

      /* Verify */
      expect(cartDao.getCartById).toHaveBeenCalledTimes(1);
      expect(cartDao.setShippingAddress).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartById).toHaveBeenNthCalledWith(
        1,
        market.country,
        cartDto.id,
      );
      expect(cartMapper.cartToDto).toHaveBeenNthCalledWith(
        1,
        cartDraftDto,
        market,
        globalSettings.priceFormat,
      );
    });

    test('returns the cartDto from mapper', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartService
        .setShippingAddress(market, globalSettings.priceFormat, cartDto.id, authToken, customer, addressRequestDto);

      /* Verify */
      expect(response).toBe(cartDto);
    });

    test('returns the cartDto from mapper if recipientName is undefined', async () => {
      /* Prepare */
      delete addressRequestDto.recipientName;
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartService
        .setShippingAddress(market, globalSettings.priceFormat, cartDto.id, authToken, customer, addressRequestDto);

      /* Verify */
      expect(response).toBe(cartDto);
    });

    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getCartById as Mock).mockReturnValueOnce(undefined);

      const expectedError = new ApiError(404, i18next.t('error.cartIdNotFound', { cartId: cartDto.id }));

      /* Execute */
      await expect(() => cartService
        .setShippingAddress(market, globalSettings.priceFormat, cartDto.id, authToken, customer, addressRequestDto))
        .rejects.toThrow(expectedError);

      /* Verify */
      expect(cartDao.setShippingAddress).not.toHaveBeenCalled();
      expect(cartMapper.cartToDto).not.toHaveBeenCalled();
    });
  });

  describe('getShippingMethods()', () => {
    let shippingMethodTOCartDto: ShippingMethodsResponseDto[];
    let finalMapperResp: any;
    let response: any;
    let shippingKind = 'Courier';
    beforeEach(() => {
      cartDao.getShippingMethods = jest.fn();
      magnoliaDao.getGlobalSettings = jest.fn();
      shippingMethodMapper.shippingMethodCartToDto = jest.fn();
      shippingMethodTOCartDto = stubShippingMethodsForCartResponseDto();
      finalMapperResp = stubShippingMethodsForCartResponseDto();
      response = {
        data: shippingMethodTOCartDto,
      };
    });
    test('fetches data from shipping methods by cartDao Courier', async () => {
      /* Prepare */
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getShippingMethods as Mock).mockReturnValueOnce(response);
      (shippingMethodMapper.shippingMethodCartToDto as Mock).mockReturnValueOnce(finalMapperResp);
      /* Execute */
      await cartService.getShippingMethods(market, shippingKind);

      /* Verify */
      expect(cartDao.getShippingMethods).toHaveBeenCalledTimes(1);
      expect(cartDao.getShippingMethods).toHaveBeenNthCalledWith(
        1,
        market,
        shippingKind,
      );
      expect(shippingMethodMapper.shippingMethodCartToDto).toHaveBeenCalledTimes(1);
      expect(shippingMethodMapper.shippingMethodCartToDto).toHaveBeenNthCalledWith(
        1,
        response.data.shippingMethodsByCart,
      );
    });
    test('fetches data from shipping methods by cartDao Parcelshop', async () => {
      /* Prepare */
      shippingKind = 'Parcelshop';
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getShippingMethods as Mock).mockReturnValueOnce(response);
      (shippingMethodMapper.shippingMethodCartToDto as Mock).mockReturnValueOnce(finalMapperResp);
      /* Execute */
      await cartService.getShippingMethods(market, 'Pickup');

      /* Verify */
      expect(cartDao.getShippingMethods).toHaveBeenCalledTimes(1);
      expect(shippingMethodMapper.shippingMethodCartToDto).toHaveBeenCalledTimes(1);
      expect(shippingMethodMapper.shippingMethodCartToDto).toHaveBeenNthCalledWith(
        1,
        response.data.shippingMethodsByCart,
      );
    });

    // test('Throw error', async () => {
    //   /* Prepare */
    //   (cartDao.getShippingMethods as Mock).mockReturnValueOnce({ data: null });

    //   /* Execute */
    //   const result = expect(() => cartService.getShippingMethods(market, shippingKind));
    //   /* Verify */
    //   await result.rejects.toThrow(
    //     new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartShippingMethodsNotFound')),
    //   );
    // });
  });
  describe('addShippingMethod()', () => {
    let cartDto: CartShippingMethodDto;
    let cartDraftDto: CTCartDraftDto;
    let shippingMethodId: string;
    let lineItemDraftDto: CTLineItemDto;
    let cartPaymentInfoData: any;
    beforeEach(() => {
      shippingMethodId = faker.datatype.uuid();
      cartDao.getCartById = jest.fn();
      cartDao.addShippingMethod = jest.fn();
      cartDto = {
        id: faker.datatype.uuid(),
        version: faker.datatype.number(),
        customerId: faker.datatype.uuid(),
        paymentSummary: {
          subTotalPrice: faker.commerce.price(),
          discount: faker.commerce.price(),
          deliveryPrice: faker.commerce.price(),
          totalPrice: faker.commerce.price(),
        },
      };
      lineItemDraftDto = stubCtCartLineItemDraftDto();
      cartDraftDto = stubCtCartDraftDto({
        lineItems: [lineItemDraftDto],
        shippingAddress: {
          id: faker.datatype.uuid(),
        },
        shippingInfo: {
          shippingMethodName: faker.random.word(),
          price: {
            type: faker.random.word(),
            currencyCode: faker.random.word(),
            centAmount: faker.datatype.number(),
            fractionDigits: faker.datatype.number(),
          },
        },
      });
      cartPaymentInfoData = {
        isPaymentInitiated: false,
      };
    });

    test('add shipping method from cartDao', async () => {
      /* Prepare */

      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce({});
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.addShippingMethod as Mock).mockReturnValueOnce(cartDraftDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);
      (cartMapper.createCartResponseForShippingMethodAdded as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      await cartService.addShippingMethod(market, cartDto.id, shippingMethodId, authHeader);

      /* Verify */
      expect(cartDao.getCartById).toHaveBeenCalledTimes(1);
      expect(cartDao.addShippingMethod).toHaveBeenCalledTimes(1);
      expect(cartMapper.createCartResponseForShippingMethodAdded).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartById).toHaveBeenNthCalledWith(
        1,
        market.country,
        cartDto.id,
      );
      expect(cartDao.addShippingMethod).toHaveBeenNthCalledWith(
        1,
        market.country,
        cartDraftDto,
        shippingMethodId,
        authHeader,
      );
      expect(cartMapper.createCartResponseForShippingMethodAdded).toHaveBeenNthCalledWith(
        1,
        cartDraftDto,
        stubPriceFormatSettings,
      );
    });

    test('returns the cartDto from mapper', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce({});
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.addShippingMethod as Mock).mockReturnValueOnce(cartDraftDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);
      (cartMapper.createCartResponseForShippingMethodAdded as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartService.addShippingMethod(market, cartDto.id, shippingMethodId, authHeader);

      /* Verify */
      expect(response).toBe(cartDto);
    });

    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (cartDao.getCartById as Mock).mockReturnValueOnce(undefined);

      const expectedError = new ApiError(404, i18next.t('error.cartIdNotFound', { cartId: cartDto.id }));

      /* Execute */
      await expect(() => cartService.addShippingMethod(market, cartDto.id, shippingMethodId, authHeader))
        .rejects.toThrow(expectedError);

      /* Verify */
      expect(cartDao.addShippingMethod).not.toHaveBeenCalled();
      expect(cartMapper.cartToDto).not.toHaveBeenCalled();
    });

    test('returns error shipping address is not set for cart', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValue({ isPaymentInitiated: false, cart: undefined });
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      delete cartDraftDto.shippingAddress;

      const expectedError = new ApiError(400, i18next.t('error.shippingAddressNotSet', { cartId: cartDto.id }));

      /* Execute */
      await expect(() => cartService.addShippingMethod(market, cartDto.id, shippingMethodId, authHeader))
        .rejects.toThrow(expectedError);

      /* Verify */
      expect(cartDao.addShippingMethod).not.toHaveBeenCalled();
      expect(cartMapper.cartToDto).not.toHaveBeenCalled();
    });
  });

  describe('setShippingAddressFromCustomerId()', () => {
    let cartDto: CartDto;
    let cartDraftDto: CTCartDraftDto;
    let addressRequestDto: AddressRequestDto;
    let lineItemDraftDto: CTLineItemDto;
    let authToken: string;
    let customer: Customer;
    let addressDetail: DetailResponseDto;
    let cartPaymentInfoData: any;
    beforeEach(() => {
      magnoliaDao.getGlobalSettings = jest.fn();
      addressRequestDto = stubAddressRequestDto();
      cartDao.getCartById = jest.fn();
      cartDao.setShippingAddress = jest.fn();
      cartDto = stubCtCartDto();
      customer = stubCustomerDto();
      authToken = faker.datatype.uuid();
      lineItemDraftDto = stubCtCartLineItemDraftDto();
      addressDetail = stubDetailResponseDto();
      cartDraftDto = stubCtCartDraftDto({
        lineItems: [lineItemDraftDto],
        shippingAddress: addressRequestDto,
      });
      cartPaymentInfoData = {
        isPaymentInitiated: false,
      };
    });

    test('add shipping address from cartDao', async () => {
      /* Prepare */
      customer = stubCustomerDto({
        addresses: [addressRequestDto],
      });
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);
      (addressMapper.createAddressDraftFromCustomerAddressId as Mock).mockReturnValueOnce(addressRequestDto);

      /* Execute */
      await cartService
        .setShippingAddressFromCustomerId(
          market,
          globalSettings.priceFormat,
          cartDto.id,
          authToken,
          customer,
          addressRequestDto,
        );

      /* Verify */
      expect(addressMapper.createAddressDraftFromCustomerAddressId).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartById).toHaveBeenCalledTimes(1);
      expect(cartDao.setShippingAddress).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartById).toHaveBeenNthCalledWith(
        1,
        market.country,
        cartDto.id,
      );
      expect(cartMapper.cartToDto).toHaveBeenNthCalledWith(
        1,
        cartDraftDto,
        market,
        globalSettings.priceFormat,
      );
    });

    test('shippingAddressDetails is undefined', async () => {
      /* Prepare */
      customer = stubCustomerDto();
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);
      (addressDao.addressDetail as Mock).mockReturnValueOnce(addressDetail);
      /* Execute */
      const result = expect(() => cartService
        .setShippingAddressFromCustomerId(
          market,
          globalSettings.priceFormat,
          cartDto.id,
          authToken,
          customer,
          addressRequestDto,
        ));
      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.addressNotFound')),
      );
    });

    test('returns the cartDto from mapper', async () => {
      /* Prepare */
      customer = stubCustomerDto({
        addresses: [addressRequestDto],
      });
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartService
        .setShippingAddressFromCustomerId(
          market,
          globalSettings.priceFormat,
          cartDto.id,
          authToken,
          customer,
          addressRequestDto,
        );

      /* Verify */
      expect(response).toBe(cartDto);
    });

    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getCartById as Mock).mockReturnValueOnce(undefined);
      (cartDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);
      addressRequestDto.addressId = customer.addresses[0].id;

      const expectedError = new ApiError(404, i18next.t('error.cartIdNotFound', { cartId: cartDto.id }));

      /* Execute */
      await expect(() => cartService
        .setShippingAddressFromCustomerId(
          market,
          globalSettings.priceFormat,
          cartDto.id,
          authToken,
          customer,
          addressRequestDto,
        ))
        .rejects.toThrow(expectedError);

      /* Verify */
      expect(cartDao.setShippingAddress).not.toHaveBeenCalled();
      expect(cartMapper.cartToDto).not.toHaveBeenCalled();
    });
  });

  describe('setShippingAddressFromFinder()', () => {
    let cartDto: CartDto;
    let cartDraftDto: CTCartDraftDto;
    let addressRequestDto: AddressRequestDto;
    let lineItemDraftDto: CTLineItemDto;
    let authToken: string;
    let addressDetail: DetailResponseDto;
    let customer: Customer;
    let cartPaymentInfoData: any;
    beforeEach(() => {
      magnoliaDao.getGlobalSettings = jest.fn();
      addressRequestDto = stubAddressRequestDto();
      cartDao.getCartById = jest.fn();
      addressDao.addressDetail = jest.fn();
      cartDao.setShippingAddress = jest.fn();
      cartDto = stubCtCartDto();
      authToken = faker.datatype.uuid();

      customer = stubCustomerDto({
        addresses: [addressRequestDto],
      });
      addressDetail = stubDetailResponseDto();
      lineItemDraftDto = stubCtCartLineItemDraftDto();
      cartDraftDto = stubCtCartDraftDto({
        lineItems: [lineItemDraftDto],
        shippingAddress: addressRequestDto,
      });
      cartPaymentInfoData = {
        isPaymentInitiated: false,
      };
    });

    test('add shipping address from cartDao', async () => {
      /* Prepare */
      const detailResponseDto = [stubDetailResponseDto()];
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (addressDao.addressDetail as Mock).mockReturnValueOnce({ detailResponseDto });
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);

      /* Execute */
      await cartService
        .setShippingAddressFromFinder(
          market,
          globalSettings.priceFormat,
          cartDto.id,
          authToken,
          customer,
          addressRequestDto,
        );

      /* Verify */
      expect(cartDao.setShippingAddress).toHaveBeenCalledTimes(1);
      expect(cartMapper.cartToDto).toHaveBeenNthCalledWith(
        1,
        cartDraftDto,
        market,
        globalSettings.priceFormat,
      );
    });

    test('add shipping address from cartDao if recipientName is undefined', async () => {
      /* Prepare */
      delete addressRequestDto.recipientName;
      const detailResponseDto = [stubDetailResponseDto()];
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (addressDao.addressDetail as Mock).mockReturnValueOnce({ detailResponseDto });
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);

      /* Execute */
      await cartService
        .setShippingAddressFromFinder(
          market,
          globalSettings.priceFormat,
          cartDto.id,
          authToken,
          customer,
          addressRequestDto,
        );

      /* Verify */
      expect(cartDao.setShippingAddress).toHaveBeenCalledTimes(1);
      expect(cartMapper.cartToDto).toHaveBeenNthCalledWith(
        1,
        cartDraftDto,
        market,
        globalSettings.priceFormat,
      );
    });

    test('shippingAddressDetails is undefined', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);
      (addressDao.addressDetail as Mock).mockReturnValueOnce(undefined);

      /* Execute */
      const result = expect(() => cartService
        .setShippingAddressFromFinder(
          market,
          globalSettings.priceFormat,
          cartDto.id,
          authToken,
          customer,
          addressRequestDto,
        ));
      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.addressNotFound')),
      );
    });

    test('returns the cartDto from mapper', async () => {
      /* Prepare */
      const detailResponseDto = [stubDetailResponseDto()];
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (addressDao.addressDetail as Mock).mockReturnValueOnce({ detailResponseDto });
      (cartDao.getCartById as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.setShippingAddress as Mock).mockReturnValueOnce(cartDraftDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartDto);

      /* Execute */
      const response = await cartService
        .setShippingAddressFromFinder(
          market,
          globalSettings.priceFormat,
          cartDto.id,
          authToken,
          customer,
          addressRequestDto,
        );

      /* Verify */
      expect(response).toBe(cartDto);
    });

    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      const detailResponseDto = [stubDetailResponseDto()];
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfoData);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (addressDao.addressDetail as Mock).mockReturnValueOnce({ detailResponseDto });
      (cartDao.getCartById as Mock).mockReturnValueOnce(undefined);

      const expectedError = new ApiError(404, i18next.t('error.cartIdNotFound', { cartId: cartDto.id }));

      /* Execute */
      await expect(() => cartService
        .setShippingAddressFromFinder(
          market,
          globalSettings.priceFormat,
          cartDto.id,
          authToken,
          customer,
          addressRequestDto,
        ))
        .rejects.toThrow(expectedError);

      /* Verify */
      expect(cartDao.setShippingAddress).not.toHaveBeenCalled();
      expect(cartMapper.cartToDto).not.toHaveBeenCalled();
    });
  });

  describe('getCartPaymentInfo()', () => {
    let cartDto: CartDto;
    let cartId: string;
    let stubCartWithPaymentInfo;
    let paymentInfo;

    beforeEach(() => {
      magnoliaDao.getGlobalSettings = jest.fn();
      cartId = faker.datatype.uuid();
      cartDao.getCartPaymentInfo = jest.fn();
      cartDao.replicateCartById = jest.fn();
      cartDto = stubCtCartDto();
      paymentInfo = {
        paymentInfo: {
          payments: [{
            paymentStatus: {
              state: {
                key: 'initial',
              },
            },
          }],
        },
      };
      stubCartWithPaymentInfo = {
        ...cartDto,
        paymentInfo,
      };
    });

    test('fetches data from cartDao', async () => {
      /* Prepare */
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(paymentInfo);
      (cartDao.replicateCartById as Mock).mockReturnValueOnce(stubCartWithPaymentInfo);

      /* Execute */
      const result = await cartService.checkCartPaymentInfo(market, cartId, authHeader);

      /* Verify */
      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartPaymentInfo).toHaveBeenNthCalledWith(
        1,
        market,
        cartId,
        authHeader,
      );
      expect(cartDao.replicateCartById).toHaveBeenCalledTimes(1);
      expect(result.isPaymentInitiated).toBe(true);
      expect(result.cart).toBe(stubCartWithPaymentInfo);
    });

    test('returns isPaymentInitiated false', async () => {
      /* Prepare */
      const cartPaymentInfo = {
        paymentInfo: {
          payments: [{
            paymentStatus: {
              state: {
                name: null,
              },
            },
          }],
        },
      };
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfo);

      /* Execute */
      const result = await cartService.checkCartPaymentInfo(market, cartId, authHeader);

      /* Verify */
      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(result.isPaymentInitiated).toBe(false);
      expect(cartDao.replicateCartById).not.toHaveBeenCalled();
    });

    test('returns isPaymentInitiated false if does not match payments', async () => {
      /* Prepare */
      const cartPaymentInfo = {
        paymentInfo: {
          payments: [],
        },
      };
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfo);

      /* Execute */
      const result = await cartService.checkCartPaymentInfo(market, cartId, authHeader);

      /* Verify */
      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(result.isPaymentInitiated).toBe(false);
      expect(cartDao.replicateCartById).not.toHaveBeenCalled();
    });

    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartIdNotFound', { cartId }));
      /* Execute */
      await expect(() => cartService.checkCartPaymentInfo(market, cartId, authHeader))
        .rejects.toThrow(expectedError);

      /* Verify */
      expect(cartDao.replicateCartById).not.toHaveBeenCalled();
    });
  });
  describe('getCartById()', () => {
    let cartId: string;
    let responseWithUndefined: any;
    let cartDto: CartDto;

    let cartDraftDto: CTCartDraftDto;
    let lineItemDraftDto: CTLineItemDto;

    const paymentInfo = {
      paymentInfo: {
        payments: [{
          paymentStatus: {
            state: {
              key: 'initial',
            },
          },
        }],
      },
    };

    beforeEach(() => {
      magnoliaDao.getGlobalSettings = jest.fn();
      cartId = faker.datatype.uuid();
      cartDao.getCartByIdGraphql = jest.fn();
      cartDto = stubCtCartDto();
      responseWithUndefined = '';
      lineItemDraftDto = stubCtCartLineItemDraftDto();
      cartDraftDto = stubCtCartDraftDto({
        lineItems: [lineItemDraftDto],
      });
    });
    test('fetches data from shipping method by cart id cartDao', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(paymentInfo);
      (cartDao.getCartByIdGraphql as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.recalculateCart as Mock).mockReturnValueOnce(cartDraftDto);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartMapper.createCartResponse as Mock).mockReturnValueOnce(cartDto);
      (orderDao.fetchProductsDetail as Mock).mockReturnValueOnce([]);

      /* Execute */
      await cartService.getCartById(market, globalSettings.priceFormat, cartId, authHeader);
      /* Verify */
      expect(cartDao.getCartByIdGraphql).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartByIdGraphql).toHaveBeenNthCalledWith(
        1,
        market,
        cartId,
        authHeader,
      );
      expect(cartMapper.createCartResponse).toHaveBeenCalledTimes(1);
      expect(cartMapper.createCartResponse).toHaveBeenNthCalledWith(
        1,
        cartDraftDto,
        globalSettings.priceFormat,
        [],
      );
    });
    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (cartDao.recalculateCart as Mock).mockReturnValueOnce(cartDraftDto);
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(paymentInfo);
      (cartDao.getCartByIdGraphql as Mock).mockReturnValueOnce(null);
      (orderDao.fetchProductsDetail as Mock).mockReturnValueOnce([]);

      /* Execute */
      const result = await cartService.getCartById(market, magnoliaInfo, cartId, authHeader);

      /* Verify */
      expect(result).toEqual(undefined);
    });
    // test('returns undefined if the cart does not exist', async () => {
    //   /* Prepare */
    //   (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
    //   (cartDao.getCartByIdGraphql as Mock).mockReturnValueOnce(responseWithUndefined);
    //   const expectedError = new ApiError(404, i18next.t('error.cartIdNotFound', { cartId }));
    //   /* Execute */
    //   await expect(cartService.getCartById(market, globalSettings.priceFormat, cartId, authHeader))
    //     .rejects.toThrow(expectedError);
    //   /* Verify */
    //   expect(cartMapper.createCartResponse).not.toHaveBeenCalled();
    // });
  });
});
