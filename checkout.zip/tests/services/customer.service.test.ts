import { Request } from 'express';
import faker from '@faker-js/faker';
import {
  Address, AddressDraft, Customer, FieldContainer,
} from '@commercetools/platform-sdk';
import i18next from 'i18next';
import HttpStatusCodes from 'http-status-codes';
import { MarketInfo } from '../../src/middlewares';
import { CustomerDao, AddressDao, OrderDao } from '../../src/daos';
import { ApiError, AwsEventBridgeClient, addressCustomTypeKey } from '../../src/lib';
import {
  stubMarket, stubExpressReq, stubCustomerDto, stubAddressRequestDto,
  stubAddressResponseDto, stubAddressDto, stubAddressDraftDto,
  stubCustomerWithoutAddressDto, stubCustomerRequestDto,
  stubCustomerRegisterRequestDto,
  stubGraphQLOrder,
  stubCustomerLoginResponseDto,
} from '../__stubs__';
import { CustomerService } from '../../src/services';
import { AddressMapper, CustomerMapper } from '../../src/mappers';
import {
  AddressRequestDto, AddressCollectionResponseDto, CustomerRegistrationRequestDto,
} from '../../src/dtos';
import Mock = jest.Mock;

const REGEXP_UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

type Writeable<T> = { -readonly [P in keyof T]: T[P] };

describe('CustomerService', () => {
  let customerService: CustomerService;
  let customerDao: CustomerDao;
  let addressDao: AddressDao;
  let orderDao: OrderDao;
  let market: MarketInfo;
  let eventBridgeClient: AwsEventBridgeClient;
  let addressMapper: AddressMapper;
  let customerMapper: CustomerMapper;
  let graphQLDefaultAddress: Customer;
  let authHeader: string;
  let req: Request;
  let passwordResetEventBusName: string;

  beforeEach(() => {
    /* Stubs */
    market = stubMarket({
      locale: 'ro',
      country: 'RO',
    });
    customerDao = {
      getCustomerDetailsGraphQL: jest.fn(),
      updateCustomer: jest.fn(),
    } as any;
    addressDao = {
      addressDetail: jest.fn(),
    } as any;
    orderDao = {
      orderDetails: jest.fn(),
    } as any;
    addressMapper = {
      mapAddressResponse: jest.fn(),
      mapGraphQLAddressResponse: jest.fn(),
      mapAddressCollectionResponse: jest.fn(),
      createAddressDraftFromDetails: jest.fn(),
      mapToFields: jest.fn(),
      mapCustomerResponse: jest.fn(),
    } as any;
    customerMapper = {
      mapCustomerResponse: jest.fn(),
      mapGraphQLCustomerResponse: jest.fn(),
    } as any;
    eventBridgeClient = { putEvent: jest.fn().mockReturnValueOnce({}) } as any;

    req = stubExpressReq();

    passwordResetEventBusName = `arn:123:/event-bus/${faker.random.word().toLowerCase()}`;

    /* SUT */
    customerService = new CustomerService({
      customerDao,
      addressDao,
      eventBridgeClient,
      addressMapper,
      passwordResetEventBusName,
      customerMapper,
      orderDao,
    });
    graphQLDefaultAddress = stubCustomerDto();
    authHeader = `Bearer ${faker.random.randomWord()}`;
    req.headers.authorization = authHeader;
  });

  describe('forgotCustomersPassword()', () => {
    let email: string;
    let url: string;

    beforeEach(() => {
      customerDao.forgotCustomersPassword = jest.fn();
      customerDao.findGraphQLOne = jest.fn();
      orderDao.fetchOrder = jest.fn();
      email = faker.internet.email();
      url = faker.internet.url();
    });

    test('call forgotCustomersPassword method', async () => {
      /* Prepare */
      (customerDao.forgotCustomersPassword as Mock)
        .mockReturnValueOnce({ lastName: faker.datatype.string(), firstName: faker.datatype.string() });
      (customerDao.findGraphQLOne as Mock)
        .mockReturnValueOnce({ lastName: faker.datatype.string(), firstName: faker.datatype.string() });

      /* Execute */
      await customerService.forgotCustomersPassword(market, email, url);

      /* Verify */
      expect(customerDao.forgotCustomersPassword).toHaveBeenCalledTimes(1);
      expect(customerDao.forgotCustomersPassword).toHaveBeenNthCalledWith(
        1,
        market,
        email,
      );
    });

    test('throws UNAUTHORIZED if CT rejects the token', async () => {
      /* Prepare */
      (customerDao.forgotCustomersPassword as Mock).mockReturnValueOnce(false);
      const expectedError = new ApiError(401, 'Failed to reset password. Email Id does not exist');

      /* Execute */
      const execute = () => customerService.forgotCustomersPassword(market, email, url);

      /* Verify */
      await expect(execute).rejects.toThrow(expectedError);
    });
  });

  describe('getDefaultAddress()', () => {
    test('returns undefined if defaultAddress do not exist', async () => {
      /* Prepare */
      (customerDao.getCustomerDetailsGraphQL as Mock).mockReturnValueOnce(
        stubCustomerDto({ defaultShippingAddressId: faker.random.randomWord() }),
      );
      (addressMapper.mapGraphQLAddressResponse as Mock).mockReturnValueOnce(stubCustomerDto().addresses);

      /* Execute */
      await customerService.getDefaultAddress(market, authHeader);

      /* Verify */
      expect(customerDao.getCustomerDetailsGraphQL).toHaveBeenCalledTimes(1);
    });

    test('returns defaultAddress', async () => {
      /* Prepare */
      (customerDao.getCustomerDetailsGraphQL as Mock).mockReturnValueOnce(graphQLDefaultAddress);
      (addressMapper.mapGraphQLAddressResponse as Mock).mockReturnValueOnce(graphQLDefaultAddress.addresses);

      /* Execute */
      await customerService.getDefaultAddress(market, authHeader);

      /* Verify */
      expect(customerDao.getCustomerDetailsGraphQL).toHaveBeenCalledTimes(1);
    });
  });
  describe('getCustomerDetailsByToken()', () => {
    test('returns customer response', async () => {
      /* Prepare */
      (customerDao.getCustomerDetailsGraphQL as Mock).mockReturnValueOnce(customerDao);
      (addressMapper.mapCustomerResponse as Mock).mockReturnValueOnce(customerDao);

      /* Execute */
      await customerService.getCustomerDetailsByToken(market, authHeader);

      /* Verify */
      expect(customerDao.getCustomerDetailsGraphQL).toHaveBeenCalledTimes(1);
    });
  });

  describe('getDeliveryAddressList()', () => {
    test('returns undefined if delivery AddressList do not exist', async () => {
      /* Prepare */
      (customerDao.getCustomerDetailsGraphQL as Mock).mockReturnValueOnce(
        stubCustomerDto({ shippingAddressIds: [faker.random.randomWord()] }),
      );
      (addressMapper.mapGraphQLAddressResponse as Mock).mockReturnValueOnce(stubCustomerDto().addresses);

      /* Execute */
      await customerService.getDeliveryAddressList(market, authHeader);

      /* Verify */
      expect(customerDao.getCustomerDetailsGraphQL).toHaveBeenCalledTimes(1);
    });

    test('check shippingAddressIds undefined', async () => {
      /* Prepare */
      (customerDao.getCustomerDetailsGraphQL as Mock).mockReturnValueOnce(stubCustomerDto({ shippingAddressIds: [] }));
      (addressMapper.mapGraphQLAddressResponse as Mock).mockReturnValueOnce(graphQLDefaultAddress.addresses);
      const expectedError = new ApiError(404, i18next.t('error.deliveryAddressNotFound'));
      /* Execute */
      await expect(customerService.getDeliveryAddressList(market, authHeader)).rejects.toThrow(expectedError);
      /* Verify */
      expect(addressMapper.mapGraphQLAddressResponse).not.toHaveBeenCalled();
    });

    test('returns getDeliveryAddressList', async () => {
      /* Prepare */
      (customerDao.getCustomerDetailsGraphQL as Mock).mockReturnValueOnce(graphQLDefaultAddress);
      (addressMapper.mapGraphQLAddressResponse as Mock).mockReturnValueOnce(graphQLDefaultAddress.addresses);

      /* Execute */
      await customerService.getDeliveryAddressList(market, authHeader);

      /* Verify */
      expect(customerDao.getCustomerDetailsGraphQL).toHaveBeenCalledTimes(1);
    });
  });

  describe('addAddress()', () => {
    let addressRequestDto: AddressRequestDto;
    let customer: Customer;
    let customerWithoutAddress: Customer;
    let payload: any;
    let mappedCustomerAddress: AddressCollectionResponseDto;

    beforeEach(() => {
      addressRequestDto = stubAddressRequestDto();
      customer = stubCustomerDto();
      customerWithoutAddress = stubCustomerWithoutAddressDto();
      mappedCustomerAddress = {
        addresses: [stubAddressResponseDto(), stubAddressResponseDto()],
      };
      (addressMapper.mapAddressCollectionResponse as Mock).mockReturnValueOnce(
        mappedCustomerAddress,
      );

      payload = {
        action: 'addAddress',
        address: {
          custom: {
            type: {
              key: addressCustomTypeKey,
              typeId: 'type',
            },
            fields: {
              Address1: addressRequestDto.address1,
              Address2: addressRequestDto.address2,
              Address3: addressRequestDto.address3,
              Address4: addressRequestDto.address4,
              county: addressRequestDto.county,
              Latitude: addressRequestDto.latitude,
              Longitude: addressRequestDto.longitude,
              RecipientName: addressRequestDto.recipientName,
            },
          },
          country: addressRequestDto.country,
          city: addressRequestDto.city,
          region: addressRequestDto.region,
          postalCode: addressRequestDto.zip,
          state: addressRequestDto.state,
          phone: addressRequestDto.phoneNumber,
          firstName: addressRequestDto.firstName,
          lastName: addressRequestDto.lastName,
          key: expect.stringMatching(REGEXP_UUID),
        },
      };
    });

    test('reads version from the customerDto', async () => {
      /* Prepare */
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customer);

      /* Execute */
      await customerService.addAddress(market, customer, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,
        customer.id,
        expect.objectContaining({ version: customer.version }),
      );
    });

    test('reads version from the customerDto if firstName is not received', async () => {
      /* Prepare */
      delete addressRequestDto.firstName;
      delete addressRequestDto.lastName;
      delete addressRequestDto.recipientName;
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customer);

      /* Execute */
      await customerService.addAddress(market, customer, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,
        customer.id,
        expect.objectContaining({ version: customer.version }),
      );
    });

    test('reads version from the customerDto if customer address length is 0', async () => {
      /* Prepare */
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerWithoutAddress);

      /* Execute */
      await customerService.addAddress(market, customerWithoutAddress, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,
        customerWithoutAddress.id,
        expect.objectContaining({ version: customerWithoutAddress.version }),
      );
    });
    test('creates addShippingAddressId action', async () => {
      /* Prepare */
      addressRequestDto.isBillingAddress = false;
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customer);

      /* Execute */
      await customerService.addAddress(market, customer, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,

        customer.id,
        {
          version: customer.version,
          actions: [
            payload,
            { action: 'addShippingAddressId', addressKey: expect.stringMatching(REGEXP_UUID) },
          ],
        },
      );
    });

    test('creates addBillingAddressId action', async () => {
      /* Prepare */
      addressRequestDto.isBillingAddress = true;
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customer);

      /* Execute */
      await customerService.addAddress(market, customer, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
    });
  });

  describe('updateAddress()', () => {
    let addressId: string;
    let addressKey: string;
    let addressRequestDto: AddressRequestDto;
    let customerDto: Writeable<Customer>;
    let payloadAddAddressAction;
    let mappedCustomerAddress: AddressCollectionResponseDto;
    let addressResponseDto: Address;
    let addressDraft: AddressDraft;

    beforeEach(() => {
      customerDao.updateCustomer = jest.fn();
      addressId = faker.datatype.uuid();
      addressKey = faker.datatype.uuid();
      addressRequestDto = stubAddressRequestDto({
        key: addressKey,
      });
      addressDraft = stubAddressDraftDto({
        id: addressId,
        key: addressRequestDto.key,
        city: addressRequestDto.city,
        country: addressRequestDto.country,
        phone: addressRequestDto.phoneNumber,
        postalCode: addressRequestDto.zip,
        region: addressRequestDto.region,
        state: addressRequestDto.state,
        custom: {
          type: {
            key: 'address-type',
            typeId: 'type',
          },
          fields: {
            RecipientName: addressRequestDto.recipientName,
            Address1: addressRequestDto.address1,
            Address2: addressRequestDto.address2,
            Address3: addressRequestDto.address3,
            Address4: addressRequestDto.address4,
            Latitude: addressRequestDto.latitude,
            Longitude: addressRequestDto.longitude,
            county: addressRequestDto.county,
          },
        },
      });
      addressResponseDto = stubAddressDto({
        id: addressId,
        key: addressRequestDto.key,
        city: addressRequestDto.city,
        country: addressRequestDto.country,
        phone: addressRequestDto.phoneNumber,
        postalCode: addressRequestDto.zip,
        region: addressRequestDto.region,
        state: addressRequestDto.state,
        custom: {
          type: {
            id: faker.datatype.uuid(),
            typeId: 'type',
          },
          fields: {
            Address1: addressRequestDto.address1,
            Address2: addressRequestDto.address2,
            Address3: addressRequestDto.address3,
            Address4: addressRequestDto.address4,
            Latitude: addressRequestDto.latitude,
            Longitude: addressRequestDto.longitude,
            county: addressRequestDto.county,
          },
        },
      });
      customerDto = stubCustomerDto({
        addresses: [addressResponseDto],
      });

      (addressMapper.mapAddressCollectionResponse as Mock).mockReturnValueOnce(
        mappedCustomerAddress,
      );

      payloadAddAddressAction = {
        action: 'changeAddress',
        addressId: addressResponseDto.id,
        address: addressDraft,
      };
    });

    test('reads version from the customerDto', async () => {
      /* Prepare */
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.updateAddress(market, customerDto, addressId, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,
        customerDto.id,
        expect.objectContaining({ version: customerDto.version }),
      );
    });

    test('reads version from the customerDto if addressKey is not available', async () => {
      /* Prepare */
      delete addressRequestDto.state;
      delete addressRequestDto.phoneNumber;
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.updateAddress(market, customerDto, addressId, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,
        customerDto.id,
        expect.objectContaining({ version: customerDto.version }),
      );
    });

    test('Attach addShippingAddressId action', async () => {
      /* Prepare */
      addressRequestDto.isBillingAddress = false;
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.updateAddress(market, customerDto, addressId, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,

        customerDto.id,
        {
          version: customerDto.version,
          actions: [
            payloadAddAddressAction,
            { action: 'addShippingAddressId', addressKey },
          ],
        },
      );
    });

    test('throws if address id does not exist', async () => {
      /* Prepare */
      customerDto.addresses = [];

      /* Execute */
      const result = expect(() => customerService.updateAddress(market, customerDto, addressId, addressRequestDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, `Address id "${addressId}" does not exist`),
      );
    });
  });

  describe('registration()', () => {
    let customerRequestDto: CustomerRegistrationRequestDto;
    let customerDto: CustomerRegistrationRequestDto;
    let customFields: FieldContainer;
    let graphQlResponse;

    beforeEach(() => {
      graphQlResponse = stubGraphQLOrder();
      customerRequestDto = stubCustomerRequestDto();
      customerDto = stubCustomerRegisterRequestDto();
      customerDao.create = jest.fn();
      customerDao.login = jest.fn();
      customerDao.updateCustomer = jest.fn();
      orderDao.fetchOrder = jest.fn();
      customFields = {
        customFieldsRaw:
        [
          {
            name: faker.datatype.string(),
            value: faker.random.word(),
          },
        ],
      };

      (addressMapper.mapToFields as Mock).mockReturnValueOnce(
        customFields,
      );
    });

    test('creates the Customer using the customerDao', async () => {
      /* Prepare */
      delete graphQlResponse.customerId;
      (customerDao.create as Mock).mockReturnValueOnce(customerDto);
      (customerDao.login as Mock).mockReturnValueOnce(stubCustomerLoginResponseDto());
      (orderDao.fetchOrder as Mock).mockReturnValueOnce(graphQlResponse);
      (customerMapper.mapCustomerResponse as Mock).mockReturnValueOnce(customerDto);
      const currentDate = Math.floor(new Date().getTime() / 1000);
      const customerEmail = graphQlResponse.customerEmail.split('@')[0].replace(/\./g, '');
      /* Execute */

      customerDto.key = `${customerEmail}-${currentDate}`;
      await customerService.registration(market, customerDto, authHeader);

      /* Verify */
      expect(customerDao.create).toHaveBeenCalledTimes(1);
    });

    test('throw error Order already associated with existing', async () => {
      /* Prepare */
      (customerDao.create as Mock).mockReturnValueOnce(customerDto);
      (orderDao.fetchOrder as Mock).mockReturnValueOnce(graphQlResponse);
      (customerMapper.mapCustomerResponse as Mock).mockReturnValueOnce(customerDto);
      /* Execute */
      const result = expect(() => customerService.registration(market, customerRequestDto, authHeader));
      /* Verify */
      await result.rejects.toThrow(
        new ApiError(
          HttpStatusCodes.UNAUTHORIZED,
          `Order already associated with existing ${graphQlResponse.customerId}`,
        ),
      );
    });

    test('throw error Order not found', async () => {
      /* Prepare */
      (customerDao.create as Mock).mockReturnValueOnce(customerDto);
      (orderDao.fetchOrder as Mock).mockReturnValueOnce(undefined);
      /* Execute */
      const result = expect(() => customerService.registration(market, customerRequestDto, authHeader));
      /* Verify */
      await result.rejects.toThrow(
        new ApiError(
          HttpStatusCodes.NOT_FOUND,
          `Order Details not found for ${customerRequestDto.orderId}`,
        ),
      );
    });
  });
});
