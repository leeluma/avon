import { CartUpdate, CustomerSignin } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { MarketInfo } from '../../src/middlewares';
import {
  CustomerDao, CartDao, AddressDao, DefaultDao,
} from '../../src/daos';
import {
  stubCustomerLoginRequestDto,
  stubCustomerLoginResponseDto,
  stubMarket,
  stubPickupPointRequestDto,
  stubPickupPointResponseDto,
  stubUpdateCartRequestDto,
} from '../__stubs__';
import { DefaultService } from '../../src/services';
import Mock = jest.Mock;
import {
  CustomerLoginResponseDto,
  LoginDto,
  PickupPointRequestDto,
  PickupPointResponseDto,
  UpdateCartRequestDto,
} from '../../src/dtos';
import { addressCustomTypeKey, ApiError } from '../../src/lib';

describe('DefaultService', () => {
  /* System Under Test */
  let defaultService: DefaultService;

  /* Dependencies */
  let customerDao: CustomerDao;
  let defaultDao: DefaultDao;
  let cartDao: CartDao;
  let addressDao: AddressDao;
  let market: MarketInfo;
  enum CART_ACTIONS {
    setCustomerId = 'setCustomerId',
    setCustomerEmail = 'setCustomerEmail',
    setShippingAddress = 'setShippingAddress',
  }
  let params: string;
  beforeEach(() => {
    market = stubMarket(
      {
        locale: 'ro',
        country: 'RO',
      },
    );
    /* Dependencies */
    customerDao = {} as any;
    cartDao = {} as any;
    addressDao = {} as any;
    defaultDao = {
      refreshToken: jest.fn(),
    } as any;
    params = faker.datatype.string();

    /* SUT */
    defaultService = new DefaultService({
      addressDao, customerDao, cartDao, defaultDao,
    });
  });

  describe('login()', () => {
    let loginDto: LoginDto;
    let customerLoginResDto: CustomerLoginResponseDto;
    let customerLoginDraftReqDto: CustomerSignin;
    beforeEach(() => {
      customerDao.login = jest.fn();
      customerDao.setCustomerIdToCart = jest.fn();
      cartDao.getCartById = jest.fn();
      loginDto = stubCustomerLoginRequestDto();
      customerLoginResDto = stubCustomerLoginResponseDto();
      customerLoginDraftReqDto = {
        email: loginDto.email,
        password: loginDto.password,
      };
    });

    test('reads the customer data from customerDao', async () => {
      /* Prepare */
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      (cartDao.getCartById as Mock).mockReturnValueOnce({ version: 1 });

      /* Execute */
      await defaultService.login(market, loginDto);

      /* Verify */
      expect(customerDao.login).toHaveBeenCalledTimes(1);
      expect(customerDao.login).toHaveBeenNthCalledWith(
        1,
        market,
        customerLoginDraftReqDto,
      );
    });

    test('throws NOT_FOUND if CtCart does not exist', async () => {
      /* Prepare */
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      cartDao.getCartById = jest.fn().mockReturnValueOnce(undefined);

      /* Execute */
      const result = expect(() => defaultService.login(market, loginDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartNotFound')),
      );
    });

    test('throws CONFLICT, if cart attached to customer', async () => {
      /* Prepare */
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      cartDao.getCartById = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
        customerId: faker.datatype.uuid(),
      });

      /* Execute */
      const result = expect(() => defaultService.login(market, loginDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.CONFLICT, i18next.t('error.cartIdConflict')),
      );
    });

    test('throws BAD_REQUEST, if email is blank', async () => {
      /* Prepare */
      loginDto.email = '';
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      cartDao.getCartById = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
        customerId: faker.datatype.uuid(),
      });

      /* Execute */
      const result = expect(() => defaultService.login(market, loginDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.emailIsMandatory')),
      );
    });

    test('throws BAD_REQUEST, if email is invalid', async () => {
      /* Prepare */
      loginDto.email = 'ab';
      market.country = 'RO';
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      cartDao.getCartById = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
        customerId: faker.datatype.uuid(),
      });

      /* Execute */
      const result = expect(() => defaultService.login(market, loginDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.emailShouldBeValid')),
      );
    });
  });

  test('call refreshToken method', async () => {
    /* Prepare */
    (defaultDao.refreshToken as Mock)
      .mockReturnValueOnce({ access_token: faker.datatype.string() });

    /* Execute */
    await defaultService.refreshToken(market, params);

    /* Verify */
    expect(defaultDao.refreshToken).toHaveBeenCalledTimes(1);
    expect(defaultDao.refreshToken).toHaveBeenNthCalledWith(
      1,
      market,
      params,
    );
  });

  describe('updateMyCartById()', () => {
    let updateCartRequestDto: UpdateCartRequestDto;
    let authToken = faker.datatype.uuid();
    let updateCartActionDraft: CartUpdate;
    const version = faker.datatype.number();
    beforeEach(() => {
      cartDao.getCartById = jest.fn();
      cartDao.updateMyCartById = jest.fn();
      updateCartRequestDto = stubUpdateCartRequestDto();
      updateCartActionDraft = {
        version,
        actions: [{
          action: CART_ACTIONS.setCustomerEmail,
          email: updateCartRequestDto.email,
        }, {
          action: CART_ACTIONS.setShippingAddress,
          address: {
            firstName: updateCartRequestDto.firstName,
            lastName: updateCartRequestDto.lastName,
            country: market.country,
            custom: {
              type: {
                typeId: 'type',
                key: addressCustomTypeKey,
              },
              fields: {
                RecipientName: `${updateCartRequestDto.firstName} ${updateCartRequestDto.lastName}`,
              },
            },
          } as any,
        }],
      };
    });

    test('update cart information inside cartDao', async () => {
      /* Prepare */
      (cartDao.getCartById as Mock).mockReturnValueOnce({ version, anonymousId: faker.datatype.uuid() });
      /* Execute */
      await defaultService.updateMyCartById(market, updateCartRequestDto, authToken);

      /* Verify */
      expect(cartDao.updateMyCartById).toHaveBeenCalledTimes(1);
      expect(cartDao.updateMyCartById).toHaveBeenNthCalledWith(
        1,
        market.country,
        updateCartActionDraft,
        authToken,
        updateCartRequestDto.cartId,
      );
    });

    test('throws NOT_FOUND if CtCart does not exist', async () => {
      /* Prepare */
      cartDao.getCartById = jest.fn().mockReturnValueOnce(undefined);

      /* Execute */
      const result = expect(() => defaultService.updateMyCartById(market, updateCartRequestDto, authToken));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartNotFound')),
      );
    });

    test('throws CONFLICT, if cart does not have anonymousId', async () => {
      /* Prepare */
      cartDao.getCartById = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
      });

      /* Execute */
      const result = expect(() => defaultService.updateMyCartById(market, updateCartRequestDto, authToken));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.CONFLICT, i18next.t('error.cartIdConflict')),
      );
    });

    test('throws BAD_REQUEST, if email is blank', async () => {
      /* Prepare */
      updateCartRequestDto.email = '';
      cartDao.getCartById = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
        anonymousId: faker.datatype.uuid(),
      });

      /* Execute */
      const result = expect(() => defaultService.updateMyCartById(market, updateCartRequestDto, authToken));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.emailIsManadatory')),
      );
    });

    test('throws BAD_REQUEST, if email is invalid', async () => {
      /* Prepare */
      updateCartRequestDto.email = 'ab';
      market.country = 'RO';
      cartDao.getCartById = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
        anonymousId: faker.datatype.uuid(),
      });

      /* Execute */
      const result = expect(() => defaultService.updateMyCartById(market, updateCartRequestDto, authToken));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.emailShouldBeValid')),
      );
    });

    test('throws BAD_REQUEST, if firstName is blank', async () => {
      /* Prepare */
      updateCartRequestDto.firstName = '';
      market.country = 'RO';
      cartDao.getCartById = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
        anonymousId: faker.datatype.uuid(),
      });

      /* Execute */
      const result = expect(() => defaultService.updateMyCartById(market, updateCartRequestDto, authToken));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.firstNameIsManadatory')),
      );
    });

    test('throws BAD_REQUEST, if firstName is invalid', async () => {
      /* Prepare */
      updateCartRequestDto.firstName = 'ab';
      market.country = 'RO';
      cartDao.getCartById = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
        anonymousId: faker.datatype.uuid(),
      });

      /* Execute */
      const result = expect(() => defaultService.updateMyCartById(market, updateCartRequestDto, authToken));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.firstNameShouldBeValid')),
      );
    });

    test('throws BAD_REQUEST, if lastName is blank', async () => {
      /* Prepare */
      updateCartRequestDto.lastName = '';
      cartDao.getCartById = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
        anonymousId: faker.datatype.uuid(),
      });
      /* Execute */
      const result = expect(() => defaultService.updateMyCartById(market, updateCartRequestDto, authToken));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.lastNameIsManadatory')),
      );
    });

    test('throws BAD_REQUEST, if lastName is invalid', async () => {
      /* Prepare */
      updateCartRequestDto.lastName = 'ab';
      market.country = 'RO';
      cartDao.getCartById = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
        anonymousId: faker.datatype.uuid(),
      });

      /* Execute */
      const result = expect(() => defaultService.updateMyCartById(market, updateCartRequestDto, authToken));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('validationError.lastNameShouldBeValid')),
      );
    });

    test('throws unauthorized, if authToken is invalid', async () => {
      /* Prepare */

      authToken = '';
      cartDao.getCartById = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
        anonymousId: faker.datatype.uuid(),
      });

      /* Execute */
      const result = expect(() => defaultService.updateMyCartById(market, updateCartRequestDto, authToken));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.UNAUTHORIZED, i18next.t('validationError.unauthorized')),
      );
    });

    describe('getPickupDetail()', () => {
      let pickupPointRequestDto : PickupPointRequestDto;
      let pickupPointResponseDto: PickupPointResponseDto;

      beforeEach(() => {
        addressDao.getPickupDetail = jest.fn();
        pickupPointRequestDto = stubPickupPointRequestDto();
        pickupPointResponseDto = stubPickupPointResponseDto();
      });

      test('reads the DetailResponseDto from addressDao', async () => {
        /* Prepare */
        (addressDao.getPickupDetail as Mock).mockReturnValueOnce(pickupPointResponseDto);
        /* Execute */
        await defaultService.getPickupDetail(market, pickupPointRequestDto);

        /* Verify */
        expect(addressDao.getPickupDetail).toHaveBeenCalledTimes(1);
      });
      test('reads the DetailResponseDto from addressDao if distanceUnit is undefined', async () => {
        /* Prepare */
        delete pickupPointRequestDto.distance;
        delete pickupPointRequestDto.distanceUnit;
        (addressDao.getPickupDetail as Mock).mockReturnValueOnce(pickupPointResponseDto);
        /* Execute */
        await defaultService.getPickupDetail(market, pickupPointRequestDto);

        /* Verify */
        expect(addressDao.getPickupDetail).toHaveBeenCalledTimes(1);
      });
    });
  });
});
