import { Router, RequestHandler } from 'express';
import { DefaultRouter } from '../../src/routers';
import { DefaultController } from '../../src/controllers';
import {
  fieldValidator, validateCustomerLogin, validatePickupDetail,
  validateRefreshToken,
} from '../../src/validators';
import { validateRequestSchema } from '../../src/middlewares';
import { stubRouter } from '../__stubs__';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks__/express-validator.mock').default);

describe('DefaultRouter', () => {
  let defaultController: DefaultController;
  let authMiddleware: RequestHandler;
  let defaultRouter: DefaultRouter;
  let mockRouter: Router;
  let validationSettingsMiddleware: RequestHandler;

  beforeEach(() => {
    defaultController = {
      login: jest.fn(),
      updateMyCartById: jest.fn(),
      getPickupDetail: jest.fn(),
      refreshToken: jest.fn(),
    } as any;

    mockRouter = stubRouter();
    validationSettingsMiddleware = jest.fn(() => mockRouter);

    defaultRouter = new DefaultRouter({
      defaultController,
      Router: () => mockRouter,
      authMiddleware,
      validationSettingsMiddleware,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = defaultRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });
    test('mounts the expected number of routes', () => {
      defaultRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenCalledTimes(3);
      expect(mockRouter.get).toHaveBeenCalledTimes(1);
      expect(mockRouter.put).toHaveBeenCalledTimes(0);
    });

    test('configures the POST /login route', () => {
      defaultRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenNthCalledWith(
        1,
        '/login',
        validateCustomerLogin,
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the POST /refresh-token route', () => {
      defaultRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        2,
        '/refresh-token',
        validateRefreshToken,
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the POST /guest-login route', () => {
      defaultRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenNthCalledWith(
        3,
        '/guest-login',
        authMiddleware,
        validationSettingsMiddleware,
        [
          fieldValidator('email'),
          fieldValidator('firstName'),
          fieldValidator('lastName'),
          fieldValidator('cartId'),
        ],
        validateRequestSchema,
        expect.any(Function),
      );
    });
    test('configures the GET /pickup-points route', () => {
      defaultRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/pickup-points',
        validatePickupDetail,
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
