import { Router } from 'express';
import { CtClient } from '../../src/lib';
import { ShippingMethodRouter } from '../../src/routers';
import { CartController } from '../../src/controllers';
import { validateRequestSchema, magnoliaUrlMiddleware } from '../../src/middlewares';
import { stubCtClient, stubRouter } from '../__stubs__';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks__/express-validator.mock').default);

describe('ShippingMethodsRouter', () => {
  let cartController: CartController;
  let shippingMethodsRouter: ShippingMethodRouter;
  let mockRouter: Router;
  let ctClient: CtClient;

  beforeEach(() => {
    cartController = {
      getShippingMethods: jest.fn(),
    } as any;

    mockRouter = stubRouter();

    ctClient = stubCtClient('RO');

    shippingMethodsRouter = new ShippingMethodRouter({
      cartController,
      ctClient,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = shippingMethodsRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      shippingMethodsRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenCalledTimes(1);
      expect(mockRouter.post).toHaveBeenCalledTimes(0);
      expect(mockRouter.put).toHaveBeenCalledTimes(0);
    });

    test('configures the GET /:id route', () => {
      shippingMethodsRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/',
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
  });
});
