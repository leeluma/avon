import { Router } from 'express';
import { OrderRouter } from '../../src/routers';
import { OrderController } from '../../src/controllers';
import { validateRequestSchema, magnoliaUrlMiddleware } from '../../src/middlewares';
import { validateOrderIdAndBearerToken } from '../../src/validators';
import { stubRouter } from '../__stubs__';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks__/express-validator.mock').default);

describe('OrderRouter', () => {
  let orderController: OrderController;
  let orderRouter: OrderRouter;
  let mockRouter: Router;

  beforeEach(() => {
    orderController = {
      getOrder: jest.fn(),
      getOrderMagnolia: jest.fn(),
    } as any;

    mockRouter = stubRouter();

    orderRouter = new OrderRouter({
      orderController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = orderRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      orderRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(2);
      expect(mockRouter.post).toHaveBeenCalledTimes(0);
      expect(mockRouter.put).toHaveBeenCalledTimes(0);
    });

    /**
     * Test case for the route to get order data
     */
    test('configures the order routes', () => {
      orderRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/:orderId',
        validateOrderIdAndBearerToken,
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
    /**
     * Test case for the route to get order magnolia data
     */
    test('configures the order magnolia routes', () => {
      orderRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenNthCalledWith(
        2,
        '/',
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
  });
});
