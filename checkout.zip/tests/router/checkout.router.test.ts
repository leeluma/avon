import { Router } from 'express';
import { CheckoutRouter } from '../../src/routers/checkout.router';
import { CheckoutController } from '../../src/controllers/checkout.controller';
import { validateRequestSchema, magnoliaUrlMiddleware } from '../../src/middlewares';
import { stubRouter } from '../__stubs__';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks__/express-validator.mock').default);

describe('CheckoutRouter', () => {
  let checkoutController: CheckoutController;
  let checkoutRouter: CheckoutRouter;
  let mockRouter: Router;

  beforeEach(() => {
    checkoutController = {
      getCheckoutPageData: jest.fn(),
    } as any;

    mockRouter = stubRouter();

    checkoutRouter = new CheckoutRouter({
      checkoutController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = checkoutRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      checkoutRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(1);
      expect(mockRouter.post).toHaveBeenCalledTimes(0);
      expect(mockRouter.put).toHaveBeenCalledTimes(0);
    });

    /**
     * Test case for the route to get checkout data
     */
    test('configures the checkouts routes', () => {
      checkoutRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/',
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
  });
});
