import { RequestHandler, Router } from 'express';
import { oneOf } from 'express-validator';
import { CartRouter } from '../../src/routers';
import { CartController } from '../../src/controllers';
import {
  validateAddShippingMethod, validateSetCartAddress,
  fieldValidator, validateId,
} from '../../src/validators';
import { validateRequestSchema, magnoliaUrlMiddleware } from '../../src/middlewares';
import { stubRouter } from '../__stubs__';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks__/express-validator.mock').default);

describe('CartRouter', () => {
  let cartController: CartController;
  let cartRouter: CartRouter;
  let mockRouter: Router;
  let authMiddleware: RequestHandler;
  let mockValidationSettingsMiddleware: RequestHandler;

  beforeEach(() => {
    cartController = {
      getShippingMethodsByCartId: jest.fn(),
      addShippingMethod: jest.fn(),
      setShippingAddress: jest.fn(),
      initiatePayment: jest.fn(),
      getCartById: jest.fn(),
    } as any;

    mockRouter = stubRouter();

    authMiddleware = jest.fn(() => mockRouter);
    mockValidationSettingsMiddleware = jest.fn(() => mockRouter);

    cartRouter = new CartRouter({
      cartController,
      authMiddleware,
      Router: () => mockRouter,
      addressValidationSettingsMiddleware: mockValidationSettingsMiddleware,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = cartRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      cartRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenCalledTimes(1);
      expect(mockRouter.post).toHaveBeenCalledTimes(2);
      expect(mockRouter.put).toHaveBeenCalledTimes(0);
    });

    test('configures the POST /:cartId/shippingMethods route', () => {
      cartRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenNthCalledWith(
        1,
        '/:cartId/shippingMethods',
        authMiddleware,
        validateAddShippingMethod,
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the POST /:cartId/shippingAddress route', () => {
      cartRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenNthCalledWith(
        2,
        '/:cartId/shippingAddress',
        expect.any(Function),
        fieldValidator('address1'),
        fieldValidator('address2'),
        fieldValidator('phoneNumber'),
        fieldValidator('city'),
        fieldValidator('zip'),
        validateSetCartAddress,
        authMiddleware,
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });

    test('configures the GET /:id route for cart', () => {
      cartRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/:id',
        authMiddleware,
        validateId,
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
  });
});
