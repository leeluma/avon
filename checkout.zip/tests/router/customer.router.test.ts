import { RequestHandler, Router } from 'express';
import { body } from 'express-validator';
import { CustomerRouter } from '../../src/routers';
import { CustomerController } from '../../src/controllers';
import { validateRequestSchema } from '../../src/middlewares';
import { fieldValidator } from '../../src/validators';
import { stubRouter } from '../__stubs__';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks__/express-validator.mock').default);

describe('CustomerRouter', () => {
  let customerController: CustomerController;
  let authMiddleware: RequestHandler;
  let customerRouter: CustomerRouter;
  let mockRouter: Router;
  let mockValidationSettingsMiddleware: RequestHandler;

  beforeEach(() => {
    customerController = {
      getDefaultAddress: jest.fn(),
      forgotCustomersPassword: jest.fn(),
      createAnonymousSession: jest.fn(),
      getDeliveryAddresses: jest.fn(),
      getCustomerByToken: jest.fn(),
      registration: jest.fn(),
    } as any;

    mockRouter = stubRouter();

    authMiddleware = jest.fn(() => mockRouter);
    mockValidationSettingsMiddleware = jest.fn(() => mockRouter);

    customerRouter = new CustomerRouter({
      customerController,
      Router: () => mockRouter,
      authMiddleware,
      addressValidationSettingsMiddleware: mockValidationSettingsMiddleware,
      validationSettingsMiddleware: mockValidationSettingsMiddleware,
    });
  });

  describe('buildExpressRouter()', () => {
    test('mounts the expected number of routes', () => {
      customerRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(3);
      expect(mockRouter.post).toHaveBeenCalledTimes(2);
      expect(mockRouter.put).toHaveBeenCalledTimes(0);
    });

    test('returns the express router', () => {
      const response = customerRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('configures the GET /default-delivery route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/default-delivery',
        authMiddleware,
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the POST /forgot-password route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        1,
        '/forgot-password',
        body('email').notEmpty().isEmail().withMessage('internet.email'),
        body('url').notEmpty().isURL().withMessage('internet.url'),
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the POST /registration route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        2,
        '/registration',
        authMiddleware,
        mockValidationSettingsMiddleware,
        [
          fieldValidator('password'),
          fieldValidator('confirmPassword'),
          fieldValidator('orderId'),
        ],
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the GET /addresses route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        2,
        '/addresses',
        authMiddleware,
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the GET / route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        3,
        '/',
        authMiddleware,
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
