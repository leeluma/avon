import { RequestHandler, Router } from 'express';
import { PaymentRouter } from '../../src/routers';
import { PaymentController } from '../../src/controllers';
import {
  validateInitiatePayment,
  validateNotifications,
} from '../../src/validators';
import { validateRequestSchema } from '../../src/middlewares';
import { stubRouter } from '../__stubs__';
import { magnoliaUrlMiddleware } from '../../src/middlewares/magnolia-url.middleware';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks__/express-validator.mock').default);

describe('PaymentRouter', () => {
  let paymentController: PaymentController;
  let paymentRouter: PaymentRouter;
  let mockRouter: Router;
  let authMiddleware: RequestHandler;

  beforeEach(() => {
    paymentController = {
      getShippingMethodsByPaymentId: jest.fn(),
      addShippingMethod: jest.fn(),
      setShippingAddress: jest.fn(),
      initiatePayment: jest.fn(),
      getPaymentStatus: jest.fn(),
    } as any;

    mockRouter = stubRouter();

    authMiddleware = jest.fn().mockReturnValueOnce(mockRouter);

    paymentRouter = new PaymentRouter({
      paymentController,
      authMiddleware,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = paymentRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      paymentRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(0);
      expect(mockRouter.post).toHaveBeenCalledTimes(2);
      expect(mockRouter.put).toHaveBeenCalledTimes(0);
    });

    test('configures the POST /:cartId/payment/initiate route', () => {
      paymentRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenNthCalledWith(
        1,
        '/:cartId/payment/initiate',
        authMiddleware,
        validateInitiatePayment,
        validateNotifications,
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
  });
});
