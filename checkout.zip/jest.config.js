// eslint-disable-next-line @typescript-eslint/no-var-requires
const path = require('path');

const config = {
  verbose: true,
  // setupFiles: [path.resolve(__dirname, 'tests/setup.ts')],
  modulePathIgnorePatterns: ['__stubs__'],
  maxWorkers: '100%',
  resetMocks: true,
  coverageDirectory: path.resolve(__dirname, 'artifacts/coverage'),
  cacheDirectory: path.resolve(__dirname, 'artifacts/jest-cache'),
  testPathIgnorePatterns: ['/node_modules/', '/dist/'],
  coveragePathIgnorePatterns: ['/src/lib/', '/src/config/', '/src/dtos/', 'index\\.ts',
    '/src/middlewares/', '/src/validators/', '/src/common/',
    path.resolve(__dirname, 'tests/__stubs__'), path.resolve(__dirname, 'tests/__mocks__')],
  testResultsProcessor: 'jest-sonar-reporter',
  reporters: [
    'default',
    ['./node_modules/jest-html-reporter', {
      pageTitle: 'Test Report',
      outputPath: path.resolve(__dirname, 'artifacts/jest-html-report.html'),
    }],
  ],
};

module.exports = config;
