# leap-bff-checkout

This is a BFF for checkout MFE.

# Repo Owner

HCL

# Installation

```shell
npm install
npm run build
```

Configure the `.env` file according to the sample below in this readme.

```shell
npm start
```

# Sample .env file

```
API_CONTEXT_PATH="checkout"
API_VERSION="v1"
API_PORT=3001

NODE_ENV=development
LOG_LEVEL=trace

CT_ACTIVE_MARKETS=["RO"]

CT_PROJECT_KEY_RO=avon-ph-v1
CT_CLIENT_ID_RO=<CT client id>
CT_CLIENT_SECRET_RO=<CT client secret>

CT_MAX_RETRIES=2
CT_RETRY_DELAY=300
CT_RETRY_MAX_DELAY=1000
CT_RETRY_ON_ABORT=true
CT_TIMEOUT=2000
CT_CONCURRENCY=20

CT_API_ENDPOINT=https://api.europe-west1.gcp.commercetools.com
CT_AUTH_ENDPOINT=https://auth.europe-west1.gcp.commercetools.com

PAYMENT_API_KEY=<epay API key>
PAYMENT_API_URL_PREFIX=https://epay-eu.api-dev.aws.avon.com/{{country}}/{{locale}}/
PAYMENT_API_INIT_SUFFIX=capturenow/init
PAYMENT_ORDER_NUMBER_GENERATOR=https://qq2hshex0h.execute-api.eu-west-1.amazonaws.com/order/{{country}}
PAYMENT_KEY_GENERATOR=https://qq2hshex0h.execute-api.eu-west-1.amazonaws.com/payment/{{country}}
PAYMENT_RETURN_URL=https://app.leap-dev.aws.avon.com/ro/payment/

ADDRESS_FINDER_HOST=https://wxtboyvy5j.execute-api.eu-west-1.amazonaws.com/
ADDRESS_FINDER_AUTOCOMPLETE=Development/autocomplete/{{locale}}-{{country}}
PICKUP_POINT_HOST=https://choiceservicesqaf.avon.com

AWS_REGION=eu-west-1
AWS_EVENT_BUS_NAME_PASSWORD_RESET=arn:aws:events:eu-west-1:507640941000:event-bus/awa-sandbox-eventbus
AWS_EVENT_BUS_NAME_MARKETING_NOTIFICATIONS=arn:aws:events:eu-west-1:507640941000:event-bus/marketing-notification-eventbus

APPTUS_CLUSTER_ID=XXXXXXX
APPTUS_API_KEY=XXXXXXX
APPTUS_BASE_URL=https://{{CLUSTER_ID}}.api.esales.apptus.cloud/api/v2/
APPTUS_ESALES_MARKET=AVONSHOP_

PAYMENT_RETRY_COUNT=5
PAYMENT_RETRY_TIMEOUT=1000
```

# Error handling

The `api-error` and `error-handler.middleware` will do most of the heavy lifting for you.

If a technical error happens (something that the client should not know about),
just throw an `Error(...)` in your controller/service/dao.

If there is an error that should inform the client about what went wrong,
then throw an `ApiError(...)`. The `ApiError` class requires two parameters.
The first parameter is the HTTP status code and the second parameter can be
an array of errors, or a single error (which will be automatically converted
into an array with a single element).

The `Error` will be converted into a generic 500 error and the message will be hidden from the client.

The `ApiError` will be forwarded to the client,
so **be careful what information you send to the client**.

`express-validator` errors are handled automatically.

### Error handling examples

- If anything goes wrong, this will be turned into a generic 500 error.

DAO code:

```typescript
db.query({});
```

Output:

```json
{
    "statusCode": 500,
    "message": "Internal Server Error",
    "timestamp": "2021-12-21T08:35:14.697Z",
    "errors": [
        "Internal Server Error"
    ]
}
```

- If there is a validation error, it will be forwarded to the client.

Router code:

```typescript
express.Router()
  .post('/',
    validateAddToCart,
    validateRequestSchema,
    wrapJsonApiController(
      this.cartController.addProductToCart.bind(this.cartController),
    ))
```

Request:

```json
{
    "cartId": "",
    "lineItems": {
        "productKey": "",
        "sku": "",
        "quantity": ""
    }
}
```

Output:

```json
{
    "statusCode": 400,
    "message": "Bad Request",
    "timestamp": "2022-01-10T11:26:17.934Z",
    "errors": [
        {
            "value": "",
            "msg": "SKU code is mandatory",
            "param": "lineItems.sku",
            "location": "body"
        },
        {
            "value": "",
            "msg": "Line Item quantity is mandatory.",
            "param": "lineItems.quantity",
            "location": "body"
        }
    ]
}
```

- If an `ApiError` is thrown, it will be forwarded to the client.

Service code:

```typescript
if (lineItem.quantity > maxPurchasableQty) {
  throw new ApiError(
    HttpStatusCodes.NOT_FOUND,
    'Unable to add. Item per user restriction (maxPurchasableQty)',
  );
}
```

Output:

```json
{
    "statusCode": 404,
    "message": "Not Found",
    "timestamp": "2022-01-10T11:29:01.761Z",
    "errors": [
        {
            "message": "Unable to add. Item per user restriction (maxPurchasableQty)"
        }
    ]
}
```
