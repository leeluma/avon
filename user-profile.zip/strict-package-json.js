const versionRegExp = /^(\d+\.\d+\.\d+)|(file:.*)$/;

const getInvalidPackageVersions = (packageJson, depsFieldName) => {
  const deps = packageJson[depsFieldName] || {};

  return Object.keys(deps)
    .filter((depKey) => !versionRegExp.test(deps[depKey]));
};

const packageJson = require('./package.json');

const errorKeys = [
  ...getInvalidPackageVersions(packageJson, 'dependencies'),
  ...getInvalidPackageVersions(packageJson, 'devDependencies'),
  ...getInvalidPackageVersions(packageJson, 'peerDependencies'),
];

if (errorKeys.length) {
  console.error('The following packages have invalid versions specified in package.json:'
    + `\n - ${errorKeys.join('\n - ')}\nAll packages must have exact versions specified.`
    + ' For example, write "1.2.3" instead of "^1.2.3"');
  process.exit(1);
}
