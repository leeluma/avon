// eslint-disable-next-line @typescript-eslint/no-var-requires
const path = require('path');

const config = {
  verbose: true,
  setupFiles: [path.resolve(__dirname, 'tests/setup.ts')],
  modulePathIgnorePatterns: ['__stubs__'],
  maxWorkers: '100%',
  resetMocks: true,
  coverageDirectory: path.resolve(__dirname, 'artifacts/coverage'),
  cacheDirectory: path.resolve(__dirname, 'artifacts/jest-cache'),
  testPathIgnorePatterns: ['/node_modules/', '/dist/'],
  coveragePathIgnorePatterns: ['/src/lib/', 'index\\.ts', '/src/middlewares/', '/src/validators/', 'tests/__mocks'],
  reporters: [
    'default',
    ['./node_modules/jest-html-reporter', {
      pageTitle: 'Test Report',
      outputPath: path.resolve(__dirname, 'artifacts/jest-html-report.html'),
    }],
  ],
  testResultsProcessor: 'jest-sonar-reporter',
};

module.exports = config;
