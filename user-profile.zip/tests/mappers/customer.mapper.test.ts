import faker from '@faker-js/faker';
import { Address, Customer } from '@commercetools/platform-sdk';
import {
  AddressResponseDto, CustomerResponseDto, GraphQLCustomerResponse,
} from '../../src/dtos';
import Mock = jest.Mock;
import { CustomerMapper, AddressMapper } from '../../src/mappers';
import {
  stubAddressResponseDto, stubCustomerDto,
} from '../__stubs__';
import { stubAddressRequestDto } from '../__stubs__/address-request.dto.stub';

describe('CustomerMapper', () => {
  /** start testing address mapper */
  let customerMapper: CustomerMapper;
  let addressMapper: AddressMapper;
  let customerResponseDtoWithoutAddresses: CustomerResponseDto;
  let customerDto: Customer;
  let gqCustomerDto: GraphQLCustomerResponse;
  let customerResponseDto: CustomerResponseDto;
  let addressResponseDto: AddressResponseDto;
  let addressRequestDto: Address;

  beforeEach(() => {
    addressMapper = {
      mapAddressResponse: jest.fn(),
      mapGraphQLCustomerResponse: jest.fn(),
    } as any;
    customerMapper = new CustomerMapper({ addressMapper });
    addressRequestDto = stubAddressRequestDto();
    addressResponseDto = stubAddressResponseDto({ ...addressRequestDto });
    customerDto = stubCustomerDto({
      addresses: [addressRequestDto],
    });
    gqCustomerDto = customerDto as any;
    gqCustomerDto.addresses = [
      {
        id: addressRequestDto.id,
        city: addressRequestDto.city,
        state: addressRequestDto.state,
        country: addressRequestDto.country,
        phone: addressRequestDto.phone,
        custom: {
          type: {
            typeId: 'type',
            key: 'address-type',
          },
          customFieldsRaw: [
            {
              name: 'Address1',
              value: addressRequestDto.custom?.fields.Address1,
            },
            {
              name: 'Address2',
              value: addressRequestDto.custom?.fields.Address2,
            },
          ],
        },
      },
    ];
    gqCustomerDto.custom = {
      type: {
        typeId: 'type',
        id: '',
      },
      fields: {

      },
      customFieldsRaw: [{
        name: faker.internet.userName(),
      }],
    };
    customerResponseDto = {
      id: customerDto.id,
      email: customerDto.email,
      firstName: customerDto.firstName,
      lastName: customerDto.lastName,
      addresses: [addressResponseDto],
    };
    customerResponseDtoWithoutAddresses = {
      id: customerDto.id,
      email: customerDto.email,
      firstName: customerDto.firstName,
      lastName: customerDto.lastName,
    };
    addressMapper.mapAddressResponse = jest.fn();
    addressMapper.mapGraphQLAddressResponse = jest.fn();
  });

  describe('mapAddressResponse()', () => {
    test('responds with the mapped CustomerDto', () => {
      /** prepare */
      (addressMapper.mapAddressResponse as Mock).mockReturnValueOnce(addressResponseDto);
      const result = customerMapper.mapCustomerResponse(customerDto);
      expect(customerDto.addresses).toHaveLength(1);
      expect(result).toEqual(customerResponseDto);
    });
  });
  describe('mapGraphQLCustomerResponse()', () => {
    test('responds with the mapped GraphQL CustomerDto', () => {
      /** prepare */
      (addressMapper.mapGraphQLAddressResponse as Mock).mockReturnValueOnce(addressResponseDto);
      const result = customerMapper.mapGraphQLCustomerResponse(gqCustomerDto);
      expect(result).toEqual(customerResponseDtoWithoutAddresses);
    });
    test('responds with the mapped GraphQL CustomerDto if mapAddress is true', () => {
      /** prepare */

      (addressMapper.mapGraphQLAddressResponse as Mock).mockReturnValueOnce(addressResponseDto);
      const result = customerMapper.mapGraphQLCustomerResponse(gqCustomerDto, true);
      expect(result).toBeTruthy();
    });
  });
});
