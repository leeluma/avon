import { ShippingInfoMapper } from '../../src/mappers';
import { Common } from '../../src/lib';

describe('ShippingInfoMapper()', () => {
  /** start testing ShippingInfoMapper mapper */
  let shippingInfoMapper: ShippingInfoMapper;
  let common: Common;
  let shippingInfo;

  beforeEach(() => {
    shippingInfo = {
      shippingMethodName: 'Standard Delivery',
      deliveries: [],
      price: {
        currencyCode: 'RON',
        centAmount: 1000,
        fractionDigits: 2,
      },
      discountedPrice: null,
    };
    common = {
      priceConverter: jest.fn(),
    } as any;
    shippingInfoMapper = new ShippingInfoMapper({ common });
  });

  describe('mapShippingInfoResponse', () => {
    test('maps shippingInfo to mapShippingInfoResponse', () => {
      const result = shippingInfoMapper.mapShippingInfoResponse(shippingInfo);
      expect(result).toBeTruthy();
    });
    test('maps shippingInfo if shippinginfo object is undefined', () => {
      const result = shippingInfoMapper.mapShippingInfoResponse(undefined);
      expect(result).toBe(undefined);
    });
  });
});
