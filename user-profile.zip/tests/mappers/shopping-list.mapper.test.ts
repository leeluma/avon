import faker from '@faker-js/faker';
import { LineItemMapper, ShoppingListMapper } from '../../src/mappers';
import { MagnoliaPriceFormatDto } from '../../src/dtos/line-item.dto';
import { MarketInfo } from '../../src/middlewares';
import { GraphQLShoppingList } from '../../src/dtos';
import {
  stubMarket, stubGraphQLShoppingList,
} from '../__stubs__';
import { Common } from '../../src/lib/common';

describe('ShoppingListMapper', () => {
  /** start testing address mapper */
  let shoppingListMapper: ShoppingListMapper;
  let lineItemMapper: LineItemMapper;
  let market: MarketInfo;
  let magPriceFormat: MagnoliaPriceFormatDto;

  let shoppingList: GraphQLShoppingList;
  let common: Common;
  let listPrices: number;
  let sellPrices: number;
  let url: string;
  let productMassDetail: string;

  beforeEach(() => {
    market = stubMarket();
    shoppingList = stubGraphQLShoppingList(market);
    productMassDetail = faker.datatype.uuid();
    listPrices = faker.datatype.number();
    sellPrices = faker.datatype.number();

    magPriceFormat = {
      isVatIncluded: faker.datatype.boolean(),
      baseMeasure: { unitPriceBaseMeasure: faker.datatype.number() },
    } as any;

    common = {
      getNonRepPrice: jest.fn().mockReturnValueOnce(listPrices),
      getNonRepPriceWithDiscount: jest.fn().mockReturnValueOnce(sellPrices),
      getproductMassDetail: jest.fn().mockReturnValueOnce(productMassDetail),
      getUrl: jest.fn().mockReturnValueOnce(url),
    } as any;
    lineItemMapper = new LineItemMapper({ common });
    shoppingListMapper = new ShoppingListMapper({ lineItemsMapper: lineItemMapper });
    (lineItemMapper as any).getproductMassDetail = jest.fn().mockReturnValueOnce(productMassDetail);
    (lineItemMapper as any).getNonRepPrice = jest.fn().mockReturnValueOnce(listPrices);
    (lineItemMapper as any).getNonRepPriceWithDiscount = jest.fn().mockReturnValueOnce(sellPrices);
    (lineItemMapper as any).mapLineItemResponse = jest.fn().mockReturnValueOnce(sellPrices);
  });

  describe('map_CtShoppingListDto_WishlistDto', () => {
    test('responds with CtShoppingListDto mapped to WishlistDto', () => {
      const result = shoppingListMapper.mapShoppingListResponse(market, shoppingList, magPriceFormat);
      expect(result).toBeTruthy();
    });
  });
});
