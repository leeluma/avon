import { PromotionMapper } from '../../src/mappers';
import { Common } from '../../src/lib';
import { stubGraphQLOrder } from '../__stubs__';

describe('PromotionMapper()', () => {
  /** start testing PromotionMapper mapper */
  let promotionMapper: PromotionMapper;
  let common: Common;
  let order;

  beforeEach(() => {
    order = stubGraphQLOrder();

    common = {
      priceConverter: jest.fn(),
    } as any;

    promotionMapper = new PromotionMapper({ common });
  });

  describe('mapPromotionResponse', () => {
    test('maps order to mapPromotionResponse', () => {
      const result = promotionMapper.mapPromotionResponse(order);
      expect(result).toBeTruthy();
      expect(result?.promotionId).toBeDefined();
      expect(result?.promotionAmount).toBeDefined();
    });
  });
});
