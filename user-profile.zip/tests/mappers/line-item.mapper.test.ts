import faker from '@faker-js/faker';
import { Price } from '@commercetools/platform-sdk';
import { LineItemDto, MagnoliaPriceFormatDto } from '../../src/dtos/line-item.dto';
import { LineItemMapper } from '../../src/mappers/line-item.mapper';
import { MarketInfo } from '../../src/middlewares';
import { Common } from '../../src/lib/common';
import { stubMarket } from '../__stubs__';
import { GraphQLShoppingListLineItem } from '../../src/dtos';

describe('LineItemMapper', () => {
  /** start testing address mapper */
  let lineItemMapper: LineItemMapper;

  let lineItemDraft: GraphQLShoppingListLineItem;
  let lineItemDto: LineItemDto;
  let market: MarketInfo;
  let magPriceFormat: MagnoliaPriceFormatDto;
  let productMassDetail: string;
  let listPrices: number;
  let sellPrices: number;
  let common: Common;
  let url: string;

  beforeEach(() => {
    market = stubMarket();
    magPriceFormat = {
      isVatIncluded: faker.datatype.boolean(),
    } as any;

    productMassDetail = faker.datatype.uuid();
    listPrices = faker.datatype.number();
    sellPrices = faker.datatype.number();

    lineItemDraft = {
      id: faker.datatype.uuid(),
      variantId: faker.datatype.number(),
      quantity: faker.datatype.number(),
      productId: faker.datatype.uuid(),
      name: 'test product name',
      productSlug: 'test-product-url',
      variant: {
        id: faker.datatype.number(),
        sku: faker.datatype.uuid(),
        key: faker.datatype.uuid(),
        attributes: [],
        assets: [],
        prices: [
          {
            value: {
              type: faker.datatype.uuid(),
              currencyCode: faker.datatype.uuid(),
              centAmount: faker.datatype.number(),
              fractionDigits: faker.datatype.number(),
            },
            id: faker.datatype.uuid(),
            channel: {
              id: faker.datatype.uuid(),
            },
            discounted: {
              value: {
                type: faker.random.word(),
                currencyCode: faker.finance.currencyCode(),
                centAmount: faker.datatype.number(),
                fractionDigits: faker.datatype.number(2),
              },
              discount: {
                typeId: faker.random.word(),
                id: faker.datatype.uuid(),
              },
            },
          },
        ] as Price[],
        images: [
          {
            url: faker.internet.url(),
            label: faker.name.title(),
            dimensions: {
              w: faker.datatype.number(),
              h: faker.datatype.number(),
            },
          },
        ],
      },
    };
    url = `/p/${lineItemDraft.productSlug}`;
    lineItemDto = {
      id: lineItemDraft.id,
      variantId: lineItemDraft.variantId,
      quantity: lineItemDraft.quantity,
      product: { id: lineItemDraft.productId },
      name: lineItemDraft.name,
      url,
      listPrice: listPrices,
      sellPrice: sellPrices,
      vatIncluded: magPriceFormat.isVatIncluded === 'true' ? magPriceFormat.vatIncludedMessage : '',
      productMassDetails: productMassDetail,
      images: lineItemDraft.variant?.images?.map((image: any, index: number) => {
        return {
          url: image.url,
          assetType: image.label,
          sequence: index,
        };
      }),
    };

    common = {
      getNonRepPrice: jest.fn().mockReturnValueOnce(listPrices),
      getNonRepPriceWithDiscount: jest.fn().mockReturnValueOnce(sellPrices),
      getproductMassDetail: jest.fn().mockReturnValueOnce(productMassDetail),
      getProductUrl: jest.fn().mockReturnValueOnce(url),
    } as any;

    lineItemMapper = new LineItemMapper({ common });
    (lineItemMapper as any).getproductMassDetail = jest.fn().mockReturnValueOnce(productMassDetail);
    (lineItemMapper as any).getNonRepPrice = jest.fn().mockReturnValueOnce(listPrices);
    (lineItemMapper as any).getNonRepPriceWithDiscount = jest.fn().mockReturnValueOnce(sellPrices);
  });

  describe('mapLineItemResponse', () => {
    test('To check if response is okay', () => {
      const result = lineItemMapper.mapLineItemResponse(market, lineItemDraft, magPriceFormat);
      expect(result).toEqual(lineItemDto);
    });
    test('check with isVatIncluded true', () => {
      magPriceFormat = {
        isVatIncluded: 'true',
        vatIncludedMessage: faker.internet.userName(),
      } as any;
      lineItemDto = {
        id: lineItemDraft.id,
        variantId: lineItemDraft.variantId,
        quantity: lineItemDraft.quantity,
        product: { id: lineItemDraft.productId },
        name: lineItemDraft.name,
        url,
        listPrice: listPrices,
        sellPrice: sellPrices,
        vatIncluded: magPriceFormat.isVatIncluded === 'true' ? magPriceFormat.vatIncludedMessage : '',
        productMassDetails: productMassDetail,
        images: lineItemDraft.variant?.images?.map((image: any, index: number) => {
          return {
            url: image.url,
            assetType: image.label,
            sequence: index,
          };
        }),
      };
      const result = lineItemMapper.mapLineItemResponse(market, lineItemDraft, magPriceFormat);
      expect(result).toEqual(lineItemDto);
    });
  });
});
