import { PaymentInfoMapper } from '../../src/mappers';
import { Common } from '../../src/lib';

describe('PaymentInfoMapper()', () => {
  /** start testing PaymentInfoMapper mapper */
  let paymentInfoMapper: PaymentInfoMapper;
  let common: Common;
  let paymentInfo;

  beforeEach(() => {
    paymentInfo = {
      payments: [
        {
          key: null,
          paymentStatus: {
            state: {
              name: null,
            },
          },
          paymentMethodInfo: {
            method: 'CashOnDelivery',
            name: null,
          },
          amountPlanned: {
            type: 'centPrecision',
            currencyCode: 'RON',
            centAmount: 9228,
            fractionDigits: 2,
          },
        },
      ],
    };

    common = {
      priceConverter: jest.fn(),
    } as any;

    paymentInfoMapper = new PaymentInfoMapper({ common });
  });

  describe('mapPaymentInfoResponse', () => {
    test('maps paymentInfo to mapPaymentInfoResponse', () => {
      const result = paymentInfoMapper.mapPaymentInfoResponse(paymentInfo);
      expect(result).toBeTruthy();
    });
  });
});
