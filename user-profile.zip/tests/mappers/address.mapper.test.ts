import { Address, Customer } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import { AddressResponseDto, GraphQLAddress, GraphQLCustomerResponse } from '../../src/dtos';
import { AddressMapper } from '../../src/mappers';
import { MarketInfo } from '../../src/middlewares';
import {
  stubAddressDto, stubGraphQLAddressDto, stubAddressResponseDto, stubCustomerDto, stubGraphQLCustomerDto, stubMarket,
} from '../__stubs__';
import { stubAddressRequestDto } from '../__stubs__/address-request.dto.stub';

describe('AddressMapper', () => {
  /** start testing address mapper */
  let addressMapper: AddressMapper;
  let addressDto: Address;
  let graphQLAddressDto: GraphQLAddress;
  let addressResponseDto: AddressResponseDto;
  let customerDto: Customer;
  let graphQLcustomerDto: GraphQLCustomerResponse;

  let id: string;
  let address1: string;
  let address2: string;
  let address3: string;
  let address4: string;
  let country: string;
  let county: string;
  let city: string;
  let latitude: number;
  let longitude: number;
  let region: string;
  let postalCode: string;
  let state: string;
  let phone: string;

  let isShippingAddress: boolean;
  let isBillingAddress: boolean;

  beforeEach(() => {
    address1 = faker.address.streetAddress();
    address2 = faker.address.streetAddress();
    address3 = faker.address.streetAddress();
    address4 = faker.address.streetAddress();
    country = faker.address.countryCode();
    county = faker.address.county();
    latitude = +faker.address.latitude();
    longitude = +faker.address.longitude();
    state = faker.address.state();
    postalCode = faker.address.zipCode();
    phone = faker.phone.phoneNumber();
    city = faker.address.cityName();
    id = faker.datatype.uuid();

    isShippingAddress = faker.datatype.boolean();
    isBillingAddress = faker.datatype.boolean();

    addressDto = stubAddressDto({
      id,
      custom: {
        type: {
          id: 'address-type',
          typeId: 'type',
        },
        fields: {
          Address1: address1,
          Address2: address2,
          Address3: address3,
          Address4: address4,
          Latitude: latitude,
          Longitude: longitude,
          county,
        },
      },
      city,
      region,
      country,
      state,
      phone,
      postalCode,
    });

    customerDto = stubCustomerDto({
      addresses: [addressDto as Address],
      shippingAddressIds: isShippingAddress ? [id] : [],
      billingAddressIds: isBillingAddress ? [id] : [],
    });

    graphQLAddressDto = stubGraphQLAddressDto({
      id,
      custom: {
        type: {
          id: 'address-type',
          typeId: 'type',
        },
        customFieldsRaw: [
          {
            name: 'Address1',
            value: address1,
          }, {
            name: 'Address2',
            value: address2,
          }, {
            name: 'Address3',
            value: address3,
          }, {
            name: 'Address4',
            value: address4,
          }, {
            name: 'Latitude',
            value: latitude,
          }, {
            name: 'Longitude',
            value: longitude,
          },
          {
            name: 'county',
            value: county,
          },

        ],
      },
      city,
      region,
      country,
      state,
      phone,
      postalCode,
    });

    graphQLcustomerDto = stubGraphQLCustomerDto({
      id: customerDto.id,
      addresses: [graphQLAddressDto],
      shippingAddressIds: isShippingAddress ? [id] : [],
      billingAddressIds: isBillingAddress ? [id] : [],
    });

    addressResponseDto = stubAddressResponseDto({
      id,
      customerId: customerDto.id,
      phoneNumber: phone,
      zip: postalCode,
      address1,
      address2,
      address3,
      address4,
      county,
      latitude,
      longitude,
      city,
      region,
      country,
      state,
      isShippingAddress,
      isBillingAddress,
    });

    addressMapper = new AddressMapper();
  });

  describe('mapAddressResponse', () => {
    test('maps Address to AddressResponseDto', () => {
      const result = addressMapper.mapAddressResponse(addressDto as Address, customerDto);
      expect(result).toMatchObject(addressResponseDto);
    });
  });

  describe('mapGraphQLAddressResponse', () => {
    test('maps GraphQL Address to AddressResponseDto', () => {
      const result = addressMapper.mapGraphQLAddressResponse(graphQLAddressDto, graphQLcustomerDto);
      expect(result).toMatchObject(addressResponseDto);
    });
  });

  describe('mapAddressCollectionResponse', () => {
    test('maps Customer Address to AddressCollectionResponseDto', () => {
      const result = addressMapper.mapAddressCollectionResponse(customerDto);
      expect(customerDto.addresses).toHaveLength(1);
      expect(result).toMatchObject({
        addresses: [addressResponseDto],
      });
    });
  });

  describe('createAddressDraftFromDetails', () => {
    let market: MarketInfo;
    let key: string;
    let address;
    beforeEach(() => {
      market = stubMarket();
      key = faker.datatype.uuid();
      id = faker.datatype.uuid();
      address = stubAddressResponseDto();
    });
    test('creates AddressDraft From Details', () => {
      const result = addressMapper
        .createAddressDraftFromDetails(market, address, key, id);
      expect(result).toBeTruthy();
    });
  });

  describe('createAddressDraft', () => {
    let market: MarketInfo;
    let key: string;
    let address;
    let addressRequestDto;
    beforeEach(() => {
      market = stubMarket();
      key = faker.datatype.uuid();
      id = faker.datatype.uuid();
      address = stubAddressResponseDto();
      addressRequestDto = stubAddressRequestDto();
    });
    test('creates AddressDraft', () => {
      const result = addressMapper
        .createAddressDraft(market, customerDto, addressRequestDto, key, id);
      expect(result).toBeTruthy();
    });

    test('creates AddressDraft if firstName is missing in addressRequestDto', () => {
      delete addressRequestDto.firstName;
      delete addressRequestDto.lastName;
      const result = addressMapper
        .createAddressDraft(market, customerDto, addressRequestDto, key, id);
      expect(result).toBeTruthy();
    });
  });
});
