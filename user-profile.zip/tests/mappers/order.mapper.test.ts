import faker from '@faker-js/faker';
import {
  AddressMapper, OrderMapper, PaymentInfoMapper, PromotionMapper, ShippingInfoMapper,
} from '../../src/mappers';
import {
  GraphQLOrder,
} from '../../src/dtos';
import {
  stubGraphQLOrder, stubMagnoliaSettings, stubMarket,
} from '../__stubs__';
import { Common, MarketInfo } from '../../src/lib';

describe('OrderMapper', () => {
  let orderMapper: OrderMapper;
  let addressMapper: AddressMapper;
  let shippingInfoMapper: ShippingInfoMapper;
  let paymentInfoMapper: PaymentInfoMapper;
  let promotionMapper: PromotionMapper;
  let graphQLOrder: GraphQLOrder;
  let globalSettings;
  let common: Common;
  let market: MarketInfo;

  beforeEach(() => {
    globalSettings = stubMagnoliaSettings();
    graphQLOrder = stubGraphQLOrder();
    market = stubMarket();
    addressMapper = new AddressMapper();
    common = {
      priceConverter: jest.fn(),
      getUrl: jest.fn(),
    } as any;
    shippingInfoMapper = new ShippingInfoMapper({ common });
    paymentInfoMapper = new PaymentInfoMapper({ common });
    promotionMapper = new PromotionMapper({ common });
    addressMapper = new AddressMapper();
    orderMapper = new OrderMapper({
      addressMapper,
      common,
      paymentInfoMapper,
      promotionMapper,
      shippingInfoMapper,
    });
  });

  describe('createOrderResponse()', () => {
    test('responds with the mapped OrderResponse', () => {
      /** prepare */
      const result = orderMapper.createOrderResponse(graphQLOrder, globalSettings.priceFormat);
      expect(graphQLOrder).toBeTruthy();
      expect(result).toBeTruthy();
      expect(result.currencyCode).toBeDefined();
    });
  });

  test('getCartProductId mapper', () => {
    /* Prepare */
    const cartData = {
      id: faker.datatype.uuid(),
      lineItems: [{
        lineItemId: faker.datatype.string(),
        productId: faker.datatype.string(),
      }],
    };
    const productIdExpected = `"${cartData.lineItems[0].productId}"`;
    /* Execute */
    const result = orderMapper.getCartProductId(cartData.lineItems as any);

    /* Verify */
    expect(result).toBe(productIdExpected);
  });
  test('mapOrderDetails', () => {
    /* Execute */
    const productDetails = [{
      id: graphQLOrder.lineItems[0].productId,
      key: '71141',
      masterData: {
        current: {
          categories: [
            {
              id: '8432ceb1-f9bf-4d17-acca-bf3dea8b0f0c',
              typeId: 'category',
              slug: faker.internet.url(),
              custom: {
                customFieldsRaw: [
                  {
                    name: 'type',
                    value: 'Offer',
                  },
                ],
              },
            },
          ],
          slug: 'apa-de-parfum-si-apa-de-toaleta-404'['0'],
          name: 'Apă de parfum și apă de toaletă',
        },
      },
    }];

    const result = orderMapper.mapOrderDetails(
      graphQLOrder,
      market,
      globalSettings.priceFormat,
      productDetails as any[],
    );

    /* Verify */
    expect(graphQLOrder).toBeTruthy();
    expect(result).toBeTruthy();
  });

  test('mapOrderDetails if category slug is empty', () => {
    /* Execute */
    const productDetails = [{
      id: graphQLOrder.lineItems[0].productId,
      key: '71141',
      masterData: {
        current: {
          categories: [
            {
              id: '8432ceb1-f9bf-4d17-acca-bf3dea8b0f0c',
              typeId: 'category',
              custom: {
                customFieldsRaw: [
                  {
                    name: 'type',
                    value: 'Offer',
                  },
                ],
              },
            },
          ],
          slug: 'apa-de-parfum-si-apa-de-toaleta-404'['0'],
          name: 'Apă de parfum și apă de toaletă',
        },
      },
    }];

    const result = orderMapper.mapOrderDetails(
      graphQLOrder,
      market,
      globalSettings.priceFormat,
      productDetails as any[],
    );

    /* Verify */
    expect(graphQLOrder).toBeTruthy();
    expect(result).toBeTruthy();
  });
  /**
   * Check discount function in order mapper
   */
  test('checkDiscount mapper', () => {
    /* Setup */
    const price = {
      id: faker.datatype.uuid(),
      value: {
        type: 'centPrecision',
        currencyCode: 'RON',
        centAmount: faker.datatype.number(),
        fractionDigits: 2,
      },
      discounted: {
        value: {
          type: 'centPrecision',
          currencyCode: 'RON',
          centAmount: faker.datatype.number(),
          fractionDigits: 2,
        },
        discount: {
          typeId: faker.datatype.string(),
          id: faker.datatype.uuid(),
        },
      },
    };
    const expectedRes = true;
    /* Execute */
    const result = (orderMapper as any).checkDiscount(price);

    /* Verify */
    expect(result.isPromotionApplied).toBe(expectedRes);
  });

  test('checkDiscount without discounted', () => {
    /* Setup */
    const price = {
      id: faker.datatype.uuid(),
      value: {
        type: 'centPrecision',
        currencyCode: 'RON',
        centAmount: faker.datatype.number(),
        fractionDigits: 2,
      },
    };
    const expectedRes = false;
    /* Execute */
    const result = (orderMapper as any).checkDiscount(price);

    /* Verify */
    expect(result.isPromotionApplied).toBe(expectedRes);
  });

  test('getProductAttributes()', () => {
    /* Execute */
    const result = (orderMapper as any).getProductAttributes([
      { name: 'maxPurchasableQty', value: 1 },
      { name: 'discontinued', value: true }]);
    const result1 = (orderMapper as any).getProductAttributes([
      { name: 'maxPurchasableQty', value: { key: true, label: 1 } },
      { name: 'discontinued', value: { key: true, label: true } },
    ]);
    const result2 = (orderMapper as any).getProductAttributes([{
      name: 'brandId',
      value: '535',
    }]);
    /* Verify */
    expect(result).toMatchObject({ maxPurchasableQty: 1, discontinued: true });
    expect(result1).toMatchObject({ maxPurchasableQty: 1, discontinued: true });
    expect(result2).toStrictEqual({});
  });

  test('getPriceFormatDetails', () => {
    /* Setup */
    const priceFormat = 'RON 3.54';
    /* Execute */
    const result = (orderMapper as any).getPriceFormatDetails(354, globalSettings.priceFormat, true);

    /* Verify */
    expect(result).toEqual(priceFormat);
  });

  test('getPriceFormatDetails showDecimalZero false', () => {
    /* Setup */
    const priceFormat = '354 RON';
    delete globalSettings.priceFormat.showDecimalZero;
    delete globalSettings.priceFormat.noOfDigit;
    delete globalSettings.priceFormat.decimalPoint;
    delete globalSettings.priceFormat.thousandSeperator;
    delete globalSettings.priceFormat.currencyPlacement;
    /* Execute */
    const result = (orderMapper as any).getPriceFormatDetails(354, globalSettings.priceFormat, true);

    /* Verify */
    expect(result).toEqual(priceFormat);
  });

  test('getPriceFormatDetails false', () => {
    /* Setup */
    const priceFormat = 'RON 3.54';
    /* Execute */
    const result = (orderMapper as any).getPriceFormatDetails(354, globalSettings.priceFormat, false);

    /* Verify */
    expect(result).toEqual(priceFormat);
  });
});
