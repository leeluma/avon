/* eslint-disable @typescript-eslint/no-non-null-assertion */
import faker from '@faker-js/faker';
import { CartDraft, ShoppingList, ShoppingListLineItemDraft } from '@commercetools/platform-sdk';
import { CtClient } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import { graphql } from '../../src/graphql';
import {
  stubCartDraftDto, stubCartDto, stubCtClient, stubMarket,
  stubShoppingList, stubShoppingListLineItemDraft,
} from '../__stubs__';
import { CartDao } from '../../src/daos';
import Mock = jest.Mock;
import { CartDto } from '../../src/dtos';

describe('CartDao', () => {
  let cartDao: CartDao;

  let market: MarketInfo;
  let ctClient: CtClient;
  let gql: typeof graphql;
  let withId: Mock;
  let get: Mock;
  let post: Mock;
  let execute: Mock;
  let authHeader: string;
  let customerId: string;

  beforeEach(() => {
    market = stubMarket();
    execute = jest.fn();
    customerId = faker.datatype.uuid();
    authHeader = faker.datatype.string();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    ctClient = stubCtClient(market.country, {
      graphql: jest.fn().mockReturnValueOnce({ post }),
      carts: jest.fn().mockReturnValueOnce({ withId, get, post }),
    });

    gql = {
      getCustomerByToken: Promise.resolve('query () { customer {} }'),
      getCustomerById: Promise.resolve('query () { customer {} }'),
      getCustomerOrders: Promise.resolve('query () { orders {} }'),
      getCustomerOrderDetails: Promise.resolve('query () { orders {} }'),
      getProducts: Promise.resolve('query () { product {} }'),
      getShoppingListById: Promise.resolve('query () { shoppinglist {} }'),
      getCustomerCart: Promise.resolve('query () { cart {} }'),
      getActiveCartId: Promise.resolve('query () { cart {} }'),
    };
    cartDao = new CartDao({ ctClient, graphql: gql });
  });

  describe('getCartById()', () => {
    let cartId: string;
    let ctResponse: any;

    beforeEach(() => {
      ctResponse = {
        body: {
          data: {
            cart: {
              id: faker.datatype.uuid(),
            },
            shippingMethods: {
              results: [
                {},
              ],
            },
          },
        },
      };
    });

    test('builds request body with customerId', async () => {
      cartId = faker.datatype.uuid();
      const expectedBody = {
        query: 'query () { cart {} }',
        variables: {
          shippingCondition: 'isDefault in ("true")',
          cartId,
          locale: market.locale.toUpperCase(),
        },
      };
      execute.mockReturnValueOnce(ctResponse);

      await cartDao.getCartById(market, cartId);

      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: expectedBody },
      );
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await cartDao.getCartById(market, cartId);
      expect(result).toBeTruthy();
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {};
      execute.mockRejectedValueOnce(err);

      const result = cartDao.getCartById(market, cartId);

      await expect(result).rejects.toThrow(err);
    });
  });

  describe('findOne()', () => {
    let cartDto: CartDto;

    beforeEach(() => {
      cartDto = stubCartDto();
    });

    test('queries ctClient with ID', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ cart: { body: '1234' } });

      /* Execute */
      await cartDao.findOne(market, cartDto.id);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: cartDto.id },
      );
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.findOne(market, cartDto.id);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('returns undefined if CtClient throws 404', async () => {
      /* Prepare */
      const notFoundError = new Error('Not Found');
      (notFoundError as any).statusCode = 404;
      execute.mockRejectedValueOnce(notFoundError);

      /* Execute */
      const result = await cartDao.findOne(market, cartDto.id);

      /* Verify */
      expect(result).toBe(undefined);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.findOne(market, cartDto.id));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('addShoppingList()', () => {
    let shoppingListDto: ShoppingList;
    let cartDto: CartDto;

    beforeEach(() => {
      shoppingListDto = stubShoppingList(market);
      cartDto = stubCartDto();
    });

    test('queries ctClient with ID', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.addShoppingList(market, cartDto.id, cartDto.version, shoppingListDto.id);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: cartDto.id },
      );
    });

    test('does not return anything', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.addShoppingList(market, cartDto.id, cartDto.version, shoppingListDto.id);

      /* Verify */
      expect(result).toBe(undefined);
    });

    test('posts the addShoppingList action', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });
      const expectedBody = {
        version: cartDto.version,
        actions: [{
          action: 'addShoppingList',
          shoppingList: {
            typeId: 'shopping-list',
            id: shoppingListDto.id,
          },
        }],
      };

      /* Execute */
      await cartDao.addShoppingList(market, cartDto.id, cartDto.version, shoppingListDto.id);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1, { body: expectedBody });
    });
  });

  describe('create()', () => {
    let cartDraftDto: CartDraft;
    let cartDto: CartDto;

    beforeEach(() => {
      cartDraftDto = stubCartDraftDto();

      cartDto = stubCartDto();
      execute.mockReturnValueOnce({ body: cartDto });
    });

    test('creates Cart in CtClient', async () => {
      /* Execute */
      await cartDao.create(market, cartDraftDto);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: cartDraftDto },
      );
    });

    test('returns CtClient response body', async () => {
      /* Execute */
      const response = await cartDao.create(market, cartDraftDto);

      /* Verify */
      expect(response).toEqual(cartDto);
    });
  });

  describe('addLineItem', () => {
    let lineItemDraftDto: ShoppingListLineItemDraft;
    let cartDto: CartDto;

    beforeEach(() => {
      lineItemDraftDto = stubShoppingListLineItemDraft(market);

      cartDto = stubCartDto();
      execute.mockReturnValueOnce({ body: cartDto });
    });

    test('creates Cart in CtClient', async () => {
      /* Execute */
      await cartDao.addLineItem(
        market,
        cartDto.id,
        cartDto.version,
        lineItemDraftDto.productId!,
        lineItemDraftDto.variantId!,
      );

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1, {
        body: {
          version: cartDto.version,
          actions: [{
            action: 'addLineItem',
            productId: lineItemDraftDto.productId,
            variantId: lineItemDraftDto.variantId,
          }],
        },
      });
    });

    test('does not return anything', async () => {
      /* Execute */
      const response = await cartDao.addLineItem(
        market,
        cartDto.id,
        cartDto.version,
        lineItemDraftDto.productId!,
        lineItemDraftDto.variantId!,
      );

      /* Verify */
      expect(response).toBeUndefined();
    });
  });

  describe('getCustomerActiveCart()', () => {
    beforeEach(() => {
      authHeader = faker.datatype.string();
    });
    const stubActiveCartId = {
      body: {
        data: {
          me: {
            ActiveCart: { id: faker.datatype.uuid() },
          },
        },
      },
    };
    test('fetch active cartId using graphQL', async () => {
      /* Prepare */
      execute.mockReturnValueOnce(stubActiveCartId);

      /* Execute */
      const result = await cartDao.getCustomerWishlistAndCartId(customerId, authHeader, market);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
    });

    test('forwards GraphQL errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.uuid());
      execute.mockRejectedValueOnce(err);
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      const result = () => cartDao.getCustomerWishlistAndCartId(customerId, authHeader, market);

      /* Verify */
      await expect(result).rejects.toThrow(err);
    });

    test('re-throws non-404 GraphQL errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.getCustomerWishlistAndCartId(customerId, authHeader, market));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('re-throws GraphQL errors', async () => {
      /* Prepare */
      const error = {
        body: {
          statusCode: 400,
          status: {
            statusCode: 400,
            msg: faker.datatype.string(),
            timestamp: faker.datatype.datetime(),
          },
          errors: [
            {
              code: faker.datatype.string(),
              message: faker.datatype.string(),
            },
          ],
        },
      };

      execute.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => cartDao.getCustomerWishlistAndCartId(customerId, authHeader, market));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });
});
