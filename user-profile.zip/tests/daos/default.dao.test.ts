import faker from '@faker-js/faker';
import axios from 'axios';
import { CtClient, ApiError } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';

import { stubMarket, stubCtClient, stubVerifyTokenDto } from '../__stubs__';
import Mock = jest.Mock;
import { DefaultDao } from '../../src/daos';
import { config } from '../../src/config';

jest.mock('axios');

describe('DefaultDao', () => {
  let defaultDao: DefaultDao;
  let ctClient: CtClient;
  let market: MarketInfo;

  let execute: Mock;
  let get: Mock;
  let post: Mock;
  let withPasswordToken: Mock;
  let refreshTokenFlow: Mock;

  beforeEach(() => {
    market = stubMarket();
    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    refreshTokenFlow = jest.fn();
    withPasswordToken = jest.fn().mockReturnValueOnce({ get, post });
    const getClient = stubCtClient(market.country, {
      customers: jest.fn().mockReturnValueOnce({
        withPasswordToken, get,
      }),
    });
    ctClient = {
      ...getClient,
      getAuthClient: jest.fn().mockReturnValueOnce({ refreshTokenFlow }),
    } as any;

    defaultDao = new DefaultDao({ ctClient });
  });

  describe('refreshToken()', () => {
    const params = faker.datatype.string();
    test('queries ctClient with refreshToken', async () => {
      await defaultDao.refreshToken(market, params);
      /* Verify */
      expect(refreshTokenFlow).toHaveBeenCalledTimes(1);
      expect(refreshTokenFlow).toHaveBeenNthCalledWith(
        1,
        params,
      );
    });

    test('returns response from CT', async () => {
      /* Execute */
      refreshTokenFlow.mockReturnValueOnce({ access_token: faker.datatype.string() });

      const response = await defaultDao.refreshToken(market, params);

      /* Verify */
      expect(response).toBeTruthy();
    });

    test('returns undefined if CtClient throws 404', async () => {
      /* Prepare */
      const err = { statusCode: 404, errors: 'Not found' };
      refreshTokenFlow.mockRejectedValueOnce(err);

      /* Execute */
      const call = () => defaultDao.refreshToken(market, params);

      /* Verify */
      await expect(call).rejects.toThrow(
        new ApiError(err.statusCode, err.errors),
      );
    });

    test('forwards CT errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.string());
      refreshTokenFlow.mockRejectedValueOnce(err);

      /* Execute */
      const refreshToken = () => defaultDao.refreshToken(market, params);

      /* Verify */
      await expect(refreshToken).rejects.toThrow(err);
    });
    test('re-throws non-500  ctClient errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 500,
      };

      refreshTokenFlow.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => defaultDao.refreshToken(market, params));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  describe('verifyToken()', () => {
    const params = faker.datatype.string();
    test('queries ctClient with verifyToken', async () => {
      execute.mockReturnValueOnce({ body: stubVerifyTokenDto() });
      await defaultDao.verifyToken(market, params);
      /* Verify */
      expect(withPasswordToken).toHaveBeenCalledTimes(1);
      expect(withPasswordToken).toHaveBeenNthCalledWith(
        1,
        { passwordToken: params },
      );
    });

    test('returns response from CT', async () => {
      /* Execute */
      withPasswordToken.mockReturnValueOnce({ passwordToken: faker.datatype.string() });
      execute.mockReturnValueOnce({ body: stubVerifyTokenDto() });
      const response = await defaultDao.verifyToken(market, params);

      /* Verify */
      expect(response).toBeTruthy();
      expect(response.authenticationMode).toBe('Password');
    });

    test('returns undefined if CtClient throws 404', async () => {
      /* Prepare */
      // eslint-disable-next-line max-len
      const msg = `Unfortunately, the link you've used has expired. To reset your password, enter your email below & click the link within ${config.ttlMinutes} minutes`;
      const err = { statusCode: 404, errors: msg };
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const call = () => defaultDao.verifyToken(market, params);

      /* Verify */
      await expect(call).rejects.toThrow(
        new ApiError(err.statusCode, err.errors),
      );
    });

    test('forwards CT errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.string());
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const verifyToken = () => defaultDao.verifyToken(market, params);

      /* Verify */
      await expect(verifyToken).rejects.toThrow(err);
    });

    test('re-throws non-500  ctClient errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 500,
      };

      execute.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => defaultDao.verifyToken(market, params));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  describe('logout()', () => {
    const authorizeToken = faker.datatype.string();
    test('queries ctClient with logout if return response is true', async () => {
      (axios as any as Mock).mockReturnValueOnce({
        status: 200,
      });
      const response = await defaultDao.logout(authorizeToken);
      /* Verify */
      expect(response).toBe(true);
    });

    test('return false and status not 200 if commerce tool return', async () => {
      /* prepare */
      (axios as any as Mock).mockReturnValueOnce({
        status: 400,
      });
      const response = await defaultDao.logout(authorizeToken);
      /* Verify */
      expect(response).toBe(false);
    });

    test('return error if found from commerce tool', async () => {
      /* prepare */
      const error = new Error('something went wrong');
      (axios as any as Mock).mockRejectedValueOnce(error);
      const response = () => defaultDao.logout(authorizeToken);
      /* Verify */
      await expect(response).rejects.toThrow(error);
    });
  });
});
