import faker from '@faker-js/faker';
import axios from 'axios';
import {
  ShoppingList,
} from '@commercetools/platform-sdk';
import { CtClient } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import Mock = jest.Mock;
import { ShoppingListDao } from '../../src/daos';
import { stubMarket, stubShoppingList } from '../__stubs__';
import { stubCtClient } from '../__stubs__/client.stub';
import { graphql } from '../../src/graphql';

jest.mock('axios');

describe('ShoppingListDao', () => {
  let shoppingListDao: ShoppingListDao;

  let ctClient: CtClient;
  let market: MarketInfo;
  let post: Mock;
  let withId: Mock;
  let get: Mock;
  let execute: Mock;
  let gql: typeof graphql;

  let shoppingList: ShoppingList;

  beforeEach(() => {
    market = stubMarket();

    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    ctClient = stubCtClient(market.country, {
      shoppingLists: jest.fn().mockReturnValueOnce({ withId, post, get }),
      graphql: jest.fn().mockReturnValueOnce({ post }),
    });

    gql = {
      getCustomerByToken: Promise.resolve('query () { customer {} }'),
      getCustomerById: Promise.resolve('query () { customer {} }'),
      getCustomerOrders: Promise.resolve('query () { orders {} }'),
      getCustomerOrderDetails: Promise.resolve('query () { orders {} }'),
      getProducts: Promise.resolve('query () { product {} }'),
      getShoppingListById: Promise.resolve('query () { shoppinglist {} }'),
      getCustomerCart: Promise.resolve('query () { cart {} }'),
      getActiveCartId: Promise.resolve('query () { cart {} }'),
    };
    shoppingList = stubShoppingList(market);
    shoppingListDao = new ShoppingListDao({ ctClient, graphql: gql });
  });

  describe('findOne()', () => {
    let shoppingListDto: ShoppingList;

    beforeEach(() => {
      shoppingListDto = stubShoppingList(market);
    });

    test('queries ctClient with ID', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await shoppingListDao.findOne(market, shoppingListDto.id);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: shoppingListDto.id },
      );
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: shoppingListDto });

      /* Execute */
      const result = await shoppingListDao.findOne(market, shoppingListDto.id);

      /* Verify */
      expect(result).toBe(shoppingListDto);
    });

    test('returns undefined if CtClient throws 404', async () => {
      /* Prepare */
      const notFoundError = new Error('Not Found');
      (notFoundError as any).statusCode = 404;
      execute.mockRejectedValueOnce(notFoundError);

      /* Execute */
      const result = await shoppingListDao.findOne(market, shoppingListDto.id);

      /* Verify */
      expect(result).toBe(undefined);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => shoppingListDao.findOne(market, shoppingListDto.id));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('findGraphQLOne()', () => {
    let shoppingListDto: ShoppingList;
    let ctResponse: any;

    beforeEach(() => {
      shoppingListDto = stubShoppingList(market);
      ctResponse = { body: { data: { shoppingList } } };
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await shoppingListDao.findGraphQLOne(market, shoppingListDto.id);
      expect(result).toBe(shoppingList);
    });

    test('throws error if the GQL returns 0 item test 1', async () => {
      ctResponse.body.data.shoppingList = null;
      execute.mockReturnValueOnce(ctResponse);

      const result = await shoppingListDao.findGraphQLOne(market, shoppingListDto.id);
      expect(result).toBe(undefined);
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {};
      execute.mockRejectedValueOnce(err);

      const result = shoppingListDao.findGraphQLOne(market, shoppingListDto.id);

      await expect(result).rejects.toThrow(err);
    });
  });

  describe('findOneBy()', () => {
    let condition;

    beforeEach(() => {
      condition = `id="${faker.datatype.uuid()}"`;
    });

    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await shoppingListDao.findOneBy(market, condition);

      /* Verify */
      expect(get).toHaveBeenCalledTimes(1);
      expect(get).toHaveBeenNthCalledWith(1, {
        queryArgs: {
          expand: ['lineItems[*].variant', 'lineItems[*].productSlug'],
          where: condition,
          limit: 1,
        },
      });
    });

    test('returns ctClient response body of result index 0', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          results: [shoppingList],
        },
      });

      /* Execute */
      const result = await shoppingListDao.findOneBy(market, condition);
      /* Verify */
      expect(result).toEqual(shoppingList);
    });

    test('returns undefined if CtClient throws 404', async () => {
      /* Prepare */
      const notFoundError = new Error('Not Found');
      (notFoundError as any).statusCode = 404;
      execute.mockRejectedValueOnce(notFoundError);

      /* Execute */
      const result = await shoppingListDao.findOneBy(market, condition);

      /* Verify */
      expect(result).toBe(undefined);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => shoppingListDao.findOneBy(market, condition));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('getPriceFormat()', () => {
    test('Get price format from magnolia', async () => {
      (axios as unknown as Mock).mockResolvedValueOnce({ data: 'test' });
      /* Execute */
      const response = await shoppingListDao.getPriceFormat(market);
      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch price format  from magnolia', async () => {
      const err = {
        stack: 'some error',
      };
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (shoppingListDao as any).getPriceFormat(market));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch magnolia price format, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('deleteLineItems()', () => {
    let shoppingListId: string;
    let shoppingListVersion: number;

    beforeEach(() => {
      shoppingListId = faker.datatype.uuid();
      shoppingListVersion = faker.datatype.number();
    });

    test('queries ctClient with ID', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await shoppingListDao.deleteLineItems(market, shoppingListId, shoppingListVersion, []);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: shoppingListId },
      );
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      const lineItemIds = [faker.datatype.uuid(), faker.datatype.uuid(), faker.datatype.uuid()];

      const shoppingListDto = stubShoppingList(market);
      execute.mockReturnValueOnce({ body: shoppingListDto });

      /* Execute */
      const result = await shoppingListDao.deleteLineItems(
        market,
        shoppingListId,
        shoppingListVersion,
        [lineItemIds[0], lineItemIds[1], lineItemIds[2]],
      );

      /* Verify */
      expect(result).toEqual(shoppingListDto);
    });
  });

  describe('getResult', () => {
    test('Magnolia getResult Success Case', async () => {
      (axios as unknown as Mock).mockResolvedValueOnce({ data: 'test' });
      /* Execute */
      const response = await shoppingListDao.getResult(market);
      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch GlobalSetting from magnolia', async () => {
      /* Prepare */
      const err = new Error('some error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);

      /* Execute */
      const response = expect(() => (shoppingListDao as any).getResult(market));

      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch data , because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
});
