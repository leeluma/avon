import axios from 'axios';
import { MarketInfo } from '../../src/middlewares';
import Mock = jest.Mock;
import { SettingDao } from '../../src/daos';
import { stubMarket } from '../__stubs__';
import { MagnoliaPriceFormatDto } from '../../src/dtos';

jest.mock('axios');

describe('SettingDao', () => {
  let settingDao: SettingDao;
  let market: MarketInfo;
  let magPriceFormat: MagnoliaPriceFormatDto;

  /* Stubs */
  let magnoliaBasePath: string;

  beforeEach(() => {
    market = stubMarket();
    magnoliaBasePath = 'https://magnolia-author.leap-dev.aws.avon.com/';

    /* SUT */
    settingDao = new SettingDao({
      magnoliaBasePath,
    });
  });

  describe('get Price format from Magnolia()', () => {
    test('Get Static Pages from magnolia', async () => {
      (axios as unknown as Mock).mockResolvedValueOnce({
        status: 200,
        magPriceFormat,
      });
      /* Execute */
      await settingDao.getPriceFormat(market);
      /* Verify */
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch price from magnolia', async () => {
      const err = {
        stack: 'some error',
      };
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (settingDao as any).getPriceFormat(market));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch magnolia price format, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
});
