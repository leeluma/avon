import { faker } from '@faker-js/faker';
import i18next from 'i18next';
import HttpStatusCodes from 'http-status-codes';
import { CtClient, ApiError } from '../../src/lib';
import { graphql } from '../../src/graphql';
import { MarketInfo } from '../../src/middlewares';
import { GraphQLOrder, OrderDto } from '../../src/dtos';
import {
  stubGraphQLOrder, stubMarket, stubCtClient, stubCtProductDto,
} from '../__stubs__';
import Mock = jest.Mock;
import { OrderDao } from '../../src/daos';

describe('OrderDao', () => {
  let ctClient: CtClient;
  let gql: typeof graphql;
  let graphQLOrders: GraphQLOrder[];
  let market: MarketInfo;
  let orderDto: OrderDto;
  let post: Mock;
  let execute: Mock;
  let orders: Mock;
  let orderDao: OrderDao;
  let authHeader: string;
  let multiProductDto;
  let limit: number;
  let offset: number;
  let sort: string;

  beforeEach(() => {
    market = stubMarket();
    multiProductDto = stubCtProductDto();
    execute = jest.fn();
    post = jest.fn().mockReturnValueOnce({ execute });
    ctClient = stubCtClient(market.country, {
      me: jest.fn().mockReturnValueOnce({ orders }),
      graphql: jest.fn().mockReturnValueOnce({ post }),
    });
    gql = {
      getCustomerByToken: Promise.resolve('query () { customer {} }'),
      getCustomerById: Promise.resolve('query () { customer {} }'),
      getCustomerOrders: Promise.resolve('query () { orders {} }'),
      getCustomerOrderDetails: Promise.resolve('query () { orders {} }'),
      getProducts: Promise.resolve('query () { product {} }'),
      getShoppingListById: Promise.resolve('query () { shoppinglist {} }'),
      getCustomerCart: Promise.resolve('query () { cart {} }'),
      getActiveCartId: Promise.resolve('query () { cart {} }'),
    };
    orderDao = new OrderDao({ ctClient, graphql: gql });
    graphQLOrders = [stubGraphQLOrder()];
    authHeader = `Bearer ${faker.random.randomWord()}`;
    limit = faker.datatype.number();
    offset = faker.datatype.number();
    sort = faker.datatype.string();
  });

  describe('find()', () => {
    test('returns client response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            me: {
              orders: {
                results: graphQLOrders,
              },
            },
          },
        },
      });

      /* Execute */
      const result = await orderDao.find(market, authHeader, limit, sort, offset);

      /* Verify */
      expect(result).toBeTruthy();
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => orderDao.find(market, authHeader, limit, sort, offset));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const err = { body: { statusCode: 401, errors: [] } };
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const result = expect(() => orderDao.find(market, authHeader, limit, sort, offset));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  /**
   * Unit test case for fetchProduct function of product.dao
   */
  describe('fetchProductsDetail()', () => {
    let condition;
    let ctResponse: any;
    beforeEach(() => {
      multiProductDto = stubCtProductDto({ id: faker.datatype.uuid() });
      condition = `id in ("${multiProductDto.id}")`;
      ctResponse = {
        body: {
          data: {
            products: {
              results: [multiProductDto],
            },
          },
        },
      };
    });

    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      const expectedBody = {
        query: 'query () { product {} }',
        variables: {
          where: condition,
          locale: market.locale,
        },
      };
      execute.mockReturnValueOnce(ctResponse);

      /* Execute */
      await orderDao.fetchProductsDetail(market, `"${multiProductDto.id}"`);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: expectedBody },
      );
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await orderDao.fetchProductsDetail(market, multiProductDto.id);

      expect(result).toBe(ctResponse.body.data.products.results);
    });

    test('returns undefined from the GraphQL server', async () => {
      ctResponse = {
        body: {
          data: {
            products: {
            },
          },
        },
      };
      execute.mockReturnValueOnce(ctResponse);

      const result = await orderDao.fetchProductsDetail(market, multiProductDto.id);

      expect(result).toBe(undefined);
    });

    test('if ctResponse is undefined', async () => {
      ctResponse = {
        body: {
          data: null,
          errors: [
            {},
            {},
          ],
        },
      };
      execute.mockReturnValueOnce(ctResponse);
      /* Execute */
      const data = expect(() => orderDao.fetchProductsDetail(market, multiProductDto.id));

      /* Verify */
      await data.rejects.toThrow(
        new ApiError(HttpStatusCodes.BAD_REQUEST, i18next.t('error.productsInvalidUuid')),
      );
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {
        data: null,
        errors: ['msg'],
      };
      execute.mockRejectedValueOnce(err);

      const result = orderDao.fetchProductsDetail(market, multiProductDto.id);

      await expect(result).rejects.toThrow(err);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);
      /* Execute */
      const result = expect(() => orderDao.fetchProductsDetail(market, multiProductDto.id));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('fetchOrder()', () => {
    let orderId: string;
    beforeEach(() => {
      orderId = faker.datatype.uuid();
      authHeader = faker.datatype.string();
    });

    test('fetch order detail using graphQL', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            me: {
              order: orderDto,
            },
          },
        },
      });

      /* Execute */
      const result = await orderDao.fetchOrder(authHeader, market, orderId);

      /* Verify */
      expect(result).toBe(orderDto);
    });

    test('forwards GraphQL errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.uuid());
      execute.mockRejectedValueOnce(err);
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      const order = () => orderDao.fetchOrder(authHeader, market, orderId);

      /* Verify */
      await expect(order).rejects.toThrow(err);
    });

    test('re-throws non-404 GraphQL errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => orderDao.fetchOrder(authHeader, market, orderId));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('re-throws GraphQL errors', async () => {
      /* Prepare */
      const error = {
        body: {
          statusCode: 400,
          status: {
            statusCode: 400,
            msg: faker.datatype.string(),
            timestamp: faker.datatype.datetime(),
          },
          errors: [
            {
              code: faker.datatype.string(),
              message: faker.datatype.string(),
            },
          ],
        },
      };

      execute.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => orderDao.fetchOrder(authHeader, market, orderId));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });
});
