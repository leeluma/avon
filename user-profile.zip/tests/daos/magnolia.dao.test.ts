import faker from '@faker-js/faker';
import axios from 'axios';
import { MarketInfo } from '../../src/lib';
import { MagnoliaDao } from '../../src/daos';
import { MAGNOLIA_URI } from '../../src/common/constants';

import { stubMarket } from '../__stubs__';
import Mock = jest.Mock;
import { MagnoliaInfo } from '../../src/dtos';
import { axiosOptions } from '../../src/lib/axios-instance';

jest.mock('axios');

describe('MagnoliaDao', () => {
  let magnoliaDao: MagnoliaDao;
  let market: MarketInfo;
  let magnoliaBasePath: string;
  let magnolia: MagnoliaInfo;
  const templateName = faker.datatype.string();

  const mockResponse = {
    data: {
      name: faker.datatype.string(),
      path: faker.datatype.string(),
      id: faker.datatype.uuid(),
      nodeType: faker.datatype.string(),
      title: faker.datatype.string(),
      facebook: {
        name: faker.datatype.string(),
        path: faker.datatype.string(),
      },
      twitter: {
        name: faker.datatype.string(),
        path: faker.datatype.string(),
      },
    },
  };

  beforeEach(() => {
    market = stubMarket();
    magnoliaBasePath = faker.internet.url();
    magnolia = { url: faker.internet.url(), isPreview: faker.datatype.boolean(), marketPath: faker.datatype.string() };

    const magnoliaGlobalSettingUrl = faker.internet.url();
    magnoliaDao = new MagnoliaDao({
      basePath: magnoliaBasePath,
      globalSettingUrl: magnoliaGlobalSettingUrl,
    });
  });

  describe('Get Data From Magnolia', () => {
    test('Magnolia GlobalSetting Success Case', async () => {
      (axios as unknown as Mock).mockResolvedValueOnce({ data: 'test' });
      /* Execute */
      const response = await magnoliaDao.getGlobalSetting(market);
      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });
    test('Magnolia basepath not exist', async () => {
      magnoliaDao = new MagnoliaDao({
        basePath: '',
        globalSettingUrl: '',
      });
      (axios as unknown as Mock).mockResolvedValueOnce({ data: 'test' });

      const result = expect(() => magnoliaDao.getGlobalSetting(market));

      /* Verify */
      await result.rejects.toThrow(
        new Error('The magnolia "basePath" field in config is missing!'),
      );
    });

    test('Magnolia globalSettingUrl not exist', async () => {
      magnoliaDao = new MagnoliaDao({
        basePath: faker.internet.url(),
        globalSettingUrl: '',
      });
      (axios as unknown as Mock).mockResolvedValueOnce({ data: 'test' });

      const result = expect(() => magnoliaDao.getGlobalSetting(market));

      /* Verify */
      await result.rejects.toThrow(
        new Error('The magnolia "globalSettingUrl" field in config is missing!'),
      );
    });

    test('Failed to fetch GlobalSetting from magnolia', async () => {
      /* Prepare */
      const err = new Error('some error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);

      /* Execute */
      const response = expect(() => (magnoliaDao as any).getGlobalSetting(market));

      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch global settings, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  // Unite test case for getAccountPageData() method
  describe('getAccountPageData()', () => {
    test('returns magnolia response body', async () => {
      /* Prepare */
      let accountUrl = `${magnolia.url}${MAGNOLIA_URI.page}?lang=${market.locale}-${market.country}`;
      accountUrl = accountUrl.replace('{{country}}', `${magnolia.marketPath}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: accountUrl,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getAccountPageData(market, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getAccountPageData(market, magnolia));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch account data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getTemplateDataFromMagnolia()', () => {
    test('returns magnolia template response body', async () => {
      /* Prepare */
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: `${magnoliaBasePath}${MAGNOLIA_URI.template}${templateName}`,
      };
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getTemplateDataFromMagnolia(templateName, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
      expect(axios).toHaveBeenNthCalledWith(1, config);
    });

    test('Failed to fetch magnolia template data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getTemplateDataFromMagnolia(templateName, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch template data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
  describe('getAddressSettings', () => {
    test('Magnolia GlobalSetting Success Case', async () => {
      (axios as unknown as Mock).mockResolvedValueOnce({ data: 'test' });
      /* Execute */
      const response = await magnoliaDao.getAddressSettings(market);
      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch GlobalSetting from magnolia', async () => {
      /* Prepare */
      const err = new Error('some error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);

      /* Execute */
      const response = expect(() => (magnoliaDao as any).getAddressSettings(market));

      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch address validation settings data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
});
