import faker from '@faker-js/faker';
import {
  Customer, CustomerDraft, CustomerChangePassword, MyCustomerUpdate, CustomerSignin, CartUpdate,
}
  from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import { ApiError, CtClient } from '../../src/lib';
import { graphql } from '../../src/graphql';
import { MarketInfo } from '../../src/middlewares';
import {
  stubCustomerDto, stubMarket, stubCustomerDraftDto, stubCtCustomerClient, stubCustomerLoginResponseDto,
} from '../__stubs__';
import Mock = jest.Mock;
import { CustomerDao } from '../../src/daos';
import { GraphQLCustomerResponse } from '../../src/dtos';
import { config } from '../../src/config';

describe('CustomerDao', () => {
  let customerDao: CustomerDao;

  let customerDraftDto: CustomerDraft;
  let ctClient: CtClient;
  let gql: typeof graphql;
  let market: MarketInfo;
  let execute: Mock;
  let get: Mock;
  let post: Mock;
  let withId: Mock;
  let password: Mock;
  let passwordReset: Mock;
  let passwordToken: Mock;
  let authHeader: string;
  let customerPasswordFlow: Mock;
  beforeEach(() => {
    market = stubMarket();
    customerDraftDto = stubCustomerDraftDto();

    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    password = jest.fn().mockReturnValueOnce({ post });
    passwordReset = jest.fn().mockReturnValueOnce({ post });
    passwordToken = jest.fn().mockReturnValueOnce({ post });
    customerPasswordFlow = jest.fn();
    authHeader = `Bearer ${faker.random.randomWord()}`;
    ctClient = stubCtCustomerClient(market.country, {
      customers: jest.fn().mockReturnValueOnce({
        passwordToken, passwordReset, withId, post,
      }),
      carts: jest.fn().mockReturnValueOnce({ withId, post }),
      me: jest.fn().mockReturnValueOnce({ password, post }),
      graphql: jest.fn().mockReturnValueOnce({ post }),
      customerPasswordFlow,
    });
    gql = {
      getCustomerByToken: Promise.resolve('query () { customer {} }'),
      getCustomerById: Promise.resolve('query () { customer {} }'),
      getCustomerOrders: Promise.resolve('query () { orders {} }'),
      getCustomerOrderDetails: Promise.resolve('query () { orders {} }'),
      getProducts: Promise.resolve('query () { orders {} }'),
      getShoppingListById: Promise.resolve('query () { shoppinglist {} }'),
      getCustomerCart: Promise.resolve('query () { cart {} }'),
      getActiveCartId: Promise.resolve('query () { cart {} }'),
    };

    customerDao = new CustomerDao({ ctClient, graphql: gql });
  });

  describe('create()', () => {
    test('queries ctClient with the CustomerDraft', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: { customer: undefined } });

      /* Execute */
      await customerDao.create(market, customerDraftDto);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: customerDraftDto },
      );
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      const customerResponse = {
        customer: {
          id: faker.datatype.uuid(),
          email: customerDraftDto.email,
        },
      };
      execute.mockReturnValueOnce({ body: customerResponse });

      /* Execute */
      const result = await customerDao.create(market, customerDraftDto);

      /* Verify */
      expect(result).toBe(customerResponse.customer);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => customerDao.create(market, customerDraftDto));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const err = { body: { statusCode: 400, errors: [] } };
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const result = expect(() => customerDao.create(market, customerDraftDto));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  describe('addAddress()', () => {
    let customerId: string;
    let payload: any;

    beforeEach(() => {
      customerId = faker.datatype.uuid();
      payload = [{ action: 'some action...' }];
    });

    test('queries client with the customerId', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await customerDao.updateCustomer(market, customerId, payload);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: customerId },
      );
    });

    test('queries client with the payload', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await customerDao.updateCustomer(market, customerId, payload);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: payload },
      );
    });
  });

  describe('findOne()', () => {
    let customerDto: Customer;

    beforeEach(() => {
      customerDto = stubCustomerDto(market);
    });

    test('queries ctClient with ID', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await customerDao.findOne(market, customerDto.id);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: customerDto.id },
      );
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: customerDto });

      /* Execute */
      const result = await customerDao.findOne(market, customerDto.id);

      /* Verify */
      expect(result).toBe(customerDto);
    });

    test('returns undefined if CtClient throws 404', async () => {
      /* Prepare */
      const notFoundError = new Error('Not Found');
      (notFoundError as any).statusCode = 404;
      execute.mockRejectedValueOnce(notFoundError);

      /* Execute */
      const result = await customerDao.findOne(market, customerDto.id);

      /* Verify */
      expect(result).toBe(undefined);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => customerDao.findOne(market, customerDto.id));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('findGraphQLOne()', () => {
    let customerDto: Customer;

    beforeEach(() => {
      customerDto = stubCustomerDto(market);
    });

    test('returns client response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: { data: { customer: customerDto } } });

      /* Execute */
      const result = await customerDao.findGraphQLOne(market, customerDto.id);

      /* Verify */
      expect(result).toBe(customerDto);
    });

    test('returns undefined response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: { data: { customer: null } } });

      /* Execute */
      const result = await customerDao.findGraphQLOne(market, customerDto.id);

      /* Verify */
      expect(result).toBe(undefined);
    });
  });
  describe('changePassword()', () => {
    let version: number;
    let currentPassword: string;
    let newPassword: string;
    let payload: CustomerChangePassword;
    let id: string;
    beforeEach(() => {
      authHeader = faker.datatype.uuid();
      version = faker.datatype.number();
      currentPassword = faker.datatype.string();
      newPassword = faker.datatype.string();
      id = faker.datatype.string();
      payload = {
        id,
        version,
        currentPassword,
        newPassword,
      };
    });

    test('queries ctClient with the payload', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await customerDao.changePassword(market, payload, authHeader);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        {
          body: payload,
          headers: {
            Authorization: authHeader,
          },
        },
      );
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      const customer = stubCustomerDto();
      const ctCustomerResponse = { customer };
      execute.mockReturnValueOnce({ body: ctCustomerResponse });

      /* Execute */
      const result = await customerDao.changePassword(market, payload, authHeader);

      /* Verify */
      expect(result).toBe(ctCustomerResponse);
    });

    test('returns 403 if service returns any error', async () => {
      const serviceError = new Error('Bad Password');
      const expectedError = new ApiError(HttpStatusCodes.FORBIDDEN, 'Invalid password');

      execute.mockRejectedValueOnce(serviceError);

      const result = () => customerDao.changePassword(market, payload, authHeader);

      await expect(result).rejects.toThrow(expectedError);
    });
  });
  describe('resetCustomersPassword()', () => {
    let tokenValue: string;
    let newPassword: string;

    beforeEach(() => {
      tokenValue = faker.datatype.uuid();
      newPassword = faker.internet.password();
    });

    test('queries ctClient with token and newPassword', async () => {
      /* Execute */
      await customerDao.resetCustomersPassword(market, tokenValue, newPassword);

      /* Verify */
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: { tokenValue, newPassword } },
      );

      expect(execute).toHaveBeenCalledTimes(1);
    });

    test('returns true if Commerce tool updated the password', async () => {
      /* Execute */
      const response = await customerDao.resetCustomersPassword(market, tokenValue, newPassword);

      /* Verify */
      expect(response).toBe(true);
    });

    test('returns false if Commerce tool failed to update the password', async () => {
      /* Prepare */
      execute.mockRejectedValueOnce({});

      /* Execute */
      const response = await customerDao.resetCustomersPassword(market, tokenValue, newPassword);

      /* Verify */
      expect(response).toBe(false);
    });
  });
  describe('forgotCustomersPassword()', () => {
    const email = faker.internet.email();
    test('queries ctClient with email', async () => {
      /* Execute */
      execute.mockReturnValueOnce({ body: { value: faker.datatype.string() } });
      await customerDao.forgotCustomersPassword(market, email);

      /* Verify */
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: { email, ttlMinutes: Number(config.ttlMinutes) } },
      );

      expect(execute).toHaveBeenCalledTimes(1);
    });

    test('returns true if CT returns response', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: { value: faker.datatype.string() } });
      /* Execute */
      const response = await customerDao.forgotCustomersPassword(market, email);

      /* Verify */
      expect(response).toBeTruthy();
    });

    test('returns BAD_REQUEST', async () => {
      const serviceError = new Error('Bad Password');
      const expectedError = new ApiError(HttpStatusCodes.BAD_REQUEST, 'Invalid email id');

      execute.mockRejectedValueOnce(serviceError);

      const result = () => customerDao.forgotCustomersPassword(market, email);

      await expect(result).rejects.toThrow(expectedError);
    });
  });

  describe('login()', () => {
    let customerLoginRequestDto: CustomerSignin;

    beforeEach(() => {
      customerLoginRequestDto = {
        email: faker.internet.email(),
        password: faker.internet.password(),
      };
    });

    test('queries ctClient with email and Password', async () => {
      /* Execute */
      await customerDao.login(market, customerLoginRequestDto);

      /* Verify */
      expect(customerPasswordFlow).toHaveBeenCalledTimes(1);
      expect(customerPasswordFlow).toHaveBeenNthCalledWith(
        1,
        {
          username: customerLoginRequestDto.email,
          password: customerLoginRequestDto.password,
        },

        {
          disableRefreshToken: false,
        },
      );
    });

    test('returns response from CT', async () => {
      /* Execute */
      const customerLoginResDto = stubCustomerLoginResponseDto();
      customerPasswordFlow.mockReturnValueOnce(customerLoginResDto);

      const response = await customerDao.login(market, customerLoginRequestDto);

      /* Verify */
      expect(response).toBe(customerLoginResDto);
    });

    test('forwards CT errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.uuid());
      customerPasswordFlow.mockRejectedValueOnce(err);

      /* Execute */
      const login = () => customerDao.login(market, customerLoginRequestDto);

      /* Verify */
      await expect(login).rejects.toThrow(err);
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 400,
        status: {
          statusCode: 400,
          msg: faker.datatype.string(),
          timestamp: faker.datatype.datetime(),
        },
        errors: [
          {
            code: faker.datatype.string(),
            message: faker.datatype.string(),
          },
        ],
      };

      customerPasswordFlow.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => customerDao.login(market, customerLoginRequestDto));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  describe('setDefaultAddress()', () => {
    let version: number;
    let addressId: string;
    let payload : MyCustomerUpdate;
    let actions: any;
    beforeEach(() => {
      authHeader = faker.datatype.uuid();
      version = faker.datatype.number();
      addressId = faker.datatype.string();
      actions = [{
        action: 'setDefaultBillingAddress',
        addressId,
      }];

      payload = {
        version,
        actions,

      };
    });

    test('queries ctClient with the payload', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await customerDao.setDefaultAddress(market, payload, authHeader);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        {
          body: payload,
          headers: {
            Authorization: authHeader,
          },
        },
      );
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      const customer = stubCustomerDto();
      const ctCustomerResponse = { customer };
      execute.mockReturnValueOnce({ body: ctCustomerResponse });

      /* Execute */
      const result = await customerDao.setDefaultAddress(market, payload, authHeader);

      /* Verify */
      expect(result).toBe(ctCustomerResponse);
    });

    test('returns 403 if service returns any error', async () => {
      const serviceError = new Error('Bad Password');
      const expectedError = new ApiError(HttpStatusCodes.FORBIDDEN, 'Invalid address id');

      execute.mockRejectedValueOnce(serviceError);

      const result = () => customerDao.setDefaultAddress(market, payload, authHeader);

      await expect(result).rejects.toThrow(expectedError);
    });
  });
  describe('getCustomerDetailsGraphQL()', () => {
    let graphQLCustomerResponse: GraphQLCustomerResponse;
    test('returns client response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            me: {
              customer: {
                results: graphQLCustomerResponse,
              },
            },
          },
        },
      });

      /* Execute */
      const result = await customerDao.getCustomerDetailsGraphQL(market, authHeader);

      /* Verify */
      expect(result).toEqual({ results: graphQLCustomerResponse });
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader));

      /* Verify */
      await result.rejects.toThrowError();
    });

    test('re-throws non-404 ctClient errors if customer not found', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            me: {},
          },
        },
      });

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader));

      /* Verify */
      await result.rejects.toBeTruthy();
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const err = {
        statusCode: 401,
        message: 'Unauthorized',
        messageArray: [],
        timestamp: faker.time.recent(),
        errors: [
          null,
        ],
      };
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader));
      /* Verify */
      await result.rejects.toBeTruthy();
    });

    test('re-throws API-Error ctClient errors if statusCode is not present in error', async () => {
      /* Prepare */
      const err = {
        message: 'Unauthorized',
        timestamp: faker.time.recent(),
        errors: [
          null,
        ],
      };
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader));
      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });

  describe('updateMyCustomer()', () => {
    let payload: any;

    beforeEach(() => {
      authHeader = faker.datatype.uuid();
      payload = [{ action: 'some action...' }];
    });

    test('queries client with the payload', async () => {
      /* Prepare */
      const customer = stubCustomerDto();
      execute.mockReturnValueOnce(customer);

      /* Execute */
      await customerDao.updateMyCustomer(market, authHeader, payload);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        {
          body: payload,
          headers: {
            Authorization: authHeader,
          },
        },
      );
    });

    test('returns FORBIDDEN if Invalid customer', async () => {
      /* Prepare */
      const iseError = new ApiError(HttpStatusCodes.FORBIDDEN, 'Invalid customer');
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => customerDao.updateMyCustomer(market, authHeader, payload));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('setCustomerIdToCart()', () => {
    let cartId: string;
    let version: number;
    let customerId: string;
    let bodyDraft: CartUpdate;

    enum CART_ACTIONS {
      setCustomerId = 'setCustomerId',
    }

    beforeEach(() => {
      cartId = faker.datatype.uuid();
      customerId = faker.datatype.uuid();
      version = faker.datatype.number();
      bodyDraft = {
        version,
        actions: [{
          action: CART_ACTIONS.setCustomerId,
          customerId,
        }],
      };
    });

    test('queries ctClient with version, cartId and customerId', async () => {
      /* Execute */
      await customerDao.setCustomerIdToCart(market, cartId, version, customerId);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(
        1,
        { ID: cartId },
      );
    });

    test('post the setCustomerId action', async () => {
      /* Execute */
      await customerDao.setCustomerIdToCart(market, cartId, version, customerId);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1, { body: bodyDraft });
    });

    test('forwards CT errors', async () => {
      /* Prepare */
      const err = new Error(faker.datatype.uuid());
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const setCustomerIdToCart = () => customerDao.setCustomerIdToCart(market, cartId, version, customerId);

      /* Verify */
      await expect(setCustomerIdToCart).rejects.toThrow(err);
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const error = {
        statusCode: 400,
        status: {
          statusCode: 400,
          msg: faker.datatype.string(),
          timestamp: faker.datatype.datetime(),
        },
        errors: [
          {
            code: faker.datatype.string(),
            message: faker.datatype.string(),
          },
        ],
      };

      execute.mockRejectedValueOnce(error);
      /* Execute */
      const result = expect(() => customerDao.setCustomerIdToCart(market, cartId, version, customerId));

      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });
});
