import faker from '@faker-js/faker';
import axios from 'axios';
import Mock = jest.Mock;
import { AddressDao } from '../../src/daos';
import { stubDetailResponseDto } from '../__stubs__';

jest.mock('axios');

describe('addressDao', () => {
  let addressDao: AddressDao;
  let url: string;
  let address: string;
  let addressId: string;
  let detailResponseDto;

  beforeEach(() => {
    url = faker.datatype.string();
    address = faker.datatype.string();
    addressId = faker.datatype.string();
    detailResponseDto = stubDetailResponseDto;
    addressDao = {} as any;

    /* SUT */
    addressDao = new AddressDao();
  });

  describe('addressAutocomplete()', () => {
    test('mocking axios', async () => {
      /* Prepare */
      (axios.get as unknown as Mock).mockResolvedValueOnce({
        data: {
          suggestions: [
            {
              exactMatch: true,
              addressId: faker.datatype.uuid(),
            },
            {
              exactMatch: false,
              addressId: faker.datatype.uuid(),
            },
          ],
        },
      });

      /* Execute */
      await (addressDao).addressAutocomplete(url, address);

      /* Verify */
      expect(axios.get).toHaveBeenCalledTimes(1);
    });

    test('Failed to get address autocomplete from url', async () => {
      const expectedError = new Error(`Failed to get address autocomplete from url ${url}, because:`);

      (axios.get as unknown as Mock).mockRejectedValueOnce(
        expectedError,
      );
      const result = () => addressDao.addressAutocomplete(url, address);

      await expect(result).rejects.toThrow(expectedError);
    });
  });

  describe('addressDetail()', () => {
    test('mocking axios', async () => {
      /* Prepare */
      (axios.get as unknown as Mock).mockResolvedValueOnce({
        data: {
          detailResponseDto,
        },
      });

      /* Execute */
      const response = await (addressDao).addressDetail(url, addressId);

      /* Verify */
      expect(response).toBeTruthy();
      expect(axios.get).toHaveBeenCalledTimes(1);
    });

    test('Failed to get address details from url', async () => {
      const expectedError = new Error(`Failed to get address details from url ${url}, because:`);

      (axios.get as unknown as Mock).mockRejectedValueOnce(
        expectedError,
      );
      const result = () => addressDao.addressDetail(url, address);

      await expect(result).rejects.toThrow(expectedError);
    });
  });
});
