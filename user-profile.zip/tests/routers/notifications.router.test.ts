import { Router } from 'express';
import { NotificationsRouter } from '../../src/routers';
import { NotificationsController } from '../../src/controllers';
import { validateNotifications } from '../../src/validators';
import { apptusLogConfig, validateRequestSchema } from '../../src/middlewares';

describe('notificationsRouter', () => {
  let notificationsController: NotificationsController;
  let notificationsRouter: NotificationsRouter;
  let mockRouter: Router;

  beforeEach(() => {
    notificationsController = {
      product: jest.fn(),
      addToCart: jest.fn(),
    } as any;

    mockRouter = {
      post: jest.fn(() => mockRouter),
    } as any;

    notificationsRouter = new NotificationsRouter({
      notificationsController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter() for Search', () => {
    test('returns the express router', () => {
      const response = notificationsRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      notificationsRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenCalledTimes(2);
    });

    test('configures the GET /product route', () => {
      notificationsRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        1,
        '/product',
        validateNotifications,
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the GET /adding-to-cart route', () => {
      notificationsRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        2,
        '/adding-to-cart',
        validateNotifications,
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
