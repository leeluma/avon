import { Router } from 'express';
import { AddressController } from '../../src/controllers';
import { validateRequestSchema } from '../../src/middlewares';
import { AddressRouter } from '../../src/routers';
import { validateAddresses, validateAddressFinderId } from '../../src/validators';

describe('AddressRouter', () => {
  let addressController: AddressController;
  let addressRouter: AddressRouter;
  let mockRouter: Router;

  beforeEach(() => {
    addressController = {
      addressAutocomplete: jest.fn(),
      addressDetail: jest.fn(),
    } as any;

    mockRouter = {
      get: jest.fn(() => mockRouter),
    } as any;

    addressRouter = new AddressRouter({
      addressController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = addressRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      addressRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(2);
    });

    test('configures the GET /autocomplete route', () => {
      addressRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/autocomplete',
        validateAddresses,
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });

  test('configures the GET /detail route', () => {
    addressRouter.buildExpressRouter();

    expect(mockRouter.get).toHaveBeenNthCalledWith(
      2,
      '/detail',
      validateAddressFinderId,
      validateRequestSchema,
      expect.any(Function),
    );
  });
});
