import { Router } from 'express';
import { AccountRouter } from '../../src/routers/account.router';
import { AccountController } from '../../src/controllers/account.controller';
import { validateRequestSchema, magnoliaUrlMiddleware } from '../../src/middlewares';
import { stubRouter } from '../__stubs__';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks/express-validator.mock').default);

describe('AccountRouter', () => {
  let accountController: AccountController;
  let accountRouter: AccountRouter;
  let mockRouter: Router;

  beforeEach(() => {
    accountController = {
      getAccountPageData: jest.fn(),
    } as any;

    mockRouter = stubRouter();

    accountRouter = new AccountRouter({
      accountController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = accountRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      accountRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(1);
      expect(mockRouter.post).toHaveBeenCalledTimes(0);
    });

    /**
     * Test case for the route to get account data
     */
    test('configures the accounts routes', () => {
      accountRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/',
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
  });
});
