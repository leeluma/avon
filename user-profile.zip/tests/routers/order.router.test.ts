import { RequestHandler, Router } from 'express';
import { OrderRouter } from '../../src/routers';
import { OrderController } from '../../src/controllers';
import { validateBearerToken, validateOrderIdAndBearerToken } from '../../src/validators';
import { validateRequestSchema } from '../../src/middlewares';
import { config } from '../../src/config';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks/express-validator.mock').default);

jest.mock('../../src/config');
config.ctMarkets = JSON.stringify(['RO']);

describe('OrderRouter', () => {
  let orderController: OrderController;
  let orderRouter: OrderRouter;
  let mockRouter: Router;
  let authMiddleware: RequestHandler;

  beforeEach(() => {
    orderController = {
      getAll: jest.fn(),
      getOrderDetails: jest.fn(),
    } as any;

    mockRouter = {
      get: jest.fn(() => mockRouter),
    } as any;

    authMiddleware = jest.fn().mockReturnValueOnce(mockRouter);
    orderRouter = new OrderRouter({
      orderController,
      authMiddleware,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = orderRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      orderRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenCalledTimes(2);
    });

    test('configures the GET / route', () => {
      orderRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/orders',
        authMiddleware,
        validateBearerToken,
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the GET / route with orderId', () => {
      orderRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        2,
        '/orders/:orderId',
        authMiddleware,
        validateOrderIdAndBearerToken,
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
