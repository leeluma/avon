import { Router, RequestHandler } from 'express';
import { body } from 'express-validator';
import { CustomerRouter } from '../../src/routers';
import { CustomerController } from '../../src/controllers';
import {
  validateAddressId, validateId,
  fieldValidator, defaultAddress,
} from '../../src/validators';
import { validateRequestSchema } from '../../src/middlewares';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks/express-validator.mock').default);

describe('CustomerRouter', () => {
  let customerController: CustomerController;
  let customerRouter: CustomerRouter;
  let mockRouter: Router;
  let mockValidationSettingsMiddleware: RequestHandler;
  let authMiddleware: RequestHandler;

  beforeEach(() => {
    customerController = {
      getById: jest.fn(),
      registration: jest.fn(),
      changePassword: jest.fn(),
      getAddress: jest.fn(),
      addAddress: jest.fn(),
      updateAddress: jest.fn(),
      getAddressesByCustomerId: jest.fn(),
      updateMyCustomer: jest.fn(),
      deleteAddress: jest.fn(),
      login: jest.fn(),
      resetCustomersPassword: jest.fn(),
      forgotCustomersPassword: jest.fn(),
      defaultAddress: jest.fn(),
      getCustomerByToken: jest.fn(),
      updateCustomerOptIn: jest.fn(),
    } as any;

    mockRouter = {
      get: jest.fn(() => mockRouter),
      post: jest.fn(() => mockRouter),
      put: jest.fn(() => mockRouter),
      delete: jest.fn(() => mockRouter),
    } as any;

    mockValidationSettingsMiddleware = jest.fn(() => mockRouter);
    authMiddleware = jest.fn().mockReturnValueOnce(mockRouter);

    customerRouter = new CustomerRouter({
      customerController,
      Router: () => mockRouter,
      validationSettingsMiddleware: mockValidationSettingsMiddleware,
      addressValidationSettingsMiddleware: mockValidationSettingsMiddleware,
      authMiddleware,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = customerRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      customerRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(3);
      expect(mockRouter.post).toHaveBeenCalledTimes(9);
      expect(mockRouter.put).toHaveBeenCalledTimes(1);
      expect(mockRouter.delete).toHaveBeenCalledTimes(1);
    });

    test('configures the GET /:id route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        2,
        '/:id',
        validateId,
        validateRequestSchema,
        expect.any(Function),
      );
    });
    test('configures the POST /registration route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        1,
        '/registration',
        mockValidationSettingsMiddleware,
        [
          fieldValidator('email'),
          fieldValidator('firstName'),
          fieldValidator('lastName'),
          fieldValidator('password'),
          fieldValidator('confirmPassword'),
        ],
        body('cartId').optional().isUUID().withMessage('datatype.uuid'),
        validateRequestSchema,
        expect.any(Function),
      );
    });
    test('configures the POST /address route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        2,
        '/address',
        mockValidationSettingsMiddleware,
        [
          fieldValidator('firstName'),
          fieldValidator('lastName'),
          fieldValidator('address1'),
          fieldValidator('address2'),
          fieldValidator('phoneNumber'),
          fieldValidator('city'),
          fieldValidator('zip'),
        ],
        body('latitude').optional().isFloat({ min: 0, max: 360 }).withMessage('customer.latitude'),
        body('longitude').optional().isFloat({ min: 0, max: 360 }).withMessage('customer.longitude'),
        body('isBillingAddress').optional().isBoolean({ strict: true })
          .withMessage('customer.isBillingAddress'),
        validateRequestSchema,
        authMiddleware,
        expect.any(Function),
      );
    });

    test('configures the POST /reset-password route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        3,
        '/reset-password',
        body('token').notEmpty().isLength({ min: 40, max: 40 }).withMessage('token'),
        body('newPassword').notEmpty().isLength({ min: 6, max: 18 }).withMessage('internet.password'),
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the POST /change-password route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        4,
        '/change-password',
        mockValidationSettingsMiddleware,
        [
          fieldValidator('currentPassword'),
          fieldValidator('newPassword'),
        ],
        validateRequestSchema,
        authMiddleware,
        expect.any(Function),
      );
    });

    test('configures the PUT /address/:addressId route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.put).toHaveBeenNthCalledWith(
        1,
        '/address/:addressId',
        validateAddressId,
        mockValidationSettingsMiddleware,
        fieldValidator('firstName'),
        fieldValidator('lastName'),
        fieldValidator('address1'),
        fieldValidator('address2'),
        fieldValidator('phoneNumber'),
        fieldValidator('city'),
        fieldValidator('zip'),
        body('latitude').optional().isFloat({ min: 0, max: 360 }).withMessage('customer.latitude'),
        body('longitude').optional().isFloat({ min: 0, max: 360 }).withMessage('customer.longitude'),
        body('isBillingAddress').optional().isBoolean({ strict: true })
          .withMessage('customer.isBillingAddress'),
        validateRequestSchema,
        authMiddleware,
        expect.any(Function),
      );
    });

    test('configures the DELETE /address/:addressId route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.delete).toHaveBeenNthCalledWith(
        1,
        '/address/:addressId',
        validateRequestSchema,
        authMiddleware,
        validateAddressId,
        validateRequestSchema,
        authMiddleware,
        expect.any(Function),
      );
    });

    test('configures the POST /forgot-password route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        5,
        '/forgot-password',
        body('email').notEmpty().isEmail().withMessage('internet.email'),
        body('url').notEmpty().isURL().withMessage('internet.url'),
        validateRequestSchema,
        expect.any(Function),
      );
    });
    test('configures the POST /default-address/:addressId route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        6,
        '/default-address/:addressId',
        expect.any(Function),
        defaultAddress,
        validateRequestSchema,
        expect.any(Function),
      );
    });
    test('configures the GET / route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        3,
        '/',
        authMiddleware,
        validateRequestSchema,
        expect.any(Function),
      );
    });
    test('configures the POST /update route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        7,
        '/update',
        authMiddleware,
        mockValidationSettingsMiddleware,
        [
          fieldValidator('firstName'),
          fieldValidator('lastName'),
          fieldValidator('phoneNumber'),
        ],
        validateRequestSchema,
        expect.any(Function),
      );
    });
    test('configures the POST /login route', () => {
      customerRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenNthCalledWith(
        8,
        '/login',
        mockValidationSettingsMiddleware,
        [
          fieldValidator('email'),
          fieldValidator('password'),
        ],
        body('cartId').optional().isUUID().withMessage('datatype.uuid'),
        validateRequestSchema,
        expect.any(Function),
      );
    });
    test('configures the POST /marketing-constent route', () => {
      customerRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenNthCalledWith(
        9,
        '/marketing-constent',
        authMiddleware,
        body('optIn').isBoolean({ strict: true }).withMessage('customer.optIn'),
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
