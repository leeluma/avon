import { Router } from 'express';
import { body, param } from 'express-validator';
import { ShoppingListRouter } from '../../src/routers';
import { magnoliaUrlMiddleware, validateRequestSchema } from '../../src/middlewares';
import { ShoppingListController } from '../../src/controllers';
import { validateId } from '../../src/validators';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks/express-validator.mock').default);

describe('WishlistRouter', () => {
  let shoppingListController: ShoppingListController;
  let shoppingListRouter: ShoppingListRouter;
  let mockRouter: Router;

  beforeEach(() => {
    shoppingListController = {
      create: jest.fn(),
      moveAllLineItemsToCart: jest.fn(),
      moveOneLineItemToCart: jest.fn(),
      getById: jest.fn(),
      deleteLineItem: jest.fn(),
    } as any;

    mockRouter = {
      post: jest.fn(() => mockRouter),
      get: jest.fn(() => mockRouter),
      delete: jest.fn(() => mockRouter),
    } as any;

    shoppingListRouter = new ShoppingListRouter({
      shoppingListController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = shoppingListRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      shoppingListRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenCalledTimes(2);
      expect(mockRouter.get).toHaveBeenCalledTimes(1);
    });

    test('configures the POST /:id/cart/lineitems route', () => {
      shoppingListRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        2,
        '/:id/cart/lineitems',
        validateId,
        body('cartId').isUUID(),
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the GET /:id route', () => {
      shoppingListRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/:id',
        validateId,
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });

    test('configures the DELETE /:id/lineitems/:lineItemId route', () => {
      shoppingListRouter.buildExpressRouter();

      expect(mockRouter.delete).toHaveBeenNthCalledWith(
        1,
        '/:id/lineitems/:lineItemId',
        validateId,
        param('lineItemId').isUUID(),
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
