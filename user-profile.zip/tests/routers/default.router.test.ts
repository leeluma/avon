import { Router, RequestHandler } from 'express';
import { DefaultRouter } from '../../src/routers';
import { DefaultController } from '../../src/controllers';
import {
  validateRefreshToken, validateVerifyToken, validateAuthorizeToken,
} from '../../src/validators';
import { validateRequestSchema } from '../../src/middlewares';
import { stubRouter } from '../__stubs__';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks/express-validator.mock').default);

describe('DefaultRouter', () => {
  let defaultController: DefaultController;
  let defaultRouter: DefaultRouter;
  let mockRouter: Router;
  let validationSettingsMiddleware: RequestHandler;

  beforeEach(() => {
    defaultController = {
      login: jest.fn(),
      updateMyCartById: jest.fn(),
      getPickupDetail: jest.fn(),
      refreshToken: jest.fn(),
      verifyToken: jest.fn(),
      logout: jest.fn(),
    } as any;

    mockRouter = stubRouter();
    validationSettingsMiddleware = jest.fn(() => mockRouter);

    defaultRouter = new DefaultRouter({
      defaultController,
      Router: () => mockRouter,
      validationSettingsMiddleware,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = defaultRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });
    test('mounts the expected number of routes', () => {
      defaultRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenCalledTimes(3);
    });

    test('configures the POST /refresh-token route', () => {
      defaultRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        1,
        '/refresh-token',
        validateRefreshToken,
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the POST /verify-token route', () => {
      defaultRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        2,
        '/verify-token',
        validateVerifyToken,
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the POST /logout route', () => {
      defaultRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        3,
        '/logout',
        validateAuthorizeToken,
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
