import faker from '@faker-js/faker';
import {
  stubGraphQLLineItem,
} from '.';
import { GraphQLOrder } from '../../src/dtos/order.dto';

export const AddressStub = (): any => {
  return {
    id: faker.datatype.uuid(),
    firstName: faker.datatype.string(),
    lastName: faker.datatype.string(),
    streetName: faker.datatype.string(),
    streetNumber: faker.datatype.number(),
    additionalStreetInfo: faker.datatype.string(),
    city: faker.datatype.string(),
    region: faker.datatype.string(),
    state: faker.datatype.string(),
    postalCode: faker.datatype.string(),
    country: faker.datatype.string(),
    company: faker.datatype.string(),
    department: faker.datatype.string(),
    building: faker.datatype.string(),
    apartment: faker.datatype.string(),
    pOBox: faker.datatype.string(),
    additionalAddressInfo: faker.datatype.string(),
    phone: faker.datatype.string(),
    mobile: faker.datatype.string(),
    email: faker.datatype.string(),
    custom: {
      type: {
        id: faker.datatype.uuid(),
        name: faker.datatype.string(),
      },
      customFieldsRaw: [
        {
          name: faker.datatype.string(),
          value: faker.datatype.string(),
        },
        {
          name: faker.datatype.string(),
          value: faker.datatype.string(),
        },
        {
          name: faker.datatype.string(),
          value: faker.datatype.string(),
        },
        {
          name: 'recipientName',
          value: faker.datatype.string(),
        },
      ],
    },
  };
};
