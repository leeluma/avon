import faker from '@faker-js/faker';
import { GraphQLLineItem, OrderLineItem } from '../../src/dtos';

export const stubGraphQLLineItem = (
  config: Partial<GraphQLLineItem> = {},
): GraphQLLineItem => {
  return {
    id: faker.datatype.uuid(),
    productId: faker.datatype.uuid(),
    productSlug: `p/${faker.datatype.uuid()}`,
    name: faker.name.firstName(),
    quantity: faker.datatype.number(),
    totalPrice: {
      type: 'centPrecision',
      currencyCode: 'RON',
      centAmount: faker.datatype.number(),
      fractionDigits: 2,
    },
    variant: {
      id: faker.datatype.number(),
      sku: faker.datatype.uuid(),
      images: [],
      attributesRaw: [
        {
          name: 'ContentFillMeasure',
          value: 'kg',
        },
        {
          name: 'ContentFill',
          value: '2022-04-01T00:00:00.000Z',
        },
        {
          name: 'endDate',
          value: '2022-05-01T00:00:00.000Z',
        },
        {
          name: 'brandName',
          value: 'Avon Attraction',
        },
        {
          name: 'finishedStockCode',
          value: '52456',
        },
        {
          name: 'maxPurchasableQty',
          value: 10,
        },
        {
          name: 'discontinued',
          value: false,
        },
        {
          name: 'excludeCountDown',
          value: true,
        },
      ],
      prices: [
        {
          id: faker.datatype.uuid(),
          value: {
            type: 'centPrecision',
            currencyCode: 'RON',
            centAmount: 8500,
            fractionDigits: 2,
          },
          channel: {
            typeId: 'channel',
            id: 'c6960089-fb9f-4d3a-a075-b0208be59137',
          },
        },
      ],
    },
    discountedPricePerQuantity: [{
      quantity: 1,
      discountedPrice: {
        value: {
          type: 'centPrecision',
          currencyCode: 'RON',
          centAmount: faker.datatype.number(),
          fractionDigits: faker.datatype.number(),
        },
        includedDiscounts: [
          {
            discount: {
              typeId: 'cart-discount',
              id: faker.datatype.uuid(),
            },
            discountedAmount: {
              type: 'centPrecision',
              currencyCode: 'RON',
              centAmount: faker.datatype.number(),
              fractionDigits: faker.datatype.number(),
            },
          },
        ],
      },
    }],
    ...config,
  };
};

export const stubOrderLineItem = (
  config: Partial<OrderLineItem> = {},
): OrderLineItem => {
  return {
    lineItemId: faker.datatype.uuid(),
    productId: faker.datatype.uuid(),
    productSlug: faker.datatype.uuid(),
    name: faker.name.firstName(),
    skuCode: faker.datatype.uuid(),
    images: [],
    quantity: faker.datatype.number(),
    totalPrice: faker.datatype.number(),
    currencyCode: 'RON',
    hexCode: '',
    unitPrice: '',
    listPrice: 0,
    sellPrice: 0,
    formattedListPrice: '',
    formattedSellPrice: '',
    variantType: '',
    variantValue: '',
    offers: [],
    ...config,
  };
};
