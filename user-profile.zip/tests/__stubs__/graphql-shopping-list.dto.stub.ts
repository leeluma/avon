import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { GraphQLShoppingList } from '../../src/dtos';

export const stubGraphQLShoppingList = (
  market: MarketInfo,
  config: Partial<GraphQLShoppingList> = {},
): GraphQLShoppingList => {
  return {
    id: faker.datatype.uuid(),
    key: faker.datatype.uuid(),
    name: faker.random.word(),
    lineItems: [{
      name: faker.datatype.string(),
      productSlug: faker.datatype.string(),
      id: faker.datatype.string(),
      quantity: faker.datatype.number(),
      productId: faker.datatype.string(),
    }],
    version: faker.datatype.number(),
    ...config,
  };
};
