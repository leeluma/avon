import faker from '@faker-js/faker';
import { WishlistDto } from '../../src/dtos';

export const stubWishlistDto = (
  config: Partial<WishlistDto> = {},
): WishlistDto => {
  return {
    id: faker.datatype.uuid(),
    name: faker.random.word(),
    lineItems: [],
    ...config,
  };
};
