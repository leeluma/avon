import faker from '@faker-js/faker';
import { ChangePasswordRequestDto, SetDefaultAddressDto } from '../../src/dtos';

export const stubChangePasswordRequestDto = (
  config: Partial<ChangePasswordRequestDto> = {},
): ChangePasswordRequestDto => {
  return {
    customerId: faker.datatype.uuid(),
    currentPassword: faker.internet.password(),
    newPassword: faker.internet.password(),
    ...config,
  };
};

export const stubSetDefaultAddressDto = (
  config: Partial<SetDefaultAddressDto> = {},
): SetDefaultAddressDto => {
  return {
    isBilling: faker.datatype.boolean(),
    isDelivery: faker.datatype.boolean(),
    addressId: faker.datatype.string(),
    version: faker.datatype.number(),
    ...config,
  };
};
