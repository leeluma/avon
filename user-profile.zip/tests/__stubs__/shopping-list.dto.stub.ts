import { ShoppingList } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { stubTrackingFields } from './trackingfields.stub';

export const stubShoppingList = (
  market: MarketInfo,
  config: Partial<ShoppingList> = {},
): ShoppingList => {
  return {
    id: faker.datatype.uuid(),
    key: faker.datatype.uuid(),
    name: { [market.locale]: faker.random.word() },
    lineItems: [],
    version: faker.datatype.number(),
    ...stubTrackingFields(),
    ...config,
  };
};
