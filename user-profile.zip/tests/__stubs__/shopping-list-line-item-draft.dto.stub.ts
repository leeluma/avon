import { ShoppingListLineItem } from '@commercetools/platform-sdk';
import { MarketInfo } from '../../src/middlewares';

export const stubShoppingListLineItemDraft = (
  market: MarketInfo,
  config: Partial<ShoppingListLineItem> = {},
): ShoppingListLineItem => {
  return {
    id: 'abc',
    addedAt: 'qwe',
    name: {
      en: 'abc',
    },
    productId: '123e',
    quantity: 1,
    productType: {
      typeId: 'product-type',
      id: ' abc',
    },
    ...config,
  };
};
