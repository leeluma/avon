import faker from '@faker-js/faker';

export const stubVerifyTokenDto = (
  config: Partial<any> = {},
): any => {
  return {
    id: faker.datatype.uuid(),
    customerId: faker.datatype.uuid(),
    email: faker.datatype.string(),
    firstName: faker.datatype.string(),
    lastName: faker.datatype.string(),
    password: faker.datatype.string(),
    addresses: {
      firstName: faker.datatype.string(),
      lastName: faker.datatype.string(),
      city: faker.address.city(),
      region: faker.address.streetName(),
      zip: faker.address.zipCode(),
      country: faker.address.country(),
      state: faker.address.state(),
      phoneNumber: faker.address.state(),
    },
    authenticationMode: 'Password',
    ...config,
  };
};
