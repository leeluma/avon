import {
  ByProjectKeyRequestBuilder,
// eslint-disable-next-line import/no-unresolved
} from '@commercetools/platform-sdk/dist/declarations/src/generated/client/by-project-key-request-builder';
import { CtClient } from '../../src/lib';

export const stubCtClient = (
  expectedCountry: string,
  requestBuilderConfig: Partial<ByProjectKeyRequestBuilder>,
): CtClient => {
  return {
    getClient: (country): ByProjectKeyRequestBuilder => {
      expect(country).toEqual(expectedCountry);
      return {
        ...requestBuilderConfig,
      } as ByProjectKeyRequestBuilder;
    },
  } as CtClient;
};

export const stubCtCustomerClient = (
  expectedCountry: string,
  requestBuilderConfig: any,
): any => {
  return {
    getClient: (country) => {
      expect(country).toEqual(expectedCountry);
      return {
        ...requestBuilderConfig,
      };
    },
    getAuthClient: (country) => {
      expect(country).toEqual(expectedCountry);
      return {
        ...requestBuilderConfig,
      };
    },
  } as any;
};
