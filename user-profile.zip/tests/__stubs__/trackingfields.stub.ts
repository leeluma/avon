import faker from '@faker-js/faker';
import { TrackingFieldsDto } from '../../src/dtos';

export const stubTrackingFields = (
  config: Partial<TrackingFieldsDto> = {},
): TrackingFieldsDto => {
  return {
    createdAt: faker.datatype.datetime().toISOString(),
    createdBy: {
      clientId: faker.datatype.uuid(),
      isPlatformClient: faker.datatype.boolean(),
    },
    lastModifiedAt: faker.datatype.datetime().toISOString(),
    lastModifiedBy: {
      clientId: faker.datatype.uuid(),
      isPlatformClient: faker.datatype.boolean(),
    },
    ...config,
  };
};
