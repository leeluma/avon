import { CartDraft } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';

export const stubCartDraftDto = (
  config: Partial<CartDraft> = {},
): CartDraft => {
  return {
    currency: faker.finance.currencyCode(),
    ...config,
  };
};
