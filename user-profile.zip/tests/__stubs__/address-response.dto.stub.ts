import faker from '@faker-js/faker';
import { AddressResponseDto } from '../../src/dtos';

export const stubAddressResponseDto = (
  config: Partial<AddressResponseDto> = {},
): AddressResponseDto => {
  return {
    id: faker.datatype.uuid(),
    customerId: faker.datatype.uuid(),
    address1: faker.address.streetAddress(),
    address2: faker.address.streetAddress(),
    city: faker.address.city(),
    region: faker.address.streetName(),
    zip: faker.address.zipCode(),
    county: faker.address.county(),
    country: faker.address.country(),
    latitude: parseInt(faker.address.latitude(), 10),
    longitude: parseInt(faker.address.longitude(), 10),
    address3: faker.address.streetAddress(),
    address4: faker.address.streetAddress(),
    state: faker.address.state(),
    phoneNumber: faker.address.state(),
    isBillingAddress: faker.datatype.boolean(),
    isShippingAddress: faker.datatype.boolean(),
    ...config,
  };
};
