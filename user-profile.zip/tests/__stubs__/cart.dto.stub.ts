import faker from '@faker-js/faker';
import { CartDto } from '../../src/dtos';

export const stubCartDto = (
  config: Partial<CartDto> = {},
): CartDto => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    ...config,
  };
};
