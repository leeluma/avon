import { Router } from 'express';

export const stubRouter = (
  config: Partial<Router> = {},
): Router => {
  const stub = {
    get: jest.fn(() => stub),
    post: jest.fn(() => stub),
    ...config,
  } as Router;

  return stub;
};
