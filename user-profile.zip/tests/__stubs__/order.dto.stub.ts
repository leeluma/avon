import { Product } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import {
  stubGraphQLAddressDto,
  stubGraphQLLineItem,
  stubAddressResponseDto,
  stubOrderLineItem,
  stubTrackingFields,
} from '.';
import { OrderResponse } from '../../src/dtos';

export const stubGraphQLOrder = (
  config: Partial<any> = {},
): any => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    lineItems: [stubGraphQLLineItem()],
    totalPrice: {
      type: 'centPrecision',
      currencyCode: 'RON',
      centAmount: faker.datatype.number(),
      fractionDigits: 2,
    },
    discountCodes: [{
      state: 'MatchesCart',
      discountCode: { id: faker.datatype.uuid() },
      code: faker.datatype.string(),
    }],
    shippingAddress: stubGraphQLAddressDto(),
    custom: {
      customFieldsRaw: [
        {
          name: 'shippingAddressType',
          value: 'Pickup',
        },
      ],
    },
    paymentInfo: {
      payments: [
        {
          key: null,
          paymentStatus: {
            state: {
              name: null,
            },
          },
          paymentMethodInfo: {
            method: 'CashOnDelivery',
            name: null,
          },
          amountPlanned: {
            type: 'centPrecision',
            currencyCode: 'RON',
            centAmount: 9228,
            fractionDigits: 2,
          },
        },
      ],
    },
    billingAddress: stubGraphQLAddressDto(),
    ...stubTrackingFields(),
    ...config,
  };
};

export const stubOrderResponse = (
  config: Partial<OrderResponse> = {},
): OrderResponse => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    lineItems: [stubOrderLineItem()],
    totalPrice: faker.datatype.number(),
    currencyCode: 'RON',
    shippingAddress: stubAddressResponseDto(),
    billingAddress: stubAddressResponseDto(),
    ...stubTrackingFields(),
    ...config,
  };
};

export const stubMagnoliaSettings = (
  config: Partial<any> = {},
): any => {
  return {
    priceFormat: {
      '@name': 'priceFormat',
      '@path': '/ro/settings/priceFormat',
      '@id': '14251328-5916-4fb7-a445-ffd7589076b3',
      '@nodeType': 'mgnl:contentNode',
      ccy: 'RON',
      showDecimalZero: 'true',
      thousandSeperator: ',',
      noOfDigit: '2',
      currencyPlacement: 'before',
      decimalPoint: '.',
      isVatIncluded: 'true',
      vatIncludedMessage: 'Vat Include',
      baseMeasure: {
        '@name': 'baseMeasure',
        '@path': '/ro/settings/priceFormat/baseMeasure',
        '@id': 'ebae5260-ab77-4651-b611-5218f9851bff',
        '@nodeType': 'mgnl:contentNode',
        translation: 'mg',
        unitPriceBaseMeasure: '100 mg',
        containerSizeLimit: '10',
        baseMeasure0: {
          '@name': 'baseMeasure0',
          '@path': '/ro/settings/priceFormat/baseMeasure/baseMeasure0',
          '@id': '4184818d-85b9-4c9d-a8b3-536f2484a959',
          '@nodeType': 'mgnl:contentNode',
          unitType: 'mg',
          translation: 'MG',
          unitPriceBaseMeasure: '100',
          containerSizeLimit: '0',
          '@nodes': [],
        },
        baseMeasure1: {
          '@name': 'baseMeasure1',
          '@path': '/ro/settings/priceFormat/baseMeasure/baseMeasure1',
          '@id': '9cc1a022-a571-474e-a5d7-c6dc16edbcc7',
          '@nodeType': 'mgnl:contentNode',
          unitType: 'kg',
          translation: 'KG',
          unitPriceBaseMeasure: '1',
          containerSizeLimit: '0',
          '@nodes': [],
        },
        baseMeasure2: {
          '@name': 'baseMeasure2',
          '@path': '/ro/settings/priceFormat/baseMeasure/baseMeasure2',
          '@id': '792cca79-db52-4c8a-8932-50684dd8397d',
          '@nodeType': 'mgnl:contentNode',
          unitType: 'undefined',
          translation: 'G',
          unitPriceBaseMeasure: '100',
          containerSizeLimit: '15',
          '@nodes': [],
        },
        baseMeasure3: {
          '@name': 'baseMeasure3',
          '@path': '/ro/settings/priceFormat/baseMeasure/baseMeasure3',
          '@id': '1ebae344-b9e2-4622-91dd-0cf15012d731',
          '@nodeType': 'mgnl:contentNode',
          unitType: 'ml',
          translation: 'ML',
          unitPriceBaseMeasure: '100',
          containerSizeLimit: '0',
          '@nodes': [],
        },
        baseMeasure4: {
          '@name': 'baseMeasure4',
          '@path': '/ro/settings/priceFormat/baseMeasure/baseMeasure4',
          '@id': 'b5e975aa-f225-40f7-845f-908ca4fe60c3',
          '@nodeType': 'mgnl:contentNode',
          unitType: 'l',
          translation: 'L',
          unitPriceBaseMeasure: '1',
          containerSizeLimit: '0',
          '@nodes': [],
        },
        baseMeasure5: {
          '@name': 'baseMeasure5',
          '@path': '/ro/settings/priceFormat/baseMeasure/baseMeasure5',
          '@id': 'c848752a-15c7-43cd-ad68-1baea75542cc',
          '@nodeType': 'mgnl:contentNode',
          unitType: 'set',
          translation: 'szt.',
          unitPriceBaseMeasure: '1',
          containerSizeLimit: '0',
          '@nodes': [],
        },
        baseMeasure6: {
          '@name': 'baseMeasure6',
          '@path': '/ro/settings/priceFormat/baseMeasure/baseMeasure6',
          '@id': 'e423bdc0-c064-450e-92b2-e691baaa2875',
          '@nodeType': 'mgnl:contentNode',
          unitType: 'pair',
          translation: 'Paar',
          unitPriceBaseMeasure: '1',
          containerSizeLimit: '0',
          '@nodes': [],
        },
        '@nodes': [
          'baseMeasure0',
          'baseMeasure1',
          'baseMeasure2',
          'baseMeasure3',
          'baseMeasure4',
          'baseMeasure5',
          'baseMeasure6',
        ],
      },
      '@nodes': [
        'baseMeasure',
      ],
    },
    ...config,
  };
};

export const stubCtProductDto = (
  config: Partial<Product> = {},
): any => {
  return {
    id: faker.datatype.uuid(),
    key: faker.datatype.string(),
    masterData: {
      current: {
        categories: [
          {
            slug: faker.datatype.string(),
            name: faker.datatype.string(),
            key: faker.datatype.string(),
            description: faker.datatype.string(),
            custom: {
              customFieldsRaw: [
                {
                  name: faker.datatype.string(),
                  value: faker.datatype.string(),
                },
              ],
            },
          },
        ],
      },
    },
    ...config,
  };
};
