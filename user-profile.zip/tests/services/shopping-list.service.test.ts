import {
  ShoppingList, ShoppingListLineItem,
} from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { ShoppingListService } from '../../src/services';
import { ApiError } from '../../src/lib';
import { ShoppingListDao, CartDao, SettingDao } from '../../src/daos';
import { ShoppingListMapper } from '../../src/mappers';
import {
  stubCartDto, stubGraphQLShoppingList, stubMagnoliaInfo,
  stubMarket, stubShoppingList, stubShoppingListLineItemDraft, stubWishlistDto,
} from '../__stubs__';
import {
  CartDto, Writable, MagnoliaPriceFormatDto, WishlistDto, GraphQLShoppingList, MagnoliaInfo,
} from '../../src/dtos';
import Mock = jest.Mock;

describe('LeapBeWishlistService', () => {
  /* System Under Test */
  let shoppingListService: ShoppingListService;
  /* Dependencies */
  let shoppingListDao: ShoppingListDao;
  let settingDao: SettingDao;
  let market: MarketInfo;
  let cartDao: CartDao;
  let shoppingListMapper: ShoppingListMapper;
  let magPriceFormat: MagnoliaPriceFormatDto;
  let magnolia: MagnoliaInfo;

  beforeEach(() => {
    market = stubMarket();

    /* Dependencies */
    shoppingListDao = {
      create: jest.fn(),
      findOneBy: jest.fn(),
      findOne: jest.fn(),
      findGraphQLOne: jest.fn(),
      updateLineItemQuantity: jest.fn(),
      delete: jest.fn(),
      getPriceFormat: jest.fn(),
      getResult: jest.fn(),
    } as any;
    magnolia = stubMagnoliaInfo();

    cartDao = {
      create: jest.fn(),
      findOne: jest.fn(),
      addLineItem: jest.fn(),
      addShoppingList: jest.fn(),
    } as any;
    settingDao = {
      getPriceFormat: jest.fn(),
    } as any;
    shoppingListMapper = {
      mapShoppingListResponse: jest.fn(),
    } as any;
    const magnoliaGlobalSettingUrl = faker.internet.url();

    /* SUT */
    shoppingListService = new ShoppingListService({
      shoppingListDao,
      settingDao,
      cartDao,
      shoppingListMapper,
      globalSettingUrl: magnoliaGlobalSettingUrl,
    });
  });

  describe('moveAllLineItemsToCart()', () => {
    let shoppingListDto: ShoppingList;
    let cartDto: CartDto;

    beforeEach(() => {
      shoppingListDto = stubShoppingList(market);
      cartDto = stubCartDto();

      shoppingListDao.deleteLineItems = jest.fn();
      (shoppingListDao.findOne as Mock).mockReturnValueOnce(shoppingListDto);
      (cartDao.findOne as Mock).mockReturnValueOnce(cartDto);
    });

    // TODO getShoppingListAndCart

    test('asks CtCartDao to copy the items', async () => {
      /* Prepare */
      cartDao.addShoppingList = jest.fn();

      /* Execute */
      await shoppingListService.moveAllLineItemsToCart(market, shoppingListDto.id, cartDto.id);

      /* Verify */
      expect(cartDao.addShoppingList).toHaveBeenCalledTimes(1);
      expect(cartDao.addShoppingList).toHaveBeenNthCalledWith(
        1,
        market,
        cartDto.id,
        cartDto.version,
        shoppingListDto.id,
      );
    });

    test('deletes the LineItems from the ShoppingList', async () => {
      /* Prepare */
      const lineItem1 = stubShoppingListLineItemDraft(market);
      const lineItem2 = stubShoppingListLineItemDraft(market);
      const lineItem3 = stubShoppingListLineItemDraft(market);
      shoppingListDto.lineItems?.push(lineItem1, lineItem2, lineItem3);

      /* Execute */
      await shoppingListService.moveAllLineItemsToCart(market, shoppingListDto.id, cartDto.id);

      /* Verify */
      expect(shoppingListDao.deleteLineItems).toHaveBeenCalledTimes(1);
      expect(shoppingListDao.deleteLineItems).toHaveBeenNthCalledWith(
        1,
        market,

        shoppingListDto.id,

        shoppingListDto.version,
        [lineItem1.id, lineItem2.id, lineItem3.id],
      );
    });

    test('returns the shoppingListId and cartId', async () => {
      /* Execute */
      const response = await shoppingListService.moveAllLineItemsToCart(market, shoppingListDto.id, cartDto.id);

      /* Verify */
      expect(response).toEqual({
        wishlistId: shoppingListDto.id,
        cartId: cartDto.id,
      });
    });
  });

  describe('moveOneLineItemToCart()', () => {
    let shoppingListDto: Writable<ShoppingList>;
    let lineItemDto: ShoppingListLineItem;
    let cartDto: CartDto;

    beforeEach(() => {
      lineItemDto = stubShoppingListLineItemDraft(market);
      shoppingListDto = stubShoppingList(market, {
        lineItems: [{
          id: 'abc',
          addedAt: 'qwe',
          name: {
            en: 'abc',
          },
          productId: '123e',
          quantity: 1,
          productType: {
            typeId: 'product-type',
            id: ' abc',
          },
        }],
      });
      cartDto = stubCartDto();

      (shoppingListService as any).getShoppingListAndCart = jest.fn().mockReturnValueOnce({ shoppingListDto, cartDto });
      cartDao.addLineItem = jest.fn();
      shoppingListDao.deleteLineItems = jest.fn();
    });
    // addedAt, name, productId, productType, quantity
    test('gets ShoppingList and Cart from CT', async () => {
      /* Execute */
      await shoppingListService.moveOneLineItemToCart(
        market,
        shoppingListDto.id,
        lineItemDto.id,
        cartDto.id,
      );

      /* Verify */
      expect((shoppingListService as any).getShoppingListAndCart).toHaveBeenCalledTimes(1);
      expect((shoppingListService as any).getShoppingListAndCart).toHaveBeenNthCalledWith(
        1,
        market,
        shoppingListDto.id,
        cartDto.id,
      );
    });

    test('throws NOT_FOUND if LineItem is not in ShoppingList', async () => {
      /* Prepare */
      shoppingListDto.lineItems = [];

      /* Execute */
      const result = expect(() => shoppingListService.moveOneLineItemToCart(
        market,
        shoppingListDto.id,
        lineItemDto.id,
        cartDto.id,
      ));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(403, `LineItem id "${lineItemDto.id}" does not exist in Wishlist "${shoppingListDto.id}"`),
      );
    });

    test('adds LineItem to Cart', async () => {
      /* Prepare */
      cartDao.addLineItem = jest.fn();

      /* Execute */
      await shoppingListService.moveOneLineItemToCart(
        market,
        shoppingListDto.id,
        lineItemDto.id,
        cartDto.id,
      );

      /* Verify */
      expect(cartDao.addLineItem).toHaveBeenCalledTimes(1);
      expect(cartDao.addLineItem).toHaveBeenNthCalledWith(
        1,
        market,
        cartDto.id,
        cartDto.version,
        lineItemDto.productId,
        lineItemDto.variantId,
      );
    });

    test('removes the LineItem from the ShoppingList', async () => {
      /* Execute */
      await shoppingListService.moveOneLineItemToCart(
        market,
        shoppingListDto.id,
        lineItemDto.id,
        cartDto.id,
      );

      /* Verify */
      expect(shoppingListDao.deleteLineItems).toHaveBeenCalledTimes(1);
      expect(shoppingListDao.deleteLineItems).toHaveBeenNthCalledWith(
        1,
        market,
        shoppingListDto.id,
        shoppingListDto.version,
        [lineItemDto.id],
      );
    });
  });

  describe('getShoppingListAndCart()', () => {
    let shoppingListDto: Writable<ShoppingList>;
    let cartDto: CartDto;

    beforeEach(() => {
      shoppingListDto = stubShoppingList(market);
      cartDto = stubCartDto();

      shoppingListDao.deleteLineItems = jest.fn();
      (shoppingListDao.findOne as Mock).mockReturnValueOnce(shoppingListDto);
      (cartDao.findOne as Mock).mockReturnValueOnce(cartDto);
      (cartDao.create as Mock).mockReturnValueOnce(cartDto);
    });

    test('throws NOT_FOUND if CtShoppingList does not exist', async () => {
      /* Prepare */
      shoppingListDao.findOne = jest.fn().mockReturnValueOnce(undefined);

      /* Execute */
      const result = expect(() => (shoppingListService as any)
        .getShoppingListAndCart(market, shoppingListDto.id, cartDto.id));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(404, `Wishlist with id "${shoppingListDto.id}" was not found`),
      );
    });

    test('throws NOT_FOUND if CtCart does not exist', async () => {
      /* Prepare */
      cartDao.findOne = jest.fn().mockReturnValueOnce(undefined);

      /* Execute */
      const result = expect(() => (shoppingListService as any)
        .getShoppingListAndCart(market, shoppingListDto.id, cartDto.id));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(404, `Cart with id "${cartDto.id}" was not found`),
      );
    });

    test('throws FORBIDDEN if customerId does not match', async () => {
      /* Prepare */
      shoppingListDto.customer = { id: faker.datatype.uuid(), typeId: 'customer' };
      cartDto.customerId = faker.datatype.uuid();
      expect(cartDto.customerId).not.toEqual(shoppingListDto.customer);
      /* Execute */

      const result = expect(() => (shoppingListService as any).getShoppingListAndCart(
        market,
        shoppingListDto.id,
        cartDto.id,
      ));

      /* Verify */

      await result.rejects.toThrow(
        new ApiError(403, 'You may not perform this operation'),
      );
    });

    test('throws FORBIDDEN if anonymousId does not match', async () => {
      /* Prepare */
      shoppingListDto.anonymousId = faker.datatype.uuid();
      cartDto.anonymousId = faker.datatype.uuid();
      expect(cartDto.anonymousId).not.toEqual(shoppingListDto.anonymousId);

      /* Execute */
      const result = expect(() => (shoppingListService as any)
        .getShoppingListAndCart(market, shoppingListDto.id, cartDto.id));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(403, 'You may not perform this operation'),
      );
    });

    test('creates Cart if cartId does not exist', async () => {
      /* Prepare */

      /* Execute */
      const result = await (shoppingListService as any).getShoppingListAndCart(
        market,
        shoppingListDto.id,

        undefined,
      );

      /* Verify */
      expect(cartDao.create).toHaveBeenCalledTimes(1);
      expect(cartDao.create).toHaveBeenNthCalledWith(
        1,
        market,

        {
          customerId: shoppingListDto.customer?.id,
          anonymousId: shoppingListDto.anonymousId,
          currency: 'RON',
        },
      );

      expect(result).toEqual({ shoppingListDto, cartDto });
    });
  });

  describe('getById()', () => {
    let shoppingListDto: GraphQLShoppingList | undefined;
    let wishlistDto: WishlistDto;

    beforeEach(() => {
      shoppingListDao.findGraphQLOne = jest.fn();
      shoppingListDto = stubGraphQLShoppingList(market);
      settingDao.getPriceFormat = jest.fn().mockReturnValueOnce(magPriceFormat);
    });

    test('maps CtWishlistDto to WishlistDto', async () => {
      /* Prepare */
      (shoppingListDao.findGraphQLOne as Mock).mockReturnValueOnce(shoppingListDto);
      (shoppingListMapper.mapShoppingListResponse as Mock).mockReturnValueOnce(shoppingListDto);

      const params = { isPage: true, wishlistId: faker.datatype.string() };

      /* Execute */
      await shoppingListService.getById(market, params, magnolia);
      await settingDao.getPriceFormat(market);
      /* Verify */
      expect(shoppingListMapper.mapShoppingListResponse).toHaveBeenCalledTimes(1);
      expect(shoppingListMapper.mapShoppingListResponse).toHaveBeenNthCalledWith(
        1,
        market,
        shoppingListDto,
        magPriceFormat,
      );
    });

    test('maps CtWishlistDto to WishlistDto if magnolia.isPreview equals to false', async () => {
      /* Prepare */
      magnolia.isPreview = false;
      magnolia.marketPath = 'ab';
      (shoppingListDao.findGraphQLOne as Mock).mockReturnValueOnce(shoppingListDto);
      (shoppingListMapper.mapShoppingListResponse as Mock).mockReturnValueOnce(shoppingListDto);

      const params = { isPage: true, wishlistId: faker.datatype.string() };

      /* Execute */
      await shoppingListService.getById(market, params, magnolia);
      await settingDao.getPriceFormat(market);
      /* Verify */
      expect(shoppingListMapper.mapShoppingListResponse).toHaveBeenCalledTimes(1);
      expect(shoppingListMapper.mapShoppingListResponse).toHaveBeenNthCalledWith(
        1,
        market,
        shoppingListDto,
        magPriceFormat,
      );
    });

    test('maps CtWishlistDto to WishlistDto if shoppingListDto equals to undefined', async () => {
      /* Prepare */
      shoppingListDto = undefined;
      (shoppingListDao.findGraphQLOne as Mock).mockReturnValueOnce(shoppingListDto);
      (shoppingListMapper.mapShoppingListResponse as Mock).mockReturnValueOnce(shoppingListDto);

      const params = { isPage: true, wishlistId: faker.datatype.string() };

      /* Execute */
      await shoppingListService.getById(market, params, magnolia);
      await settingDao.getPriceFormat(market);
      /* Verify */
      expect(shoppingListMapper.mapShoppingListResponse).toHaveBeenCalledTimes(0);
    });
  });

  describe('deleteLineItem()', () => {
    let wishlistId;
    let lineItemId;

    beforeEach(() => {
      wishlistId = faker.datatype.uuid();
      lineItemId = faker.datatype.uuid();
      shoppingListDao.deleteLineItems = jest.fn();
    });

    test('throw error if wishlistId is invalid', async () => {
      /* Execute */
      const result = expect(() => {
        return shoppingListService.deleteLineItem(market, wishlistId, lineItemId);
      });

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(401, 'Invalid wishlistId.'),
      );
    });

    test('calls shoppingListDao.deleteLineItem()', async () => {
      /* prepare */
      const shoppingListDto = stubShoppingList(market);
      (shoppingListDao.findOne as Mock).mockReturnValueOnce(shoppingListDto);
      /* Execute */
      await shoppingListService.deleteLineItem(market, wishlistId, lineItemId);
      /* Verify */
      expect(shoppingListDao.deleteLineItems).toHaveBeenCalledTimes(1);
      expect(shoppingListDao.deleteLineItems).toHaveBeenNthCalledWith(
        1,
        market,
        wishlistId,
        shoppingListDto.version,
        [lineItemId],
      );
    });

    test('maps CT response to Dao', async () => {
      /* Prepare */
      const shoppingListDto = stubShoppingList(market);
      (shoppingListDao.findOne as Mock).mockReturnValueOnce(shoppingListDto);
      (shoppingListDao.deleteLineItems as Mock).mockReturnValueOnce(shoppingListDao);

      /* Execute */
      await shoppingListService.deleteLineItem(market, wishlistId, lineItemId);

      /* Verify */
      expect(shoppingListMapper.mapShoppingListResponse).toHaveBeenCalledTimes(1);
      expect(shoppingListMapper.mapShoppingListResponse).toBeTruthy();
    });

    test('returns result from mapper', async () => {
      /* Prepare */
      const shoppingListDto = stubShoppingList(market);
      (shoppingListDao.findOne as Mock).mockReturnValueOnce(shoppingListDto);
      const wishlistDto = stubWishlistDto();
      (shoppingListMapper.mapShoppingListResponse as Mock).mockReturnValueOnce(wishlistDto);

      /* Execute */
      const response = await shoppingListService.deleteLineItem(market, wishlistId, lineItemId);

      /* Verify */
      expect(response).toEqual(wishlistDto);
    });
  });
});
