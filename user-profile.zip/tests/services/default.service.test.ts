import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { DefaultDao } from '../../src/daos';
import {
  stubMarket,
} from '../__stubs__';
import { DefaultService } from '../../src/services';
import Mock = jest.Mock;

describe('DefaultService', () => {
  /* System Under Test */
  let defaultService: DefaultService;

  /* Dependencies */
  let defaultDao: DefaultDao;
  let market: MarketInfo;
  let params: string;
  beforeEach(() => {
    market = stubMarket(
      {
        locale: 'ro',
        country: 'RO',
      },
    );
    /* Dependencies */
    defaultDao = {
      refreshToken: jest.fn(),
      verifyToken: jest.fn(),
      logout: jest.fn(),
    } as any;
    params = faker.datatype.string();

    /* SUT */
    defaultService = new DefaultService({ defaultDao });
  });

  test('call refreshToken method', async () => {
    /* Prepare */
    (defaultDao.refreshToken as Mock)
      .mockReturnValueOnce({ access_token: faker.datatype.string() });

    /* Execute */
    await defaultService.refreshToken(market, params);

    /* Verify */
    expect(defaultDao.refreshToken).toHaveBeenCalledTimes(1);
    expect(defaultDao.refreshToken).toHaveBeenNthCalledWith(
      1,
      market,
      params,
    );
  });

  test('call verifyToken method', async () => {
    /* Prepare */
    (defaultDao.verifyToken as Mock)
      .mockReturnValueOnce({ access_token: faker.datatype.string() });

    /* Execute */
    await defaultService.verifyToken(market, params);

    /* Verify */
    expect(defaultDao.verifyToken).toHaveBeenCalledTimes(1);
    expect(defaultDao.verifyToken).toHaveBeenNthCalledWith(
      1,
      market,
      params,
    );
  });

  test('call logout method', async () => {
    const authorizeToken = faker.datatype.string();
    /* Prepare */
    (defaultDao.logout as Mock)
      .mockReturnValueOnce({ data: true });

    /* Execute */
    await defaultService.logout(authorizeToken);

    /* Verify */
    expect(defaultDao.logout).toHaveBeenCalledTimes(1);
    expect(defaultDao.logout).toHaveBeenNthCalledWith(
      1,
      authorizeToken,
    );
  });
});
