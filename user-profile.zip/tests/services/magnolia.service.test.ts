import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { MagnoliaInfo } from '../../src/dtos';
import {
  stubMarket, stubMagnoliaInfo, stubMagnoliaHome,
} from '../__stubs__';
import { MagnoliaDao } from '../../src/daos';
import { MagnoliaService } from '../../src/services/magnolia.service';
import Mock = jest.Mock;

describe('LeapApp', () => {
  /* System Under Test */
  let magnoliaService: MagnoliaService;

  /* Dependencies */
  let magnoliaDao: MagnoliaDao;
  let market: MarketInfo;
  let magnolia: MagnoliaInfo;
  let magnoliaHome;
  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();
    magnoliaHome = stubMagnoliaHome();
    /* Dependencies */
    magnoliaDao = {} as any;

    /* SUT */
    magnoliaService = new MagnoliaService({ magnoliaDao });
  });

  /**
   * Unit test case for Get Magnolia Data
   */
  describe('Get Magnolia Data', () => {
    beforeEach(() => {
      magnoliaDao.getAccountPageData = jest.fn();
      magnoliaDao.getGlobalSetting = jest.fn();
      magnoliaDao.getTemplateDataFromMagnolia = jest.fn();
    });

    test('fetches Account data from Magnolia', async () => {
      /* Prepare */
      (magnoliaDao.getAccountPageData as Mock).mockReturnValueOnce(magnoliaHome);
      /* Execute */
      const result = await magnoliaService.getAccountPageData(market, magnolia);

      /* Verify */
      expect(result).toEqual(magnoliaHome);
      expect(magnoliaDao.getAccountPageData).toHaveBeenCalledTimes(1);
    });

    test('fetches template data from Magnolia', async () => {
      /* Prepare */
      const templateName = faker.datatype.string();
      const magnoliaBasePath = faker.datatype.string();
      (magnoliaDao.getTemplateDataFromMagnolia as Mock).mockReturnValueOnce(magnoliaHome);

      /* Execute */
      const result = await magnoliaService.getTemplateData(templateName, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaDao.getTemplateDataFromMagnolia).toHaveBeenCalledTimes(1);
    });

    test('fetches global settings from Magnolia', async () => {
      /* Prepare */
      (magnoliaDao.getGlobalSetting as Mock).mockResolvedValueOnce(magnoliaHome);
      /* Execute */
      const result = await magnoliaService.getGlobalSettingsData(market, magnolia);

      /* Verify */
      expect(result).toEqual(magnoliaHome);
      expect(magnoliaDao.getGlobalSetting).toHaveBeenCalledTimes(1);
    });
  });
});
