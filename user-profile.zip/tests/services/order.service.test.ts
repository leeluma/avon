import faker from '@faker-js/faker';
import i18next from 'i18next';
import HttpStatusCodes from 'http-status-codes';
import { MarketInfo } from '../../src/middlewares';
import { MagnoliaDao, OrderDao } from '../../src/daos';
import {
  stubMarket, stubOrderResponse, stubGraphQLOrder, stubMagnoliaSettings,
} from '../__stubs__';
import { OrderService } from '../../src/services';
import Mock = jest.Mock;
import {
  OrderResponse,
  GraphQLOrder,
  GetMyOrdersDraftDto,
  GraphQLOrderList,
} from '../../src/dtos';
import { OrderMapper } from '../../src/mappers';
import { ApiError } from '../../src/lib';

describe('OrderService', () => {
  /* System Under Test */
  let orderService: OrderService;

  /* Dependencies */
  let orderDao: OrderDao;
  let magnoliaDao: MagnoliaDao;
  let orderMapper: OrderMapper;
  let market: MarketInfo;
  let graphQLOrder: GraphQLOrder[];
  let graphQLOrderList: GraphQLOrderList;
  let orderResponse: OrderResponse[];
  let authHeader: string;
  let orderId: string;
  let globalSettings;
  let queryParams:GetMyOrdersDraftDto;

  beforeEach(() => {
    orderMapper = {
      getLineItems: jest.fn(),
      createOrderResponse: jest.fn(),
      mapOrderDetails: jest.fn(),
      getCartProductId: jest.fn(),
    } as any;
    market = stubMarket();
    orderDao = {
      find: jest.fn(),
      fetchOrder: jest.fn(),
      fetchProductsDetail: jest.fn(),
    } as any;
    magnoliaDao = {
      getGlobalSetting: jest.fn(),
    } as any;
    orderService = new OrderService({ orderDao, orderMapper, magnoliaDao });
    orderResponse = [stubOrderResponse()];
    graphQLOrder = [stubGraphQLOrder()];
    graphQLOrderList = {
      total: faker.datatype.number(),
      results: graphQLOrder,
    };
    globalSettings = stubMagnoliaSettings();
    authHeader = `Bearer ${faker.random.randomWord()}`;
    orderId = faker.datatype.uuid();
    queryParams = {
      page: faker.datatype.number(),
      sort: faker.datatype.string(),
      limit: faker.datatype.number(),
    };
  });

  describe('getAll()', () => {
    test('fetches list of data from orderDto', async () => {
      /* Prepare */
      (orderDao.find as Mock).mockReturnValueOnce(graphQLOrderList);
      (magnoliaDao.getGlobalSetting as Mock).mockReturnValueOnce(globalSettings);
      (orderMapper.createOrderResponse as Mock).mockReturnValueOnce([orderResponse]);

      /* Execute */
      await orderService.getAll(market, authHeader, queryParams);

      /* Verify */
      expect(orderDao.find).toHaveBeenCalledTimes(1);
      expect(magnoliaDao.getGlobalSetting).toHaveBeenCalledTimes(1);
      expect(orderMapper.createOrderResponse).toHaveBeenCalledTimes(1);
    });

    test('returns undefined if orders do not exist', async () => {
      /* Prepare */
      (orderDao.find as Mock).mockReturnValueOnce(undefined);

      /* Execute */
      const response = await orderService.getAll(market, authHeader, queryParams);

      /* Verify */
      expect(response).toBeUndefined();
      expect(orderMapper.createOrderResponse).not.toHaveBeenCalled();
    });
  });

  describe('orderDetails()', () => {
    test('fetches list of data from orderDto', async () => {
      /* Prepare */
      graphQLOrder = stubGraphQLOrder();
      (magnoliaDao.getGlobalSetting as Mock).mockReturnValueOnce(globalSettings);
      (orderDao.fetchOrder as Mock).mockReturnValueOnce(graphQLOrder);

      /* Execute */
      await orderService.orderDetails(market, authHeader, orderId);

      /* Verify */
      expect(magnoliaDao.getGlobalSetting).toHaveBeenCalledTimes(1);
      expect(orderDao.fetchOrder).toHaveBeenCalledTimes(1);
      expect(orderMapper.mapOrderDetails).toHaveBeenCalledTimes(1);
    });

    test('returns undefined if order does not exist', async () => {
      /* Prepare */
      graphQLOrder = stubGraphQLOrder();
      (magnoliaDao.getGlobalSetting as Mock).mockReturnValueOnce(globalSettings);
      (orderDao.fetchOrder as Mock).mockReturnValueOnce(undefined);

      /* Execute */
      const result = expect(() => orderService.orderDetails(market, authHeader, orderId));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.orderIdNotFound')),
      );
    });
  });
});
