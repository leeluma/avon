import faker from '@faker-js/faker';
import { AddressDao } from '../../src/daos';
import { AddressService } from '../../src/services';
import { MarketInfo } from '../../src/middlewares';
import { stubAutocompleteResponseDto, stubDetailResponseDto, stubMarket } from '../__stubs__';
import Mock = jest.Mock;

describe('addressService', () => {
  /* System Under Test */
  let addressService: AddressService;

  /* Dependencies */
  let addressDao: AddressDao;
  let market: MarketInfo;

  beforeEach(() => {
    addressDao = {} as any;
    market = stubMarket(
      {
        locale: 'ro',
        country: 'RO',
      },
    );

    /* SUT */
    addressService = new AddressService({ addressDao });
  });

  describe('addressAutoComplete()', () => {
    let address: string;

    beforeEach(() => {
      addressDao.addressAutocomplete = jest.fn();
      address = faker.datatype.string();
    });

    test('reads the autocompleteResponseDto from addressDao', async () => {
      /* Prepare */
      const addressAutocompleteDto = [stubAutocompleteResponseDto()];
      (addressDao.addressAutocomplete as Mock).mockReturnValueOnce({ addressAutocompleteDto });

      /* Execute */
      await addressService.addressAutocomplete(market, address);

      /* Verify */
      expect(addressDao.addressAutocomplete).toHaveBeenCalledTimes(1);
    });
  });

  describe('addressDetail()', () => {
    let addressId: string;

    beforeEach(() => {
      addressDao.addressDetail = jest.fn();
      addressId = faker.datatype.string();
    });

    test('reads the DetailResponseDto from addressDao', async () => {
      /* Prepare */
      const detailResponseDto = [stubDetailResponseDto()];
      (addressDao.addressDetail as Mock).mockReturnValueOnce({ detailResponseDto });

      /* Execute */
      await addressService.addressDetail(market, addressId);

      /* Verify */
      expect(addressDao.addressDetail).toHaveBeenCalledTimes(1);
    });
  });
});
