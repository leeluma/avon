import faker from '@faker-js/faker';
import HttpStatusCodes from 'http-status-codes';
import {
  Address, AddressDraft, Customer, CustomerChangePassword, CustomerSignin,
} from '@commercetools/platform-sdk';
import i18next from 'i18next';
import { MarketInfo } from '../../src/middlewares';
import { CustomerDao, AddressDao, CartDao } from '../../src/daos';
import {
  stubMarket, stubAddressResponseDto,
  stubCustomerRequestDto,
  stubCustomerResponseDto,
  stubAddressDraftDto,
  stubAddressDto,
  stubGraphQLAddressDto,
  stubGraphQLCustomerDto,
  stubChangePasswordRequestDto,
  stubCustomerDto,
  stubSetDefaultAddressDto,
  stubCustomerLoginRequestDto,
  stubCustomerLoginResponseDto,

} from '../__stubs__';
import { AddressAction, CustomerService, CustomCustomerDraft } from '../../src/services';
import Mock = jest.Mock;
import {
  AddressCollectionResponseDto,
  AddressRequestDto,
  CustomerResponseDto,
  CustomerRegistrationRequestDto,
  Writable,
  ChangePasswordRequestDto,
  SetDefaultAddressDto,
  CustomerRequestDto,
  LoginDto,
  CustomerLoginResponseDto,
  CustomerOptInRequestDto,
} from '../../src/dtos';
import { AddressMapper, CustomerMapper } from '../../src/mappers';
import { stubAddressRequestDto } from '../__stubs__/address-request.dto.stub';
import {
  addressCustomTypeKey, ApiError, customerCustomTypeKey, AwsEventBridgeClient,
} from '../../src/lib';

const REGEXP_UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;

type Writeable<T> = { -readonly [P in keyof T]: T[P] };

type CustomerWritableAddress = Writeable<Customer>;

describe('CustomerService', () => {
  /* System Under Test */
  let customerService: CustomerService;

  /* Dependencies */
  let customerDao: CustomerDao;
  let addressDao: AddressDao;
  let cartDao: CartDao;
  let addressMapper: AddressMapper;
  let customerMapper: CustomerMapper;
  let market: MarketInfo;
  let eventBridgeClient: AwsEventBridgeClient;
  let eventBridgeClientCatch: Mock;
  let marketingEmailConsentEventBusName: string;
  let passwordResetEventBusName: string;

  beforeAll(() => {
    jest.useFakeTimers().setSystemTime(new Date());
  });

  afterAll(() => {
    jest.useRealTimers();
  });

  beforeEach(() => {
    market = stubMarket();

    addressMapper = {
      mapAddressResponse: jest.fn(),
      mapGraphQLAddressResponse: jest.fn(),
      mapAddressCollectionResponse: jest.fn(),
      createAddressDraft: jest.fn(),
      createAddressDraftFromDetails: jest.fn(),
    } as any;
    customerMapper = {
      mapCustomerResponse: jest.fn(),
      mapGraphQLCustomerResponse: jest.fn(),
    } as any;
    customerDao = {} as any;
    addressDao = {} as any;
    cartDao = {} as any;
    eventBridgeClientCatch = jest.fn((callback) => callback());
    eventBridgeClient = { putEvent: jest.fn().mockReturnValueOnce({ catch: eventBridgeClientCatch }) } as any;

    /* SUT */
    customerService = new CustomerService({
      customerDao,
      addressDao,
      cartDao,
      addressMapper,
      customerMapper,
      eventBridgeClient,
      marketingEmailConsentEventBusName,
      passwordResetEventBusName,
    });
  });
  describe('login()', () => {
    let loginDto: LoginDto;
    let customerLoginResDto: CustomerLoginResponseDto;

    beforeEach(() => {
      customerDao.login = jest.fn();
      cartDao.findOne = jest.fn();
      customerDao.setCustomerIdToCart = jest.fn();
      cartDao.getCustomerWishlistAndCartId = jest.fn();
      loginDto = stubCustomerLoginRequestDto();
      customerLoginResDto = stubCustomerLoginResponseDto();
    });

    test('reads the customer data from customerDao', async () => {
      /* Prepare */
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      (cartDao.findOne as Mock).mockReturnValueOnce({ version: 1 });

      const customerLoginDraftReqDto: CustomerSignin = {
        email: loginDto.email,
        password: loginDto.password,
      };

      /* Execute */
      await customerService.login(market, loginDto);

      /* Verify */
      expect(customerDao.login).toHaveBeenCalledTimes(1);
      expect(customerDao.login).toHaveBeenNthCalledWith(
        1,
        market,

        customerLoginDraftReqDto,
      );
    });
    test('reads the customer data from customerDao if cartId not present in requestBody', async () => {
      /* Prepare */
      delete loginDto.cartId;
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      (cartDao.getCustomerWishlistAndCartId as Mock).mockReturnValueOnce({
        shoppingLists: {
          results: [
            {
              id: faker.datatype.uuid(),
            },
          ],
        },
        me: {
          activeCart: {
            id: faker.datatype.uuid(),
          },
        },
      });

      const customerLoginDraftReqDto: CustomerSignin = {
        email: loginDto.email,
        password: loginDto.password,
      };

      /* Execute */
      await customerService.login(market, loginDto);

      /* Verify */
      expect(customerDao.login).toHaveBeenCalledTimes(1);
      expect(customerDao.login).toHaveBeenNthCalledWith(
        1,
        market,

        customerLoginDraftReqDto,
      );
    });
    test('throws NOT_FOUND if CtCart does not exist', async () => {
      /* Prepare */
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      cartDao.findOne = jest.fn().mockReturnValueOnce(undefined);

      /* Execute */
      const result = expect(() => customerService.login(market, loginDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartNotFound')),
      );
    });

    test('throws CONFLICT, if cart attached to customer', async () => {
      /* Prepare */
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      cartDao.findOne = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
        customerId: faker.datatype.uuid(),
      });

      /* Execute */
      const result = expect(() => customerService.login(market, loginDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.CONFLICT, i18next.t('error.cartIdConflict')),
      );
    });
  });

  describe('registration()', () => {
    let customerDto: Customer;
    let loginDto: LoginDto;
    let customerLoginResDto: CustomerLoginResponseDto;
    let customerRequestDto: CustomerRegistrationRequestDto;

    beforeEach(() => {
      loginDto = stubCustomerLoginRequestDto();
      customerRequestDto = stubCustomerRequestDto();
      customerLoginResDto = stubCustomerLoginResponseDto();
      customerDto = stubCustomerDto();
      customerDao.create = jest.fn();
      customerDao.login = jest.fn();
      cartDao.findOne = jest.fn();
      customerDao.setCustomerIdToCart = jest.fn();
    });

    test('creates the Customer using the customerDao', async () => {
      /* Prepare */
      (customerDao.create as Mock).mockReturnValueOnce(customerDto);
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      (cartDao.findOne as Mock).mockReturnValueOnce({ version: 1 });
      (customerMapper.mapCustomerResponse as Mock).mockReturnValueOnce(customerDto);
      const currentDate = Math.floor(new Date().getTime() / 1000);
      const customerEmail = customerRequestDto.email.split('@')[0].replace(/\./g, '');
      const customerDraftDto: CustomCustomerDraft = {
        key: customerRequestDto.key ?? `${customerEmail}-${currentDate}`,
        email: customerRequestDto.email,
        isEmailVerified: false,
        firstName: customerRequestDto.firstName,
        lastName: customerRequestDto.lastName,
        password: customerRequestDto.password,
        custom: {
          type: {
            typeId: 'type',
            key: customerCustomTypeKey,
          },
          fields: {
            OptIn: customerRequestDto.optIn,
            TermsAndConditions: true,
            Activated: false,
            ActivatedDate: new Date(),
            IsFraud: false,
          },
        },
      };

      /* Execute */
      await customerService.registration(market, customerRequestDto);
      await customerDao.login(market, loginDto);

      /* Verify */
      expect(customerDao.create).toHaveBeenCalledTimes(1);
      expect(customerDao.create).toHaveBeenNthCalledWith(
        1,
        market,
        customerDraftDto,
      );
    });

    test('creates the Customer using the customerDao if optIn false', async () => {
      /* Prepare */
      (customerDao.create as Mock).mockReturnValueOnce(customerDto);
      (cartDao.findOne as Mock).mockReturnValueOnce({ version: 1 });
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      delete customerRequestDto.optIn;

      const currentDate = Math.floor(new Date().getTime() / 1000);
      const customerEmail = customerRequestDto.email.split('@')[0].replace(/\./g, '');

      const customerDraftDto: CustomCustomerDraft = {
        key: customerRequestDto.key ?? `${customerEmail}-${currentDate}`,
        email: customerRequestDto.email,
        isEmailVerified: false,
        firstName: customerRequestDto.firstName,
        lastName: customerRequestDto.lastName,
        password: customerRequestDto.password,
        custom: {
          type: {
            typeId: 'type',
            key: customerCustomTypeKey,
          },
          fields: {
            OptIn: customerRequestDto.optIn ?? false,
            TermsAndConditions: true,
            Activated: false,
            ActivatedDate: new Date(),
            IsFraud: false,
          },
        },
      };

      /* Execute */
      await customerService.registration(market, customerRequestDto);
      await customerDao.login(market, loginDto);

      /* Verify */
      expect(customerDao.create).toHaveBeenCalledTimes(1);
      expect(customerDao.create).toHaveBeenNthCalledWith(
        1,
        market,
        customerDraftDto,
      );
    });

    test('throws NOT_FOUND if CtCart does not exist', async () => {
      /* Prepare */
      (customerDao.create as Mock).mockReturnValueOnce(customerDto);
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      cartDao.findOne = jest.fn().mockReturnValueOnce(undefined);

      /* Execute */
      const result = expect(() => customerService.registration(market, customerRequestDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartNotFound')),
      );
    });

    test('throws CONFLICT, if cart attached to customer', async () => {
      /* Prepare */
      (customerDao.login as Mock).mockReturnValueOnce(customerLoginResDto);
      cartDao.findOne = jest.fn().mockReturnValueOnce({
        version: faker.datatype.number(),
        customerId: faker.datatype.uuid(),
      });

      /* Execute */
      const result = expect(() => customerService.registration(market, customerRequestDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.CONFLICT, i18next.t('error.cartIdConflict')),
      );
    });
  });

  describe('getById()', () => {
    let customerResponseDto: CustomerResponseDto;
    let customerDto: Customer;

    beforeEach(() => {
      customerDao.findOne = jest.fn();
      customerDao.findGraphQLOne = jest.fn();
      customerDto = stubCustomerDto(market);
      customerResponseDto = stubCustomerResponseDto();
    });

    test('fetches data from customerDto', async () => {
      /* Prepare */
      (customerDao.findGraphQLOne as Mock).mockReturnValueOnce(customerDto);
      (customerMapper.mapGraphQLCustomerResponse as Mock).mockReturnValueOnce(customerResponseDto);

      /* Execute */
      await customerService.getById(market, customerResponseDto.id);

      /* Verify */
      expect(customerDao.findGraphQLOne).toHaveBeenCalledTimes(1);
      expect(customerDao.findGraphQLOne).toHaveBeenNthCalledWith(1, market, customerResponseDto.id);
    });

    test('maps Customer to CustomerResponseDto', async () => {
      /* Prepare */
      (customerDao.findGraphQLOne as Mock).mockReturnValueOnce(customerResponseDto);
      (customerMapper.mapGraphQLCustomerResponse as Mock).mockReturnValueOnce(customerResponseDto);

      /* Execute */
      await customerService.getById(market, customerResponseDto.id);

      /* Verify */
      expect(customerMapper.mapGraphQLCustomerResponse).toHaveBeenCalledTimes(1);
      expect(customerMapper.mapGraphQLCustomerResponse).toHaveBeenNthCalledWith(1, customerResponseDto, true);
    });

    test('returns the CustomerResponseDto from mapper', async () => {
      /* Prepare */
      (customerDao.findGraphQLOne as Mock).mockReturnValueOnce(customerResponseDto);
      (customerMapper.mapGraphQLCustomerResponse as Mock).mockReturnValueOnce(customerResponseDto);

      /* Execute */
      const response = await customerService.getById(market, customerResponseDto.id);

      /* Verify */
      expect(response).toBe(customerResponseDto);
    });

    test('returns undefined if the customer does not exist', async () => {
      /* Prepare */
      (customerDao.findGraphQLOne as Mock).mockReturnValueOnce(undefined);
      (customerMapper.mapGraphQLCustomerResponse as Mock).mockReturnValueOnce(customerResponseDto);

      /* Execute */
      const response = await customerService.getById(market, customerResponseDto.id);

      /* Verify */
      expect(response).toBeUndefined();
      expect(customerMapper.mapGraphQLCustomerResponse).not.toHaveBeenCalled();
    });
  });

  describe('getAddress()', () => {
    let customerResponseDto;
    let customerDto;

    beforeEach(() => {
      customerDao.findOne = jest.fn();
      customerDao.findGraphQLOne = jest.fn();
      customerDto = stubGraphQLCustomerDto(market);
      customerResponseDto = stubCustomerResponseDto();
    });

    test('fetches data from customerDao', async () => {
      /* Prepare */
      (customerDao.findGraphQLOne as Mock).mockReturnValueOnce(customerDto);
      (customerMapper.mapGraphQLCustomerResponse as Mock).mockReturnValueOnce(customerResponseDto);

      /* Execute */
      await customerService.getAddress(market, customerResponseDto.id);

      /* Verify */
      expect(customerDao.findGraphQLOne).toHaveBeenCalledTimes(1);
      expect(customerDao.findGraphQLOne).toHaveBeenNthCalledWith(
        1,
        market,
        customerResponseDto.id,
      );
    });

    test('maps addressDto to AddressResponseDto', async () => {
      /* Prepare */
      const addressDto1 = stubGraphQLAddressDto(customerDto);
      const addressDto2 = stubGraphQLAddressDto(customerDto);
      customerDto.addresses = [addressDto1, addressDto2];
      (customerDao.findGraphQLOne as Mock).mockReturnValueOnce(customerDto);
      (customerMapper.mapCustomerResponse as Mock).mockReturnValueOnce(customerResponseDto);

      /* Execute */
      await customerService.getAddress(market, customerResponseDto.id);

      /* Verify */
      expect(addressMapper.mapGraphQLAddressResponse).toHaveBeenCalledTimes(2);
      expect(addressMapper.mapGraphQLAddressResponse).toHaveBeenNthCalledWith(
        1,
        addressDto1,
        customerDto,
      );
      expect(addressMapper.mapGraphQLAddressResponse).toHaveBeenNthCalledWith(
        2,
        addressDto2,
        customerDto,
      );
    });

    test('returns the CustomerResponseDto from mapper', async () => {
      /* Prepare */
      customerDto.addresses = [stubGraphQLAddressDto(customerDto), stubGraphQLAddressDto(customerDto)];
      (customerDao.findGraphQLOne as Mock).mockReturnValueOnce(customerDto);
      const address1 = stubAddressResponseDto();
      const address2 = stubAddressResponseDto();
      (addressMapper.mapGraphQLAddressResponse as Mock)
        .mockReturnValueOnce(address1)
        .mockReturnValueOnce(address2);

      /* Execute */
      const response = await customerService.getAddress(market, customerDto.id);

      /* Verify */
      expect(response).toEqual([address1, address2]);
    });

    test('returns undefined if the customer does not exist', async () => {
      /* Prepare */
      (customerDao.findGraphQLOne as Mock).mockReturnValueOnce(undefined);
      (customerMapper.mapGraphQLCustomerResponse as Mock).mockReturnValueOnce(customerResponseDto);

      /* Execute */
      const response = await customerService.getAddress(market, customerResponseDto.id);

      /* Verify */
      expect(response).toBeUndefined();
      expect(customerMapper.mapGraphQLCustomerResponse).not.toHaveBeenCalled();
    });
  });

  describe('addAddress()', () => {
    let customerId: string;
    let addressRequestDto: AddressRequestDto;
    let addressDraft: AddressDraft;
    let customerDto: CustomerWritableAddress;
    let payloadAddAddressAction: AddressAction;
    let mappedCustomerAddress: AddressCollectionResponseDto;

    beforeEach(() => {
      customerDao.findOne = jest.fn();
      customerDao.updateCustomer = jest.fn();
      addressDao.addressDetail = jest.fn();
      customerId = faker.datatype.uuid();
      addressRequestDto = stubAddressRequestDto();
      customerDto = stubCustomerDto();

      mappedCustomerAddress = {
        addresses: [stubAddressResponseDto(), stubAddressResponseDto()],
      };
      (addressMapper.mapAddressCollectionResponse as Mock).mockReturnValueOnce(
        mappedCustomerAddress,
      );
      addressDraft = {
        custom: {
          type: {
            key: addressCustomTypeKey,
            typeId: 'type',
          },
          fields: {
            Address1: addressRequestDto.address1,
            Address2: addressRequestDto.address2,
            Address3: addressRequestDto.address3,
            Address4: addressRequestDto.address4,
            county: addressRequestDto.county,
            Latitude: addressRequestDto.latitude,
            Longitude: addressRequestDto.longitude,
            RecipientName: `${addressRequestDto.firstName} ${addressRequestDto.lastName}`,
          },
        },
        country: market.country,
        city: addressRequestDto.city,
        region: addressRequestDto.region,
        postalCode: addressRequestDto.zip,
        state: addressRequestDto.state,
        phone: addressRequestDto.phoneNumber,
        firstName: addressRequestDto.firstName,
        lastName: addressRequestDto.lastName,
        key: expect.stringMatching(REGEXP_UUID),
      };
      payloadAddAddressAction = {
        action: 'addAddress',
        address: addressDraft,
      };
    });

    test('reads the customerDto from customerDao', async () => {
      /* Prepare */
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.addAddress(market, customerId, addressRequestDto);

      /* Verify */
      expect(customerDao.findOne).toHaveBeenCalledTimes(1);
      expect(customerDao.findOne).toHaveBeenNthCalledWith(
        1,
        market,

        customerId,
      );
    });

    test('reads the customerDto from customerDao if addressDetail is undefined', async () => {
      /* Prepare */
      addressRequestDto.addressFinderId = faker.datatype.uuid();
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      // (addressDao.addressDetail as Mock).mockRejectedValueOnce(undefined);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      const result = expect(() => customerService.addAddress(market, customerId, addressRequestDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.addressNotFound')),
      );
    });

    test('reads the customerDto from customerDao if addressFinderId is available', async () => {
      /* Prepare */
      addressRequestDto.addressFinderId = faker.datatype.uuid();
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (addressDao.addressDetail as Mock).mockReturnValueOnce(stubAddressResponseDto());
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.addAddress(market, customerId, addressRequestDto);

      /* Verify */
      expect(customerDao.findOne).toHaveBeenCalledTimes(1);
      expect(customerDao.findOne).toHaveBeenNthCalledWith(
        1,
        market,

        customerId,
      );
    });

    test('reads the customerDto from customerDao if address in not available', async () => {
      /* Prepare */
      customerDto.addresses = [];
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (addressDao.addressDetail as Mock).mockReturnValueOnce(stubAddressResponseDto());
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.addAddress(market, customerId, addressRequestDto);

      /* Verify */
      expect(customerDao.findOne).toHaveBeenCalledTimes(1);
      expect(customerDao.findOne).toHaveBeenNthCalledWith(
        1,
        market,

        customerId,
      );
    });

    test('throws NOT_FOUND if the customer does not exist', async () => {
      /* Prepare */
      (customerDao.findOne as Mock).mockReturnValueOnce(undefined);

      /* Execute */
      const result = expect(() => customerService.addAddress(market, customerId, addressRequestDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, `Customer id "${customerId}" does not exist`),
      );
    });

    test('reads version from the customerDto', async () => {
      /* Prepare */
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.addAddress(market, customerId, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,

        customerId,

        expect.objectContaining({ version: customerDto.version }),
      );
    });

    test('creates addShippingAddressId action', async () => {
      /* Prepare */
      addressRequestDto.isBillingAddress = false;
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);
      (addressMapper.createAddressDraft as Mock).mockReturnValueOnce(addressDraft);

      /* Execute */
      await customerService.addAddress(market, customerId, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,
        customerId,
        {
          version: customerDto.version,
          actions: [
            payloadAddAddressAction,
            { action: 'addShippingAddressId', addressKey: expect.stringMatching(REGEXP_UUID) },
          ],
        },
      );
    });

    test('creates addBillingAddressId action', async () => {
      /* Prepare */
      addressRequestDto.isBillingAddress = true;
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);
      (addressMapper.createAddressDraft as Mock).mockReturnValueOnce(addressDraft);

      /* Execute */
      await customerService.addAddress(market, customerId, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,

        customerId,
        {
          version: customerDto.version,
          actions: [
            payloadAddAddressAction,
            { action: 'addShippingAddressId', addressKey: expect.stringMatching(REGEXP_UUID) },
            { action: 'addBillingAddressId', addressKey: expect.any(String) },
          ],
        },
      );
    });
  });

  describe('updateAddress()', () => {
    let customerId: string;
    let addressId: string;
    let addressKey: string;
    let addressRequestDto: AddressRequestDto;
    let customerDto: CustomerWritableAddress;
    let payloadAddAddressAction: AddressAction;
    let mappedCustomerAddress: AddressCollectionResponseDto;
    let addressResponseDto: Address;
    let addressDraft: AddressDraft;

    beforeEach(() => {
      customerDao.findOne = jest.fn();
      customerDao.updateCustomer = jest.fn();
      addressDao.addressDetail = jest.fn();
      customerId = faker.datatype.uuid();
      addressId = faker.datatype.uuid();
      addressKey = faker.datatype.uuid();
      addressRequestDto = stubAddressRequestDto({
        key: addressKey,
      });
      addressDraft = stubAddressDraftDto({
        id: addressId,
        key: addressRequestDto.key,
        city: addressRequestDto.city,
        country: market.country,
        phone: addressRequestDto.phoneNumber,
        postalCode: addressRequestDto.zip,
        region: addressRequestDto.region,
        state: addressRequestDto.state,
        firstName: addressRequestDto.firstName,
        lastName: addressRequestDto.lastName,
        custom: {
          type: {
            key: 'address-type',
            typeId: 'type',
          },
          fields: {
            Address1: addressRequestDto.address1,
            Address2: addressRequestDto.address2,
            Address3: addressRequestDto.address3,
            Address4: addressRequestDto.address4,
            Latitude: addressRequestDto.latitude,
            Longitude: addressRequestDto.longitude,
            county: addressRequestDto.county,
            RecipientName: `${addressRequestDto.firstName} ${addressRequestDto.lastName}`,
          },
        },
      });
      addressResponseDto = stubAddressDto({
        id: addressId,
        key: addressRequestDto.key,
        city: addressRequestDto.city,
        country: addressRequestDto.country,
        phone: addressRequestDto.phoneNumber,
        postalCode: addressRequestDto.zip,
        region: addressRequestDto.region,
        state: addressRequestDto.state,
        firstName: addressRequestDto.firstName,
        lastName: addressRequestDto.lastName,
        custom: {
          type: {
            id: faker.datatype.uuid(),
            typeId: 'type',
          },
          fields: {
            Address1: addressRequestDto.address1,
            Address2: addressRequestDto.address2,
            Address3: addressRequestDto.address3,
            Address4: addressRequestDto.address4,
            Latitude: addressRequestDto.latitude,
            Longitude: addressRequestDto.longitude,
            county: addressRequestDto.county,
            RecipientName: `${addressRequestDto.firstName} ${addressRequestDto.lastName}`,
          },
        },
      });
      customerDto = stubCustomerDto({
        addresses: [addressResponseDto],
      });

      mappedCustomerAddress = {
        addresses: [stubAddressResponseDto({
          id: addressId,
        })],
      };
      (addressMapper.mapAddressCollectionResponse as Mock).mockReturnValueOnce(
        mappedCustomerAddress,
      );

      payloadAddAddressAction = {
        action: 'changeAddress',
        addressId: addressResponseDto.id,
        address: addressDraft,
      };
    });

    test('read customer information from CT', async () => {
      /* Prepare */
      addressRequestDto.isBillingAddress = false;
      if (customerDto.billingAddressIds !== undefined) {
        customerDto.billingAddressIds[2] = addressId;
      }

      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.updateAddress(market, customerId, addressId, addressRequestDto);

      /* Verify */
      expect(customerDao.findOne).toHaveBeenCalledTimes(1);
      expect(customerDao.findOne).toHaveBeenNthCalledWith(
        1,
        market,

        customerId,
      );
    });

    test('read customer information from CT if addressDetail is undefined', async () => {
      /* Prepare */
      addressRequestDto.addressFinderId = faker.datatype.uuid();
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      const result = expect(() => customerService.updateAddress(market, customerId, addressId, addressRequestDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.addressNotFound')),
      );
    });

    test('read customer information from CT if addressFinderId is available', async () => {
      /* Prepare */
      addressRequestDto.addressFinderId = faker.datatype.uuid();
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (addressDao.addressDetail as Mock).mockReturnValueOnce(stubAddressResponseDto());
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.updateAddress(market, customerId, addressId, addressRequestDto);

      /* Verify */
      expect(customerDao.findOne).toHaveBeenCalledTimes(1);
      expect(customerDao.findOne).toHaveBeenNthCalledWith(
        1,
        market,

        customerId,
      );
    });

    test('throws NOT_FOUND if the customer does not exist', async () => {
      /* Prepare */
      (customerDao.findOne as Mock).mockReturnValueOnce(undefined);

      /* Execute */
      const result = expect(() => customerService.updateAddress(market, customerId, addressId, addressRequestDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, `Customer id "${customerId}" does not exist`),
      );
    });

    test('reads version from the customerDto', async () => {
      /* Prepare */
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.updateAddress(market, customerId, addressId, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,

        customerId,

        expect.objectContaining({ version: customerDto.version }),
      );
    });

    test('Attach addShippingAddressId action', async () => {
      /* Prepare */
      addressRequestDto.isBillingAddress = false;
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);
      (addressMapper.createAddressDraft as Mock).mockReturnValueOnce(addressDraft);

      /* Execute */
      await customerService.updateAddress(market, customerId, addressId, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,

        customerId,
        {
          version: customerDto.version,
          actions: [
            payloadAddAddressAction,
            { action: 'addShippingAddressId', addressKey },
          ],
        },
      );
    });

    test('creates addBillingAddressId action', async () => {
      /* Prepare */
      addressRequestDto.isBillingAddress = true;
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);
      (addressMapper.createAddressDraft as Mock).mockReturnValueOnce(addressDraft);

      /* Execute */
      await customerService.updateAddress(market, customerId, addressId, addressRequestDto);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,

        customerId,
        {
          version: customerDto.version,
          actions: [
            payloadAddAddressAction,
            { action: 'addShippingAddressId', addressKey },
            { action: 'addBillingAddressId', addressKey },
          ],
        },
      );
    });

    test('throws if address id does not exist', async () => {
      /* Prepare */
      customerDto.addresses = [];
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      const result = expect(() => customerService.updateAddress(market, customerId, addressId, addressRequestDto));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, `Address id "${addressId}" does not exist`),
      );
    });
  });
  describe('changePassword()', () => {
    let customerId: string;
    let customer: Customer;
    let changePasswordRequestDto: ChangePasswordRequestDto;
    let authHeader;
    let payload: CustomerChangePassword;
    beforeEach(() => {
      changePasswordRequestDto = stubChangePasswordRequestDto();
      customer = stubCustomerDto();
      customerId = faker.datatype.uuid();
      changePasswordRequestDto.customerId = customerId;
      customerDao.changePassword = jest.fn();
      customerDao.findOne = jest.fn();
      authHeader = faker.datatype.uuid();
      payload = {
        id: customer.id,
        version: customer.version,
        currentPassword: changePasswordRequestDto.currentPassword,
        newPassword: changePasswordRequestDto.newPassword,
      };
    });

    test('reads the customerDto from customerDao', async () => {
      /* Execute */
      await customerService.changePassword(market, changePasswordRequestDto, authHeader, customer);

      /* Verify */
      expect(customerDao.changePassword).toHaveBeenCalledTimes(1);
      expect(customerDao.changePassword).toHaveBeenNthCalledWith(
        1,
        market,
        payload,
        authHeader,
      );
    });
  });
  describe('resetCustomersPassword()', () => {
    let tokenValue: string;
    let newPassword: string;

    beforeEach(() => {
      (customerDao as any).resetCustomersPassword = jest.fn();
      tokenValue = faker.datatype.uuid();
      newPassword = faker.internet.password();
    });

    test('asks customerDao to reset the password', async () => {
      /* Prepare */
      (customerDao.resetCustomersPassword as Mock).mockReturnValueOnce(true);

      /* Execute */
      await customerService.resetCustomersPassword(market, tokenValue, newPassword);

      /* Verify */
      expect(customerDao.resetCustomersPassword).toHaveBeenCalledTimes(1);
      expect(customerDao.resetCustomersPassword).toHaveBeenNthCalledWith(
        1,
        market,

        tokenValue,

        newPassword,
      );
    });

    test('throws UNAUTHORIZED if CT rejects the token', async () => {
      /* Prepare */
      (customerDao.resetCustomersPassword as Mock).mockReturnValueOnce(false);
      const expectedError = new ApiError(401, 'Failed to reset password. Please try with a new token.');

      /* Execute */
      const execute = () => customerService.resetCustomersPassword(market, tokenValue, newPassword);

      /* Verify */
      await expect(execute).rejects.toThrow(expectedError);
    });
  });

  describe('forgotCustomersPassword()', () => {
    let email: string;
    let url: string;

    beforeEach(() => {
      customerDao.forgotCustomersPassword = jest.fn();
      customerDao.findGraphQLOne = jest.fn();
      email = faker.internet.email();
      url = faker.internet.url();
    });

    test('call forgotCustomersPassword method', async () => {
      /* Prepare */
      (customerDao.forgotCustomersPassword as Mock)
        .mockReturnValueOnce({ lastName: faker.datatype.string(), firstName: faker.datatype.string() });
      (customerDao.findGraphQLOne as Mock)
        .mockReturnValueOnce({ lastName: faker.datatype.string(), firstName: faker.datatype.string() });

      /* Execute */
      await customerService.forgotCustomersPassword(market, email, url);

      /* Verify */
      expect(customerDao.forgotCustomersPassword).toHaveBeenCalledTimes(1);
      expect(customerDao.forgotCustomersPassword).toHaveBeenNthCalledWith(
        1,
        market,
        email,
      );
    });

    test('throws UNAUTHORIZED if CT rejects the token', async () => {
      /* Prepare */
      (customerDao.forgotCustomersPassword as Mock).mockReturnValueOnce(false);
      const expectedError = new ApiError(401, 'Failed to reset password. Email Id does not exist');

      /* Execute */
      const execute = () => customerService.forgotCustomersPassword(market, email, url);

      /* Verify */
      await expect(execute).rejects.toThrow(expectedError);
    });
  });

  describe('deleteAddress()', () => {
    let customerId: string;
    let addressId: string;
    let customerDto: Writable<Customer>;
    let actions: any;
    let mappedCustomerAddress: AddressCollectionResponseDto;
    let addressResponseDto: Address[];

    beforeEach(() => {
      customerDao.findOne = jest.fn();
      customerDao.updateCustomer = jest.fn();
      customerId = faker.datatype.uuid();
      addressId = faker.datatype.uuid();
      addressResponseDto = [stubAddressDto({
        id: addressId,
      }), stubAddressDto()];
      customerDto = stubCustomerDto({
        defaultBillingAddressId: addressId,
        defaultShippingAddressId: addressId,
        addresses: addressResponseDto,
      });

      mappedCustomerAddress = {
        addresses: [stubAddressResponseDto({
          id: addressId,
        })],
      };
      (addressMapper.mapAddressCollectionResponse as Mock).mockReturnValueOnce(
        mappedCustomerAddress,
      );

      actions = [
        { action: 'removeAddress', addressId },
        { action: 'setDefaultShippingAddress', addressId: addressResponseDto[1].id },
        { action: 'setDefaultBillingAddress', addressId: addressResponseDto[1].id },
      ];
    });

    test('read customer information from CT', async () => {
      /* Prepare */
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.deleteAddress(market, customerId, addressId);

      /* Verify */
      expect(customerDao.findOne).toHaveBeenCalledTimes(1);
      expect(customerDao.findOne).toHaveBeenNthCalledWith(
        1,
        market,

        customerId,
      );
    });

    test('throws NOT_FOUND if the customer does not exist', async () => {
      /* Prepare */
      (customerDao.findOne as Mock).mockReturnValueOnce(undefined);

      /* Execute */
      const result = expect(() => customerService.deleteAddress(market, customerId, addressId));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, `Customer id "${customerId}" does not exist`),
      );
    });

    test('reads version from the customerDto', async () => {
      /* Prepare */
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.deleteAddress(market, customerId, addressId);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,

        customerId,

        expect.objectContaining({ version: customerDto.version }),
      );
    });

    test('deleteCustomer should be call with payload', async () => {
      /* Prepare */
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);
      (customerDao.updateCustomer as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.deleteAddress(market, customerId, addressId);

      /* Verify */
      expect(customerDao.updateCustomer).toHaveBeenCalledTimes(1);
      expect(customerDao.updateCustomer).toHaveBeenNthCalledWith(
        1,
        market,
        customerId,
        {
          version: customerDto.version,
          actions,
        },
      );
    });

    test('throws if address id does not exist', async () => {
      /* Prepare */
      customerDto.addresses = [];
      (customerDao.findOne as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      const result = expect(() => customerService.deleteAddress(market, customerId, addressId));

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(HttpStatusCodes.NOT_FOUND, `Address id "${addressId}" does not exist`),
      );
    });
  });
  describe('setDefaultAddress()', () => {
    let setDefaultAddressDto: SetDefaultAddressDto;
    let authHeader;
    let actions: any = [];
    beforeEach(() => {
      setDefaultAddressDto = stubSetDefaultAddressDto();
      customerDao.setDefaultAddress = jest.fn();
      authHeader = faker.datatype.uuid();
    });

    test('if isDelivery = true', async () => {
      actions = [{
        action: 'setDefaultShippingAddress',
        addressId: setDefaultAddressDto.addressId,
      }];
      setDefaultAddressDto.isBilling = false;
      setDefaultAddressDto.isDelivery = true;
      const { version } = setDefaultAddressDto;
      const payload = { version, actions };
      /* Execute */
      await customerService.defaultAddress(market, setDefaultAddressDto, authHeader);

      /* Verify */
      expect(customerDao.setDefaultAddress).toHaveBeenCalledTimes(1);
      expect(customerDao.setDefaultAddress).toHaveBeenNthCalledWith(
        1,
        market,
        payload,
        authHeader,
      );
    });

    test('if isDelivery = false', async () => {
      actions = [{
        action: 'setDefaultBillingAddress',
        addressId: setDefaultAddressDto.addressId,
      }];
      setDefaultAddressDto.isBilling = true;
      setDefaultAddressDto.isDelivery = false;
      const { version } = setDefaultAddressDto;
      const payload = { version, actions };
      /* Execute */
      await customerService.defaultAddress(market, setDefaultAddressDto, authHeader);

      /* Verify */
      expect(customerDao.setDefaultAddress).toHaveBeenCalledTimes(1);
      expect(customerDao.setDefaultAddress).toHaveBeenNthCalledWith(
        1,
        market,
        payload,
        authHeader,
      );
    });

    test('if isDelivery = false and isBilling= false', async () => {
      actions = [{
        action: 'setDefaultBillingAddress',
        addressId: setDefaultAddressDto.addressId,
      }];
      setDefaultAddressDto.isBilling = false;
      setDefaultAddressDto.isDelivery = false;
      const expectedError = new ApiError(400, 'sorry, one value of isBilling/isDelivery should be true');
      /* Execute */
      const execute = () => customerService.defaultAddress(market, setDefaultAddressDto, authHeader);
      /* Verify */
      await expect(execute).rejects.toThrow(expectedError);
    });
  });

  describe('updateMyCustomer()', () => {
    let customerRequestDto: CustomerRequestDto;
    let customerDto: Writeable<Customer>;
    let authHeader: string;

    beforeEach(() => {
      customerDao.updateMyCustomer = jest.fn();
      authHeader = faker.datatype.uuid();
      customerRequestDto = {
        firstName: faker.internet.userName(),
        lastName: faker.internet.userName(),
        phoneNumber: faker.datatype.string(),
      };
      customerDto = stubCustomerDto();
    });

    test('reads the customerDto from customerDao', async () => {
      /* Prepare */
      (customerDao.updateMyCustomer as Mock).mockReturnValueOnce(customerDto);
      (customerMapper.mapCustomerResponse as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.updateMyCustomer(market, customerDto, authHeader, customerRequestDto);

      /* Verify */
      expect(customerDao.updateMyCustomer).toHaveBeenCalledTimes(1);
      expect(customerMapper.mapCustomerResponse).toHaveBeenNthCalledWith(1, customerDto);
    });

    test('reads the customerDto from customerDao if custom object is present in customerDto', async () => {
      /* Prepare */
      customerDto.custom = {
        type: {
          typeId: 'type',
          id: faker.datatype.uuid(),
        },
        fields: {
          PhoneNumber: faker.datatype.string(),
        },
      };
      (customerDao.updateMyCustomer as Mock).mockReturnValueOnce(customerDto);
      (customerMapper.mapCustomerResponse as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.updateMyCustomer(market, customerDto, authHeader, customerRequestDto);

      /* Verify */
      expect(customerDao.updateMyCustomer).toHaveBeenCalledTimes(1);
      expect(customerMapper.mapCustomerResponse).toHaveBeenNthCalledWith(1, customerDto);
    });
  });

  describe('updateCustomerOptIn()', () => {
    let customerOptInRequestDto: CustomerOptInRequestDto;
    let customerDto: Writeable<Customer>;
    let authHeader: string;

    beforeEach(() => {
      customerDao.updateMyCustomer = jest.fn();
      authHeader = faker.datatype.uuid();
      customerOptInRequestDto = {
        optIn: faker.datatype.boolean(),
      };
      customerDto = stubCustomerDto();
    });

    test('reads the customerDto from customerDao', async () => {
      /* Prepare */
      (customerDao.updateMyCustomer as Mock).mockReturnValueOnce(customerDto);
      (customerMapper.mapCustomerResponse as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.updateCustomerOptIn(market, customerDto, authHeader, customerOptInRequestDto);

      /* Verify */
      expect(customerDao.updateMyCustomer).toHaveBeenCalledTimes(1);
      expect(customerMapper.mapCustomerResponse).toHaveBeenNthCalledWith(1, customerDto);
    });

    test('reads the customerDto from customerDao if custom object is present in customerDto', async () => {
      /* Prepare */
      customerDto.custom = {
        type: {
          typeId: 'type',
          id: faker.datatype.uuid(),
        },
        fields: {
          PhoneNumber: faker.datatype.string(),
        },
      };
      (customerDao.updateMyCustomer as Mock).mockReturnValueOnce(customerDto);
      (customerMapper.mapCustomerResponse as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.updateCustomerOptIn(market, customerDto, authHeader, customerOptInRequestDto);

      /* Verify */
      expect(customerDao.updateMyCustomer).toHaveBeenCalledTimes(1);
      expect(customerMapper.mapCustomerResponse).toHaveBeenNthCalledWith(1, customerDto);
    });

    test('expect client event bridge catch errors', async () => {
      /* Prepare */
      customerDto.custom = {
        type: {
          typeId: 'type',
          id: faker.datatype.uuid(),
        },
        fields: {
          PhoneNumber: faker.datatype.string(),
        },
      };
      (customerDao.updateMyCustomer as Mock).mockReturnValueOnce(customerDto);
      (customerMapper.mapCustomerResponse as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.updateCustomerOptIn(market, customerDto, authHeader, customerOptInRequestDto);

      /* Verify */
      expect(eventBridgeClientCatch).toHaveBeenCalledTimes(1);
    });
  });

  describe('getCustomerDetailsByToken()', () => {
    let customerDto: Writeable<Customer>;
    let authHeader: string;

    beforeEach(() => {
      customerDao.getCustomerDetailsGraphQL = jest.fn();
      authHeader = faker.datatype.uuid();
      customerDto = stubCustomerDto();
    });

    test('reads the customerDto from customerDao', async () => {
      /* Prepare */
      (customerDao.getCustomerDetailsGraphQL as Mock).mockReturnValueOnce(customerDto);
      (customerMapper.mapCustomerResponse as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.getCustomerDetailsByToken(market, authHeader);

      /* Verify */
      expect(customerDao.getCustomerDetailsGraphQL).toHaveBeenCalledTimes(1);
      expect(customerMapper.mapGraphQLCustomerResponse).toHaveBeenNthCalledWith(1, customerDto);
    });
  });
});
