import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes,
} from '../__stubs__';
import { DefaultController } from '../../src/controllers';
import { DefaultService } from '../../src/services';

import Mock = jest.Mock;

describe('DefaultController', () => {
  /* System Under Test */
  let defaultController: DefaultController;

  /* Dependencies */
  let defaultService: DefaultService;
  let market: MarketInfo;

  /* Stubs */
  let request: Request;
  let response: Response;

  beforeEach(() => {
    market = stubMarket();

    /* Stubs */
    request = stubExpressReq();
    response = stubExpressRes(market);

    /* Dependencies */
    defaultService = {} as any;

    /* SUT */
    defaultController = new DefaultController({ defaultService });
  });

  describe('default controller', () => {
    const authToken = faker.datatype.uuid();

    beforeEach(() => {
      request.headers.authorization = authToken;
    });

    describe('refreshToken()', () => {
      test('reads request parameters', async () => {
      /* Prepare */
        const refreshtoken = faker.datatype.string();

        request.headers = { refreshtoken };
        (defaultService.refreshToken as Mock) = jest.fn();

        /* Execute */
        await defaultController.refreshToken(request, response);

        /* Verify */
        expect(defaultService.refreshToken).toHaveBeenCalledTimes(1);
        expect(defaultService.refreshToken).toHaveBeenNthCalledWith(
          1,
          market,
          refreshtoken,
        );
      });
    });

    describe('verifyToken()', () => {
      test('reads request parameters', async () => {
      /* Prepare */
        const token = faker.datatype.string();

        request.body = { token };
        (defaultService.verifyToken as Mock) = jest.fn();

        /* Execute */
        await defaultController.verifyToken(request, response);

        /* Verify */
        expect(defaultService.verifyToken).toHaveBeenCalledTimes(1);
        expect(defaultService.verifyToken).toHaveBeenNthCalledWith(
          1,
          market,
          token,
        );
      });
    });

    describe('logout()', () => {
      test('reads request parameters', async () => {
        const authHeader = request.headers?.authorization;
        const token = authHeader?.replace('Bearer ', '');
        /* Prepare */
        (defaultService.logout as Mock) = jest.fn();

        /* Execute */
        await defaultController.logout(request);

        /* Verify */
        expect(defaultService.logout).toHaveBeenCalledTimes(1);
        expect(defaultService.logout).toHaveBeenNthCalledWith(
          1,
          token,
        );
      });
    });
  });
});
