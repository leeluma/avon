import { Request, Response } from 'express';
import { Customer, CustomerSignin } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import HttpStatusCodes from 'http-status-codes';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubAddressResponseDto,
  stubCustomerRequestDto, stubCustomerResponseDto,
  stubChangePasswordRequestDto, stubCustomerDto, stubCustomerLoginRequestDto, stubCustomerLoginResponseDto,
} from '../__stubs__';
import { CustomerController } from '../../src/controllers';
import { CustomerService } from '../../src/services';

import Mock = jest.Mock;
import {
  AddressRequestDto,
  AddressResponseDto,
  CustomerRegistrationRequestDto,
  CustomerResponseDto,
  ChangePasswordRequestDto,
  CustomerActionResponseDto,
  CustomerRequestDto,
  CustomerLoginResponseDto,
  CustomerOptInRequestDto,
} from '../../src/dtos';
import { stubAddressRequestDto } from '../__stubs__/address-request.dto.stub';
import { ApiError } from '../../src/lib';

describe('CustomerController', () => {
  /* System Under Test */
  let customerController: CustomerController;

  /* Dependencies */
  let customerService: CustomerService;
  let market: MarketInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    customerService = {} as any;

    /* SUT */
    customerController = new CustomerController({ customerService });
  });
  describe('customer methods', () => {
    let customerRequestDto: CustomerSignin;
    let customerResponseDto: CustomerLoginResponseDto;

    beforeEach(() => {
      customerRequestDto = stubCustomerLoginRequestDto();
      customerResponseDto = stubCustomerLoginResponseDto();
    });

    describe('login', () => {
      beforeEach(() => {
        req.body = customerRequestDto;
        customerService.login = jest.fn();
      });

      test('forward request payload to login service', async () => {
        await customerController.login(req, res);
        expect(customerService.login).toHaveBeenCalledTimes(1);
        expect(customerService.login).toHaveBeenNthCalledWith(
          1,
          market,

          customerRequestDto,
        );
      });

      test('return login Response from Service', async () => {
        (customerService.login as Mock).mockReturnValueOnce(customerResponseDto);
        const resultData = await customerController.login(req, res);
        expect(resultData.statusCode).toEqual(200);
      });
    });
  });
  describe('customer method login', () => {
    let customerRequestDto: CustomerSignin;
    let customerResponseDto: CustomerLoginResponseDto;

    beforeEach(() => {
      customerRequestDto = stubCustomerLoginRequestDto();
      customerResponseDto = stubCustomerLoginResponseDto();
    });

    describe('login', () => {
      beforeEach(() => {
        req.body = customerRequestDto;
        customerService.login = jest.fn();
      });

      test('forward request payload to login service', async () => {
        await customerController.login(req, res);
        expect(customerService.login).toHaveBeenCalledTimes(1);
        expect(customerService.login).toHaveBeenNthCalledWith(
          1,
          market,

          customerRequestDto,
        );
      });

      test('return login Response from Service', async () => {
        (customerService.login as Mock).mockReturnValueOnce(customerResponseDto);
        const resultData = await customerController.login(req, res);
        expect(resultData.statusCode).toEqual(200);
      });
    });
  });
  describe('customer method', () => {
    let customerRequestDto: CustomerRegistrationRequestDto;
    let customerResponseDto: CustomerResponseDto;
    let authHeader: string;
    beforeEach(() => {
      customerRequestDto = stubCustomerRequestDto();
      customerResponseDto = stubCustomerResponseDto();
      authHeader = `Bearer ${faker.datatype.uuid()}`;
    });

    describe('getById()', () => {
      beforeEach(() => {
        customerService.getById = jest.fn();
        req.params.id = faker.datatype.uuid();
      });

      test('calls customerService with request parameters', async () => {
        /* Prepare */
        (customerService.getById as Mock).mockReturnValueOnce(customerResponseDto);

        /* Execute */
        await customerController.getById(req, res);

        /* Verify */
        expect(customerService.getById).toHaveBeenCalledTimes(1);
        expect(customerService.getById).toHaveBeenNthCalledWith(
          1,
          market,
          req.params.id,
        );
      });

      test('returns customerResponseDto as JsonApiResponseEntity', async () => {
        /* Prepare */
        (customerService.getById as Mock).mockReturnValueOnce(customerResponseDto);

        /* Execute */
        const response = await customerController.getById(req, res);

        /* Verify */
        expect(response).toEqual({
          statusCode: 200,
          body: customerResponseDto,
        });
      });

      test('throws ApiError(NOT_FOUND) if customer does not exist', async () => {
        /* Prepare */
        (customerService.getById as Mock).mockReturnValueOnce(undefined);

        const result = expect(() => customerController.getById(req, res));

        /* Execute */
        await result.rejects.toThrow(
          new ApiError(404, `Customer with id "${req.params.id}" not found.`),
        );
      });
    });

    describe('registration()', () => {
      beforeEach(() => {
        req.body = customerRequestDto;
        customerService.registration = jest.fn();
      });

      test('forwards request parameters to service', async () => {
        /* Execute */
        await customerController.registration(req, res);

        /* Verify */
        expect(customerService.registration).toHaveBeenCalledTimes(1);
        expect(customerService.registration).toHaveBeenNthCalledWith(
          1,
          market,

          customerRequestDto,
        );
      });

      test('returns customerResponseDto as JsonApiResponseEntity', async () => {
        /* Prepare */
        (customerService.registration as Mock).mockReturnValueOnce(customerResponseDto);

        /* Execute */
        const response = await customerController.registration(req, res);

        /* Verify */
        expect(response).toEqual({
          statusCode: 201,
          body: customerResponseDto,
        });
      });
    });
    describe('getCustomerByToken()', () => {
      beforeEach(() => {
        customerService.getCustomerDetailsByToken = jest.fn();
        req.headers.authorization = authHeader;
      });

      test('calls customerService with request parameters', async () => {
        /* Prepare */
        (customerService.getCustomerDetailsByToken as Mock).mockReturnValueOnce(customerResponseDto);

        /* Execute */
        await customerController.getCustomerByToken(req, res);

        /* Verify */
        expect(customerService.getCustomerDetailsByToken).toHaveBeenCalledTimes(1);
        expect(customerService.getCustomerDetailsByToken).toHaveBeenNthCalledWith(
          1,
          market,
          authHeader,
        );
      });

      test('returns customerResponseDto as JsonApiResponseEntity', async () => {
        /* Prepare */
        (customerService.getCustomerDetailsByToken as Mock).mockReturnValueOnce(customerResponseDto);

        /* Execute */
        const response = await customerController.getCustomerByToken(req, res);

        /* Verify */
        expect(response).toEqual({
          statusCode: 200,
          body: customerResponseDto,
        });
      });

      test('throws ApiError(NOT_FOUND) if customer does not exist', async () => {
        /* Prepare */
        (customerService.getCustomerDetailsByToken as Mock).mockReturnValueOnce(undefined);

        const result = expect(() => customerController.getCustomerByToken(req, res));

        /* Execute */
        await result.rejects.toThrowError();
      });
    });
  });

  describe('addresses methods', () => {
    describe('getAddress', () => {
      let addressResponseDto: AddressResponseDto;

      beforeEach(() => {
        addressResponseDto = stubAddressResponseDto();
        customerService.getAddress = jest.fn();
        res.locals.customer = {
          id: faker.datatype.uuid(),
        };
      });

      test('forwards request parameters to service', async () => {
        const customerId = res.locals.customer.id;

        /* Prepare */
        (customerService.getAddress as Mock).mockReturnValueOnce(addressResponseDto);

        /* Execute */
        await customerController.getAddress(req, res);

        /* Verify */
        expect(customerService.getAddress).toHaveBeenCalledTimes(1);
        expect(customerService.getAddress).toHaveBeenNthCalledWith(
          1,
          market,
          customerId,
        );
      });

      test('throws NOT_FOUND if customer does not exist', async () => {
        /* Prepare */
        res.locals.customer = {
          id: faker.datatype.uuid(),
        };
        const customerId = res.locals.customer.id;
        (customerService.getAddress as Mock).mockReturnValueOnce(undefined);

        /* Execute */
        const response = expect(() => customerController.getAddress(req, res));

        /* Verify */
        await response.rejects.toThrow(
          new ApiError(HttpStatusCodes.NOT_FOUND, `Address with customer id "${customerId}" not found.`),
        );
      });

      test('returns data from service as JsonApiResponseEntity', async () => {
        /* Prepare */
        const customerResponseDto = stubCustomerResponseDto();
        (customerService.getAddress as Mock).mockReturnValueOnce(customerResponseDto);

        /* Execute */
        const response = await customerController.getAddress(req, res);

        /* Verify */
        expect(response).toEqual({
          statusCode: 200,
          body: customerResponseDto,
        });
      });
    });
    describe('addAddress', () => {
      let addressRequestDto: AddressRequestDto;

      beforeEach(() => {
        addressRequestDto = stubAddressRequestDto();
        req.body = addressRequestDto;
        customerService.addAddress = jest.fn();
        res.locals.customer = {
          id: faker.datatype.uuid(),
        };
      });

      test('forwards request parameters to service', async () => {
        const customerId = res.locals.customer.id;

        /* Execute */
        await customerController.addAddress(req, res);

        /* Verify */
        expect(customerService.addAddress).toHaveBeenCalledTimes(1);
        expect(customerService.addAddress).toHaveBeenNthCalledWith(
          1,
          market,
          customerId,
          addressRequestDto,
        );
      });

      test('returns customer from service', async () => {
        /* Prepare */
        const addressResponseDto = [stubAddressResponseDto()];
        (customerService.addAddress as Mock).mockReturnValueOnce(addressResponseDto);

        /* Execute */
        const result = await customerController.addAddress(req, res);

        /* Verify */
        expect(result).toEqual({
          statusCode: 201,
          body: addressResponseDto,
        });
      });
    });

    describe('updateAddress', () => {
      let addressRequestDto: AddressRequestDto;

      beforeEach(() => {
        addressRequestDto = stubAddressRequestDto();
        req.body = addressRequestDto;
        req.params.addressId = faker.datatype.uuid();
        customerService.updateAddress = jest.fn();
        res.locals.customer = {
          id: faker.datatype.uuid(),
        };
      });

      test('To check if service method call', async () => {
        /* Execute */
        await customerController.updateAddress(req, res);
        const customerId = res.locals.customer.id;

        /* Verify */
        expect(customerService.updateAddress).toHaveBeenCalledTimes(1);
        expect(customerService.updateAddress).toHaveBeenNthCalledWith(
          1,
          market,
          customerId,
          req.params.addressId,
          addressRequestDto,
        );
      });

      test('returns addresses from service', async () => {
        /* Prepare */
        const addressResponseDto = [stubAddressResponseDto(), stubAddressResponseDto()];
        (customerService.updateAddress as Mock).mockReturnValueOnce(addressResponseDto);

        /* Execute */
        const result = await customerController.updateAddress(req, res);

        /* Verify */
        expect(result).toEqual({
          statusCode: 202,
          body: addressResponseDto,
        });
      });
    });

    describe('deleteAddress', () => {
      beforeEach(() => {
        req.params.addressId = faker.datatype.uuid();
        customerService.deleteAddress = jest.fn();
        res.locals.customer = {
          id: faker.datatype.uuid(),
        };
      });

      test('To check if service method call', async () => {
        const customerId = res.locals.customer.id;
        /* Execute */
        await customerController.deleteAddress(req, res);

        /* Verify */
        expect(customerService.deleteAddress).toHaveBeenCalledTimes(1);
        expect(customerService.deleteAddress).toHaveBeenNthCalledWith(
          1,
          market,
          customerId,
          req.params.addressId,
        );
      });

      test('returns addresses from service', async () => {
        /* Prepare */
        const addressResponseDto = [stubAddressResponseDto(), stubAddressResponseDto()];
        (customerService.deleteAddress as Mock).mockReturnValueOnce(addressResponseDto);

        /* Execute */
        const result = await customerController.deleteAddress(req, res);

        /* Verify */
        expect(result).toEqual({
          statusCode: 202,
          body: addressResponseDto,
        });
      });
    });
  });
  describe('changePassword', () => {
    let changePasswordRequestDto: ChangePasswordRequestDto;
    let authHeader;
    let cTActionResponseDto: CustomerActionResponseDto;
    beforeEach(() => {
      changePasswordRequestDto = stubChangePasswordRequestDto();
      req.body = changePasswordRequestDto;
      res.locals.customer = stubCustomerDto();
      authHeader = faker.datatype.uuid();
      req.headers.authorization = authHeader;
      customerService.changePassword = jest.fn();
    });

    test('To check if service method call', async () => {
      /* Prepare */
      (customerService.changePassword as Mock).mockReturnValueOnce(cTActionResponseDto);
      /* Execute */
      await customerController.changePassword(req, res);

      /* Verify */
      expect(customerService.changePassword).toHaveBeenCalledTimes(1);
      expect(customerService.changePassword).toHaveBeenNthCalledWith(
        1,
        market,
        changePasswordRequestDto,
        authHeader,
        res.locals.customer,
      );
    });

    test('To check if service method call if authHeader not passed', async () => {
      /* Prepare */
      req.headers.authorization = undefined;
      (customerService.changePassword as Mock).mockReturnValueOnce(cTActionResponseDto);
      /* Execute */
      await customerController.changePassword(req, res);

      /* Verify */
      expect(customerService.changePassword).toHaveBeenCalledTimes(1);
      expect(customerService.changePassword).toHaveBeenNthCalledWith(
        1,
        market,
        changePasswordRequestDto,
        '',
        res.locals.customer,
      );
    });

    test('returns response as JsonApiResponseEntity', async () => {
      /* Prepare */
      (customerService.changePassword as Mock).mockReturnValueOnce(cTActionResponseDto);

      /* Execute */
      const response = await customerController.changePassword(req, res);
      /* Verify */
      expect(response).toEqual({
        statusCode: 202,
        body: undefined,
      });
    });
  });
  describe('resetCustomersPassword()', () => {
    test('reads request parameters', async () => {
      /* Prepare */
      const token = faker.datatype.uuid();
      const newPassword = faker.internet.password();

      req.body = { token, newPassword };
      (customerService.resetCustomersPassword as Mock) = jest.fn();

      /* Execute */
      await customerController.resetCustomersPassword(req, res);

      /* Verify */
      expect(customerService.resetCustomersPassword).toHaveBeenCalledTimes(1);
      expect(customerService.resetCustomersPassword).toHaveBeenNthCalledWith(
        1,
        market,

        token,

        newPassword,
      );
    });
  });

  describe('forgotCustomersPassword()', () => {
    test('reads request parameters', async () => {
    /* Prepare */
      const email = faker.internet.email();
      const url = faker.internet.password();

      req.body = { email, url };
      (customerService.forgotCustomersPassword as Mock) = jest.fn();

      /* Execute */
      await customerController.forgotCustomersPassword(req, res);

      /* Verify */
      expect(customerService.forgotCustomersPassword).toHaveBeenCalledTimes(1);
      expect(customerService.forgotCustomersPassword).toHaveBeenNthCalledWith(
        1,
        market,

        email,

        url,
      );
    });
  });
  describe('default-address', () => {
    let authHeader;
    let cTActionResponseDto: CustomerActionResponseDto;
    let customerDto;
    beforeEach(() => {
      customerDto = stubCustomerDto();
      res.locals.customer = customerDto;
      authHeader = faker.datatype.uuid();
      req.headers.authorization = authHeader;
      customerService.defaultAddress = jest.fn();
    });

    test('To check if service method call', async () => {
      /* Execute */
      await customerController.defaultAddress(req, res);

      /* Verify */
      expect(customerService.defaultAddress).toHaveBeenCalledTimes(1);
    });

    test('To check if service method call if authHeader not passed', async () => {
      /* Execute */
      req.headers.authorization = undefined;
      await customerController.defaultAddress(req, res);

      /* Verify */
      expect(customerService.defaultAddress).toHaveBeenCalledTimes(1);
    });

    test('returns response as JsonApiResponseEntity', async () => {
      /* Prepare */
      (customerService.defaultAddress as Mock).mockReturnValueOnce(cTActionResponseDto);

      /* Execute */
      const response = await customerController.defaultAddress(req, res);
      /* Verify */
      expect(response).toEqual({
        statusCode: 202,
        body: undefined,
      });
    });
  });

  describe('updateMyCustomer', () => {
    let customerRequestDto: CustomerRequestDto;
    let authHeader: string;
    beforeEach(() => {
      customerRequestDto = {
        firstName: faker.internet.userName(),
        lastName: faker.internet.userName(),
        phoneNumber: faker.datatype.string(),
      };
      authHeader = faker.datatype.uuid();
      req.body = customerRequestDto;
      req.headers.authorization = authHeader;
      res.locals.customer = stubCustomerDto();
      customerService.updateMyCustomer = jest.fn();
    });

    test('forwards request parameters to service', async () => {
      /* Execute */
      await customerController.updateMyCustomer(req, res);

      /* Verify */
      expect(customerService.updateMyCustomer).toHaveBeenCalledTimes(1);
      expect(customerService.updateMyCustomer).toHaveBeenNthCalledWith(
        1,
        market,
        res.locals.customer,
        authHeader,
        customerRequestDto,
      );
    });

    test('returns customer from service', async () => {
      /* Prepare */
      const customerResponseDto = stubCustomerResponseDto();
      (customerService.updateMyCustomer as Mock).mockReturnValueOnce(customerResponseDto);

      /* Execute */
      const result = await customerController.updateMyCustomer(req, res);

      /* Verify */
      expect(result).toEqual({
        statusCode: 202,
        body: customerResponseDto,
      });
    });
  });

  describe('updateCustomerOptIn', () => {
    let customerOptInRequestDto: CustomerOptInRequestDto;
    let authHeader: string;
    beforeEach(() => {
      customerOptInRequestDto = {
        optIn: faker.datatype.boolean(),
      };
      authHeader = faker.datatype.uuid();
      req.body = customerOptInRequestDto;
      req.headers.authorization = authHeader;
      res.locals.customer = stubCustomerDto();
      customerService.updateCustomerOptIn = jest.fn();
    });

    test('forwards request parameters to service', async () => {
      /* Execute */
      await customerController.updateCustomerOptIn(req, res);

      /* Verify */
      expect(customerService.updateCustomerOptIn).toHaveBeenCalledTimes(1);
      expect(customerService.updateCustomerOptIn).toHaveBeenNthCalledWith(
        1,
        market,
        res.locals.customer,
        authHeader,
        customerOptInRequestDto,
      );
    });

    test('returns customer from service', async () => {
      /* Prepare */
      const customerResponseDto = stubCustomerResponseDto();
      (customerService.updateCustomerOptIn as Mock).mockReturnValueOnce(customerResponseDto);

      /* Execute */
      const result = await customerController.updateCustomerOptIn(req, res);

      /* Verify */
      expect(result).toEqual({
        statusCode: 202,
        body: customerResponseDto,
      });
    });
  });
});
