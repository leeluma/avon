import {
  ShoppingList,
} from '@commercetools/platform-sdk';
import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MagnoliaInfo, WishlistDto, Writable } from '../../src/dtos';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubShoppingList, stubWishlistDto, stubMagnoliaInfo,
} from '../__stubs__';
import { ShoppingListController } from '../../src/controllers';
import { ShoppingListService } from '../../src/services';
import { ApiError } from '../../src/lib';

import Mock = jest.Mock;

describe('LeapBeWishlistController', () => {
  /* System Under Test */
  let shoppingListController: ShoppingListController;

  /* Dependencies */
  let shoppingListService: ShoppingListService;
  let market: MarketInfo;
  let magnolia: MagnoliaInfo;

  /* Stubs */
  let request: Request;
  let response: Response;

  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();
    /* Stubs */
    request = stubExpressReq();
    response = stubExpressRes(market);

    /* Dependencies */
    shoppingListService = {} as any;

    /* SUT */
    shoppingListController = new ShoppingListController({ shoppingListService });
  });

  describe('moveAllLineItemsToCart()', () => {
    let shoppingListId: string;
    let cartId: string;

    beforeEach(() => {
      shoppingListId = faker.datatype.uuid();
      cartId = faker.datatype.uuid();
      request.params.id = shoppingListId;
      request.body.cartId = cartId;
      shoppingListService.moveAllLineItemsToCart = jest.fn().mockReturnValueOnce({ shoppingListId, cartId });
    });

    test('fetches data from shoppingListService', async () => {
      /* Execute */
      await shoppingListController.moveAllLineItemsToCart(request, response);

      /* Verify */
      expect(shoppingListService.moveAllLineItemsToCart).toHaveBeenCalledTimes(1);
      expect(shoppingListService.moveAllLineItemsToCart).toHaveBeenNthCalledWith(
        1,
        market,
        shoppingListId,
        cartId,
      );
    });

    test('returns result from shoppingListService.moveAllLineItemsToCart as JsonApiResponseEntity', async () => {
      /* Execute */
      const result = await shoppingListController.moveAllLineItemsToCart(request, response);

      /* Verify */
      expect(result).toEqual({
        statusCode: 200,
        body: { shoppingListId, cartId },
      });
    });
  });

  describe('moveOneLineItemToCart()', () => {
    let shoppingListId: string;
    let lineItemId: string;
    let cartId: string;

    beforeEach(() => {
      shoppingListId = faker.datatype.uuid();
      lineItemId = faker.datatype.uuid();
      cartId = faker.datatype.uuid();
      request.params.id = shoppingListId;
      request.params.lineItemId = lineItemId;
      request.body.cartId = cartId;
      shoppingListService.moveOneLineItemToCart = jest.fn().mockReturnValueOnce({ shoppingListId, cartId });
    });

    test('fetches data from shoppingListService', async () => {
      /* Execute */
      await shoppingListController.moveOneLineItemToCart(request, response);

      /* Verify */
      expect(shoppingListService.moveOneLineItemToCart).toHaveBeenCalledTimes(1);
      expect(shoppingListService.moveOneLineItemToCart).toHaveBeenNthCalledWith(
        1,
        market,
        shoppingListId,
        lineItemId,
        cartId,
      );
    });

    test('returns result from shoppingListService.moveOneLineItemToCart as JsonApiResponseEntity', async () => {
      /* Execute */
      const shoppingList = await shoppingListController.moveOneLineItemToCart(request, response);

      /* Verify */
      expect(shoppingList).toEqual({
        statusCode: 200,
        body: { shoppingListId, cartId },
      });
    });
  });

  describe('getById()', () => {
    let shoppingListDto: Writable<ShoppingList>;

    beforeEach(() => {
      shoppingListService.getById = jest.fn();
      shoppingListDto = stubShoppingList(market);
      request.params.id = shoppingListDto.id;
    });

    test('returns shoppingListDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (shoppingListService.getById as Mock).mockReturnValueOnce(shoppingListDto);

      /* Execute */
      const result = await shoppingListController.getById(request, response);

      /* Verify */
      expect(result).toEqual({
        statusCode: 200,
        body: shoppingListDto,
      });
    });

    test('throws ApiError(NOT_FOUND) if shoppingList does not exist', async () => {
      /* Prepare */
      (shoppingListService.getById as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(404, `Wishlist with id "${shoppingListDto.id}" not found.`);

      /* Execute */
      await expect(() => shoppingListController.getById(request, response))
        .rejects.toThrow(expectedError);
    });
  });

  describe('deleteLineItem()', () => {
    let lineItemId: string;
    let wishlistDto: WishlistDto;

    beforeEach(() => {
      shoppingListService.deleteLineItem = jest.fn();
      wishlistDto = stubWishlistDto();
      request.params.id = wishlistDto.id;
      lineItemId = faker.datatype.uuid();
      request.params.lineItemId = lineItemId;
      response.locals.market = market;
    });

    test('fetches data from wishlistService', async () => {
      /* Prepare */
      (shoppingListService.deleteLineItem as Mock).mockReturnValueOnce(wishlistDto);

      /* Execute */
      await shoppingListController.deleteLineItem(request, response);

      /* Verify */
      expect(shoppingListService.deleteLineItem).toHaveBeenCalledTimes(1);
      expect(shoppingListService.deleteLineItem).toHaveBeenNthCalledWith(
        1,
        market,
        wishlistDto.id,
        lineItemId,
      );
    });

    test('returns result from wishlistService.deleteLineItemWishlist as JsonApiResponseEntity', async () => {
      /* Prepare */
      (shoppingListService.deleteLineItem as Mock).mockReturnValueOnce(wishlistDto);

      /* Execute */
      const result = await shoppingListController.deleteLineItem(request, response);

      /* Verify */
      expect(result).toEqual({
        statusCode: 200,
        body: wishlistDto,
      });
    });
  });
});
