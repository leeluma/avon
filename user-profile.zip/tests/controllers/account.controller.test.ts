import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { MagnoliaInfo } from '../../src/dtos';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubMagnoliaData, stubMagnoliaHome, stubMagnoliaInfo,
} from '../__stubs__';
import { AccountController } from '../../src/controllers/account.controller';
import { MagnoliaService } from '../../src/services/magnolia.service';
import { MagnoliaData } from '../../src/dtos/magnolia.dto';

import Mock = jest.Mock;

describe('LeapApp', () => {
  /* System Under Test */
  let accountController: AccountController;

  /* Dependencies */
  let magnoliaService: MagnoliaService;
  let market: MarketInfo;
  let magnolia: MagnoliaInfo;
  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();
    magnolia = stubMagnoliaInfo();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    magnoliaService = {} as any;

    /* SUT */
    accountController = new AccountController({ magnoliaService });
  });

  /**
   * Unit test case for getAccountPageData
   */
  describe('getAccountPageData()', () => {
    let magnoliaHome: any;
    let magnoliaData: MagnoliaData;

    beforeEach(() => {
      magnoliaService.getAccountPageData = jest.fn();
      magnoliaService.getGlobalSettingsData = jest.fn();
      magnoliaService.getTemplateData = jest.fn();

      magnoliaHome = stubMagnoliaHome();
      magnoliaData = stubMagnoliaData();

      res.locals.magnolia = magnolia;
    });

    test('fetches data from productService', async () => {
      /* Prepare */
      (magnoliaService.getAccountPageData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getGlobalSettingsData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);

      /* Execute */
      const result = await accountController.getAccountPageData(req, res);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaService.getGlobalSettingsData).toHaveBeenCalledTimes(1);
      expect(magnoliaService.getAccountPageData).toHaveBeenCalledTimes(1);
    });

    test('fetches data from productService if isPreview is true', async () => {
      /* Prepare */
      res.locals.magnolia.isPreview = true;
      (magnoliaService.getAccountPageData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getGlobalSettingsData as Mock).mockReturnValueOnce(magnoliaData);
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(stubMagnoliaHome);

      /* Execute */
      const result = await accountController.getAccountPageData(req, res);

      /* Verify */
      expect(result).toBeTruthy();
      expect(magnoliaService.getGlobalSettingsData).toHaveBeenCalledTimes(1);
      expect(magnoliaService.getAccountPageData).toHaveBeenCalledTimes(1);
    });

    test('returns empty template if not preview', async () => {
      /* Prepare */
      const staticData = { staticField: faker.datatype.uuid() };
      (magnoliaService.getAccountPageData as Mock).mockReturnValueOnce(staticData);
      (magnoliaService.getGlobalSettingsData as Mock).mockReturnValueOnce(magnoliaData);
      magnolia.isPreview = false;
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);

      /* Execute */
      const result = await accountController.getAccountPageData(req, res);

      /* Verify */
      expect(result).toEqual({
        statusCode: 200,
        body: {
          staticField: staticData.staticField,
          globalSettings: magnoliaData,
          templateDefinition: {},
        },
      });
      expect(magnoliaService.getTemplateData).not.toHaveBeenCalled();
    });

    test('returns template from magnolia if preview', async () => {
      /* Prepare */
      const staticData = { staticField: faker.datatype.uuid() };
      (magnoliaService.getAccountPageData as Mock).mockReturnValueOnce(staticData);
      (magnoliaService.getGlobalSettingsData as Mock).mockReturnValueOnce(magnoliaData);
      magnolia.isPreview = true;
      (magnoliaService.getTemplateData as Mock).mockReturnValueOnce(magnoliaHome);

      /* Execute */
      const result = await accountController.getAccountPageData(req, res);

      /* Verify */
      expect(result).toEqual({
        statusCode: 200,
        body: {
          staticField: staticData.staticField,
          globalSettings: magnoliaData,
          templateDefinition: magnoliaHome,
        },
      });
      expect(magnoliaService.getTemplateData).toHaveBeenCalledTimes(1);
      expect(magnoliaService.getTemplateData).toHaveBeenNthCalledWith(
        1,
        staticData['mgnl:template'],
        magnolia.url,
      );
    });
  });
});
