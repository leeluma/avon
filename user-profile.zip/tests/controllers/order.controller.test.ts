import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubOrderResponse,
} from '../__stubs__';
import { OrderController } from '../../src/controllers';
import { OrderService } from '../../src/services';
import {
  GetMyOrdersDraftDto,
  OrderResponse,
} from '../../src/dtos';

import Mock = jest.Mock;

import { ApiError } from '../../src/lib';

describe('OrderController', () => {
  /* System Under Test */
  let orderController: OrderController;
  let orderResponse: OrderResponse[];
  /* Dependencies */
  let orderService: OrderService;
  let market: MarketInfo;

  /* Stubs */
  let req: Request;
  let res: Response;
  let authHeader: string;
  let orderId: string;

  beforeEach(() => {
    market = stubMarket();
    orderResponse = [stubOrderResponse()];

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);
    req.params.page = '1';
    req.params.sort = 'Asc';

    /* Dependencies */
    orderService = {} as any;

    /* SUT */
    orderController = new OrderController({ orderService });
    orderService.getAll = jest.fn();
    orderService.orderDetails = jest.fn();
    authHeader = `Bearer ${faker.random.randomWord()}`;
    req.headers.authorization = authHeader;
  });
  describe('getAll()', () => {
    test('fetches orders', async () => {
      /* Prepare */
      const params:GetMyOrdersDraftDto = {
        page: Number(req.params.page),
        sort: req.params.sort,
        limit: 10,
      };
      (orderService.getAll as Mock).mockReturnValueOnce(orderResponse);

      /* Execute */
      await orderController.getAll(req, res);

      /* Verify */
      expect(orderService.getAll).toHaveBeenCalledTimes(1);
      expect(orderService.getAll).toHaveBeenNthCalledWith(1, market, authHeader, params);
    });

    test('returns ctOrderResDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (orderService.getAll as Mock).mockReturnValueOnce(orderResponse);

      /* Execute */
      const response = await orderController.getAll(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: orderResponse,
      });
    });

    test('throws ApiError(NOT_FOUND) if orders do not exist', async () => {
      /* Prepare */
      (orderService.getAll as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(404, 'Orders not found.');

      /* Execute */
      await expect(() => orderController.getAll(req, res))
        .rejects.toThrow(expectedError);
    });
  });

  describe('getOrderDetails()', () => {
    beforeEach(() => {
      orderId = faker.datatype.uuid();
      req.params.orderId = orderId;
    });
    test('fetches orders', async () => {
      /* Prepare */
      (orderService.orderDetails as Mock).mockReturnValueOnce(orderResponse);

      /* Execute */
      await orderController.getOrderDetails(req, res);

      /* Verify */
      expect(orderService.orderDetails).toHaveBeenCalledTimes(1);
      expect(orderService.orderDetails).toHaveBeenNthCalledWith(1, market, authHeader, orderId);
    });

    test('returns ctOrderResDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (orderService.orderDetails as Mock).mockReturnValueOnce(orderResponse);

      /* Execute */
      const response = await orderController.getOrderDetails(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: orderResponse,
      });
    });

    test('throws ApiError(NOT_FOUND) if orders do not exist', async () => {
      /* Prepare */
      (orderService.orderDetails as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(404, 'Order not found.');

      /* Execute */
      await expect(() => orderController.getOrderDetails(req, res))
        .rejects.toThrow(expectedError);
    });
  });
});
