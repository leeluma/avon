import { readFile } from 'fs/promises';
import { graphql } from '../../src/graphql';

describe('graphql', () => {
  test('getCustomerById', async () => {
    const expected = (await readFile(`${__dirname}/../../src/graphql/get-customer-by-id.graphql`))
      .toString();

    const actual = await graphql.getCustomerById;

    expect(actual).toEqual(expected);
  });
});
