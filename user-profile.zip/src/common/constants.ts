export const DEFAULT_QUANTITY = {
  DEFAULT_MAX_PURCHASABLE_QUANTITY: 9999999,
  DEFAULT_MAX_AVAILABLE_QUANTITY: 9999999,
  DEFAULT_CENT_AMOUNT: 9999,
  BASE_NUMBER: 10,
};

export const VARIANT_ATTRIBUTES = {
  variantType: 'variantType',
  variantValue: 'variantValue',
  hexCode: 'hexCode',
  maxPurchasableQty: 'maxPurchasableQty',
  discontinued: 'discontinued',
};

export const CATEGORY_TYPE = {
  offer: 'Offer',
};

export const ATTRIBUTE_NAMES = {
  config: 'config',
  galleryVideo: 'galleryVideo',
  badges: 'badges',
  contentFillMeasurement: 'ContentFillMeasure',
  contentFill: 'ContentFill',
  availability: 'availability',
  excludeCountDown: 'excludeCountDown',
};

export const ATTRIBUTE_VALUES = {
  attributeValue: 'value',
  availabilitySku: 'skuCode',
  assetType: 'Video Gallery',
};

export const MEASUREMENT = {
  baseMeasure: 'baseMeasure',
  nodes: '@nodes',
};

export enum MAGNOLIA_URI {
  userprofilePage = '.rest/delivery/pages/v1/{{country}}/user-profile',
  template = '.rest/template-definitions/v1/',
  page = '.rest/delivery/pages/v1/{{country}}',
  wareHouseSetting = '.rest/delivery/global-settings/{{country}}/settings/warehouseSettings',
  globalSettings = '.rest/delivery/global-settings/{{country}}/settings',
  priceFormat = '.rest/delivery/global-settings/{{country}}/settings/priceFormat',
  AddressSettings = '.rest/delivery/global-settings/{{country}}/settings/addressSettings',
  getmgnlTemplate= 'mgnl:template',
}
