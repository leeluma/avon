import AWS from 'aws-sdk';
import { logger } from './logger';
import { logError } from './common';

const AWS_EVENT_BRIDGE_RESOURCE_NAME = 'leap';

export interface AwsEventBridgeClientConfig {
  region: string;
}

export enum AwsEventBridgeSource {
  passwordResetQueue = 'passwordResetQueue',
  marketingNotifications = 'marketingNotifications'
}

export class AwsEventBridgeClient {
  private readonly region: string;

  /**
   * @example
   *    const awsEventBridgeClient = new AwsEventBridgeClient({region});
   * @param config Configuration variables.
   */
  constructor(config: AwsEventBridgeClientConfig) {
    this.region = config.region;
  }

  /**
   * Put a single event in aws EventBridge
   * @param eventBusName - string EventBus name
   * @param source - string Source key, e.g. passwordResetQueue
   * @param detail - any A JS object that will be stringified and sent to the EventBus
   */
  async putEvent(
    eventBusName: string,
    source: AwsEventBridgeSource,
    detail: any,
  ): Promise<void> {
    const eventBridge = new AWS.EventBridge({
      region: this.region,
    });

    try {
      const data: AWS.EventBridge.PutEventsRequest = {
        Entries: [
          {
            EventBusName: eventBusName,
            Source: source,
            DetailType: source,
            Resources: [AWS_EVENT_BRIDGE_RESOURCE_NAME],
            Time: new Date(),
            Detail: JSON.stringify(detail),
          },
        ],
      };

      logger.info(`EventBridge Request: ${JSON.stringify(data)}`);

      const result = await eventBridge.putEvents(data).promise();

      // TODO Handle errors (see result.FailedCount)

      logger.info(`EventBridge Response: ${JSON.stringify(result)}`);
    } catch (error: any) {
      logError('AwsEventBridgeClient', 'Failed to put message', error);
      throw error;
    }
  }
}
