export const URI = {
  CommerceTool: {
    authToken: '/oauth/token/revoke?token=',
    tokenHint: '&token_type_hint=refresh_token',
  },
  tokens: {
    clusterId: '{{CLUSTER_ID}}',
  },
  magnolia: {
    category: '/c',
    pageData: '.rest/delivery/pages/v1/{{country}}',
    logSetting: '.rest/delivery/pages/v1/{{country}}/apptusSetting',
    categorySearch: '.rest/delivery/ecommerce-categories?q=',
    templatePath: '.rest/template-definitions/v1/',
    wareHouseSetting: '.rest/delivery/global-settings/{{country}}/settings/warehouseSettings',
    mgnlTemplate: 'mgnl:template',
    priceFormatUrl: '.rest/delivery/pages/v1/{{country}}/priceFormat?lang={{localeAndCountry}}',
  },
  apptus: {
    esales: 'notifications/click',
    nonEsales: 'notifications/non-esales-click',
    esaleAddToCart: 'notifications/adding-to-cart',
    nonEsaleAddToCart: 'notifications/non-esales-adding-to-cart',
  },
};

export const MARKET = '{{market}}';
