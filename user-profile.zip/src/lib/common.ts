/* eslint-disable no-unsafe-optional-chaining */
import { inspect } from 'util';
import {
  Attribute, Price, TypedMoney,
} from '@commercetools/platform-sdk';
import { DEFAULT_QUANTITY } from '../common/constants';
import { logger } from './logger';
import { config } from '../config';
import { LogConfig, LogStatus } from '../middlewares';
import { MarketInfo } from './utils';
import { GraphQLShoppingListLineItem, ProductVariantPriceDto } from '../dtos';

export const addressCustomTypeKey = 'address-type';
export const customerCustomTypeKey = 'customer-type';

export const priceFromMoney = (money: TypedMoney) =>
  money.centAmount / (10 ** money.fractionDigits);
export const CONTENT_FILL_MEASURE = 'ContentFillMeasure';
export const CONTENT_FILL = 'ContentFill';
export const CHANNEL = 'channel';

export class Common {
  /**
   * It used to convert object parameters to query string.
   *
   * @param params
   * @returns
   */
  public queryString(params: Record<string, any>): string {
    const removeUndefined = JSON.parse(JSON.stringify(params));
    return Object.entries(removeUndefined).map(
      ([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value as string)}`,
    ).join('&');
  }

  public convertUnderScoreToCamelCaseForApptus(params:Record<string, any>): Record<string, any> {
    return Object.fromEntries(
      Object.entries(params).map(([key, value]) =>
        [key.replace(/_([a-z])/g, (g) => { return g[1].toUpperCase(); }), value[0]]),
    );
  }

  public convertUnderScoreToCamelCase(params: Record<string, any>): Record<string, any> {
    return Object.fromEntries(
      Object.entries(params).map(([key, value]) =>
        [
          key.replace(/_([a-z])/g, (g) => g[1].toUpperCase()),
          value[0],
        ]),
    );
  }

  public isResponseOK = (status) => status >= 200 && status < 299;

  public log(conf: any, result: any, status, logConfig: LogConfig):void {
    if (logConfig.apptusLogStatus === LogStatus.TRACE) {
      logger.trace(`Request:: ${JSON.stringify(conf)}`);
      logger.trace(`Response:: ${JSON.stringify(result)}`);
    } else if (logConfig.apptusLogStatus === LogStatus.INFO && this.isResponseOK(status)) {
      logger.info(`Request:: ${JSON.stringify(conf)}`);
      logger.info(`Response:: ${JSON.stringify(result)}`);
    } else if (logConfig.apptusLogStatus === LogStatus.ERROR && !this.isResponseOK(status)) {
      logger.error(`Request:: ${JSON.stringify(conf)}`);
      logger.error(`Response:: ${JSON.stringify(result)}`);
    }
  }

  /**
   * Generate URL from Product id and Slug
   * @param lineItemDraft - ShoppingListLineItem
   * @param market - Market
   * @returns URL
   */
  public getUrl(productSlug): string {
    return `/p/${productSlug}`;
  }

  /**
   * Generate URL from Product id and Slug
   * @param lineItemDraft - ShoppingListLineItem
   * @param market - Market
   * @returns URL
   */
  public getProductUrl(market: MarketInfo, lineItemDraft: GraphQLShoppingListLineItem): string {
    return `/p/${lineItemDraft.productSlug}`;
  }

  /**
  * Get Formatted Magnolia Price
  * @param prices - List of prices
  * @param priceFormatJson - Magnolia Price Format
  * @returns Magnolia Formatted Price
  */
  public magnoliaPriceFormatter = (price: any, priceFormatJson: any): string => {
    const currency = priceFormatJson.ccy ?? '';
    const showDecimalZero = priceFormatJson.showDecimalZero ?? false;
    const noOfDigitAtLast = priceFormatJson.noOfDigits ?? 0;
    const decimalPoint = priceFormatJson.decimalPoint ?? '.';
    const thousandSeperator = priceFormatJson.thousandSeperator ?? '';
    const currencyPlacement = priceFormatJson.currencyPlacement ?? 'after';

    let returnPrice: string;
    const lastDigitNo = (10 ** noOfDigitAtLast);
    const sellPrice = price / lastDigitNo;
    const parts = sellPrice.toString().split('.');
    if (showDecimalZero === 'true') {
      returnPrice = parts[0]
        .replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeperator) + (parts[1] ? decimalPoint + parts[1] : '');
    } else {
      returnPrice = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeperator);
    }
    returnPrice = (currencyPlacement === 'before') ? `${currency} ${returnPrice}` : `${returnPrice} ${currency}`;

    return returnPrice;
  };

  /**
  * Get non-representative price i.e. price which do not have
  * Channel ID associated with it.
  * @param prices - List of prices
  * @param channel - Channel
  * @returns non-representative price
  */
  public getNonRepPrice(prices: Price[]) {
    if (!prices) return 0;
    const nonRepPrice = prices.find((price) => (price.channel === null));
    return nonRepPrice ? nonRepPrice.value.centAmount / (10 ** (nonRepPrice.value.fractionDigits || 2)) : 0;
  }

  /**
  * Get non-representative price with discount
  * @param prices - List of prices
  * @param channel - Channel
  * @returns non-representative price with discounts included
  */
  public getNonRepPriceWithDiscount(prices: Price[]) {
    if (!prices) return 0;
    const priceArr = prices.filter((price) => (price.channel === null));

    let listPrice = 0;
    if (priceArr[0]?.value?.centAmount) {
      listPrice = priceArr[0]?.value?.centAmount / (10 ** (priceArr[0]?.value?.fractionDigits || 2));
    }

    let discountedPrice = 0;
    if (priceArr[0]?.discounted?.value.centAmount) {
      discountedPrice = priceArr[0]?.discounted?.value.centAmount
        / (10 ** priceArr[0]?.discounted?.value.fractionDigits || 2);
    }

    return discountedPrice !== 0 ? discountedPrice : listPrice;
  }

  /**
   * function to convert number to decimal in given fraction
   * @param amount - Given amount
   * @param fraction - Given fraction
   * @returns
   */
  public readonly priceConverter = (amount:number, fraction:number) => {
    const denominator = DEFAULT_QUANTITY.BASE_NUMBER ** fraction;
    return (amount / denominator).toFixed(fraction);
  };

  /**
  * Get Attribute value by Attribute name
  * @param attributes - List of `AttributesDto`s
  * @param attrName - Attribute name
  * @returns attribute value
  */
  public getAttributeValue(attributes: Attribute[], attrName: string) {
    if (!attributes) return '';
    const attr = attributes.find((a) => a.name === attrName);
    if (typeof attr?.value === 'object') {
      return attr.value.key ?? attr.value;
    }
    return attr ? attr.value : '';
  }

  /**
  * Get non-representative price with discount && wuthout discount
  * @param prices - List of prices
  * @param channel - Channel
  * @returns non-representative price with discounts included without dot
  */
  public getNonRepPriceCal(prices: ProductVariantPriceDto[]) {
    if (!prices) {
      return {
        withoutDiscount: 0,
        withDiscount: 0,
      };
    }
    const priceAttribute = prices?.filter((price) => (price.channel === null));
    let listPrice = 0;
    if (priceAttribute[0]?.value?.centAmount) {
      listPrice = priceAttribute[0]?.value?.centAmount;
    }
    let discountedPrice = 0;
    if (priceAttribute[0]?.discounted?.value.centAmount) {
      discountedPrice = priceAttribute[0]?.discounted?.value.centAmount;
    }
    return {
      withoutDiscount: listPrice !== 0 ? listPrice : 0,
      withDiscount: discountedPrice !== 0 ? discountedPrice : listPrice,
    };
  }

  /**
  * Get Product Mass Detail
  * @param attributes - list of `AttributesDto`s
  * @param magnoliaObject Magnolia Price Format
  * @returns Product Mass Detail
  */
  public getproductMassDetail(
    attributes: Attribute[],
    magnoliaObject: any,
    prices: any[],
  ) {
    let price: any;
    const contentFill = this.getAttributeValue(attributes, CONTENT_FILL);
    const contentFillMeasure = this.getAttributeValue(attributes, CONTENT_FILL_MEASURE);
    const { withDiscount } = this.getNonRepPriceCal(prices);
    if (!Number.isNaN(withDiscount)) {
      price = this.magnoliaPriceFormatter(withDiscount, magnoliaObject);
      return `${contentFill} ${contentFillMeasure}(${price}/${magnoliaObject.baseMeasure.unitPriceBaseMeasure})`.trim();
    }
    return '';
  }
}

/**
 * Log a JavaScript Error object. This function sanitizes the Error a bit
 * before printing it (removes req/res in case the Error comes from axios)
 * and supports circular references.
 * @param source
 * @param reason
 * @param error
 */
export const logError = (
  source: string,
  reason: string,
  error: Error,
): void => {
  if (config.logLevel !== 'trace') {
    logger.error(`${source} ERROR: ${reason} because:\n${error}`);
    return;
  }

  const cleanError: any = { ...error };

  /* Remove fields we don't care about, because many errors contain
     the HTTP request and response objects, but they are complicated,
     and we rarely care to see what's in them */
  delete cleanError.req;
  delete cleanError.res;
  delete cleanError.request;
  delete cleanError.response;

  const stringError = inspect(error, { depth: 10 });

  logger.error(`${source} ERROR: ${reason} because:\n${stringError}`);
};
