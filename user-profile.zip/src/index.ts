import { Router } from 'express';
import {
  CtClient, Common, AwsEventBridgeClient,
} from './lib';
import { LeapApp, LeapAppConfig } from './app/leap.app';
import {
  AddressDao, CustomerDao, OrderDao, DefaultDao, ShoppingListDao,
  CartDao, SettingDao, NotificationsDao,
} from './daos';
import {
  AddressController, CustomerController, OrderController, AccountController, DefaultController,
  ShoppingListController, NotificationsController,
} from './controllers';
import {
  AddressService, CustomerService, OrderService, MagnoliaService, DefaultService, ShoppingListService,
  NotificationsService,
} from './services';
import {
  AddressRouter, CustomerRouter, OrderRouter, AccountRouter, DefaultRouter, ShoppingListRouter,
  NotificationsRouter,
} from './routers';
import {
  AddressMapper,
  CustomerMapper,
  OrderMapper,
  PaymentInfoMapper,
  PromotionMapper,
  ShippingInfoMapper,
  ShoppingListMapper,
  LineItemMapper,
} from './mappers';
import { graphql } from './graphql';
import { config } from './config';
import { MagnoliaDao } from './daos/magnolia.dao';
import {
  buildAuthMiddleware,
  makeAddressValidationSettingsMiddleware,
  makeValidationSettingsMiddleware,
} from './middlewares';

const {
  projectName, projectVersion, apiContextPath, apiVersion,
  port, ctMarkets, addressFinderHost, addressFinderAutoComplete, addressFinderDetail, awsRegion,
  awsEventBusNameMarketingNotifications, awsEventBusNamePasswordReset, apptusClusterId,
  apptusBaseUrl,
  apptusEsalesMarket,
} = config;
const magnoliaBasePath = config.uri.magnolia.basePath;
const magnoliaGlobalSettingUrl = config.uri.magnolia.globalSettingUrl;
/* Build configuration */
if (!magnoliaBasePath) {
  throw new Error('The "magnoliaBasePath" field in configuration is mandatory!');
}

if (!magnoliaGlobalSettingUrl) {
  throw new Error('The "magnoliaGlobalSettingUrl" field in configuration is mandatory!');
}

if (!projectName) {
  throw new Error('The "name" field in package.json is mandatory!');
}

if (!projectVersion) {
  throw new Error('The "version" field in package.json is mandatory!');
}

if (!apiContextPath) {
  throw new Error('The "API_CONTEXT_PATH" environment variable is mandatory! (suggested value: api)');
}

if (!apiVersion) {
  throw new Error('The "API_VERSION" environment variable is mandatory! (suggested value: v1)');
}

if (!port) {
  throw new Error('The "API_PORT" environment variable is missing or not a valid number! (suggested value: 3000)');
}
if (!apptusClusterId) {
  throw new Error('The "APPTUS_CLUSTER_ID" environment variable is missing');
}

if (!apptusEsalesMarket) {
  throw new Error('The "APPTUS_ESALES_MARKET" environment variable is missing');
}

if (!apptusBaseUrl) {
  throw new Error('The "APPTUS_BASE_URL" environment variable is missing');
}
if (!ctMarkets) {
  throw new Error('The "CT_ACTIVE_MARKETS" environment variable is missing (suggested value: ["RO"])');
}

if (!addressFinderHost) {
  throw new Error('The "ADDRESS_FINDER_HOST" environment variable is missing!');
}

if (!addressFinderAutoComplete) {
  throw new Error('The "addressFinderAutoComplete" variable is missing!');
}

if (!addressFinderDetail) {
  throw new Error('The "addressFinderDetail" variable is missing!');
}

if (!awsRegion) {
  throw new Error('The "AWS_REGION" variable is missing! (you probably want eu-west-1)');
}

if (!awsEventBusNameMarketingNotifications) {
  throw new Error('The "AWS_EVENT_BUS_NAME_MARKETING_NOTIFICATIONS" variable is missing!');
}

if (!awsEventBusNamePasswordReset) {
  throw new Error('The "AWS_EVENT_BUS_NAME_PASSWORD_RESET" variable is missing!');
}

if (!apptusClusterId) {
  throw new Error('The "APPTUS_CLUSTER_ID" environment variable is missing');
}

if (!apptusEsalesMarket) {
  throw new Error('The "APPTUS_ESALES_MARKET" environment variable is missing');
}

if (!apptusBaseUrl) {
  throw new Error('The "APPTUS_BASE_URL" environment variable is missing');
}

const appConfig: LeapAppConfig = {
  projectName,
  projectVersion,
  apiContextPath,
  apiVersion,
  port,
};

/* Initialize dependencies */
const common = new Common();
const ctClient = new CtClient(process.env as any);
const eventBridgeClient = new AwsEventBridgeClient({ region: awsRegion });

/** Daos */
const magnoliaDao = new MagnoliaDao({ basePath: magnoliaBasePath, globalSettingUrl: magnoliaGlobalSettingUrl });
const customerDao = new CustomerDao({ ctClient, graphql });
const orderDao = new OrderDao({ ctClient, graphql });
const addressDao = new AddressDao();
const defaultDao = new DefaultDao({ ctClient });
const notificationsDao = new NotificationsDao({
  common,
  apptusBaseUrl,
  apptusClusterId,
  apptusEsalesMarket,
});
const cartDao = new CartDao({ ctClient, graphql });
const settingDao = new SettingDao({
  magnoliaBasePath,
});
const shoppingListDao = new ShoppingListDao({ ctClient, graphql });

/** Mappers */
const addressMapper = new AddressMapper();
const shippingInfoMapper = new ShippingInfoMapper({ common });
const paymentInfoMapper = new PaymentInfoMapper({ common });
const promotionMapper = new PromotionMapper({ common });
const customerMapper = new CustomerMapper({ addressMapper });
const orderMapper = new OrderMapper({
  addressMapper,
  common,
  shippingInfoMapper,
  promotionMapper,
  paymentInfoMapper,
});

const lineItemsMapper = new LineItemMapper({ common });
const shoppingListMapper = new ShoppingListMapper({ lineItemsMapper });

/** Services */
const customerService = new CustomerService({
  customerDao,
  addressDao,
  cartDao,
  addressMapper,
  customerMapper,
  eventBridgeClient,
  marketingEmailConsentEventBusName: awsEventBusNameMarketingNotifications,
  passwordResetEventBusName: awsEventBusNamePasswordReset,
});
const orderService = new OrderService({ orderDao, orderMapper, magnoliaDao });
const addressService = new AddressService({ addressDao });
const magnoliaService = new MagnoliaService({ magnoliaDao });
const defaultService = new DefaultService({ defaultDao });
const notificationsService = new NotificationsService({ notificationsDao });

const shoppingListService = new ShoppingListService({
  cartDao,
  settingDao,
  shoppingListDao,
  shoppingListMapper,
  globalSettingUrl: magnoliaGlobalSettingUrl,
});

/** Controllers */
const customerController = new CustomerController({ customerService });
const orderController = new OrderController({ orderService });
const addressController = new AddressController({ addressService });
const accountController = new AccountController({ magnoliaService });
const defaultController = new DefaultController({ defaultService });
const notificationsController = new NotificationsController({ notificationsService });
const shoppingListController = new ShoppingListController({ shoppingListService });

/** Validations */
const validationSettingsReader = magnoliaDao.getGlobalSetting.bind(magnoliaDao);
const validationSettingsMiddleware = makeValidationSettingsMiddleware(validationSettingsReader);
const authMiddleware = buildAuthMiddleware(ctClient);
const addressValidationSettingsReader = magnoliaDao.getAddressSettings.bind(magnoliaDao);
const addressValidationSettingsMiddleware = makeAddressValidationSettingsMiddleware(addressValidationSettingsReader);

/** Routers */
const orderRouter = new OrderRouter({ orderController, Router, authMiddleware });
const customerRouter = new CustomerRouter({
  customerController,
  Router,
  validationSettingsMiddleware,
  addressValidationSettingsMiddleware,
  authMiddleware,
});
const addressRouter = new AddressRouter({ addressController, Router });
const accountRouter = new AccountRouter({ accountController, Router });
const defaultRouter = new DefaultRouter({ defaultController, Router, validationSettingsMiddleware });
const notificationsRouter = new NotificationsRouter({ Router, notificationsController });

const shoppingListRouter = new ShoppingListRouter({ Router, shoppingListController });
/* Start app */

const leapApp = new LeapApp(appConfig);
leapApp.bootstrap().then(() => {
  leapApp.mount('/customers', customerRouter.buildExpressRouter());
  leapApp.mount(
    '/',
    accountRouter.buildExpressRouter(),
    orderRouter.buildExpressRouter(),
    defaultRouter.buildExpressRouter(),
  );
  leapApp.mount('/addresses', addressRouter.buildExpressRouter());
  leapApp.mount('/notifications', notificationsRouter.buildExpressRouter());
  leapApp.mount('/wishlists', shoppingListRouter.buildExpressRouter());
  leapApp.listen();
});
