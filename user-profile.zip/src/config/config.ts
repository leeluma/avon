import dotenv from 'dotenv';

dotenv.config();
export const config = {
  env: process.env.NODE_ENV,
  apiUrl: process.env.API_CONTEXT_PATH,
  port: parseInt(process.env.API_PORT || '0', 10),
  projectName: process.env.npm_package_name,
  projectVersion: process.env.npm_package_version,
  apiContextPath: process.env.API_CONTEXT_PATH,
  apiVersion: process.env.API_VERSION,
  templateId: process.env.TEMPLATE_ID,
  contactFormUrl: process.env.CONTACT_FORM_URL,
  fromName: process.env.FROM_NAME,
  fromEmail: process.env.FROM_EMAIL,
  ctRO: {
    projectKey: process.env.CT_PROJECT_KEY_RO,
    clientId: process.env.CT_CLIENT_ID_RO,
    clientSecret: process.env.CT_CLIENT_SECRET_RO,
  },
  ctPH: {
    projectKey: process.env.CT_PROJECT_KEY_PH,
    clientId: process.env.CT_CLIENT_ID_PH,
    clientSecret: process.env.CT_CLIENT_SECRET_PH,
  },
  ctMarkets: process.env.CT_ACTIVE_MARKETS,
  ctApiEndpoint: process.env.CT_API_ENDPOINT,
  ctAuthEndpoint: process.env.CT_AUTH_ENDPOINT,
  apptusClusterId: process.env.APPTUS_CLUSTER_ID,
  apptusBaseUrl: process.env.APPTUS_BASE_URL,
  apptusEsalesMarket: process.env.APPTUS_ESALES_MARKET,
  logLevel: process.env.LOG_LEVEL,
  uri: {
    magnolia: {
      globalSettingUrl: '.rest/delivery/global-settings/{{country}}/settings?lang={{locale}}',
      basePath: process.env.MAGNOLIA_BASE_PATH,
      previewBasePath: process.env.PREVIEW_MAGNOLIA_BASE_PATH,
    },
  },
  addressFinderHost: process.env.ADDRESS_FINDER_HOST,
  addressFinderAutoComplete: 'autocomplete/{{market}}',
  addressFinderDetail: 'addressdetails/{{market}}',
  awsRegion: process.env.AWS_REGION,
  awsEventBusNameMarketingNotifications: process.env.AWS_EVENT_BUS_NAME_MARKETING_NOTIFICATIONS,
  awsEventBusNamePasswordReset: process.env.AWS_EVENT_BUS_NAME_PASSWORD_RESET,
  ctLimit: 10,
  ctPage: 1,
  ctSort: 'Asc',
  ttlMinutes: process.env.TTL_MINUTES || 15, // NOSONAR
};

export const stringLiteral = {
  magnolia: {
    priceFormatUrl: '.rest/delivery/global-settings/{{country}}/settings/priceFormat?lang={{lang}}',
  },
  graphQL: {
    expand: {
      variant: 'lineItems[*].variant',
      productSlug: 'lineItems[*].productSlug',
    },
  },
  messages: {
    FORBIDDEN: 'You may not perform this operation',
  },
};
