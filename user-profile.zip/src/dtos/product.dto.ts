import { CtId } from './common.dto';

export interface AttributesDto{
  variantType?: string;
  variantValue?: string;
  shortDescription?: string;
  brandId?: string;
  brandName?: string;
  finishedStockCode?: string;
  specialMessage?: string;
  ContentFillMeasure?: string;
  ContentFill?: string;
  hexCode?: string;
  contentFill?: string;
  contentFillMeasure?: string;
  excludeCountDown?: boolean;
}

export interface Availability {
  isOnStock: boolean;
  availableQuantity: number;
  version: number;
  id: string;
}

export interface VariantDimensions {
  w: number;
  h: number;
}
export interface VariantImage {
  url: string;
  label: string;
  dimensions: VariantDimensions;
}

export interface ProductVariantPriceDto extends CtId {
  value: {
      type: string;
      currencyCode: string;
      centAmount: number;
      fractionDigits: number;
  },
  channel: {
      typeId: string;
      id: string;
  }
  discounted: {
      value: {
         type: string;
         currencyCode: string;
         centAmount: number;
         fractionDigits: number;
      },
  discount: {
      typeId: string;
      id: string;
      }
  }
}
