import {
  CentPrecisionMoney,
  DiscountCode,
  DiscountCodeState,
  Image, Order, Payment,
} from '@commercetools/platform-sdk';
import { AddressResponseDto, GraphQLAddress, GraphQLLineItem } from '.';

export interface GraphQLDiscountCode {
  discountCode: DiscountCode;
  state: DiscountCodeState;
}

export interface GraphQLPaymentInfo {
  payments: Payment;
}
export interface GraphQLOrder extends Omit<Order,
  'lineItems' | 'discountCodes' | 'paymentInfo' | 'shippingAddress'| 'billingAddress' | 'custom'> {
  lineItems: GraphQLLineItem[];
  totalPrice: CentPrecisionMoney;
  discountCodes: GraphQLDiscountCode;
  paymentInfo: GraphQLPaymentInfo;
  shippingAddress: GraphQLAddress;
  billingAddress: GraphQLAddress;
  custom?: {
    customFieldsRaw: []
  };
}

export interface GraphQLOrderList {
  total: number;
  results: GraphQLOrder[]
}

export interface Offers {
    key?: string;
    displayName?: string;
    description?: string;
    fulfilled?: boolean;
}
export interface OrderLineItem {
    lineItemId: string
    productId: string
    productSlug: string
    name: string
    skuCode: string
    images: Image[]
    quantity: number
    totalPrice: number
    sellPrice: number
    listPrice: number
    formattedListPrice: string
    formattedSellPrice: string
    unitPrice: string
    currencyCode: string
    variantType: string
    variantValue: string
    hexCode: string
    offers: Offers[]
  }

export interface OrderResponse {
    id: string
    version: number
    customerId?: string
    customerEmail?: string;
    totalPrice: number
    currencyCode: string
    lineItems: OrderLineItem[]
    shippingAddress?: AddressResponseDto
    billingAddress?: AddressResponseDto
  }

export interface MyOrdersResponse {
    id: string;
    customerId?: string;
    totalPrice: number;
    formattedTotalPrice: string;
    currencyCode: string;
    orderSlug: string;
    orderStatus: string;
    orderDate: string;
    itemsCount: number;
  }

export interface MyOrdersListResponse {
  total: number;
  results: MyOrdersResponse[];
  }
export interface PaymentInfoDto {
    paymentStatus?: string;
    paymentType: string;
    paymentAmount: string;
  }

export interface PromotionDto {
    promotionId: string;
    promotionCode: string;
    promotionAmount: number;
    formattedPromotionAmount: string;
    promotionState?: string;
    promotionApplied: boolean;
  }
export interface ShippingInfoDto {
    shippingMethodName: string;
    shippingMethodPrice: string;
    shippingPrice: number;
  }
export interface OrderDto {
    id: string;
    version: number;
    orderNumber?: string;
    customerId?: string;
    anonymousId?: string;
    lineItems: OrderLineItem[];
    orderState: string;
    totalPrice?: number;
    shippingAddressType?: string;
    shippingAddress?: AddressResponseDto;
    shippingInfo?: ShippingInfoDto;
    billingAddress?: AddressResponseDto;
    totalRetailPriceAmount: string;
    totalInvoiceAmount: number;
    currencyCode: string;
    formattedTotalPrice: string;
    customerEmail?: string;
    promotion?: PromotionDto;
    paymentInfo?:PaymentInfoDto;
    formattedTotalInvoiceAmount: string;

  }

export interface ImageDto {
    url: string;
    label: string;
    width: number;
    height: number;
  }

export interface OffersDto {
    key: string;
    displayName: string;
    url: string;
    description: string;
    fulfilled: boolean;
  }

export interface GetMyOrdersDraftDto {
  page: number;
  sort: string;
  limit: number;
}
/**
 * @swagger
 * components:
 *   schemas:
 *     OrderLineItem:
 *       additionalProperties: false
 *       properties:
 *         currencyCode:
 *           type: string
 *         images:
 *           items:
 *             $ref: '#/components/schemas/Image'
 *           type: array
 *         lineItemId:
 *           type: string
 *         name:
 *           type: string
 *         productId:
 *           type: string
 *         productSlug:
 *           type: string
 *         quantity:
 *           type: number
 *         skuCode:
 *           type: string
 *         totalPrice:
 *           type: number
 *       required:
 *         - lineItemId
 *         - productId
 *         - productSlug
 *         - name
 *         - skuCode
 *         - images
 *         - quantity
 *         - totalPrice
 *         - currencyCode
 *       type: object
 *     OrderResponse:
 *       additionalProperties: false
 *       properties:
 *         billingAddress:
 *           $ref: '#/components/schemas/AddressResponseDto'
 *         currencyCode:
 *           type: string
 *         customerEmail:
 *           type: string
 *         customerId:
 *           type: string
 *         id:
 *           type: string
 *         lineItems:
 *           items:
 *             $ref: '#/components/schemas/OrderLineItem'
 *           type: array
 *         shippingAddress:
 *           $ref: '#/components/schemas/AddressResponseDto'
 *         totalPrice:
 *           type: number
 *         version:
 *           type: number
 *       required:
 *         - id
 *         - version
 *         - totalPrice
 *         - currencyCode
 *         - lineItems
 *       type: object
 *     MyOrdersResponse:
 *       additionalProperties: false
 *       properties:
 *         id:
 *           type: string
 *         customerId:
 *           type: string
 *         formattedTotalPrice:
 *           type: string
 *         totalPrice:
 *           type: number
 *         orderSlug:
 *           type: string
 *         orderStatus:
 *           type: string
 *         orderDate:
 *           type: string
 *         itemsCount:
 *           type: number
 *         currencyCode:
 *           type: string
 *       required:
 *         - id
 *         - totalPrice
 *         - formattedTotalPrice
 *         - orderSlug
 *         - orderStatus
 *         - orderDate
 *         - itemsCount
 *         - currencyCode
 *       type: object
 *     AddressResponseDto:
 *       additionalProperties: false
 *       properties:
 *         id:
 *           type: string
 *         customerId:
 *           type: string
 *         firstName:
 *           type: string
 *         lastName:
 *           type: string
 *         recipientName:
 *           type: string
 *         address1:
 *           type: string
 *         address2:
 *           type: string
 *         address3:
 *           type: string
 *         address4:
 *           type: string
 *         city:
 *           type: string
 *         region:
 *           type: string
 *         zip:
 *           type: string
 *         county:
 *           type: string
 *         country:
 *           type: string
 *         latitude:
 *           type: number
 *         longitude:
 *           type: number
 *         state:
 *           type: string
 *         isShippingAddress:
 *           type: boolean
 *         isBillingAddress:
 *           type: boolean
 *         phoneNumber:
 *           type: string
 *       required:
 *         - address1
 *         - country
 *       type: object
 */
