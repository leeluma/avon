import {
  DiscountedLineItemPriceForQuantity, Image, Price, TypedMoney,
} from '@commercetools/platform-sdk';
import { BaseMeasure } from './magnolia.dto';

export interface MagnoliaPriceFormatDto{
  'isVatIncluded': string;
  'vatIncludedMessage': string;
  '@name': string,
  '@path':string,
  '@id':string,
  '@nodeType':string,
  'ccy':string,
  'showDecimalZero':string,
  'thousandSeperator':string,
  'noOfDigit':string,
  'masterContentIdentifier':string,
  'currencyPlacement':string,
  'mgnl:created':string,
  'decimalPoint':string,
  'mgnl:lastModified':string,
  'baseMeasure':BaseMeasure,
  '@nodes':Array<string>
}

export interface LooseObject {
    [key: string]: string | number | { [key: string]: string | number }
  }
interface Datum {
    [k: string]: boolean | number | string | LooseObject;
  }
type Data = Datum[];
export interface GraphQLVariant {
    id: number;
    sku: string;
    images: Image[];
    attributesRaw: Data;
    prices: Price[];
  }
export interface GraphQLLineItem {
    id: string;
    productId: string;
    productSlug: string;
    name: string;
    quantity: number;
    totalPrice: TypedMoney;
    variant: GraphQLVariant;
    discountedPricePerQuantity: DiscountedLineItemPriceForQuantity[];
  }

export interface ProductDto {
  [k: string]: string;
}

export interface CustomImage {
  url: string;
  assetType: string | undefined;
  sequence: number;
}
export interface LineItemDto {
  id: string;
  variantId?: number;
  quantity: number | undefined;
  url: string;
  name: string;
  product: ProductDto;
  listPrice: number,
  sellPrice: number,
  vatIncluded: string,
  productMassDetails: string;
  images?: CustomImage[]
}
