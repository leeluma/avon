export interface MagnoliaDto {
  [key: string]: string | string[];
}

export interface BaseMeasure {
  '@name': string;
  '@path': string;
  '@id': string;
  '@nodeType': string;
  translation: string;
  unitPriceBaseMeasure: string;
  containerSizeLimit: string;
  '@nodes': Array<string>;
}
export interface PriceFormat {
  '@name': string;
  '@path': string;
  '@id': string;
  '@nodeType': string;
  ccy: string;
  showDecimalZero: string;
  thousandSeperator: string;
  noOfDigit: string;
  currencyPlacement: string;
  decimalPoint: string;
  isVatIncluded: string;
  vatIncludedMessage: string;
  baseMeasure: BaseMeasure;
  '@nodes': Array<string>;
}
export interface ProductIds {
  [key: string]: Array<string>;
}
export interface ProductsIds {
  productIds: ProductIds;
  keys: Array<string>;
}
export interface MagnoliaData {
  data: any; // NOSONAR
  productIds: ProductsIds;
  templateName: string;
}
