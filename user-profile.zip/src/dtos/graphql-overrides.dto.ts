import {
  Attribute, Cart, ProductVariant, ShippingMethod,
} from '@commercetools/platform-sdk';
import { GraphQLLineItem } from './line-item.dto';

export interface GraphQLProductVariant extends Omit<ProductVariant, 'attributes'> {
  readonly attributesRaw: Attribute[];
}

/*  */
export interface GraphQLShippingMethodDto extends ShippingMethod {
  readonly results: ShippingMethod[];
}

export interface GraphQLCart extends Omit<Cart, 'lineItems'
| 'createdAt' | 'customLineItems' | 'taxRoundingMode' | 'refusedGifts'> {
  totalLineItemQuantity: number;
  lineItems: GraphQLLineItem[],
}
export interface GraphQLCartResponseDto {
  cart: GraphQLCart;
  shippingMethods: GraphQLShippingMethodDto;
}
