import { ShoppingList, ShoppingListLineItem } from '@commercetools/platform-sdk';
import { LineItemDto } from '.';

/**
 * @swagger
 * components:
 *   schemas:
 *     LineItemDto:
 *       additionalProperties: false
 *       properties:
 *         id:
 *           type: string
 *         images:
 *           items: {}
 *           type: array
 *         prices:
 *           type: number
 *         product:
 *           $ref: '#/components/schemas/ProductDto'
 *         quantity:
 *           type: number
 *         variantId:
 *           type: number
 *       required:
 *         - id
 *         - product
 *         - prices
 *         - images
 *       type: object
 *     ProductDto:
 *       additionalProperties:
 *         type: string
 *       type: object
 *     WishlistDto:
 *       additionalProperties: false
 *       properties:
 *         anonymousId:
 *           type: string
 *         customerId:
 *           type: string
 *         id:
 *           type: string
 *         key:
 *           type: string
 *         lineItems:
 *           items:
 *             $ref: '#/components/schemas/LineItemDto'
 *           type: array
 *         name:
 *           type: string
 *       required:
 *         - id
 *         - name
 *         - lineItems
 *       type: object
 */
export interface WishlistDto {
  id: string;
  name: string;
  key?: string;
  lineItems: LineItemDto[];
  customerId?: string;
  anonymousId?: string;
  version?: number;
}

export interface WishlistMoveToCartResponseDto {
  wishlistId: string;
  cartId: string;
}

export interface GraphQLShoppingListLineItem extends Omit<ShoppingListLineItem, 'name' | 'productSlug' |
'addedAt' | 'productType'> {
  name: string;
  productSlug: string;
}

export interface GraphQLShoppingList extends Omit<ShoppingList, 'name' | 'lineItems' |
'createdAt' | 'lastModifiedAt'> {
  name: string;
  lineItems?: GraphQLShoppingListLineItem[],
}
