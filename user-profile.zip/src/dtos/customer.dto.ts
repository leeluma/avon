import { Customer } from '@commercetools/platform-sdk';
import { AddressResponseDto, GraphQLAddress } from '.';
import { CommonResponse, GraphQLCustomFields } from './common.dto';

/** Used to accept customer info in registration API */
export interface CustomerRegistrationRequestDto {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    optIn?: boolean;
    cartId?: string;
    key?: string;
}
/**
 * Used to accept customer login request info
 */
export interface LoginReqDto {
    email: string,
    password: string
}

/** Used to return customer info in API response */
export interface CustomerResponseDto {
    id: string;
    email: string;
    firstName?: string;
    lastName?: string;
    optIn?: boolean;
    phoneNumber?: string;
    termsAndConditions?: boolean;
    addresses?: AddressResponseDto[];
}
export interface SetDefaultAddressPayload {
    version: string;
    actions : CommonResponse
}
/**
 * customer's login response Dto
 */
export interface CustomerLoginResDto{
    accessToken: string;
    tokenType: string;
    expiresIn: number;
    refreshToken: string;
}
/**
 *  Used to return cusrtomers response
 */
export interface CustomerAddressResponseDto {
    addresses?: AddressResponseDto[];
}

/** Used to accept customer info in change password API */
export interface ChangePasswordRequestDto {
    customerId: string;
    currentPassword: string;
    newPassword: string;
}

export interface CustomerForgotPassword {
    value: string,
    expiresAt: string,
    customerId: string,
}
export interface LoginDto {
    email: string,
    password: string,
    cartId?: string,
  }

export type GraphQLCustomerResponse = Omit<Customer, 'addresses'> & {
    custom?: GraphQLCustomFields;
    addresses: GraphQLAddress[] };

export interface SetDefaultAddressDto {
    isBilling: boolean,
    isDelivery: boolean,
    addressId: string,
    version: number,
}

export interface LoginCustomerDto{
    access_token: string;
    expires_in: number;
    token_type: string;
    refresh_token: string;
    scope: string;
    expires_at?: number;
}

export interface CustomerLoginResponseDto {
    accessToken: string;
    expiresIn: number;
    tokenType: string;
    scope?: string;
    refreshToken: string;
    expiresAt?: number;
    customerId: string | undefined;
    cartId?: string;
    wishlistId?: string;
  }
export interface LoginResponseDto {
    statusCode: number;
    body: CustomerLoginResponseDto;
  }

export interface CustomerActiveCartAndWishListDto {
    shoppingLists: {
        results: [
            {
                id: string;
            }
        ]
    };
    me: {
        activeCart:{
            id: string;
        }
    };
  }
/**
 * @swagger
 * components:
 *   schemas:
 *     CustomerRequestDto:
 *       additionalProperties: false
 *       description: Used to accept customer info in api response
 *       properties:
 *         email:
 *           type: string
 *         firstName:
 *           type: string
 *         lastName:
 *           type: string
 *         password:
 *           type: string
 *         currentPassword:
 *           type: string
 *         optIn:
 *           type: boolean
 *       required:
 *         - email
 *         - password
 *         - firstName
 *         - lastName
 *         - currentPassword
 *     CustomerResponseDto:
 *       additionalProperties: false
 *       description: Used to accept customer info in api response
 *       properties:
 *         id:
 *           type: string
 *         email:
 *           type: string
 *         firstName:
 *           type: string
 *         phoneNumber:
 *           type: string
 *         lastName:
 *           type: string
 *         password:
 *           type: string
 *         optIn:
 *           type: boolean
 *         termsAndConditions:
 *           type: boolean
 *     CustomerAddressRequestDto:
 *       additionalProperties: false
 *       description: Used to accept customer's address payload
 *       properties:
 *         address1:
 *           type: string
 *         address2:
 *           type: string
 *         address3:
 *           type: string
 *         address4:
 *           type: string
 *         city:
 *           type: string
 *         region:
 *           type: string
 *         postalCode:
 *           type: string
 *         country:
 *           type: string
 *         county:
 *           type: string
 *         latitude:
 *           type: string
 *         longitude:
 *           type: string
 *         state:
 *           type: string
 *         phoneNumber:
 *           type: string

 *     ChangePasswordRequestDto:
 *       additionalProperties: false
 *       description: Used to accept customer's change password payload
 *       properties:
 *         currentPassword:
 *           type: string
 *         newPassword:
 *           type: string

 *     LoginReqDto:
 *       additionalProperties: false
 *       description: Used to accept customer login request info
 *       properties:
 *         email:
 *           type: string
 *         password:
 *           type: string
 *       required:
 *         - email
 *         - password
 *       type: object
 *
 *     SetDefaultAddressRequestDto:
 *       additionalProperties: false
 *       description: set default address for billing/delivery
 *       properties:
 *         isBilling:
 *           type: boolean
 *           required: false
 *         isDelivery:
 *           type: boolean
 *           required: true
 *       type: object
 *
 *     SetDefaultAddressResponseDto:
 *       additionalProperties: false
 *       description: set default address for billing/delivery
 *       properties:
 *         isBilling:
 *           type: boolean
 *           required: false
 *         isDelivery:
 *           type: boolean
 *           required: true
 *       type: object
 *
 *     CustomerLoginResDto:
 *       additionalProperties: false
 *       description: customer's login response Dto
 *       properties:
 *         access_token:
 *           type: string
 *         expires_in:
 *           type: number
 *         refresh_token:
 *           type: string
 *         token_type:
 *           type: string
 *       required:
 *         - access_token
 *         - token_type
 *         - expires_in
 *         - refresh_token
 *       type: object
 */
