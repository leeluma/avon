import { Address } from '@commercetools/platform-sdk';
import { GraphQLCustomFields } from '.';

/** Address request for BFF APIS */
export interface AddressRequestDto {
  addressFinderId?: string; // ID for address validation API.
  recipientName?: string;
  firstName?: string;
  lastName?: string;
  address1: string;
  address2: string;
  address3: string;
  address4: string;
  city: string;
  region: string;
  zip: string;
  county: string;
  country: string;
  key?: string;
  latitude: number;
  longitude: number;
  state: string;
  phoneNumber: string;
  isShippingAddress: boolean;
  isBillingAddress: boolean;
}

/** Address request for BFF APIS */
export interface CustomerRequestDto {
  firstName?: string;
  lastName?: string;
  phoneNumber?: string;
}

export interface CustomerOptInRequestDto {
  optIn: boolean;
}

/** Address response for BFF APIS */
export interface AddressResponseDto {
  id?: string;
  customerId?: string;
  firstName?: string;
  lastName?: string;
  recipientName?: string;
  address1: string;
  address2: string;
  address3: string;
  address4: string;
  city?: string;
  region?: string;
  zip?: string;
  county?: string;
  country: string;
  latitude?: number;
  longitude?: number;
  state?: string;
  isShippingAddress?: boolean;
  isBillingAddress?: boolean;
  phoneNumber?: string;
}

export interface AddressOrderResponseDto {
  name?: string;
  address?: string;
  city?: string;
  region?: string;
  zip?: string;
  country: string;
  key?: string;
  latitude?: number;
  longitude?: number;
  state?: string;
  phoneNumber?: string;
  pickupPoint?: string;
  isBillingAddress?: boolean;
}
export interface AddressCollectionResponseDto {
  addresses: AddressResponseDto[]
}

export interface GraphQLAddress extends Omit<Address, 'custom'> {
  custom?: GraphQLCustomFields;
}

export interface NormalizedAddress {
  id: string;
  normalizedAddress: string;
  exactMatch: boolean;
}

export interface AutocompleteResponseDto {
  suggestions: NormalizedAddress[],
}

export interface DetailResponseDto {
  firstName?: string;
  lastName?: string;
  recipientName?: string;
  phoneNumber?: string;
  country : string,
  region1 : string,
  region2 : string | null,
  city : string,
  district1 : string,
  district2 : string | null,
  zipCode : string,
  streetName : string,
  houseNumber : string,
  floor : string | null,
  flat : string | null,
  latitude : number,
  longitude : number
}

/**
 * @swagger
 * components:
 *   schemas:
 *     NormalizedAddress:
 *       additionalProperties: false
 *       properties:
 *         id:
 *           type: string
 *         normalizedAddress:
 *           type: string
 *       required:
 *         - id
 *         - normalizedAddress
 *       type: object

 *     AutocompleteResponseDto:
 *       additionalProperties: false
 *       properties:
 *         suggestions:
 *           items:
 *             $ref: '#/components/schemas/NormalizedAddress'
 *           type: array
 *       required:
 *         - suggestions
 *       type: object

 *     DetailResponseDto:
 *       additionalProperties: false
 *       properties:
 *         country:
 *           type: string
 *         region1:
 *           type: string
 *         region2:
 *           type: string
 *         city:
 *           type: string
 *         district1:
 *           type: string
 *         district2:
 *           type: string
 *         zipCode:
 *           type: string
 *         streetName:
 *           type: string
 *         houseNumber:
 *           type: string
 *         floor:
 *           type: string
 *         flat:
 *           type: string
 *         latitude:
 *           type: number
 *         longitude:
 *           type: number
 *       required:
 *         - country
 *         - region1
 *         - region2
 *         - city
 *         - district1
 *         - district2
 *         - zipCode
 *         - streetName
 *         - houseNumber
 *         - floor
 *         - flat
 *         - latitude
 *         - longitude
 *       type: object
*/
