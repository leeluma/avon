import { CustomImage } from '.';
import { AttributesDto } from './product.dto';

export interface CartLineItemDto extends AttributesDto{
  lineItemId: string;
  productId: string;
  productKey?: string;
  name: string;
  skuCode?: string;
  images: CustomImage[];
}

export interface CartResponseDto {
  readonly id:string;
  readonly highlightProduct?: CartLineItemDto;
  readonly itemCount: number;
  readonly totalPrice: number;
  readonly formattedTotalPrice: string;
  readonly currenyCode: string;
  shippingDetail: object;
}

export interface CartDto {
  id: string;
  version: number;
  customerId?: string;
  anonymousId?: string;
}
