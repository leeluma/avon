import { FieldContainer } from '@commercetools/platform-sdk';

export interface CtId {
  id: string;
}

export interface GraphQLTypeResourceIdentifier {
    typeId: 'type';
    id?: string;
    key?: string;
  }

export interface GraphQLCustomFields {
    type: GraphQLTypeResourceIdentifier;
    customFieldsRaw: FieldContainer;
  }

export interface Dimensions {
    width: number
    height: number
  }

export interface Image {
    url: string
    label: string
    dimensions: Dimensions
  }

export interface LocalizedStringDto {
  [locale: string]: string;
}

export interface Id {
  id: string;
}

export interface TrackingClientDto {
  clientId: string;
  isPlatformClient: boolean;
}

/** Common interface to extend from in most other * interfaces */
export interface TrackingFieldsDto {
  createdAt: string;
  createdBy: TrackingClientDto;
  lastModifiedAt: string;
  lastModifiedBy: TrackingClientDto;
}
export type Writable<T> = {
  -readonly [K in keyof T]: T[K];// NOSONAR
  }// NOSONAR
/** Generic response while performing update/create actions */
export interface CustomerActionResponseDto {
  statusCode: number;
  message: string;
  timestamp: string;
}
export interface CommonResponse {
  [x: string]: any | unknown; // NOSONAR
}
export interface MagnoliaInfo {
  url: string;
  isPreview: boolean;
  marketPath: string;
}
/**
 * @swagger
 * components:
 *   schemas:
 *     Dimensions:
 *       additionalProperties: false
 *       properties:
 *         height:
 *           type: number
 *         width:
 *           type: number
 *       required:
 *         - width
 *         - height
 *       type: object
 *     FieldContainer:
 *       type: object
 *     GraphQLCustomFields:
 *       additionalProperties: false
 *       properties:
 *         customFieldsRaw:
 *           $ref: '#/components/schemas/FieldContainer'
 *         type:
 *           $ref: '#/components/schemas/GraphQLTypeResourceIdentifier'
 *       required:
 *         - type
 *         - customFieldsRaw
 *       type: object
 *     GraphQLTypeResourceIdentifier:
 *       additionalProperties: false
 *       properties:
 *         id:
 *           type: string
 *         key:
 *           type: string
 *         typeId:
 *           const: type
 *           type: string
 *       required:
 *         - typeId
 *       type: object
 *     Id:
 *       additionalProperties: false
 *       properties:
 *         id:
 *           type: string
 *       required:
 *         - id
 *       type: object
 *     Image:
 *       additionalProperties: false
 *       properties:
 *         dimensions:
 *           $ref: '#/components/schemas/Dimensions'
 *         label:
 *           type: string
 *         url:
 *           type: string
 *       required:
 *         - url
 *         - label
 *         - dimensions
 *       type: object
 *     LocalizedStringDto:
 *       additionalProperties:
 *         type: string
 *       type: object
 *     TrackingClientDto:
 *       additionalProperties: false
 *       properties:
 *         clientId:
 *           type: string
 *         isPlatformClient:
 *           type: boolean
 *       required:
 *         - clientId
 *         - isPlatformClient
 *       type: object
 *     TrackingFieldsDto:
 *       additionalProperties: false
 *       description: Common interface to extend from in most other * interfaces
 *       properties:
 *         createdAt:
 *           type: string
 *         createdBy:
 *           $ref: '#/components/schemas/TrackingClientDto'
 *         lastModifiedAt:
 *           type: string
 *         lastModifiedBy:
 *           $ref: '#/components/schemas/TrackingClientDto'
 *       required:
 *         - createdAt
 *         - createdBy
 *         - lastModifiedAt
 *         - lastModifiedBy
 *       type: object
 */
