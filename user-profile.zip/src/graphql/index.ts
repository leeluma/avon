import { readFile } from 'fs/promises';

const loadAsync = async (fileName: string): Promise<string> =>
  (await readFile(`${__dirname}/../graphql/${fileName}.graphql`, 'utf-8'))
    .toString();

export const graphql = {
  getCustomerByToken: loadAsync('get-customer-by-token'),
  getCustomerById: loadAsync('get-customer-by-id'),
  getCustomerOrders: loadAsync('get-customer-orders'),
  getCustomerOrderDetails: loadAsync('get-customer-order-details'),
  getProducts: loadAsync('get-products'),
  getShoppingListById: loadAsync('get-shopping-list-by-id'),
  getCustomerCart: loadAsync('get-customer-cart'),
  getActiveCartId: loadAsync('get-customer-active-cart'),
};
