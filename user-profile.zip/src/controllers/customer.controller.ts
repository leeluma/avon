import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { AddressDraft, Customer, CustomerSignin } from '@commercetools/platform-sdk';
import { MarketInfo } from '../middlewares';
import { ApiError, JsonApiResponseEntity } from '../lib';
import { CustomerService } from '../services';
import {
  AddressCollectionResponseDto,
  AddressRequestDto,
  AddressResponseDto,
  CustomerRegistrationRequestDto,
  CustomerResponseDto,
  ChangePasswordRequestDto,
  SetDefaultAddressDto,
  CustomerRequestDto,
  LoginResponseDto,
  CustomerOptInRequestDto,
  CustomerLoginResponseDto,
} from '../dtos';

export interface CustomerControllerConfig {
  customerService: CustomerService;
}

export class CustomerController {
  private readonly customerService: CustomerService;

  constructor(config: CustomerControllerConfig) {
    this.customerService = config.customerService;
  }

  /**
   * Get a Customer by id
   * @param request - Express request object
   * @param response - Express response object
   * @returns Customer if it was found
   * @throws ApiError 404 if Customer was not found
   */
  public async getById(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<CustomerResponseDto>> {
    const market = response.locals.market as MarketInfo;

    const customerId = request.params.id;

    const customer = await this.customerService.getById(market, customerId);

    if (customer === undefined) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, `Customer with id "${customerId}" not found.`);
    }

    return {
      statusCode: HttpStatusCodes.OK,
      body: customer,
    };
  }

  /**
   * Create a customer | Register user
   * @param request - Express request object
   * @param response - Express response object
   * @returns Created customer info
   */
  public async registration(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<CustomerLoginResponseDto>> {
    const market = response.locals.market as MarketInfo;
    const customerRequestDto = request.body as CustomerRegistrationRequestDto;
    const result = await this.customerService.registration(market, customerRequestDto);

    return {
      statusCode: HttpStatusCodes.CREATED,
      body: result,
    };
  }

  /**
   * Get list of Addresses from Commerce Tool using Customer Id
   * @param request - Express request object
   * @param response - Express response object
   * @returns Customer Id with list of Addresses if it was found
   * @throws ApiError 404 if Customer id was not found
   */
  public async getAddress(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<AddressResponseDto[]>> {
    const market = response.locals.market as MarketInfo;
    const customer = response.locals.customer as Customer;
    const { id: customerId } = customer;
    const address = await this.customerService.getAddress(market, customerId);
    if (address === undefined) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, `Address with customer id "${customerId}" not found.`);
    }

    return {
      statusCode: HttpStatusCodes.OK,
      body: address,
    };
  }

  /**
   * Add Address from Commerce Tool using Customer Id
   * @param req - Express request object
   * @param res - Express response object
   * @returns Added Address info for the given Customer Id
   */
  public async addAddress(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<AddressCollectionResponseDto>> {
    const addressRequestDto: AddressRequestDto = req.body;
    const market = res.locals.market as MarketInfo;
    const customer = res.locals.customer as Customer;
    const { id: customerId } = customer;
    const response = await this.customerService.addAddress(market, customerId, addressRequestDto);

    return {
      statusCode: HttpStatusCodes.CREATED,
      body: response,
    };
  }

  /**
   * Update Address from Commerce Tool using Customer Id and Address Id
   * @param request - Express request object
   * @param response - Express response object
   * @returns Updated Address info for the given Customer Id and Address Id
   */
  public async updateAddress(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<AddressResponseDto[] | undefined>> {
    const addressRequestDto: AddressRequestDto = request.body;
    const market = response.locals.market as MarketInfo;
    const { addressId } = request.params;
    const customer = response.locals.customer as Customer;
    const { id: customerId } = customer;

    const customerResponse = await this.customerService.updateAddress(market, customerId, addressId, addressRequestDto);

    return {
      statusCode: HttpStatusCodes.ACCEPTED,
      body: customerResponse,
    };
  }

  /**
   * Update Customer Password from Commerce tool using Customer Id
   * @param request - Express request object
   * @param response - Express response object
   * @returns Status code with message
   */
  public async changePassword(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<undefined>> {
    const market = response.locals.market as MarketInfo;
    const customer = response.locals.customer as Customer;
    const changePasswordRequestDto = request.body as ChangePasswordRequestDto;
    const authHeader = (request.headers.authorization || '');
    await this.customerService
      .changePassword(market, changePasswordRequestDto, authHeader, customer);
    return {
      statusCode: HttpStatusCodes.ACCEPTED,
      body: undefined,
    };
  }

  /**
   * Reset Customer's password by Token
   * @param request - Express request object
   * @param response - Express response object
   */
  public async resetCustomersPassword(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<undefined>> {
    const market = response.locals.market as MarketInfo;
    const { token, newPassword } = request.body;

    await this.customerService.resetCustomersPassword(market, token, newPassword);

    return {
      statusCode: HttpStatusCodes.ACCEPTED,
      body: undefined,
    };
  }

  /**
   * Delete Address from Commerce Tool using Customer Id and Address Id
   * @param request - Express request object
   * @param response - Express response object
   * @returns Deleted Address for the given Customer Id and Address Ids
   */
  public async deleteAddress(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<AddressDraft[]>> {
    const market = response.locals.market as MarketInfo;
    const { addressId } = request.params;
    const customer = response.locals.customer as Customer;
    const { id: customerId } = customer;

    const output = await this.customerService.deleteAddress(market, customerId, addressId);

    return {
      statusCode: HttpStatusCodes.ACCEPTED,
      body: output,
    };
  }

  /**
   * Reset Customer's password by Token
   * @param request - Express request object
   * @param response - Express response object
   */
  public async forgotCustomersPassword(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<undefined>> {
    const market = response.locals.market as MarketInfo;
    const { email, url } = request.body;

    await this.customerService.forgotCustomersPassword(market, email, url);

    return {
      statusCode: HttpStatusCodes.ACCEPTED,
      msg: i18next.t('success.forgotPassword'),
      body: undefined,
    };
  }

  /**
   * Set default customer's address by addressId
   * @param request - Express request object
   * @param response - Express response object
   * @returns 202 as response.
   */
  public async defaultAddress(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<undefined>> {
    const market = response.locals.market as MarketInfo;
    const { addressId } = request.params;
    const { customer: { version } } = response.locals;
    let { isBilling, isDelivery } = request.body;
    const authHeader = (request.headers.authorization || '');
    isBilling = !!isBilling;
    isDelivery = !!isDelivery;

    const params: SetDefaultAddressDto = {
      isBilling,
      isDelivery,
      addressId,
      version,
    };
    await this.customerService.defaultAddress(market, params, authHeader);

    return {
      statusCode: HttpStatusCodes.ACCEPTED,
      body: undefined,
    };
  }

  /**
   * Get customer details based on token from Commerce Tool
   * @param request - Express request object
   * @param response - Express response object
   * @returns Customer details
   * @throws ApiError 404 if Customer id was not found
   */
  public async getCustomerByToken(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<CustomerResponseDto>> {
    const market = response.locals.market as MarketInfo;
    const authHeader: string = request.headers.authorization!;
    const customer = await this.customerService.getCustomerDetailsByToken(market, authHeader);
    if (!customer) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.customerNotFound'));
    }

    return {
      statusCode: HttpStatusCodes.OK,
      body: customer,
    };
  }

  /**
   * Update Customer from Commerce Tool
   * @param request - Express request object
   * @param response - Express response object
   * @returns Updated Customer info for the given Customer
   */
  public async updateMyCustomer(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<CustomerResponseDto | undefined>> {
    const customerRequestDto: CustomerRequestDto = request.body;
    const market = response.locals.market as MarketInfo;
    const authHeader: string = request.headers.authorization!;

    const customerResponse = await this.customerService.updateMyCustomer(
      market,
      response.locals.customer,
      authHeader,
      customerRequestDto,
    );

    return {
      statusCode: HttpStatusCodes.ACCEPTED,
      body: customerResponse,
    };
  }

  /**
   * Get list of Addresses from CT using Customer Id
   * @param request - Express request object
   * @param response - Express response object
   * @returns Customer login token if it was found
   * @throws ApiError 404 if Customer was not found
   */
  public async login(
    request: Request,
    response: Response,
  ): Promise<LoginResponseDto> {
    const market = response.locals.market as MarketInfo;
    const loginReqDto = request.body as CustomerSignin;
    const output = await this.customerService.login(market, loginReqDto);
    return {
      statusCode: HttpStatusCodes.OK,
      body: output,
    };
  }

  /**
   * Update Customer optIn value
   * @param request - Express request object
   * @param response - Express response object
   * @returns Updated Customer info for the given Customer
   */
  public async updateCustomerOptIn(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<CustomerResponseDto | undefined>> {
    const optIn: CustomerOptInRequestDto = request.body;
    const market = response.locals.market as MarketInfo;
    const authHeader: string = request.headers.authorization!;

    const customerResponse = await this.customerService.updateCustomerOptIn(
      market,
      response.locals.customer,
      authHeader,
      optIn,
    );

    return {
      statusCode: HttpStatusCodes.ACCEPTED,
      body: customerResponse,
    };
  }
}
