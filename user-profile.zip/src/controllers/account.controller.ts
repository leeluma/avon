import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { MagnoliaService } from '../services/magnolia.service';
import { MarketInfo } from '../middlewares';
import { JsonApiResponseEntity } from '../lib';
import { CommonResponse, MagnoliaInfo } from '../dtos';

interface AccountControllerConfig {
  magnoliaService: MagnoliaService;
}

/**
 * `AccountController` representing `account`
 */
export class AccountController {
  private readonly magnoliaService: MagnoliaService;

  /**
   * Constructor for `AccountController` class
   * @param config injects dependencies into the object
   */
  constructor(config: AccountControllerConfig) {
    this.magnoliaService = config.magnoliaService;
  }

  /**
   * Get Account magnolia data
   * @param req - Express request object
   * @param res - Express response object
   * @returns Promise
   */
  public async getAccountPageData(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<CommonResponse>> {
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;
    const [globalSettings, staticPageData] = await Promise.all([
      this.magnoliaService.getGlobalSettingsData(market, magnolia),
      this.magnoliaService.getAccountPageData(market, magnolia),
    ]);
    let magnoliaTemplateData = {};
    if (magnolia.isPreview) {
      magnoliaTemplateData = await this.magnoliaService.getTemplateData(staticPageData['mgnl:template'], magnolia.url);
    }
    const responseData = {
      ...staticPageData,
      globalSettings,
      templateDefinition: magnoliaTemplateData,
    };
    return {
      statusCode: HttpStatusCodes.OK,
      body: responseData,
    };
  }
}
