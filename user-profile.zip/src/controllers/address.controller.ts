import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { JsonApiResponseEntity } from '../lib';
import { AddressService } from '../services';
import { AutocompleteResponseDto, DetailResponseDto } from '../dtos';
import { MarketInfo } from '../middlewares';

export interface AddressControllerConfig {
  addressService: AddressService;
}

export class AddressController {
  private readonly addressService: AddressService;

  constructor(config: AddressControllerConfig) {
    this.addressService = config.addressService;
  }

  /**
   * Get Address Autocomplete (Finder) API
   * @param request - Express request object
   */
  public async addressAutocomplete(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<AutocompleteResponseDto>> {
    const market = response.locals.market as MarketInfo;
    const { address } = request.query;
    const autocomplete = await this.addressService.addressAutocomplete(market, address as string | undefined);
    return {
      statusCode: HttpStatusCodes.OK,
      body: {
        suggestions: autocomplete,
      },
    };
  }

  /**
   * Get Address Detail API
   * @param request - Express request object
   */
  public async addressDetail(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<DetailResponseDto>> {
    const { addressId } = request.query;
    const market = response.locals.market as MarketInfo;
    const detail = await this.addressService.addressDetail(market, addressId as string);
    return {
      statusCode: HttpStatusCodes.OK,
      body: detail,
    };
  }
}
