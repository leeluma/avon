import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { ShoppingListService } from '../services';
import { MarketInfo } from '../middlewares';
import { ApiError, JsonApiResponseEntity } from '../lib';
import { WishlistDto, WishlistMoveToCartResponseDto } from '../dtos/shopping-list.dto';
import { CommonResponse, MagnoliaInfo } from '../dtos';

export interface ShoppingListControllerConfig {
    shoppingListService: ShoppingListService;
}

/**
 * `ShoppingListController` representing `Shopping List`
 */
export class ShoppingListController {
  private readonly shoppingListService: ShoppingListService;

  /**
   * Constructor for `ShoppingListController` class
   * @param config injects dependencies into the object
   */
  constructor(config: ShoppingListControllerConfig) {
    this.shoppingListService = config.shoppingListService;
  }

  /**
   * Move all `LineItem`s from `Wishlist` to `Cart`
   * @param request - Express request object
   * @param response - Express response object
   * @returns Promise
   */
  public async moveAllLineItemsToCart(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<WishlistMoveToCartResponseDto>> {
    /* Parse request */
    const market = response.locals.market as MarketInfo;

    const { id } = request.params;
    const { cartId } = request.body;

    /* Call service */
    const result = await this.shoppingListService.moveAllLineItemsToCart(market, id, cartId);

    /* Respond */
    return {
      statusCode: HttpStatusCodes.OK,
      body: result,
    };
  }

  /**
   * Moves one `LineItem` from `Wishlist` to `Cart`
   * @param request - Express request object
   * @param response - Express response object
   * @returns Promise
   */
  public async moveOneLineItemToCart(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<WishlistMoveToCartResponseDto>> {
    /* Parse request */
    const market = response.locals.market as MarketInfo;

    const { id, lineItemId } = request.params;
    const { cartId } = request.body;

    /* Call service */
    const wishlist = await this.shoppingListService.moveOneLineItemToCart(market, id, lineItemId, cartId);

    /* Respond */
    return {
      statusCode: HttpStatusCodes.OK,
      body: wishlist,
    };
  }

  /**
   * Get a Wishlist by id
   * @param request - Express request object
   * @param response - Express response object
   * @returns Wishlist if it was found
   * @throws ApiError 404 if Wishlist was not found
   */
  public async getById(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<CommonResponse>> {
    const market = response.locals.market as MarketInfo;
    const magnolia = response.locals.magnolia as MagnoliaInfo;
    const isPage: boolean = request.headers.ispage === 'false';

    const wishlistId = request.params.id;
    const params = { isPage, wishlistId };

    const wishlist = await this.shoppingListService.getById(market, params, magnolia);

    if (wishlist === undefined) {
      throw new ApiError(
        HttpStatusCodes.NOT_FOUND,
        `Wishlist with id "${wishlistId}" not found.`,
      );
    }

    return {
      statusCode: HttpStatusCodes.OK,
      body: wishlist,
    };
  }

  /**
   * Deletes Line Item from Wishlist
   * @param req - Express request object
   * @param res - Express response object
   * @returns Promise
   */
  public async deleteLineItem(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<WishlistDto>> {
    /* Parse request */
    const market = res.locals.market as MarketInfo;

    const { id, lineItemId } = req.params;

    /* Call service */
    const wishlist = await this.shoppingListService.deleteLineItem(market, id, lineItemId);

    /* Respond */
    return {
      statusCode: HttpStatusCodes.OK,
      body: wishlist,
    };
  }
}
