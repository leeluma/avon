import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { config } from '../config';
import { OrderService } from '../services';
import { MarketInfo } from '../middlewares';
import { ApiError, JsonApiResponseEntity } from '../lib';
import {
  GetMyOrdersDraftDto, OrderDto, MyOrdersListResponse,
} from '../dtos';

export interface OrderControllerConfig {
  orderService: OrderService;
}

export class OrderController {
  private readonly orderService: OrderService;

  constructor(conf: OrderControllerConfig) {
    this.orderService = conf.orderService;
  }

  /**
   * Get all Order
   * @param request - Express request object
   * @param response - Express response object
   * @returns Order Object Response
   * @throws ApiError 404 if Orders not found
   */
  public async getAll(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<MyOrdersListResponse>> {
    const market = response.locals.market as MarketInfo;
    const authHeader: string = request.headers.authorization!;
    const page = Number(request.query.page) || config.ctPage;
    const sort = request.query.sort as string || config.ctSort;

    const params:GetMyOrdersDraftDto = {
      page,
      sort,
      limit: config.ctLimit,
    };
    const order = await this.orderService.getAll(market, authHeader, params);
    if (!order) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, 'Orders not found.');
    }
    return {
      statusCode: HttpStatusCodes.OK,
      body: order,
    };
  }

  /**
   * Get a Order by id
   * @param request - Express request object
   * @param response - Express response object
   * @returns Order Object Response
   * @throws ApiError 404 if Orders was not found
   */
  public async getOrderDetails(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<OrderDto>> {
    const market = response.locals.market as MarketInfo;
    const { orderId } = request.params;
    const authHeader: string = request.headers.authorization!;
    const orderDetail = await this.orderService.orderDetails(market, authHeader, orderId);
    if (!orderDetail) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, 'Order not found.');
    }
    return {
      statusCode: HttpStatusCodes.OK,
      body: orderDetail,
    };
  }
}
