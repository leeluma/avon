import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { DefaultService } from '../services';
import { MarketInfo } from '../middlewares';
import {
  CommonResponse,
} from '../dtos';
import { JsonApiResponseEntity } from '../lib';

export interface DefaultControllerConfig {
  defaultService: DefaultService;
}

export class DefaultController {
  private readonly defaultService: DefaultService;

  constructor(config: DefaultControllerConfig) {
    this.defaultService = config.defaultService;
  }

  /**
   * Refresh token
   * @param request - Express request object
   * @param response - Express response object
   */
  public async refreshToken(
    request: Request,
    response: Response,
  ):Promise<JsonApiResponseEntity<CommonResponse>> {
    const market = response.locals.market as MarketInfo;
    const { refreshtoken } = request.headers;
    const refreshTokenResult = await this.defaultService.refreshToken(market, refreshtoken);

    return {
      statusCode: HttpStatusCodes.OK,
      body: refreshTokenResult,
    };
  }

  /**
   * verify token
   * @param request - Express request object
   * @param response - Express response object
   */
  public async verifyToken(
    request: Request,
    response: Response,
  ):Promise<JsonApiResponseEntity<undefined>> {
    const market = response.locals.market as MarketInfo;
    const { token } = request.body;
    await this.defaultService.verifyToken(market, token);

    return {
      statusCode: HttpStatusCodes.OK,
      body: undefined,
    };
  }

  /**
   * Logout
   * @param request - Express request object
   */
  public async logout(
    request: Request,
  ):Promise<JsonApiResponseEntity<boolean>> {
    const authHeader = request.headers?.authorization;
    const token = authHeader?.replace('Bearer ', '');
    const logoutResult = await this.defaultService.logout(token);

    return {
      statusCode: HttpStatusCodes.OK,
      body: logoutResult,
    };
  }
}
