import { RequestHandler, Router } from 'express';
import { validateRequestSchema } from '../middlewares';
import { DefaultController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import {
  validateRefreshToken, validateVerifyToken, validateAuthorizeToken,
} from '../validators';

export interface DefaultRouterConfig {
  defaultController: DefaultController;
  Router: typeof Router;
  validationSettingsMiddleware: RequestHandler;
}

/**
 * `DefaultRouter` for all the routes related to `/`
 */

export class DefaultRouter {
  private readonly defaultController: DefaultController;

  private readonly Router: typeof Router;

  private readonly validationSettingsMiddleware: RequestHandler;

  /**
   * Constructor for `DefaultRouter` class
   * @param config injects dependencies into the object
   */

  constructor(config: DefaultRouterConfig) {
    this.defaultController = config.defaultController;
    this.Router = config.Router;
    this.validationSettingsMiddleware = config.validationSettingsMiddleware;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();
    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/refresh-token:
     *   post:
     *     summary: Fetch refresh token
     *     tags: [Default]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: headers
     *         name: refreshToken
     *         schema:
     *            type: string
     *            default: '*****'
     *            required: true
     *     responses:
     *       200:
     *         description: Get refresh token
     *       404:
     *         description: refresh token not found
     */

    router.post(
      '/refresh-token',
      validateRefreshToken,
      validateRequestSchema,
      wrapJsonApiController(
        this.defaultController.refreshToken.bind(this.defaultController),
      ),
    );

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/verify-token:
     *   post:
     *     summary: Verify password token
     *     tags: [Default]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: headers
     *         name: token
     *         schema:
     *            type: string
     *            default: '*****'
     *            required: true
     *     responses:
     *       200:
     *         description: verify password token
     *       404:
     *         description: password token not found
     */
    router.post(
      '/verify-token',
      validateVerifyToken,
      validateRequestSchema,
      wrapJsonApiController(
        this.defaultController.verifyToken.bind(this.defaultController),
      ),
    );

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/logout:
     *   post:
     *     summary: Logout as current session
     *     tags: [Default]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       200:
     *         description: logout as current session
     *       404:
     *         description: logout not found
     */
    router.post(
      '/logout',
      validateAuthorizeToken,
      validateRequestSchema,
      wrapJsonApiController(
        this.defaultController.logout.bind(this.defaultController),
      ),
    );
    return router;
  }
}
