import { Router } from 'express';
import { validateRequestSchema } from '../middlewares';
import { AddressController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import { validateAddresses, validateAddressFinderId } from '../validators';

export interface AddressRouterConfig {
  addressController: AddressController;
  Router: typeof Router;
}

/**
 * `AddressRouter` for all the routes related to `/addresses`
 */

export class AddressRouter {
  private readonly addressController: AddressController;

  private readonly Router: typeof Router;

  /**
     * Constructor for `AddressRouter` class
     * @param config injects dependencies into the object
     */

  constructor(config: AddressRouterConfig) {
    this.addressController = config.addressController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
       * @swagger
       * /user-profile/v1/{language}-{market}/addresses/autocomplete:
       *   get:
       *     summary: Address autocomplete (finder) API.
       *     tags: [Addresses]
       *     parameters:
       *       - in: path
       *         name: language
       *         schema:
       *            type: string
       *            default: ro
       *         required: true
       *       - in: path
       *         name: market
       *         schema:
       *            type: string
       *            default: RO
       *         required: true
       *       - in: query
       *         name: address
       *         schema:
       *            type: string
       *         required: true
       *     responses:
       *       200:
       *         description: Successful Operation
       *         content:
       *           application/json:
       *             schema:
       *               $ref: '#/components/schemas/AutocompleteResponseDto'
       */
    router.get(
      '/autocomplete',
      validateAddresses,
      validateRequestSchema,
      wrapJsonApiController(
        this.addressController.addressAutocomplete.bind(this.addressController),
      ),
    );

    /**
       * @swagger
       * /user-profile/v1/{language}-{market}/addresses/detail:
       *   get:
       *     summary: Address detail API.
       *     tags: [Addresses]
       *     parameters:
       *       - in: path
       *         name: language
       *         schema:
       *            type: string
       *            default: ro
       *         required: true
       *       - in: path
       *         name: market
       *         schema:
       *            type: string
       *            default: RO
       *         required: true
       *       - in: query
       *         name: addressId
       *         schema:
       *            type: string
       *         required: true
       *     responses:
       *       200:
       *         description: Successful Operation
       *         content:
       *           application/json:
       *             schema:
       *               $ref: '#/components/schemas/DetailResponseDto'
       */
    router.get(
      '/detail',
      validateAddressFinderId,
      validateRequestSchema,
      wrapJsonApiController(
        this.addressController.addressDetail.bind(this.addressController),
      ),
    );

    return router;
  }
}
