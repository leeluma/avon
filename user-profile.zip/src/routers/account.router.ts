import { Router } from 'express';
import { AccountController } from '../controllers/account.controller';
import { wrapJsonApiController } from '../lib';
import { validateRequestSchema, magnoliaUrlMiddleware } from '../middlewares';

interface AccountRouterConfig {
  accountController: AccountController;
  Router: typeof Router;
}

/**
 * `AccountRouter` for all the routes related to `/account`
 */
export class AccountRouter {
  private readonly accountController: AccountController;

  private readonly Router: typeof Router;

  constructor(config: AccountRouterConfig) {
    this.accountController = config.accountController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * /user-profile/v1/{language}-{market}/:
     *   get:
     *     summary: Get the account magnolia page data for particular language and market
     *     operationId: getAccountPageData
     *     tags: [Account]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *           type: string
     *         required: true
     *         description: The language
     *         example: ro
     *       - in: path
     *         name: market
     *         schema:
     *           type: string
     *         required: true
     *         description: The market
     *         example: Ro
     *       - in: query
     *         name: isPreview
     *         enum: [true, false]
     *         default: false
     *         description: The preview
     *         required: false
     *     responses:
     *       200:
     *         description: account response
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/HttpResponseProductsDto'
     *       500:
     *         description: account data not found
     */
    router.get(
      '/',
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.accountController.getAccountPageData.bind(this.accountController),
      ),
    );

    return router;
  }
}
