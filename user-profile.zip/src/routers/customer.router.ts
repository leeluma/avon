import { RequestHandler, Router } from 'express';
import { body } from 'express-validator';
import { validateRequestSchema } from '../middlewares';
import { CustomerController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import {
  fieldValidator,
  defaultAddress,
  validateAddressId,
  validateId, validateBearerToken,
} from '../validators';

export interface CustomerRouterConfig {
  customerController: CustomerController;
  Router: typeof Router;
  validationSettingsMiddleware: RequestHandler;
  addressValidationSettingsMiddleware: RequestHandler;
  authMiddleware: RequestHandler;
}

/**
 * `CustomerRouter` for all the routes related to `/customer`
 */
export class CustomerRouter {
  private readonly customerController: CustomerController;

  private readonly Router: typeof Router;

  private readonly validationSettingsMiddleware: RequestHandler;

  private readonly addressValidationSettingsMiddleware: RequestHandler;

  private readonly authMiddleware: RequestHandler;

  constructor(config: CustomerRouterConfig) {
    this.customerController = config.customerController;
    this.Router = config.Router;
    this.validationSettingsMiddleware = config.validationSettingsMiddleware;
    this.addressValidationSettingsMiddleware = config.addressValidationSettingsMiddleware;
    this.authMiddleware = config.authMiddleware;
  }

  public buildExpressRouter(): Router { // NOSONAR
    const router = this.Router();

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/customers/address:
     *   get:
     *     summary: Get list of Addresses by Customer
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       200:
     *         description: Details of addresses by customer
     *       404:
     *         description: Customer Id not found.
     */
    router.get(
      '/address', // NOSONAR
      validateRequestSchema,
      this.authMiddleware,
      wrapJsonApiController(
        this.customerController.getAddress.bind(this.customerController),
      ),
    );

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/customers/{id}:
     *   get:
     *     summary: Get customer by id
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: path
     *         name: id
     *         schema:
     *            type: string
     *         required: true
     *     responses:
     *       200:
     *         description: Details of customer by customer ID
     *       404:
     *         description: Customer not found.
     */
    router.get(
      '/:id',
      validateId,
      validateRequestSchema,
      wrapJsonApiController(
        this.customerController.getById.bind(this.customerController),
      ),
    );

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/customers/registration:
     *   post:
     *     summary: Register a customer
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *      description: Valid fields
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/CustomerUpdateRequestDto'
     *     responses:
     *       201:
     *         description: Creates a Default Customer for Customer
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerResponseDto'
     *       404:
     *         description: Something went wrong.
     */
    router.post(
      '/registration',
      this.validationSettingsMiddleware,
      [
        fieldValidator('email'),
        fieldValidator('firstName'),
        fieldValidator('lastName'),
        fieldValidator('password'),
        fieldValidator('confirmPassword'),
      ],
      body('cartId').optional().isUUID().withMessage('datatype.uuid'), // NOSONAR
      validateRequestSchema,
      wrapJsonApiController(
        this.customerController.registration.bind(this.customerController),
      ),
    );

    /**
     * @swagger
     * components:
     *   schemas:
     *     CustomerAddressRequestDto:
     *       type: object
     *       required:
     *         - address1
     *         - city
     *         - zip
     *         - country
     *         - phoneNumber
     *       properties:
     *         address1:
     *           type: string
     *           description: The address1 of customer is required
     *         address2:
     *           type: string
     *           description: The address2 of customer
     *         address3:
     *           type: string
     *           description: The address3 of customer
     *         address4:
     *           type: string
     *           description: The address4 of customer
     *         city:
     *           type: string
     *           description: The city of customer is required
     *         zip:
     *           type: string
     *           description: The zip of customer is required
     *         country:
     *           type: string
     *           description: The country of customer is required
     *         region:
     *           type: string
     *           description: The region of customer
     *         county:
     *           type: string
     *           description: The county of customer
     *         latitude:
     *           type: number
     *           description: The latitude of customer
     *         longitude:
     *           type: number
     *           description: The longitude of customer
     *         state:
     *           type: string
     *           description: The state of customer is required
     *         isShippingAddress:
     *           type: boolean
     *           description: If this address is shipping address
     *         isBillingAddress:
     *           type: boolean
     *           description: If this address is billing address
     *         phoneNumber:
     *           type: string
     *           description: The phoneNumber of customer is required
     *       example:
     *         address1: "DRUM. TABEREI"
     *         address2: "nr. 22 bl. T8 sc. 1 et 5 ap. 71"
     *         address3: "BUCHAREST"
     *         address4: "DISTRICT 6, 061385"
     *         city: "Bucharest"
     *         region: "Bucharest"
     *         zip: "061385"
     *         county: "Bucharest County"
     *         country: "RO"
     *         latitude: 45.9432
     *         longitude: 24.9668
     *         state: "BUCHAREST"
     *         phoneNumber: "1122334455"
     *         isShippingAddress: true
     *         isBillingAddress: true
     *     CustomerAddressUpdateRequestDto:
     *       type: object
     *       required:
     *       properties:
     *         address1:
     *           type: string
     *           description: The address1 of customer is required
     *         address2:
     *           type: string
     *           description: The address2 of customer
     *         address3:
     *           type: string
     *           description: The address3 of customer
     *         address4:
     *           type: string
     *           description: The address4 of customer
     *         city:
     *           type: string
     *           description: The city of customer is required
     *         zip:
     *           type: string
     *           description: The zip of customer is required
     *         country:
     *           type: string
     *           description: The country of customer is required
     *         region:
     *           type: string
     *           description: The region of customer
     *         county:
     *           type: string
     *           description: The county of customer
     *         latitude:
     *           type: number
     *           description: The latitude of customer
     *         longitude:
     *           type: number
     *           description: The longitude of customer
     *         state:
     *           type: string
     *           description: The state of customer is required
     *         isShippingAddress:
     *           type: boolean
     *           description: If this address is shipping address
     *         isBillingAddress:
     *           type: boolean
     *           description: If this address is billing address
     *         phoneNumber:
     *           type: string
     *           description: The phoneNumber of customer is required
     *       example:
     *         address1: "DRUM. TABEREI"
     *         address2: "nr. 22 bl. T8 sc. 1 et 5 ap. 71"
     *         address3: "BUCHAREST"
     *         address4: "DISTRICT 6, 061385"
     *         city: "Bucharest"
     *         region: "Bucharest"
     *         zip: "061385"
     *         county: "Bucharest County"
     *         country: "RO"
     *         latitude: 45.9432
     *         longitude: 24.9668
     *         state: "BUCHAREST"
     *         phoneNumber: "1122334455"
     *         isShippingAddress: true
     *         isBillingAddress: true
     */
    /**
   * @swagger
   * /user-profile/v1/{locale}-{country}/customers/address:
   *   post:
   *     summary: Add customer's address
   *     tags: [Customers]
   *     parameters:
   *       - in: path
   *         name: locale
   *         schema:
   *            type: string
   *            default: ro
   *         required: true
   *       - in: path
   *         name: country
   *         schema:
   *            type: string
   *            default: RO
   *         required: true
   *     security:
   *      - bearerAuth: []
   *     requestBody:
   *      description: Valid fields
   *      required: true
   *      content:
   *        application/json:
   *          schema:
   *            $ref: '#/components/schemas/CustomerAddressRequestDto'
   *     responses:
   *       201:
   *         description: Add customer's address
   *         content:
   *           application/json:
   *             schema:
   *               $ref: '#/components/schemas/CustomerAddressRequestDto'
   *       400:
   *         description: Bad Request.
   *       404:
   *         description: Something went wrong.
   */
    router
      .post(
        '/address', // NOSONAR
        this.addressValidationSettingsMiddleware,
        [
          fieldValidator('firstName'),
          fieldValidator('lastName'),
          fieldValidator('address1'),
          fieldValidator('address2'),
          fieldValidator('phoneNumber'),
          fieldValidator('city'),
          fieldValidator('zip'),
        ],
        body('latitude').optional().isFloat({ min: 0, max: 360 }).withMessage('customer.latitude'), // NOSONAR
        body('longitude').optional().isFloat({ min: 0, max: 360 }).withMessage('customer.longitude'), // NOSONAR
        body('isBillingAddress').optional().isBoolean({ strict: true })
          .withMessage('customer.isBillingAddress'), // NOSONAR
        validateRequestSchema,
        this.authMiddleware,
        wrapJsonApiController(
          this.customerController.addAddress.bind(this.customerController),
        ),
      );

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/customers/address/{addressId}:
     *   put:
     *     summary: Update customer's address
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: path
     *         name: addressId
     *         schema:
     *            type: string
     *         required: true
     *     security:
     *      - bearerAuth: []
     *     requestBody:
     *      description: Valid fields
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/CustomerAddressUpdateRequestDto'
     *     responses:
     *       201:
     *         description: Update customer's address
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerAddressUpdateRequestDto'
     *       400:
     *         description: Bad Request.
     *       404:
     *         description: Something went wrong.
     */
    router
      .put(
        '/address/:addressId', // NOSONAR
        validateAddressId,
        this.addressValidationSettingsMiddleware,
        fieldValidator('firstName'),
        fieldValidator('lastName'),
        fieldValidator('address1'),
        fieldValidator('address2'),
        fieldValidator('phoneNumber'),
        fieldValidator('city'),
        fieldValidator('zip'),
        body('latitude').optional().isFloat({ min: 0, max: 360 }).withMessage('customer.latitude'),
        body('longitude').optional().isFloat({ min: 0, max: 360 }).withMessage('customer.longitude'),
        body('isBillingAddress').optional().isBoolean({ strict: true })
          .withMessage('customer.isBillingAddress'), // NOSONAR
        validateRequestSchema,
        this.authMiddleware,
        wrapJsonApiController(
          this.customerController.updateAddress.bind(this.customerController),
        ),
      );
    /**
   * @swagger
   * components:
   *   securitySchemes:
   *     bearerAuth:
   *       type: http
   *       scheme: bearer
   */
    /** @swagger
     * /user-profile/v1/{locale}-{country}/customers/reset-password:
     *   post:
     *     summary: Reset customer's password
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *      description: Verification token and new password
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            type: object
     *            properties:
     *              token:
     *                type: string
     *              newPassword:
     *                type: string
     *     responses:
     *       202:
     *         description: Password was updated successfully
     *       401:
     *         description: The token was invalid.
     *       500:
     *         description: Something went wrong.
     */
    router
      .post(
        '/reset-password',
        body('token').notEmpty().isLength({ min: 40, max: 40 }).withMessage('token'),
        body('newPassword').notEmpty().isLength({ min: 6, max: 18 }).withMessage('internet.password'),
        validateRequestSchema,
        wrapJsonApiController(
          this.customerController.resetCustomersPassword.bind(this.customerController),
        ),
      );

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/customers/change-password:
     *   post:
     *     summary: Change customer's password
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *      description: Valid fields
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/ChangePasswordRequestDto'
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       202:
     *         description: Password was changed successfully
     *       401:
     *         description: The token was invalid.
     *       500:
     *         description: Something went wrong.
     */
    router
      .post(
        '/change-password',
        this.validationSettingsMiddleware,
        [
          fieldValidator('currentPassword'),
          fieldValidator('newPassword'),
        ],
        validateRequestSchema,
        this.authMiddleware,
        wrapJsonApiController(
          this.customerController.changePassword.bind(this.customerController),
        ),
      );

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/customers/address/{addressId}:
     *   delete:
     *     summary: Delete customer's address
     *     tags: [Delete Customer Address]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: path
     *         name: addressId
     *         schema:
     *            type: string
     *         required: true
     *     security:
     *      - bearerAuth: []
     *     content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/CustomerAddressRequestDto'
     *     responses:
     *       201:
     *         description: Delete customer's address
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerAddressRequestDto'
     *       404:
     *         description: Something went wrong.
     */
    router.delete(
      '/address/:addressId', // NOSONAR
      validateRequestSchema,
      this.authMiddleware,
      validateAddressId,
      validateRequestSchema,
      this.authMiddleware,
      wrapJsonApiController(
        this.customerController.deleteAddress.bind(this.customerController),
      ),
    );

    /** @swagger
     * /header/v1/{locale}-{country}/customers/forgot-password:
     *   post:
     *     summary: forgot customer's password
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *      description: return token based on email
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            type: object
     *            properties:
     *              email:
     *                type: string
     *                default: example@avon.com
     *                required: true
     *              url:
     *                type: string
     *                default: http://avon.com
     *                required: true
     *     responses:
     *       202:
     *         description: Password was updated successfully
     *       401:
     *         description: The token was invalid.
     *       500:
     *         description: Something went wrong.
     */
    router
      .post(
        '/forgot-password',
        body('email').notEmpty().isEmail().withMessage('internet.email'),
        body('url').notEmpty().isURL().withMessage('internet.url'),
        validateRequestSchema,
        wrapJsonApiController(
          this.customerController.forgotCustomersPassword.bind(this.customerController),
        ),
      );
    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/customers/default-address/{addressId}:
     *   post:
     *     summary: set default user's address
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: path
     *         name: addressId
     *         schema:
     *            type: string
     *         required: true
     *     requestBody:
     *      description: add default delivery/billing address
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            type: object
     *            properties:
     *              isBilling:
     *                type: boolean
     *                required: true
     *              isDelivery:
     *                type: boolean
     *                required: false
     *     content:
     *        application/json:
     *            schema:
     *            $ref: '#/components/schemas/SetDefaultAddressRequestDto'
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       202:
     *         description: Delete customer's address
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/SetDefaultAddressResponseDto'
     *       404:
     *         description: Something went wrong.
     */
    router.post(
      '/default-address/:addressId',
      this.authMiddleware,
      defaultAddress,
      validateRequestSchema,
      wrapJsonApiController(
        this.customerController.defaultAddress.bind(this.customerController),
      ),
    );
    /*
  * @swagger
  * components:
  *   securitySchemes:
  *     bearerAuth:
  *       type: http
  *       scheme: bearer
  */
    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/customers:
     *   get:
     *     summary: Get customer based on token
     *     tags: [Customer Details]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       200:
     *         description: Get a customer details based on token
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerAddressRequestDto'
     *       500:
     *         description: Something went wrong.
     */
    router.get(
      '/',
      validateBearerToken,
      validateRequestSchema,
      wrapJsonApiController(
        this.customerController.getCustomerByToken.bind(this.customerController),
      ),
    );

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/customers/update:
     *   post:
     *     summary: update customer information
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *      description: update customer information
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            type: object
     *            properties:
     *              firstName:
     *                type: string
     *                required: false
     *                default: Jhon
     *              lastName:
     *                type: string
     *                default: Doe
     *                required: false
     *              phoneNumber:
     *                type: string
     *                default: 9030609070
     *                required: false
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       202:
     *         description: Updated Customer
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerResponseDto'
     *       404:
     *         description: Something went wrong.
     */
    router.post(
      '/update',
      this.authMiddleware,
      this.validationSettingsMiddleware,
      [
        fieldValidator('firstName'),
        fieldValidator('lastName'),
        fieldValidator('phoneNumber'),
      ],
      validateRequestSchema,
      wrapJsonApiController(
        this.customerController.updateMyCustomer.bind(this.customerController),
      ),
    );
    /**
     * @swagger
     * /user-profile/v1/{language}-{market}/customers/login:
     *   post:
     *     summary: Customer login
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: market
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *      description: Valid fields
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/LoginReqDto'
     *     responses:
     *       201:
     *         description: Customer has logged in successfully
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerLoginResDto'
     *       404:
     *         description: Something went wrong.
     */
    router.post(
      '/login',
      this.validationSettingsMiddleware,
      [
        fieldValidator('email'),
        fieldValidator('password'),
      ],
      body('cartId').optional().isUUID().withMessage('datatype.uuid'), // NOSONAR
      validateRequestSchema,
      wrapJsonApiController(
        this.customerController.login.bind(this.customerController),
      ),
    );

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/customers/marketing-constent:
     *   post:
     *     summary: update optIn value
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *      description: update optIn value
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            type: object
     *            properties:
     *              optIn:
     *                type: boolean
     *                required: true
     *                default: true
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       202:
     *         description: Updated Customer Information
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerResponseDto'
     *       404:
     *         description: Something went wrong.
     */
    router.post(
      '/marketing-constent',
      this.authMiddleware,
      body('optIn').isBoolean({ strict: true }).withMessage('customer.optIn'),
      validateRequestSchema,
      wrapJsonApiController(
        this.customerController.updateCustomerOptIn.bind(this.customerController),
      ),
    );
    return router;
  }
}
