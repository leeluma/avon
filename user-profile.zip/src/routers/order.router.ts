import { RequestHandler, Router } from 'express';
import { validateRequestSchema } from '../middlewares';
import { OrderController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import { validateBearerToken, validateOrderIdAndBearerToken } from '../validators';

export interface OrderRouterConfig {
  orderController: OrderController;
  Router: typeof Router;
  authMiddleware: RequestHandler;
}

/**
 * `OrderRouter` for all the routes related to `/order`
 */
export class OrderRouter {
  private readonly orderController: OrderController;

  private readonly Router: typeof Router;

  private readonly authMiddleware: RequestHandler;

  constructor(config: OrderRouterConfig) {
    this.orderController = config.orderController;
    this.Router = config.Router;
    this.authMiddleware = config.authMiddleware;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
    * @swagger
    * components:
    *   securitySchemes:
    *     bearerAuth:
    *       type: http
    *       scheme: bearer
    */
    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/orders:
     *   get:
     *     summary: Get list of orders
     *     tags: [Orders]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: query
     *         name: page
     *         schema:
     *            type: string
     *            default: '1'
     *         required: false
     *       - in: query
     *         name: sort
     *         schema:
     *            type: string
     *            default: 'asc'
     *         required: false
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       201:
     *         description: Creates a Default Customer for Customer
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/MyOrdersResponse'
     *       404:
     *         description: Something went wrong.
     */
    router.get(
      '/orders',
      this.authMiddleware,
      validateBearerToken,
      validateRequestSchema,
      wrapJsonApiController(
        this.orderController.getAll.bind(this.orderController),
      ),
    );

    /**
    * @swagger
    * components:
    *   securitySchemes:
    *     bearerAuth:
    *       type: http
    *       scheme: bearer
    */
    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/orders/{orderId}:
     *   get:
     *     summary: Get detail of order
     *     tags: [Orders]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: path
     *         name: orderId
     *         schema:
     *            type: string
     *            default: 2b3809fe-71a0-4ff7-a3d7-8913f8161e2e
     *         required: true
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       200:
     *         description: fetch order details
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/OrderResponse'
     *       404:
     *         description: Something went wrong.
     */
    router.get(
      '/orders/:orderId',
      this.authMiddleware,
      validateOrderIdAndBearerToken,
      validateRequestSchema,
      wrapJsonApiController(
        this.orderController.getOrderDetails.bind(this.orderController),
      ),
    );
    return router;
  }
}
