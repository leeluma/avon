import { Router } from 'express';
import { body, param } from 'express-validator';
import { ShoppingListController } from '../controllers/shopping-list.controller';
import { wrapJsonApiController } from '../lib';
import { magnoliaUrlMiddleware, validateRequestSchema } from '../middlewares';
import { validateId } from '../validators';

/**
 * Shopping List Router constructor config
 * @param: shoppingListController
 */

interface ShoppingListRouterConfig {
  shoppingListController: ShoppingListController;
  Router: typeof Router;
}

/**
 * `WishlistRouter` for all the routes related to `/wishlists`
 */
export class ShoppingListRouter {
  private readonly shoppingListController: ShoppingListController;

  private readonly Router: typeof Router;

  constructor(config: ShoppingListRouterConfig) {
    this.shoppingListController = config.shoppingListController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
 * @swagger
 * components:
 *   schemas:
 *     WishlistRequestDto:
 *       additionalProperties: false
 *       properties:
 *         anonymousId:
 *           type: string
 *         customerId:
 *           type: string
 *         id:
 *           type: string
 *         sku:
 *           type: string
 *       required:
 *         - sku
 *       type: object
 */

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/wishlists/{id}/cart/lineitems/{lineItemId}:
     *   post:
     *     summary: Move one LineItem from Wishlist to Cart.
     *     tags: [Wishlists]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: path
     *         name: id
     *         description: Id of the Wishlist source for LineItem
     *         schema:
     *            type: string
     *         required: true
     *       - in: path
     *         name: lineItemId
     *         description: Id of the LineItem to be moved
     *         schema:
     *            type: string
     *         required: true
     *     requestBody:
     *      description: Valid fields
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            type: object
     *            properties:
     *              cartId:
     *                type: string
     *                description: Id of the Cart where the LineItem should be moved
     *     responses:
     *       200:
     *         description: Wishlist id and Cart id
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *               properties:
     *                 wishlistId:
     *                   type: string
     *                   description: Id of the Wishlist from where the LineItem was moved
     *                 cartId:
     *                   type: string
     *                   description: Id of the Cart to where the LineItem was moved
     *               required:
     *                 - wishlistId
     *                 - cartId
     *       404:
     *         description: Something went wrong.
     */
    router.post(
      '/:id/cart/lineitems/:lineItemId',
      validateId,
      param('lineItemId').isUUID(),
      body('cartId').optional().isUUID(),
      validateRequestSchema,
      wrapJsonApiController(
        this.shoppingListController.moveOneLineItemToCart.bind(this.shoppingListController),
      ),
    );

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/wishlists/{id}/cart/lineitems:
     *   post:
     *     summary: Move all LineItems from Wishlist to Cart.
     *     tags: [Wishlists]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: path
     *         name: id
     *         description: Id of the Wishlist source for LineItems
     *         schema:
     *            type: string
     *         required: true
     *     requestBody:
     *      description: Valid fields
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            type: object
     *            properties:
     *              cartId:
     *                type: string
     *                description: Id of the Cart where the LineItems should be moved
     *            required:
     *              - cartId
     *     responses:
     *       200:
     *         description: Wishlist id and Cart id
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *               properties:
     *                 wishlistId:
     *                   type: string
     *                   description: Id of the Wishlist from where the LineItems were moved
     *                 cartId:
     *                   type: string
     *                   description: Id of the Cart to where the LineItems were moved
     *               required:
     *                 - wishlistId
     *                 - cartId
     *       404:
     *         description: Something went wrong.
     */
    router.post(
      '/:id/cart/lineitems',
      validateId,
      body('cartId').optional().isUUID(),
      validateRequestSchema,
      wrapJsonApiController(
        this.shoppingListController.moveAllLineItemsToCart.bind(this.shoppingListController),
      ),
    );

    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/wishlists/{id}:
     *   get:
     *     summary: Get wishlist details by wishlist id
     *     tags: [Wishlists]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: path
     *         name: id
     *         schema:
     *            type: string
     *         required: true
     *     responses:
     *       200:
     *         description: Details of wishlist by id
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/WishlistDto'
     *       404:
     *         description: Wishlist not found.
     */
    router.get(
      '/:id',
      validateId,
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.shoppingListController.getById.bind(this.shoppingListController),
      ),
    );

    /**
     * @swagger
     * /user-profile/v1/{language}-{market}/wishlists/{id}/lineitems/{lineItemId}:
     *   delete:
     *     summary: Delete Line Item from Wishlist
     *     tags: [Wishlists]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: market
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: path
     *         name: wishlistId
     *         schema:
     *            type: string
     *         required: true
     *       - in: path
     *         name: lineItemId
     *         schema:
     *            type: string
     *         required: true
     *     responses:
     *       200:
     *         description: Deletes a LineItem from Wishlist
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/WishlistDto'
     *       404:
     *         description: Wishlist not found.
     */
    router.delete(
      '/:id/lineitems/:lineItemId',
      validateId,
      param('lineItemId').isUUID(),
      validateRequestSchema,
      wrapJsonApiController(
        this.shoppingListController.deleteLineItem.bind(this.shoppingListController),
      ),
    );

    return router;
  }
}
