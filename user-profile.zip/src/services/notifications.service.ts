import { MarketInfo } from '../middlewares';
import { NotificationsDao } from '../daos';

export interface NotificationsServiceConfig {
  notificationsDao: NotificationsDao;
}

/**
 * Service for managing notifications
 */
export class NotificationsService {
  private readonly notificationsDao: NotificationsDao;

  constructor(config: NotificationsServiceConfig) {
    this.notificationsDao = config.notificationsDao;
  }

  /**
   * create a notification for a product
   * @param market - MarketInfo
   * @param productId - Product id
   * @returns ProductResponseDto
   * @throws ApiError 400
   */
  public async product(
    market: MarketInfo,
    params,
  ): Promise<boolean> {
    return this.notificationsDao.esaleNotifications(market, params);
  }

  /**
   * create a notification for a add to cart
   * @param market - MarketInfo
   * @param productId - Product id
   * @returns ProductResponseDto
   * @throws ApiError 400
   */
  public async addToCart(
    market: MarketInfo,
    params,
  ): Promise<boolean> {
    return this.notificationsDao.cartNotifications(market, params);
  }
}
