import { MarketInfo } from '../middlewares';
import { CommonResponse, MagnoliaInfo } from '../dtos';
import { MagnoliaDao } from '../daos';

interface MagnoliaServiceConfig {
  magnoliaDao: MagnoliaDao;
}

/**
 * `MagnoliaService` for business logic Magnolia data
 */
export class MagnoliaService {
  private readonly magnoliaDao: MagnoliaDao;

  /**
   * Constructor for `MagnoliaService` class
   * @param config injects dependencies into the object
   */
  constructor(config: MagnoliaServiceConfig) {
    this.magnoliaDao = config.magnoliaDao;
  }

  public async getTemplateData(
    templateName: string,
    magnoliaBasePath: string,
  ): Promise<CommonResponse> {
    return this.magnoliaDao.getTemplateDataFromMagnolia(templateName, magnoliaBasePath);
  }

  /**
   * Get magnolia user account page data
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   * @returns Page data from Magnolia
   */
  public async getAccountPageData(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ): Promise<CommonResponse> {
    const staticPageResponse = await this.magnoliaDao.getAccountPageData(market, magnolia);
    return {
      ...staticPageResponse,
    };
  }

  /**
   * Get magnolia global settings data
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   * @returns Global settings data from Magnolia
   */
  public async getGlobalSettingsData(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ): Promise<CommonResponse> {
    const globalSettings = await this.magnoliaDao.getGlobalSetting(market, magnolia);
    return {
      ...globalSettings,
    };
  }
}
