import {
  CommonResponse,
} from '../dtos';
import {
  DefaultDao,
} from '../daos';

import { MarketInfo } from '../middlewares';

export interface DefaultServiceConfig {
  defaultDao: DefaultDao;
}

/**
 * Default Service class
 */
export class DefaultService {
  private readonly defaultDao: DefaultDao;

  constructor(serviceConfig: DefaultServiceConfig) {
    this.defaultDao = serviceConfig.defaultDao;
  }

  /**
   * Refresh token
   * @param market - MarketInfo
   * @param params - Params
   * @param magnolia- MagnoliaInfo,
   * @returns HeaderDefaultResponse
   * @throws ApiError 404 if Header Default data was not found
   */
  public async refreshToken(
    market: MarketInfo,
    params,
  ): Promise<CommonResponse> {
    return this.defaultDao.refreshToken(market, params);
  }

  /**
   * Verify customer token
   * @param market - MarketInfo
   * @param params - Params
   * @returns HeaderDefaultResponse
   * @throws ApiError 404 if Header Default data was not found
   */
  public async verifyToken(
    market: MarketInfo,
    params,
  ): Promise<CommonResponse> {
    return this.defaultDao.verifyToken(market, params);
  }

  /**
   * Logout
   * @param authorizeToken - Authorization Token
   */
  public async logout(
    authorizeToken,
  ): Promise<boolean> {
    return this.defaultDao.logout(authorizeToken);
  }
}
