import i18next from 'i18next';
import HttpStatusCodes from 'http-status-codes';
import { Product } from '@commercetools/platform-sdk';
import { MagnoliaDao, OrderDao } from '../daos';
import {
  GetMyOrdersDraftDto, MyOrdersListResponse, OrderDto,
} from '../dtos';
import { ApiError } from '../lib';
import { OrderMapper } from '../mappers';
import { MarketInfo } from '../middlewares';

export interface OrderServiceConfig {
  orderDao: OrderDao;
  orderMapper: OrderMapper;
  magnoliaDao: MagnoliaDao;
}

/**
 * Order Service class
 */
export class OrderService {
  private readonly orderDao: OrderDao;

  private readonly orderMapper: OrderMapper;

  private readonly magnoliaDao: MagnoliaDao;

  constructor(config: OrderServiceConfig) {
    this.orderDao = config.orderDao;
    this.orderMapper = config.orderMapper;
    this.magnoliaDao = config.magnoliaDao;
  }

  /**
   * Get Orders implementation
   * @param market - MarketInfo
   * @param authHeader - authHeader
   * @returns List of Order Response
   */
  public async getAll(
    market: MarketInfo,
    authHeader: string,
    queryParams: GetMyOrdersDraftDto,
  ): Promise<MyOrdersListResponse | undefined> {
    const offset = (queryParams.page - 1) * queryParams.limit;

    const [globalSettings, orderList] = await Promise.all([
      this.magnoliaDao.getGlobalSetting(market),
      this.orderDao.find(market, authHeader, queryParams.limit, queryParams.sort, offset),
    ]);

    if (!orderList) {
      return orderList;
    }
    const orderListResponse = orderList.results
      .map((item) => this.orderMapper.createOrderResponse(item, globalSettings.priceFormat));
    return {
      total: Math.ceil(orderList.total / queryParams.limit),
      results: orderListResponse,
    };
  }

  /**
   * Get API for Order details.
   * @param market MarketInfo
   * @param orderId order id
   * @param magnolia MagnoliaInfo
   * @returns
   */
  public async orderDetails(
    market: MarketInfo,
    authHeader: string,
    orderId: string,
  ): Promise<OrderDto> {
    const [globalSettings, result] = await Promise.all([ // NOSOANR
      this.magnoliaDao.getGlobalSetting(market),
      this.orderDao.fetchOrder(authHeader, market, orderId),
    ]);

    if (!result) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.orderIdNotFound'));
    }
    const productsIds = this.orderMapper.getCartProductId(result.lineItems);
    const productDetails = await this.orderDao.fetchProductsDetail(market, productsIds);
    return this.orderMapper.mapOrderDetails(result, market, globalSettings.priceFormat, productDetails as Product[]);
  }
}
