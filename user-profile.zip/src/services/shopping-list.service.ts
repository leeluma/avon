/* eslint-disable @typescript-eslint/no-non-null-assertion */
import { ShoppingList } from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import { ApiError, logger } from '../lib';
import { MarketInfo } from '../middlewares';
import {
  ShoppingListDao, CartDao, SettingDao,
} from '../daos';
import { WishlistDto, WishlistMoveToCartResponseDto } from '../dtos/shopping-list.dto';
import { CartDto, CommonResponse, MagnoliaInfo } from '../dtos';
import { ShoppingListMapper } from '../mappers';
import { stringLiteral } from '../config';
import { MAGNOLIA_URI } from '../common/constants';

export interface ShoppingListServiceConfig {
  shoppingListDao: ShoppingListDao;
  cartDao: CartDao;
  settingDao: SettingDao,
  shoppingListMapper: ShoppingListMapper;
  globalSettingUrl: string;
}

interface ShoppingListAndCart {
  shoppingListDto: ShoppingList;
  cartDto: CartDto;
}

/**
 * `ShoppingListService` for business logic `ShoppingList`
 */
export class ShoppingListService {
  private readonly shoppingListDao: ShoppingListDao;

  private readonly cartDao: CartDao;

  private readonly settingDao: SettingDao;

  private readonly shoppingListMapper: ShoppingListMapper;

  private readonly globalSettingUrl: string;

  private readonly country = '{{country}}'; // NOSONAR

  private readonly wishlist = 'wishlist';

  /**
   * Constructor for `ShoppingListService` class
   * @param config injects dependencies into the object
   */
  constructor(config: ShoppingListServiceConfig) {
    this.shoppingListDao = config.shoppingListDao;
    this.cartDao = config.cartDao;
    this.settingDao = config.settingDao;
    this.shoppingListMapper = config.shoppingListMapper;
    this.globalSettingUrl = config.globalSettingUrl;
  }

  /**
   * Get a ShoppingList and Cart from CT while ensuring they belong to the same customer
   * by verifying they have the same customerId or anonymousId
   * @param market - Market information
   * @param shoppingListId - Id of ShoppingList
   * @param cartId - Id of Cart
   */
  private async getShoppingListAndCart(
    market: MarketInfo,
    shoppingListId: string,
    cartId: string | undefined,
  ): Promise<ShoppingListAndCart> {
    logger.debug('WishlistService.getShoppingListAndCart', JSON.stringify({ market, shoppingListId, cartId }));

    const shoppingListDto = await this.shoppingListDao.findOne(market, shoppingListId);
    if (!shoppingListDto) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, `Wishlist with id "${shoppingListId}" was not found`);
    }

    let cartDto;

    if (cartId) {
      cartDto = await this.cartDao.findOne(market, cartId);

      if (!cartDto) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, `Cart with id "${cartId}" was not found`);
      }

      if (shoppingListDto.customer?.id) {
        if (cartDto.customerId !== shoppingListDto.customer.id) {
          logger.error('The user tried to move the items from a Wishlist to a Cart, but the Cart customerId'
            + ` "${cartDto.customerId}" did not match the Wishlist customer.id "${shoppingListDto.customer.id}"`);
          throw new ApiError(HttpStatusCodes.FORBIDDEN, stringLiteral.messages.FORBIDDEN);
        }
      } else if (shoppingListDto.anonymousId) {
        if (cartDto.anonymousId !== shoppingListDto.anonymousId) {
          logger.error('The user tried to move the items from a Wishlist to a Cart, but the Cart anonymousId'
            + ` "${cartDto.anonymousId}" did not match the Wishlist anonymousId "${shoppingListDto.anonymousId}"`);
          throw new ApiError(HttpStatusCodes.FORBIDDEN, stringLiteral.messages.FORBIDDEN);
        }
      } else {
        logger.warn(`Wishlist id "${shoppingListId}" doesn't have a customer or anonymousId assigned, so it is not`
          + ` possible to determine if the current user is owning both this Wishlist anc Cart id "${cartId}"`);
      }
    } else {
      cartDto = await this.cartDao.create(market, {
        customerId: shoppingListDto.customer?.id,
        anonymousId: shoppingListDto.anonymousId,
        currency: 'RON',
      });
    }

    return { shoppingListDto, cartDto };
  }

  /**
   * Move one LineItem from Wishlist to Cart
   * @param market - Market information
   * @param wishlistId - Id of source Wishlist
   * @param lineItemId - Id of LineItem to be moved
   * @param cartId - Optional, id of destination Cart (if missing, a new Cart will be created)
   */
  public async moveOneLineItemToCart(
    market: MarketInfo,
    wishlistId: string,
    lineItemId: string,
    cartId: string | undefined,
  ): Promise<WishlistMoveToCartResponseDto> {
    logger.info(`Move LineItem id "${lineItemId}" from Wishlist id "${wishlistId}" to Cart id "${cartId}".`);

    const { shoppingListDto, cartDto } = await this.getShoppingListAndCart(market, wishlistId, cartId);

    const lineItem = shoppingListDto.lineItems!.find((li) => li.id === lineItemId);
    if (!lineItem) {
      throw new ApiError(
        HttpStatusCodes.NOT_FOUND,
        `LineItem id "${lineItemId}" does not exist in Wishlist "${wishlistId}"`,
      );
    }

    await Promise.all([
      this.cartDao.addLineItem(market, cartDto.id, cartDto.version, lineItem.productId, lineItem.variantId!),
      this.shoppingListDao.deleteLineItems(market, shoppingListDto.id, shoppingListDto.version, [lineItemId]),
    ]);

    return { wishlistId, cartId: cartDto.id };
  }

  /**
   * Wishlist Move all LineItems to cart
   * @param market - MarketInfo
   * @param wishlistId - Wishlist Id
   * @param cartId - Cart Id
   * @returns Wishlist Response
   */
  public async moveAllLineItemsToCart(
    market: MarketInfo,
    wishlistId: string,
    cartId: string | undefined,
  ): Promise<WishlistMoveToCartResponseDto> {
    logger.info(`Move all Wishlist LineItems for Wishlist id "${wishlistId}" to Cart id "${cartId}".`);

    const { shoppingListDto, cartDto } = await this.getShoppingListAndCart(market, wishlistId, cartId);

    const lineItemIds = shoppingListDto.lineItems!.map((lineItem) => lineItem.id);

    await Promise.all([
      this.cartDao.addShoppingList(market, cartDto.id, cartDto.version, wishlistId),
      this.shoppingListDao.deleteLineItems(market, shoppingListDto.id, shoppingListDto.version, lineItemIds),
    ]);

    return { wishlistId, cartId: cartDto.id };
  }

  /**
   * Wishlist Get by Id implementation
   * @param market - MarketInfo
   * @param wishlistId - Wishlist Id
   * @returns Wishlist Response
   */
  public async getById(
    market: MarketInfo,
    params,
    magnolia: MagnoliaInfo,
  ): Promise<CommonResponse | undefined> {
    let wishlistPageUrl;
    const { wishlistId, isPage } = params;
    const wishlistUrl = `${magnolia.url}${MAGNOLIA_URI.userprofilePage}`
      .replace(this.country, `${magnolia.marketPath}`);

    wishlistPageUrl = `${wishlistUrl}`;
    if (magnolia.isPreview === false || magnolia.marketPath.length < 3) { // NOSONAR
      wishlistPageUrl = `${wishlistUrl}/${this.wishlist}`;
    }
    const globalSettingUrl = `${magnolia.url}${this.globalSettingUrl}`
      .replace('{{country}}', `${market.country.toLowerCase()}`) // NOSONAR
      .replace('{{locale}}', `${market.country.toLowerCase()}`);
    const [wishlistPageData, magnoliaGlobalSettingData] = await Promise.all([
      this.shoppingListDao.getResult(wishlistPageUrl),
      this.shoppingListDao.getResult(globalSettingUrl),
    ]);
    let templateDefinitions;
    if (wishlistPageData && magnolia.isPreview && wishlistPageData[`${MAGNOLIA_URI.getmgnlTemplate}`]) {
      const templateName = wishlistPageData[`${MAGNOLIA_URI.getmgnlTemplate}`];
      const getOfferTemplateUrl = `${magnolia.url}${MAGNOLIA_URI.template}${templateName}`;
      templateDefinitions = await this.shoppingListDao
        .getResult(getOfferTemplateUrl);
    }
    logger.info(`Get Wishlist for id "${wishlistId}"`);

    const [shoppingListDto, magnoliaPriceFormat] = await Promise.all([
      this.shoppingListDao.findGraphQLOne(market, wishlistId),
      this.settingDao.getPriceFormat(market),
    ]);

    if (shoppingListDto === undefined) {
      return undefined;
    }
    const shoppingData = this.shoppingListMapper.mapShoppingListResponse(market, shoppingListDto, magnoliaPriceFormat);

    if (isPage === true) {
      return {
        wishlist: shoppingData,
        templateDefinition: templateDefinitions,
        globalSettings: magnoliaGlobalSettingData,
      };
    }
    return {
      ...wishlistPageData,
      wishlist: shoppingData,
      templateDefinition: templateDefinitions,
      globalSettings: magnoliaGlobalSettingData,
    };
  }

  /**
   * Deletes a line item from the wishlist
   * @param market - Market Info
   * @param wishlistId - Wishlist Id
   * @param lineItemId - Line Item Id
   * @returns Wishlist Response
   */
  public async deleteLineItem(
    market: MarketInfo,
    wishlistId: string,
    lineItemId: string,
  ): Promise<WishlistDto> {
    const shoppingListDto = await this.shoppingListDao.findOne(market, wishlistId);

    if (!shoppingListDto) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, 'Invalid wishlistId.');
    }
    await this.shoppingListDao.deleteLineItems(
      market,
      wishlistId,
      shoppingListDto.version,
      [lineItemId],
    );

    const [updatedWishlist, magnoliaPriceFormat] = await Promise.all([
      this.shoppingListDao.findGraphQLOne(market, wishlistId),
      this.shoppingListDao.getPriceFormat(market),
    ]);

    return this.shoppingListMapper.mapShoppingListResponse(market, updatedWishlist!, magnoliaPriceFormat);
  }
}
