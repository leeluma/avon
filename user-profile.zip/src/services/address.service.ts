import { config } from '../config';
import { AddressDao } from '../daos';
import { DetailResponseDto, NormalizedAddress } from '../dtos';
import { MarketInfo } from '../lib';
import { MARKET } from '../lib/constants';

export interface AddressServiceConfig {
  addressDao: AddressDao;
}

/**
 * Address Service class
 */
export class AddressService {
  private readonly addressDao: AddressDao;

  constructor(conf: AddressServiceConfig) {
    this.addressDao = conf.addressDao;
  }

  /**
   * Get API for address autocomplete.
   * @param market - MarketInfo
   * @param address - Address
   */
  public async addressAutocomplete(
    market: MarketInfo,
    address: string | undefined,
  ): Promise<NormalizedAddress[]> {
    const { addressFinderHost, addressFinderAutoComplete } = config;
    const url = `${addressFinderHost}${addressFinderAutoComplete}`
      .replace(MARKET, market.localeAndCountry);

    return this.addressDao.addressAutocomplete(url, address);
  }

  /**
   * Get API for address detail.
   * @param market - MarketInfo
   * @param addressId - Address Id
   */
  public async addressDetail(
    market: MarketInfo,
    addressId: string,
  ): Promise<DetailResponseDto> {
    const { addressFinderHost, addressFinderDetail } = config;
    const url = `${addressFinderHost}${addressFinderDetail}`
      .replace(MARKET, market.localeAndCountry);

    return this.addressDao.addressDetail(url, addressId);
  }
}
