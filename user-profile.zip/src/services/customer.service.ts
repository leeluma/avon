// NOSONAR
import {
  Address, AddressDraft,
  CustomerDraft, Update,
  UpdateAction, CustomerChangePassword,
  Customer, MyCustomerUpdate, MyCustomerUpdateAction, CustomerSignin,
} from '@commercetools/platform-sdk';
import { randomUUID } from 'crypto';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { CustomerDao, AddressDao, CartDao } from '../daos';

import { config } from '../config';
import {
  AddressCollectionResponseDto,
  AddressRequestDto,
  AddressResponseDto,
  CustomerRegistrationRequestDto,
  CustomerResponseDto,
  ChangePasswordRequestDto,
  CustomerForgotPassword,
  SetDefaultAddressDto,
  CustomerRequestDto,
  LoginDto,
  CustomerLoginResponseDto,
  LoginCustomerDto,
  CustomerOptInRequestDto,
  CustomerActiveCartAndWishListDto,
} from '../dtos';
import {
  ApiError, AwsEventBridgeClient,
  AwsEventBridgeSource, customerCustomTypeKey, logError, logger, MARKET,
} from '../lib';
import { AddressMapper, CustomerMapper } from '../mappers';
import { MarketInfo } from '../middlewares';

const KEY = 'customer-type';
export interface CustomerServiceConfig {
  customerDao: CustomerDao;
  addressDao: AddressDao;
  cartDao: CartDao;
  addressMapper: AddressMapper;
  customerMapper: CustomerMapper;
  eventBridgeClient: AwsEventBridgeClient;
  marketingEmailConsentEventBusName: string;
  passwordResetEventBusName: string;
}

export interface AddressAction extends UpdateAction{
  address?: AddressDraft;
  addressKey?: string;
  addressId?:string;
}

export type CustomCustomerDraft = Omit<CustomerDraft, 'addresses'>;

/**
 * Customer Service class
 */
export class CustomerService {
  private readonly customerDao: CustomerDao;

  private readonly addressDao: AddressDao;

  private readonly cartDao: CartDao;

  private readonly addressMapper: AddressMapper;

  private readonly customerMapper: CustomerMapper;

  private readonly marketingEmailConsentEventBusName: string;

  private readonly passwordResetEventBusName: string;

  private readonly eventBridgeClient: AwsEventBridgeClient;

  constructor(configuration: CustomerServiceConfig) {
    this.customerDao = configuration.customerDao;
    this.addressDao = configuration.addressDao;
    this.cartDao = configuration.cartDao;
    this.addressMapper = configuration.addressMapper;
    this.customerMapper = configuration.customerMapper;
    this.eventBridgeClient = configuration.eventBridgeClient;
    this.marketingEmailConsentEventBusName = configuration.marketingEmailConsentEventBusName;
    this.passwordResetEventBusName = configuration.passwordResetEventBusName;
  }

  /**
   * Customer Get by Id implementation
   * @param market - MarketInfo
   * @param customerId - Customer Id
   * @returns Customer Response
   */
  public async getById(
    market: MarketInfo,
    customerId: string,
  ): Promise<CustomerResponseDto | undefined> {
    logger.info(`Get Customer for id "${customerId}"`);

    const customerDto = await this.customerDao.findGraphQLOne(market, customerId);

    if (customerDto === undefined) {
      return undefined;
    }

    return this.customerMapper.mapGraphQLCustomerResponse(customerDto, true);
  }

  /**
   * Creates | Register Customer
   * @param market - MarketInfo
   * @param customer - CustomerRequestDto
   * @returns Default Customer response i.e. minimal information required by Frontend
   */
  public async registration(
    market: MarketInfo,
    customer: CustomerRegistrationRequestDto,
  ): Promise<CustomerLoginResponseDto> {
    const currentDate = Math.floor(new Date().getTime() / 1000); // NOSONAR
    const customerEmail = customer.email.split('@')[0].replace(/\./g, '');
    const { cartId } = customer;
    const customerDraft: CustomCustomerDraft = {
      key: customer.key ?? `${customerEmail}-${currentDate}`,
      email: customer.email,
      isEmailVerified: false,
      firstName: customer.firstName,
      lastName: customer.lastName,
      password: customer.password,
      custom: {
        type: {
          typeId: 'type',
          key: customerCustomTypeKey,
        },
        fields: {
          OptIn: customer.optIn ?? false,
          TermsAndConditions: true,
          Activated: false,
          ActivatedDate: new Date(),
          IsFraud: false,
        },
      },
    };
    const customerResponse = await this.customerDao.create(market, customerDraft);

    const customerLoginDraftReqDto: CustomerSignin = {
      email: customerDraft.email,
      password: customerDraft.password,
    };
    const output:LoginCustomerDto = await this.customerDao.login(market, customerLoginDraftReqDto);

    const customerId = output.scope.split(' ')[1].split(':')[1];

    if (cartId) {
      const cartResponse = await this.cartDao.findOne(market, cartId);
      if (cartResponse === undefined) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartNotFound')); // NOSONAR
      } else if (cartResponse.customerId !== undefined && cartResponse.customerId !== customerId) {
        throw new ApiError(HttpStatusCodes.CONFLICT, i18next.t('error.cartIdConflict')); // NOSONAR
      } else {
        const { version } = cartResponse;
        await this.customerDao.setCustomerIdToCart(market, cartId, version, customerId);
      }
    }

    this.eventBridgeClient.putEvent(
      this.marketingEmailConsentEventBusName,
      AwsEventBridgeSource.marketingNotifications,
      {
        marketId: market.localeAndCountry,
        eventType: 'Created',
        resourceTypeId: 'customer',
        resourceId: customerResponse.id,
      },
    ).catch((err) => logError('CustomerService', i18next.t('error.failedToPushNotification'), err)); // NOSONAR

    return {
      accessToken: output.access_token,
      expiresIn: output.expires_in,
      tokenType: output.token_type,
      refreshToken: output.refresh_token,
      customerId: customerResponse.id,
      cartId,
    };
  }

  /**
   * Get Addresses By Customer Id implementation
   * @param market - MarketInfo
   * @param customerId - Customer Id
   * @returns Address Response
   */
  public async getAddress(
    market: MarketInfo,
    customerId: string,
  ): Promise<AddressResponseDto[] | undefined> {
    logger.info(`Get list of Customer Addresses for id "${customerId}"`);

    const customerDto = await this.customerDao.findGraphQLOne(market, customerId);

    if (customerDto === undefined) {
      return undefined;
    }

    return customerDto.addresses.map((address) => {
      return this.addressMapper.mapGraphQLAddressResponse(address, customerDto);
    });
  }

  /**
   * post address draft to Commerce Tool.
   * Now mapped data return.
   * @param market - Market Info
   * @param customerId - Customer Id
   * @param addressRequestDto - Address Request Dto
   * @returns Address Response
   */
  public async addAddress(
    market: MarketInfo,
    customerId: string,
    addressRequestDto: AddressRequestDto,
  ): Promise<AddressCollectionResponseDto> {
    const customerDto = await this.customerDao.findOne(market, customerId);

    if (!customerDto) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, `Customer id "${customerId}" does not exist`);
    }

    const { version } = customerDto;

    const addressKey = randomUUID();
    const { addressFinderId } = addressRequestDto;
    const actions: AddressAction[] = [];
    if (addressFinderId) {
      const { addressFinderHost, addressFinderDetail } = config;
      const url = `${addressFinderHost}${addressFinderDetail}`
        .replace(MARKET, market.localeAndCountry);

      const addressDetail = await this.addressDao.addressDetail(url, addressFinderId);
      if (addressDetail === undefined) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.addressNotFound')); // NOSONAR
      }
      addressDetail.firstName = addressRequestDto?.firstName;
      addressDetail.lastName = addressRequestDto?.lastName;
      addressDetail.firstName ||= customerDto.firstName;
      addressDetail.lastName ||= customerDto.lastName;
      addressDetail.recipientName ||= `${addressDetail.firstName} ${addressDetail.lastName}`.trim();
      addressDetail.phoneNumber = addressRequestDto.phoneNumber;
      const address = this.addressMapper
        .createAddressDraftFromDetails(
          market,
          addressDetail,
          addressKey,
        );
      actions.push({ action: 'addAddress', address });
    } else {
      const address = this.addressMapper.createAddressDraft(market, customerDto, addressRequestDto, addressKey);

      actions.push({ action: 'addAddress', address });
    }
    logger.info(JSON.stringify(actions));
    actions.push({ action: 'addShippingAddressId', addressKey });
    if (addressRequestDto.isBillingAddress) {
      actions.push({ action: 'addBillingAddressId', addressKey });
    }
    if (!customerDto.addresses.length) {
      actions.push({ action: 'setDefaultShippingAddress', addressKey });
      actions.push({ action: 'setDefaultBillingAddress', addressKey });
    }
    const payload:Update = { version, actions };

    const updatedCustomer = await this.customerDao.updateCustomer(market, customerId, payload);

    return this.addressMapper.mapAddressCollectionResponse(updatedCustomer);
  }

  /**
   * post address draft to Commerce Tool.
   * Now mapped data return.
   * @param market - Market Info
   * @param customerId - Customer Id
   * @param addressId - Address Id
   * @param addressRequestDto - Address Request Dto
   * @returns Address Response
   */
  public async updateAddress(
    market: MarketInfo,
    customerId: string,
    addressId: string,
    addressRequestDto: AddressRequestDto,
  ): Promise<AddressResponseDto[] | undefined> {
    const customerDto = await this.customerDao.findOne(market, customerId);

    if (!customerDto) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, `Customer id "${customerId}" does not exist`);
    }

    const currentAddress = customerDto.addresses.find((item: Address) => item.id === addressId);
    if (!currentAddress) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, `Address id "${addressId}" does not exist`);
    }
    const { version, billingAddressIds } = customerDto;
    const addressKey = currentAddress.key || randomUUID();
    const { addressFinderId } = addressRequestDto;
    const actions: AddressAction[] = [];
    if (addressFinderId) {
      const { addressFinderHost, addressFinderDetail } = config;
      const url = `${addressFinderHost}${addressFinderDetail}`
        .replace(MARKET, market.localeAndCountry);

      const addressDetail = await this.addressDao.addressDetail(url, addressFinderId);
      if (addressDetail === undefined) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.addressNotFound')); // NOSONAR
      }
      addressDetail.firstName = addressRequestDto?.firstName;
      addressDetail.lastName = addressRequestDto?.lastName;
      addressDetail.firstName ||= customerDto.firstName;
      addressDetail.lastName ||= customerDto.lastName;
      addressDetail.recipientName ||= `${addressDetail.firstName} ${addressDetail.lastName}`.trim();
      addressDetail.phoneNumber = addressRequestDto.phoneNumber;
      const address = this.addressMapper
        .createAddressDraftFromDetails(
          market,
          addressDetail,
          addressKey,
          currentAddress.id,
        );
      actions.push({ action: 'changeAddress', addressId: currentAddress.id, address });
    } else {
      const address = this.addressMapper.createAddressDraft(
        market,
        customerDto,
        addressRequestDto,
        addressKey,
        currentAddress.id,
      );

      actions.push({ action: 'changeAddress', addressId: currentAddress.id, address });
    }

    if (addressRequestDto.isShippingAddress) {
      actions.push({ action: 'addShippingAddressId', addressKey });
    }
    // we have to remove address from billing address only when we receive isBillingAddress as false not for any other falsy value
    if (addressRequestDto.isBillingAddress) {
      actions.push({ action: 'addBillingAddressId', addressKey });
    } else if (addressRequestDto.isBillingAddress === false && billingAddressIds?.includes(addressId)) {
      actions.push({ action: 'removeBillingAddressId', addressKey });
    }

    const payload = { version, actions };

    const updatedCustomer = await this.customerDao.updateCustomer(market, customerId, payload);
    return updatedCustomer.addresses.map((addressDto) => {
      return this.addressMapper.mapAddressResponse(addressDto, updatedCustomer);
    });
  }

  /**
   * Fetch customer details from Commerce tool for version then change password.
   * @param market - Market Info
   * @param changePasswordRequestDto - Customer change password request dto
   * @param authHeader - Authorization header
   * @returns Action Response
   */

  public async changePassword(
    market: MarketInfo,
    changePasswordRequestDto: ChangePasswordRequestDto,
    authHeader: string,
    customer : Customer,
  ): Promise<void> {
    const { version, id } = customer;
    const payload: CustomerChangePassword = {
      id,
      version,
      currentPassword: changePasswordRequestDto.currentPassword,
      newPassword: changePasswordRequestDto.newPassword,
    };
    await this.customerDao.changePassword(market, payload, authHeader);
  }

  /** Reset a Customer's password by Token
   * @param market - MarketInfo
   * @param tokenValue - Previously requested password reset token
   * @param newPassword - New password
   */
  public async resetCustomersPassword(
    market: MarketInfo,
    tokenValue: string,
    newPassword: string,
  ): Promise<void> {
    logger.info(`Reset password by tokenValue "${tokenValue}"`);

    const success = await this.customerDao.resetCustomersPassword(market, tokenValue, newPassword);

    if (!success) {
      throw new ApiError(HttpStatusCodes.UNAUTHORIZED, 'Failed to reset password. Please try with a new token.');
    }
  }

  /**
  * Delete customer address from Commerce Tool.
  * Now mapped data return.
  * @param market - Market Info
  * @param customerId - Customer Id
  * @param addressId - Address Id
  * @returns Address Response
  */
  public async deleteAddress(
    market: MarketInfo,
    customerId: string,
    addressId: string,
  ): Promise<AddressDraft[]> {
    const customerDto = await this.customerDao.findOne(market, customerId);

    if (!customerDto) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, `Customer id "${customerId}" does not exist`);
    }

    const currentAddress = customerDto.addresses.find((item: Address) => item.id === addressId);
    if (!currentAddress) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, `Address id "${addressId}" does not exist`);
    }

    const { version } = customerDto;
    const { id } = currentAddress;

    const actions: AddressAction[] = [{ action: 'removeAddress', addressId: id }];

    const { defaultShippingAddressId, defaultBillingAddressId } = customerDto;
    const nextAddress = customerDto.addresses.find((item) => item.id !== id);
    if (defaultShippingAddressId === id && nextAddress) {
      actions.push({ action: 'setDefaultShippingAddress', addressId: nextAddress.id });
    }
    if (defaultBillingAddressId === id && nextAddress) {
      actions.push({ action: 'setDefaultBillingAddress', addressId: nextAddress.id });
    }

    const payload = { version, actions };

    const customerDtoUpdated = await this.customerDao.updateCustomer(market, customerId, payload);
    return customerDtoUpdated.addresses.map((addressDto) => {
      return this.addressMapper.mapAddressResponse(addressDto, customerDtoUpdated);
    });
  }

  /** Forgot a Customer's password by email
   * @param market - MarketInfo
   * @param tokenValue - Previously requested forgot password
   * @param newPassword - New password
   */
  public async forgotCustomersPassword(
    market: MarketInfo,
    email: string,
    url: string,
  ): Promise<void> {
    const forgotPasswordResult: CustomerForgotPassword = await this.customerDao.forgotCustomersPassword(market, email);

    if (!forgotPasswordResult) {
      throw new ApiError(HttpStatusCodes.UNAUTHORIZED, 'Failed to reset password. Email Id does not exist');
    }
    const { value, expiresAt, customerId } = forgotPasswordResult;

    const customerResult = await this.customerDao.findGraphQLOne(market, customerId);
    const { lastName, firstName } = customerResult!;
    const {
      templateId, fromEmail, fromName, contactFormUrl,
    } = config;
    const resetPasswordUrl = `${url}?token=${value}`;
    /* Events that are safe to run async */
    this.eventBridgeClient.putEvent(
      this.passwordResetEventBusName,
      AwsEventBridgeSource.passwordResetQueue,
      {
        templateId,
        fromName,
        fromEmail,
        contactFormUrl,
        customerName: `${firstName} ${lastName}`,
        email,
        resetPasswordUrl,
        expiryDate: expiresAt,
      },
    ).catch((err) => logError('CustomerService', i18next.t('error.failedToPushNotification'), err)); // NOSONAR
  }

  /**
  * Delete customer address from Commerce Tool.
  * Now mapped data return.
  * @param market - Market Info
  * @param customerId - Customer Id
  * @param addressId - Address Id
  * @returns Address Response
  */
  public async defaultAddress(
    market: MarketInfo,
    params : SetDefaultAddressDto,
    authHeader: string,
  ): Promise<void> {
    const actions: MyCustomerUpdateAction[] = [];
    const { version } = params;
    if (params.isDelivery === true) {
      actions.push({
        action: 'setDefaultShippingAddress',
        addressId: params.addressId,
      });
    }
    if (params.isBilling === true) {
      actions.push({
        action: 'setDefaultBillingAddress',
        addressId: params.addressId,
      });
    }
    if (params.isBilling === false && params.isDelivery === false) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, 'sorry, one value of isBilling/isDelivery should be true');
    }

    const payload : MyCustomerUpdate = { version, actions };

    await this.customerDao.setDefaultAddress(market, payload, authHeader);
  }

  /**
   * Get Customer details by Customer Token implementation
   * @param market - MarketInfo
   * @param authHeader - Customer Token
   * @returns Customer Response
   */
  public async getCustomerDetailsByToken(
    market: MarketInfo,
    authHeader: string,
  ): Promise<CustomerResponseDto | undefined> {
    const customer = await this.customerDao.getCustomerDetailsGraphQL(market, authHeader);
    return this.customerMapper.mapGraphQLCustomerResponse(customer);
  }

  /**
   * post address draft to Commerce Tool.
   * Now mapped data return.
   * @param market - Market Info
   * @param version - Customer version
   * @param authHeader - Bearer Token
   * @param customerRequestDto - Customer Request Dto
   * @returns Customer Response
   */
  public async updateMyCustomer(
    market: MarketInfo,
    customer: Customer,
    authHeader: string,
    customerRequestDto: CustomerRequestDto,
  ): Promise<CustomerResponseDto | undefined> {
    const { version, custom } = customer;
    let customerPhoneAction;
    if (!custom) {
      customerPhoneAction = {
        action: 'setCustomType',
        type: { typeId: 'type', key: KEY },
        fields: {
          PhoneNumber: customerRequestDto.phoneNumber,
          OptIn: false,
          TermsAndConditions: true,
          Activated: false,
          ActivatedDate: new Date(),
          IsFraud: false,
        },
      };
    } else {
      customerPhoneAction = {
        action: 'setCustomField',
        name: 'PhoneNumber',
        value: customerRequestDto.phoneNumber,
      };
    }
    const actions: MyCustomerUpdateAction[] = [{
      action: 'setFirstName',
      firstName: customerRequestDto.firstName,
    }, {
      action: 'setLastName',
      lastName: customerRequestDto.lastName,
    },
    customerPhoneAction,
    ];

    const payload: MyCustomerUpdate = { version, actions };
    const updatedCustomer = await this.customerDao.updateMyCustomer(market, authHeader, payload);
    return this.customerMapper.mapCustomerResponse(updatedCustomer);
  }

  /**
  * Use to retrive user's token data based on users credentials.
  * @param market
  * @param loginReqDto
  * @returns
  */
  public async login(
    market: MarketInfo,
    loginReqDto: LoginDto,
  ): Promise<CustomerLoginResponseDto> {
    let { cartId } = loginReqDto;
    let wishlistId;
    const customerLoginDraftReqDto: CustomerSignin = {
      email: loginReqDto.email,
      password: loginReqDto.password,
    };
    const output:LoginCustomerDto = await this.customerDao.login(market, customerLoginDraftReqDto);
    const customerId = output.scope.split(' ')[1].split(':')[1];
    let accessToken = output.access_token;

    if (cartId) {
      const cartResponse = await this.cartDao.findOne(market, cartId);
      if (cartResponse === undefined) {
        throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartNotFound')); // NOSONAR
      } else if (cartResponse.customerId !== undefined && cartResponse.customerId !== customerId) {
        throw new ApiError(HttpStatusCodes.CONFLICT, i18next.t('error.cartIdConflict')); // NOSONAR
      } else {
        const { version } = cartResponse;
        await this.customerDao.setCustomerIdToCart(market, cartId, version, customerId);
      }
    } else {
      accessToken = `Bearer ${accessToken}`;
      const customerWishlistAndCart:CustomerActiveCartAndWishListDto = await this.cartDao
        .getCustomerWishlistAndCartId(customerId, accessToken, market);

      cartId = customerWishlistAndCart?.me?.activeCart?.id;
      wishlistId = customerWishlistAndCart?.shoppingLists?.results[0]?.id;
    }

    return {
      accessToken: output.access_token,
      expiresIn: output.expires_in,
      tokenType: output.token_type,
      refreshToken: output.refresh_token,
      customerId: output.scope?.split(' ')[1].split(':')[1],
      cartId,
      wishlistId,
    };
  }

  /**
   * post customerOptInAction draft to Commerce Tool.
   * Now mapped data return.
   * @param market - Market Info
   * @param version - Customer version
   * @param authHeader - Bearer Token
   * @param customerRequestDto - Customer Request Dto
   * @returns Customer Response
   */
  public async updateCustomerOptIn(
    market: MarketInfo,
    customer: Customer,
    authHeader: string,
    customerRequestDto: CustomerOptInRequestDto,
  ): Promise<CustomerResponseDto | undefined> {
    const { version, custom, id } = customer;
    let customerOptInAction;
    if (!custom) {
      customerOptInAction = {
        action: 'setCustomType',
        type: { typeId: 'type', key: KEY },
        fields: {
          PhoneNumber: '',
          OptIn: customerRequestDto.optIn,
          TermsAndConditions: true,
          Activated: false,
          ActivatedDate: new Date(),
          IsFraud: false,
        },
      };
    } else {
      customerOptInAction = {
        action: 'setCustomField',
        name: 'OptIn',
        value: customerRequestDto.optIn,
      };
    }
    const actions: MyCustomerUpdateAction[] = [
      customerOptInAction,
    ];

    const payload: MyCustomerUpdate = { version, actions };
    const updatedCustomer = await this.customerDao.updateMyCustomer(market, authHeader, payload);
    const result = this.customerMapper.mapCustomerResponse(updatedCustomer);

    /* Events that are safe to run async */
    const customerId = id;
    this.eventBridgeClient.putEvent(
      this.marketingEmailConsentEventBusName,
      AwsEventBridgeSource.marketingNotifications,
      {
        marketId: market.localeAndCountry,
        eventType: 'Changed',
        resourceTypeId: 'customer',
        resourceId: customerId,
      },
    ).catch((err) => logError('CustomerService', i18next.t('error.failedToPushNotification'), err)); // NOSONAR

    /* Return response from PSP */

    return result;
  }
}
