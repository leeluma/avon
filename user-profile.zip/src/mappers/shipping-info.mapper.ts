import { ShippingInfo } from '@commercetools/platform-sdk';
import {
  ShippingInfoDto,
} from '../dtos';
import { Common } from '../lib';

export interface ShippingInfoMapperConfig {
  common: Common;
}

export class ShippingInfoMapper {
  private readonly common: Common;

  constructor(config: ShippingInfoMapperConfig) {
    this.common = config.common;
  }

  public mapShippingInfoResponse(
    shippingInfo: ShippingInfo | undefined,
  ): ShippingInfoDto | undefined {
    if (shippingInfo === undefined) {
      return undefined;
    }
    return {
      shippingPrice: shippingInfo.price.centAmount,
      shippingMethodName: shippingInfo?.shippingMethodName,
      shippingMethodPrice: `${this.common.priceConverter(
        shippingInfo?.price.centAmount,
        shippingInfo?.price.fractionDigits,
      )} ${shippingInfo?.price.currencyCode}`,
    };
  }
}
