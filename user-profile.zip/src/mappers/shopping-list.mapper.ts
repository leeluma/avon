import { GraphQLShoppingList, LineItemDto, MagnoliaPriceFormatDto } from '../dtos';
import { WishlistDto } from '../dtos/shopping-list.dto';
import { MarketInfo } from '../middlewares';
import { LineItemMapper } from './line-item.mapper';

export interface ShoppingListMapperConfig {
  lineItemsMapper: LineItemMapper;
}

/**
 * Maps ShoppingList Response
 */
export class ShoppingListMapper {
  readonly lineItemsMapper: LineItemMapper;

  constructor(config: ShoppingListMapperConfig) {
    this.lineItemsMapper = config.lineItemsMapper;
  }

  public mapShoppingListResponse(
    market: MarketInfo,
    shoppingListDto: GraphQLShoppingList,
    magPriceFormat: MagnoliaPriceFormatDto,
  ): WishlistDto {
    return {
      id: shoppingListDto.id,
      name: shoppingListDto.name,
      version: shoppingListDto.version,
      lineItems: shoppingListDto.lineItems?.map(
        (item) =>
          this.lineItemsMapper.mapLineItemResponse(market, item, magPriceFormat),
      ) as LineItemDto[],
      customerId: shoppingListDto.customer?.id,
      anonymousId: shoppingListDto.anonymousId,
    };
  }
}
