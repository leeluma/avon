import { Attribute, Image, Price } from '@commercetools/platform-sdk';
import { LineItemDto, MagnoliaPriceFormatDto, GraphQLShoppingListLineItem } from '../dtos';
import { Common } from '../lib/common';

import { MarketInfo } from '../middlewares';

export interface LineItemMapperConfig {
  common: Common;
}

export class LineItemMapper {
  private readonly common: Common;

  constructor(config: LineItemMapperConfig) {
    this.common = config.common;
  }

  public mapLineItemResponse(
    market: MarketInfo,
    lineItemDraft: GraphQLShoppingListLineItem,
    magPriceFormat: MagnoliaPriceFormatDto,
  ): LineItemDto {
    return {
      id: lineItemDraft.id,
      variantId: lineItemDraft.variantId,
      quantity: lineItemDraft.quantity,
      product: { id: lineItemDraft.productId },
      listPrice: this.common.getNonRepPrice(lineItemDraft.variant?.prices as Price[]),
      sellPrice: this.common.getNonRepPriceWithDiscount(lineItemDraft.variant?.prices as Price[]),
      vatIncluded: magPriceFormat.isVatIncluded === 'true' ? magPriceFormat.vatIncludedMessage : '',
      productMassDetails: this.common.getproductMassDetail(
        lineItemDraft.variant?.attributes as Attribute[],
        magPriceFormat,
        lineItemDraft.variant?.prices as Price[],
      ),
      name: lineItemDraft.name,
      url: this.common.getProductUrl(market, lineItemDraft),
      images: lineItemDraft.variant?.images?.map((image: Image, index: number) => {
        return {
          url: image.url,
          assetType: image.label,
          sequence: index,
        };
      }) as LineItemDto['images'],
    };
  }
}
