import { Customer } from '@commercetools/platform-sdk';
import { CustomerResponseDto, GraphQLCustomerResponse } from '../dtos';
import { AddressMapper } from './address.mapper';

export interface CustomerMapperConfig {
  addressMapper: AddressMapper;
}

export class CustomerMapper {
  private readonly addressMapper: AddressMapper;

  constructor(config: CustomerMapperConfig) {
    this.addressMapper = config.addressMapper;
  }

  public mapCustomerResponse(
    customerDto: Customer,
  ): CustomerResponseDto {
    return {
      id: customerDto.id,
      firstName: customerDto.firstName,
      lastName: customerDto.lastName,
      email: customerDto.email,
      optIn: customerDto.custom?.fields?.OptIn,
      phoneNumber: customerDto.custom?.fields?.PhoneNumber,
      termsAndConditions: customerDto.custom?.fields?.TermsAndConditions,
      addresses: customerDto.addresses.map((address) =>
        this.addressMapper.mapAddressResponse(address, customerDto)),
    };
  }

  public mapGraphQLCustomerResponse(
    customerDto: GraphQLCustomerResponse,
    mapAddress?: boolean,
  ): CustomerResponseDto {
    let customFieldsRaw;
    if (customerDto?.custom) {
      customFieldsRaw = customerDto.custom.customFieldsRaw.reduce((result, custom) => {
        // eslint-disable-next-line no-param-reassign
        result[custom.name] = custom.value;
        return result;
      }, {});
    }

    let addresses;
    if (mapAddress) {
      addresses = customerDto.addresses.map((address) =>
        this.addressMapper.mapGraphQLAddressResponse(address, customerDto));
    }
    return {
      id: customerDto.id,
      firstName: customerDto.firstName,
      lastName: customerDto.lastName,
      email: customerDto.email,
      optIn: customFieldsRaw?.OptIn,
      phoneNumber: customFieldsRaw?.PhoneNumber,
      addresses,
    };
  }
}
