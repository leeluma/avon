import {
  GraphQLOrder,
  PromotionDto,
} from '../dtos';
import { Common } from '../lib';

export interface PromotionMapperConfig {
  common: Common;
}

export class PromotionMapper {
  private readonly common: Common;

  constructor(config: PromotionMapperConfig) {
    this.common = config.common;
  }

  public mapPromotionResponse(
    order: GraphQLOrder,
  ): PromotionDto | undefined {
    let promotionId = '';
    let promotionCode;
    let promotionState: string | undefined;
    let totalPromotionAmount = 0.0;
    let promotionApplied = false;
    /* istanbul ignore else */
    if (Array.isArray(order.discountCodes) && order.discountCodes[0]) {
      promotionState = order.discountCodes[0].state;
      promotionId = order.discountCodes[0].discountCode.id;
      promotionCode = order.discountCodes[0].discountCode.code;
      /* istanbul ignore else */
      if (order.discountCodes[0].state === 'MatchesCart') {
        promotionApplied = true;
      }
      order.lineItems.forEach((lineItem) => {
        /* istanbul ignore else */
        if (
          Array.isArray(lineItem.discountedPricePerQuantity)
          && lineItem.discountedPricePerQuantity.length
        ) {
          lineItem.discountedPricePerQuantity.forEach((discount) => {
            discount.discountedPrice.includedDiscounts.forEach((element) => {
              totalPromotionAmount
                += element.discountedAmount.centAmount * discount.quantity;
            });
          });
        }
      });
    }
    const promotionDto: PromotionDto = {
      promotionId,
      promotionCode,
      promotionAmount: Number(
        this.common.priceConverter(
          totalPromotionAmount,
          order.totalPrice.fractionDigits,
        ),
      ),
      formattedPromotionAmount: this.common.priceConverter(
        totalPromotionAmount,
        order.totalPrice.fractionDigits,
      ),
      promotionState,
      promotionApplied,
    };
    return promotionDto;
  }
}
