import {
  GraphQLPaymentInfo,
  PaymentInfoDto,
} from '../dtos';
import { Common } from '../lib';

export interface PaymentInfoMapperConfig {
  common: Common;
}

export class PaymentInfoMapper {
  private readonly common: Common;

  constructor(config: PaymentInfoMapperConfig) {
    this.common = config.common;
  }

  /**
   * Get payment information data
   * @param paymentInfo GraphQLPaymentInfo
   * @returns PaymentInfoDto
   */
  public mapPaymentInfoResponse(
    paymentInfo: GraphQLPaymentInfo,
  ): PaymentInfoDto {
    return {
      paymentStatus: paymentInfo.payments[0].paymentStatus.state?.name,
      paymentType: paymentInfo.payments[0].paymentMethodInfo.method,
      paymentAmount: `${this.common.priceConverter(
        paymentInfo.payments[0].amountPlanned.centAmount,
        paymentInfo.payments[0].amountPlanned.fractionDigits,
      )} ${paymentInfo.payments[0].amountPlanned.currencyCode}`,
    };
  }
}
