import { Address, AddressDraft, Customer } from '@commercetools/platform-sdk';
import {
  AddressResponseDto,
  AddressCollectionResponseDto,
  GraphQLAddress,
  GraphQLCustomerResponse,
  DetailResponseDto,
  AddressRequestDto,
} from '../dtos';
import { addressCustomTypeKey, MarketInfo } from '../lib';

export class AddressMapper {
  public mapAddressResponse(
    addressDto: Address,
    customerDto?: Customer,
  ): AddressResponseDto {
    return {
      id: addressDto.id,
      customerId: customerDto?.id,
      firstName: addressDto?.firstName,
      lastName: addressDto?.lastName,
      address1: addressDto.custom?.fields.Address1,
      address2: addressDto.custom?.fields.Address2,
      address3: addressDto.custom?.fields.Address3,
      address4: addressDto.custom?.fields.Address4,
      recipientName: addressDto.custom?.fields.RecipientName,
      county: addressDto.custom?.fields.county,
      latitude: addressDto.custom?.fields.Latitude,
      longitude: addressDto.custom?.fields.Longitude,
      city: addressDto.city,
      region: addressDto.region,
      country: addressDto.country,
      state: addressDto.state,
      phoneNumber: addressDto.phone,
      zip: addressDto.postalCode,
      isShippingAddress: customerDto?.shippingAddressIds?.includes(addressDto.id!),
      isBillingAddress: customerDto?.billingAddressIds?.includes(addressDto.id!),
    };
  }

  public mapGraphQLAddressResponse(
    addressDto: GraphQLAddress,
    customerDto?: GraphQLCustomerResponse,
  ): AddressResponseDto {
    let customFieldsRaw;
    let isShippingAddress;
    let isBillingAddress;
    if (addressDto?.custom) {
      customFieldsRaw = addressDto.custom.customFieldsRaw.reduce((result, custom) => {
        // eslint-disable-next-line no-param-reassign
        result[custom.name] = custom.value;
        return result;
      }, {});
    }

    if (addressDto?.id) {
      isShippingAddress = customerDto?.shippingAddressIds?.includes(addressDto.id!); // NOSONAR
      isBillingAddress = customerDto?.billingAddressIds?.includes(addressDto.id!); // NOSONAR
    }

    return {
      id: addressDto?.id,
      customerId: customerDto?.id,
      firstName: addressDto?.firstName,
      lastName: addressDto?.lastName,
      recipientName: customFieldsRaw?.RecipientName,
      address1: customFieldsRaw?.Address1,
      address2: customFieldsRaw?.Address2,
      address3: customFieldsRaw?.Address3,
      address4: customFieldsRaw?.Address4,
      county: customFieldsRaw?.county,
      latitude: customFieldsRaw?.Latitude,
      longitude: customFieldsRaw?.Longitude,
      city: addressDto?.city,
      region: addressDto?.region,
      country: addressDto?.country,
      state: addressDto?.state,
      phoneNumber: addressDto?.phone,
      zip: addressDto?.postalCode,
      isShippingAddress,
      isBillingAddress,
    };
  }

  public mapAddressCollectionResponse(
    customerDto: Customer,
  ): AddressCollectionResponseDto {
    return {
      addresses: customerDto.addresses.map((address) =>
        this.mapAddressResponse(address, customerDto)),
    };
  }

  public createAddressDraftFromDetails(
    market: MarketInfo,
    detail: DetailResponseDto,
    key: string,
    id?: string,
  ): AddressDraft {
    const addressDetail = JSON.parse(JSON.stringify(detail).replace(/:null/gi, ':""'));
    return {
      custom: {
        type: { typeId: 'type', key: addressCustomTypeKey },
        fields: {
          RecipientName: addressDetail.recipientName,
          Address1: `${addressDetail.streetName || ''} ${addressDetail.houseNumber || ''}`.trim(),
          Address2: `${addressDetail.floor || ''} ${addressDetail.flat || ''}`.trim(),
          Address3: addressDetail.district1,
          Address4: undefined,
          county: addressDetail.region1,
          Latitude: addressDetail.latitude,
          Longitude: addressDetail.longitude,
        },
      },
      country: market.country,
      city: addressDetail.city,
      region: addressDetail.region2,
      postalCode: addressDetail.zipCode,
      state: undefined,
      phone: addressDetail.phoneNumber,
      firstName: addressDetail.firstName,
      lastName: addressDetail.lastName,
      key,
      id,
    };
  }

  public createAddressDraft(
    market: MarketInfo,
    customerDto: Customer,
    addressRequestDto: AddressRequestDto,
    key: string,
    id?: string,
  ): AddressDraft {
    const firstName = `${addressRequestDto.firstName || customerDto.firstName}`;
    const lastName = `${addressRequestDto.lastName || customerDto.lastName}`;
    const recipientName = `${firstName} ${lastName}`;
    return {
      custom: {
        type: {
          typeId: 'type',
          key: addressCustomTypeKey,
        },
        fields: {
          Address1: addressRequestDto.address1,
          Address2: addressRequestDto.address2,
          Address3: addressRequestDto.address3,
          Address4: addressRequestDto.address4,
          county: addressRequestDto.county,
          Latitude: addressRequestDto.latitude,
          Longitude: addressRequestDto.longitude,
          RecipientName: recipientName,
        },
      },
      country: market.country,
      city: addressRequestDto.city,
      region: addressRequestDto.region,
      postalCode: addressRequestDto.zip,
      state: addressRequestDto.state,
      phone: addressRequestDto.phoneNumber,
      firstName,
      lastName,
      key,
      id,
    };
  }
}
