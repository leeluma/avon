import {
  Price, Product, Attribute,
} from '@commercetools/platform-sdk';
import {
  ATTRIBUTE_NAMES,
  ATTRIBUTE_VALUES, CATEGORY_TYPE, DEFAULT_QUANTITY, MEASUREMENT, VARIANT_ATTRIBUTES,
} from '../common/constants';
import {
  GraphQLLineItem,
  GraphQLOrder,
  OffersDto,
  OrderDto,
  OrderLineItem,
  MyOrdersResponse,
  PriceFormat,
  CommonResponse,
} from '../dtos';
import { MarketInfo } from '../lib';
import { AddressMapper } from './address.mapper';
import { Common } from '../lib/common';
import { ShippingInfoMapper } from './shipping-info.mapper';
import { PromotionMapper } from './promotion.mapper';
import { PaymentInfoMapper } from './payment-info.mapper';

export interface OrderMapperConfig {
  addressMapper: AddressMapper;
  shippingInfoMapper: ShippingInfoMapper;
  promotionMapper: PromotionMapper;
  paymentInfoMapper: PaymentInfoMapper;
  common: Common;
}

export class OrderMapper {
  private readonly addressMapper: AddressMapper;

  private readonly common: Common;

  private readonly shippingInfoMapper: ShippingInfoMapper;

  private readonly promotionMapper: PromotionMapper;

  private readonly paymentInfoMapper: PaymentInfoMapper;

  constructor(config: OrderMapperConfig) {
    this.addressMapper = config.addressMapper;
    this.common = config.common;
    this.shippingInfoMapper = config.shippingInfoMapper;
    this.promotionMapper = config.promotionMapper;
    this.paymentInfoMapper = config.paymentInfoMapper;
  }

  /**
   * Function to map graphQL response of order data
   * @param orderData
   */
  public mapOrderDetails(
    orderData: GraphQLOrder,
    market: MarketInfo,
    priceFormat: PriceFormat,
    productDetails: Product[],
  ): OrderDto {
    const { currencyCode, fractionDigits, centAmount } = orderData.totalPrice;
    const totalInvoiceAmount = Number(
      this.common.priceConverter(centAmount, fractionDigits),
    );
    const shippingInfo = this.shippingInfoMapper.mapShippingInfoResponse(orderData.shippingInfo);
    let totalRetailPriceAmount = orderData.totalPrice.centAmount;
    if (shippingInfo?.shippingPrice !== undefined && Number(shippingInfo?.shippingPrice) > 0) {
      totalRetailPriceAmount -= Number(shippingInfo?.shippingPrice);
    }

    return {
      id: orderData.id,
      version: orderData.version,
      orderNumber: orderData.orderNumber,
      customerId: orderData.customerId,
      orderState: orderData.orderState,
      totalRetailPriceAmount: this.common.priceConverter(totalRetailPriceAmount, fractionDigits),
      totalInvoiceAmount,
      formattedTotalPrice: `${this.common.priceConverter(totalRetailPriceAmount, fractionDigits)} ${currencyCode}`,
      formattedTotalInvoiceAmount: `${totalInvoiceAmount} ${orderData.totalPrice.currencyCode}`,
      currencyCode: orderData.totalPrice.currencyCode,
      customerEmail: orderData.customerEmail,
      lineItems: this.getLineItems(orderData.lineItems, priceFormat, productDetails),
      shippingAddressType: this.getShippingAddressType(orderData.custom?.customFieldsRaw),
      shippingAddress: this.addressMapper.mapGraphQLAddressResponse(orderData.shippingAddress),
      shippingInfo,
      billingAddress: this.addressMapper.mapGraphQLAddressResponse(orderData.billingAddress),
      promotion: this.promotionMapper.mapPromotionResponse(orderData),
      paymentInfo: this.paymentInfoMapper.mapPaymentInfoResponse(orderData.paymentInfo),
    };
  }

  /**
   * Map cart line item product ids in string
   * @param lineItems cart line item
   * @returns string of all product ids
   */
  public getCartProductId = (lineItems: GraphQLLineItem[]): string => {
    return lineItems
      .map((lineItem) => {
        return `"${lineItem.productId}"`;
      })
      .join(', ');
  };

  public getShippingAddressType = (custom): string => {
    let result;
    custom.find((item) => {
      if (item.name === 'shippingAddressType') {
        result = item.value;
      }
      return null;
    });
    return result;
  };

  public getLineItems(lineItems: GraphQLLineItem[], priceFormat: PriceFormat, productDetails: Product[])
  : OrderLineItem[] {
    let fulfilledOfferCategoryId: string;
    return lineItems.map((lineItem) => {
      const variantAttributes = this.getProductAttributes(lineItem.variant.attributesRaw);
      const {
        sellPrice,
        listPrice,
        sellPriceCT,
        listPriceCT,
      } = this.checkChannelGraphql(lineItem.variant.prices ?? []);
      if (lineItem?.discountedPricePerQuantity.length > 0) {
        fulfilledOfferCategoryId = lineItem?.discountedPricePerQuantity[0]
          ?.discountedPrice?.includedDiscounts[0]?.discount?.obj?.custom?.fields['offer-category'].id;
      }
      const lineItemData : OrderLineItem = {
        lineItemId: lineItem.id,
        productId: lineItem.productId,
        productSlug: this.common.getUrl(lineItem.productSlug),
        name: lineItem.name,
        skuCode: lineItem.variant.sku,
        images: lineItem.variant.images,
        sellPrice: Number(sellPrice),
        listPrice: Number(listPrice),
        formattedListPrice: this.getPriceFormatDetails(listPriceCT, priceFormat),
        formattedSellPrice: this.getPriceFormatDetails(sellPriceCT, priceFormat),
        unitPrice: this.getUnitPrice(lineItem.variant.attributesRaw as [], Number(sellPriceCT), priceFormat),
        quantity: lineItem.quantity,
        offers: this.getProductOffer(
          productDetails,
          lineItem.productId,
          fulfilledOfferCategoryId,
        ),
        totalPrice: (lineItem.totalPrice.centAmount
        / (DEFAULT_QUANTITY.BASE_NUMBER ** (lineItem.totalPrice.fractionDigits))),
        currencyCode: lineItem.totalPrice.currencyCode,
        variantType: variantAttributes.variantType ?? '',
        variantValue: variantAttributes.variantValue ?? '',
        hexCode: variantAttributes.hexCode ?? '',
      };
      return lineItemData;
    });
  }

  /**
   * Maps fulfilled or missed offer info
   * @param productDetails - productDetails
   * @param productId - productId
   * @param fulfilledOfferCategoryId - fulfilledOfferCategoryId
   * @returns fulfilled or missed offer details
   */
  private readonly getProductOffer = (
    productDetails: Product[],
    productId: string,
    fulfilledOfferCategoryId: string,
  ): OffersDto[] => {
    const offerArray: OffersDto[] = [];
    // match category id to get fulfilled offers
    for (let index = 0; index < productDetails?.length; index += 1) {
      if (productDetails[index].id === productId) {
        let offerObj: OffersDto;
        productDetails[index]?.masterData?.current?.categories.forEach(
          (category: CommonResponse) => {
            if ((category?.custom?.customFieldsRaw.length > 0)
              && (category?.custom?.customFieldsRaw[0].value !== undefined)
              && (category?.custom?.customFieldsRaw[0].value === CATEGORY_TYPE.offer)) {
              offerObj = {
                key: category.key,
                displayName: category.name ?? '',
                url: category.slug ? `/c/${category.slug}` : '',
                description: category.description ?? '',
                fulfilled: category.id === fulfilledOfferCategoryId,
              };
              offerArray.push(offerObj);
            }
          },
        );
      }
    }
    return offerArray;
  };

  /**
   * @param attributes all variant attributes
   * @param sellPrice : variant sell price after discount
   * @param locale : market locale
   * @returns : string with unit price measurement
   */
  private readonly getUnitPrice = (
    attributes:Attribute[],
    sellPrice:number,
    priceFormat: PriceFormat,
  ):string => {
    let allBaseNodes;
    let measuredValue;
    let result = '';
    let formattedPrice;
    const unitFillMeasureObj = this.getObjectValue(attributes, 'contentFillMeasurement');
    const unitFillValueObj = this.getObjectValue(attributes, 'contentFill');
    const unitFillMeasure = this.getUnitFillValue(unitFillMeasureObj, '');
    const unitFillValue = this.getUnitFillValue(unitFillValueObj, '');
    const allNodes = {};
    /* istanbul ignore else */
    if (Object.keys(priceFormat).length > 0 && (unitFillMeasure !== '') && (unitFillValue !== '')) {
      // normalizing unit price json response
      if ((MEASUREMENT.baseMeasure in priceFormat) && (MEASUREMENT.nodes in priceFormat.baseMeasure)) {
        allBaseNodes = priceFormat.baseMeasure[MEASUREMENT.nodes];
        allBaseNodes.forEach((key) => {
          allNodes[priceFormat.baseMeasure[key].unitType] = priceFormat.baseMeasure[key];
          return allNodes;
        });
      }
      // get Unit Price Measurement details
      if ((unitFillMeasure in allNodes) && (unitFillValue > allNodes[unitFillMeasure].containerSizeLimit)) {
        measuredValue = sellPrice * (allNodes[unitFillMeasure].unitPriceBaseMeasure / unitFillValue);
        formattedPrice = this.getPriceFormatDetails(Math.round(measuredValue), priceFormat);
        result = `${formattedPrice} per ${allNodes[unitFillMeasure].unitPriceBaseMeasure}`
              + `${allNodes[unitFillMeasure].translation}`;
      }
    }
    return result;
  };

  public getObjectValue(attributes:Attribute[], key: string) {
    return attributes.find((value) => value.name === ATTRIBUTE_NAMES[key]);
  }

  public getUnitFillValue(unitFillObj, action : string) {
    return ((typeof unitFillObj !== 'undefined')
&& (ATTRIBUTE_VALUES.attributeValue in unitFillObj)) ? unitFillObj.value.key : action;
  }

  /**
   * Check variant prices have channel price
   * @param prices variants prices
   * @returns
   */
  private readonly checkChannelGraphql = (prices: Price[]) => {
    const priceWithoutChannel = prices.find((attribute) => (attribute.channel === undefined
        || attribute.channel === null));
    const [firstPrice] = prices;
    return this.checkDiscount(priceWithoutChannel ?? firstPrice);
  };

  /**
   * Check if product price have discount property then return sell price after applied promotion
   * if discount property not available then return empty object
   * @param price  - All price details including promotional prices
   * @returns - sellPrice and isPromotionApplied
   */
  private readonly checkDiscount = (price: Price) => {
    if (Object.prototype.hasOwnProperty.call(price, 'discounted') && price.discounted) {
      return {
        sellPrice: this.common.priceConverter(price.discounted.value.centAmount, price.discounted.value.fractionDigits),
        listPrice: this.common.priceConverter(price.value.centAmount, price.value.fractionDigits),
        sellPriceCT: price.discounted.value.centAmount,
        listPriceCT: price.value.centAmount,
        isPromotionApplied: true,
      };
    }
    return {
      sellPrice: this.common.priceConverter(price.value.centAmount, price.value.fractionDigits),
      listPrice: this.common.priceConverter(price.value.centAmount, price.value.fractionDigits),
      sellPriceCT: price.value.centAmount,
      listPriceCT: price.value.centAmount,
      isPromotionApplied: false,
    };
  };

  /**
   *
   * @param price :price
   * @param locale : Locale of market
   * @returns Formatted price
   */
  private readonly getPriceFormatDetails = (price: number, priceFormat: PriceFormat): string => {
    let returnPrice: string;
    let calculatedPrice = '';
    const currency1: string = (typeof priceFormat.ccy !== 'undefined') ? priceFormat.ccy : '';
    const showDecimalZero = Boolean(priceFormat.showDecimalZero ?? false);
    const noOfDigitAtLast = Number(priceFormat.noOfDigit ?? 0);
    const decimalPoint: string = priceFormat.decimalPoint ?? '.';
    const thousandSeparator: string = priceFormat.thousandSeperator ?? '';
    const currencyPlacement: string = priceFormat.currencyPlacement ?? 'after';
    const lastDigitNo: number = DEFAULT_QUANTITY.BASE_NUMBER ** noOfDigitAtLast;

    const sellPrice = Number((price / lastDigitNo).toFixed(noOfDigitAtLast));
    const parts = sellPrice.toString().split('.');
    if (showDecimalZero === true) {
      returnPrice = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator)
            + (parts[1] ? decimalPoint + parts[1] : '');
    } else {
      returnPrice = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator);
    }
    calculatedPrice = (currencyPlacement === 'before')
      ? `${currency1} ${returnPrice}` : `${returnPrice} ${currency1}`;
    // }
    return calculatedPrice;
  };

  /**
   * maps attributes
   * @param attributes
   */
  private getProductAttributes(attributes) {
    const variantArr = attributes.map((attribute) => {
      const variantAttributesValue = Object.values(VARIANT_ATTRIBUTES);

      if (variantAttributesValue.includes(attribute.name)) {
        return { [attribute.name]: attribute?.value?.key ? attribute?.value?.label : attribute?.value };
      }
      return undefined;
    });
    return Object.assign({}, ...variantArr);
  }

  /**
   * Mapping of order response
   * @param orderDto - order Object
   * @param locale - locale
   * @returns order response Object
   */
  public createOrderResponse(
    orderDto: GraphQLOrder,
    priceFormat: PriceFormat,
  ):MyOrdersResponse {
    return {
      id: orderDto.id,
      customerId: orderDto.customerId,
      totalPrice: (orderDto.totalPrice.centAmount
          / (DEFAULT_QUANTITY.BASE_NUMBER ** (orderDto.totalPrice.fractionDigits))),
      formattedTotalPrice: this.getPriceFormatDetails(orderDto.totalPrice.centAmount, priceFormat),
      currencyCode: orderDto.totalPrice.currencyCode,
      orderSlug: `/o/${orderDto.id}`,
      orderStatus: orderDto.orderState,
      orderDate: orderDto.createdAt,
      itemsCount: orderDto.lineItems.reduce((a, items) => { return a + items.quantity; }, 0),
    };
  }
}
