import {
  header, param, check,
} from 'express-validator';

export const validateId = param('id').isUUID().withMessage('datatype.uuid');
export const validateOrderIdAndBearerToken = [
  param('orderId')
    .exists({ checkNull: true, checkFalsy: true })
    .isUUID()
    .withMessage('validationError.idMustExistAndValidUuid'),
  header('Authorization').notEmpty().withMessage('validationError.authorizationRequired'),
];
export const validateCustomerId = param('customerId').isUUID().withMessage('datatype.uuid');
export const validateAddressId = param('addressId').notEmpty().withMessage('common.empty');
export const validateBearerToken = header('Authorization').notEmpty().withMessage('common.notEmpty');

export const fieldValidator = (fieldName: string) => check(fieldName).custom(async (value, { req }) => {
  const {
    [fieldName]: {
      required,
      regex,
      regexMsg,
      blankMsg,
      invalidMsg,
      notMatchMsg,
    },
  } = (req as any).validationSettings;

  if (req.body.addressFinderId) {
    if (value && regex && fieldName === 'phoneNumber' && !value.match(regex)) {
      const msg = invalidMsg ?? regexMsg;
      throw new Error(msg);
    }
    return true;
  }

  if (!value && required) {
    throw new Error(required);
  }
  if (!value && blankMsg) {
    throw new Error(blankMsg);
  }

  if (value && regex && !value.match(regex)) {
    const msg = invalidMsg ?? regexMsg;
    throw new Error(msg);
  }
  if (value && fieldName === 'confirmPassword' && req.body.password) {
    if (value !== req.body.password) {
      throw new Error(notMatchMsg);
    }
  }

  return true;
});
