import { header } from 'express-validator';

export const validateAuthorizeToken = [
  header('Authorization').notEmpty().withMessage('common.notEmpty'),
];
