import { query, body, oneOf } from 'express-validator';

export const validateAddresses = [
  query('address')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.addressIsMandatory'),
];

export const validateAddressFinderId = [
  query('addressId')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.addressIdMandatory'),
];

export const validateAddress = [
  query('addressId')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.addressIdMandantory'),

  query('isDelivery').optional().isBoolean()
    .withMessage('common.boolean'),
  query('isBilling').optional().isBoolean()
    .withMessage('common.boolean'),
];

export const validateIsBilling = [
  body('isBilling').notEmpty().withMessage('common.notEmpty').isBoolean(
    { strict: true },
  )
    .withMessage('common.boolean'),
];

export const validateIsDelivery = [
  body('isDelivery').notEmpty().withMessage('common.notEmpty').isBoolean({
    strict: true,
  })
    .withMessage('common.boolean'),
];

export const defaultAddress = [
  oneOf([
    validateIsBilling,
    validateIsDelivery,
  ]),
];
