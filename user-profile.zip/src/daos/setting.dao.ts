import axios from 'axios';
import { stringLiteral } from '../config';
import { MagnoliaPriceFormatDto } from '../dtos';
import { logger } from '../lib';
import { MarketInfo } from '../middlewares';

export interface SettingDaoConfig {
  magnoliaBasePath: string;
}
const COUNTRY = '{{country}}';
/**
 * `settingDao` data access class for Header
 */
export class SettingDao {
  private readonly magnoliaBasePath: string;

  /**
   * Constructor for `SettingDao` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: SettingDaoConfig) {
    this.magnoliaBasePath = config.magnoliaBasePath;
  }

  /**
   * Reads a price format page from Magnolia.
   * @param _market - MarketInfo
   * @returns Object of `MagnoliaPriceDto`
   */
  public async getPriceFormat(market: MarketInfo): Promise<MagnoliaPriceFormatDto> {
    const { locale, country } = market;
    const configUrl = {
      method: 'get' as const,
      url: `${this.magnoliaBasePath}${stringLiteral.magnolia.priceFormatUrl
        .replace(COUNTRY, country.toLocaleLowerCase())
        .replace('{{lang}}', locale)}`,
    };
    try {
      const response = await axios(configUrl);
      logger.info(`Status ${response.status}`);
      return response.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Response body: ${error.response?.data}`);
      throw new Error(`Failed to fetch magnolia price format, because: ${error.stack}`);
    }
  }
}
