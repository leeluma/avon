import axios from 'axios';
import { DetailResponseDto, NormalizedAddress } from '../dtos';
import { logger } from '../lib';

/**
 * `AddressDao` data access class for CommerceTools `addresses`
 */
export class AddressDao {
  /**
   * Constructor for `AddressDaoConfig`
   * @param config injects dependencies into the object
   */
  /**
   * Get Address Autocomplete
   * @param url
   * @param address
   */
  public async addressAutocomplete(
    url: string,
    address: string | undefined,
  ): Promise<NormalizedAddress[]> {
    try {
      const result = await axios.get(url, {
        params: {
          address,
        },
      });
      return result.data.suggestions.filter((item) => item.exactMatch === true);
    } catch (err: any) { // NOSONAR
      logger.error(`Failed to get address autocomplete from url ${url}, because: ${err}`);
      throw err;
    }
  }

  /**
   * Get Address Detail
   * @param url
   * @param addressId
   */
  public async addressDetail(
    url: string,
    addressId: string,
  ): Promise<DetailResponseDto> {
    try {
      const result = await axios.get(url, {
        params: {
          addressId,
        },
      });
      return result.data;
    } catch (err: any) { // NOSONAR
      logger.error(`Failed to get address details from url ${url}, because: ${err}`);
      throw err;
    }
  }
}
