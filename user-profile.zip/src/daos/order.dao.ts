import {
  ClientResponse, GraphQLResponse, Product,
} from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { MarketInfo } from '../middlewares';
import { CtClient, ApiError, logger } from '../lib';
import { graphql } from '../graphql';
import { GraphQLOrder, GraphQLOrderList } from '../dtos';

export interface OrderDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

/**
 * `OrderDao` data access class for CommerceTools `order`
 */
export class OrderDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `CtOderDraftDto` class
   * @param config injects dependencies into the object
   */
  constructor(config: OrderDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
   * Reads all Orders from CommerceTools
   * @param market - MarketInfo
   * @param customerId - Id of Commerce tool Order to retrieve
   * @returns Fetched OrdersDao (or undefined if the Orders don't exist)
   */
  public async find(
    market: MarketInfo,
    authHeader: string,
    limit: number,
    sort: string,
    offset: number,
  ): Promise<GraphQLOrderList | undefined> {
    try {
      const locale = market.locale.toLocaleUpperCase();
      const body = {
        query: await this.graphql.getCustomerOrders,
        variables: {
          locale,
          limit,
          offset,
          sort: [`createdAt ${sort}`],
        },
      };
      const orders: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          headers: {
            Authorization: authHeader,
          },
          body,
        })
        .execute();
      return orders.body.data.me.orders;
    } catch (err: any) { // NOSONAR
      logger.error(`from Commerce tool, because:\n${err.stack}`);
      if (err.body?.statusCode) {
        throw new ApiError(err.body.statusCode, err.body.errors);
      }
      throw err;
    }
  }

  /**
   * Fetch order details data based on order id using GraphQL
   * @param market - Market info
   * @param orderId - Order id
   * @returns - Order details
   */
  public async fetchOrder(
    authHeader: string,
    market: MarketInfo,
    orderId: string,
  ): Promise<GraphQLOrder> {
    const body = {
      query: await this.graphql.getCustomerOrderDetails,
      variables: {
        orderId,
        locale: market.locale,
      },
    };
    let ctResponse: ClientResponse<GraphQLResponse>;

    try {
      ctResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          headers: {
            Authorization: authHeader,
          },
          body,
        })
        .execute();
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`from Commerce tool, because:\n${err.stack}`);
      if (err.body?.statusCode) {
        throw new ApiError(err.body.statusCode, err.body.errors);
      }
      throw err;
    }
    return ctResponse?.body?.data?.me.order;
  }

  /**
   * Fetch products data based on provided ids using GraphQL
   * @param market - Market info
   * @param productIds - multiple product ids as comma separated
   * @returns - product details
   */
  public async fetchProductsDetail(
    market: MarketInfo,
    productIds: string,
  ): Promise<Product[] | undefined> {
    const body = {
      query: await this.graphql.getProducts,
      variables: {
        where: `id in (${productIds})`,
        locale: market.locale,
      },
    };

    let ctResponse: ClientResponse<GraphQLResponse>;

    try {
      ctResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body })
        .execute();
      if (ctResponse.body?.data === null && ctResponse.body?.errors?.length !== undefined) {
        throw new ApiError(
          HttpStatusCodes.BAD_REQUEST,
          i18next.t('error.productsInvalidUuid'),
        );
      }
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
        + ` GraphQL returned: ${JSON.stringify(err.body?.errors)}.`);
      throw err;
    }
    return ctResponse.body?.data?.products.results ?? undefined;
  }
}
