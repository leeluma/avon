import {
  Customer, ClientResponse, Update, CustomerUpdate,
  CustomerDraft, GraphQLResponse, CustomerChangePassword, MyCustomerUpdate, CustomerSignin, CartUpdate,
} from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { graphql } from '../graphql';
import { MarketInfo } from '../middlewares';
import { logger, CtClient, ApiError } from '../lib';
import { CustomerForgotPassword, GraphQLCustomerResponse, LoginCustomerDto } from '../dtos';
import { config } from '../config';

export interface CustomerDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

/**
 * `CustomerDao` data access class for CommerceTools `customer`
 */
export class CustomerDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `customerDraftDto` class
   * @param configs injects dependencies into the object
   */
  constructor(configs: CustomerDaoConfig) {
    this.ctClient = configs.ctClient;
    this.graphql = configs.graphql;
  }

  /**
   * Creates a customerDao for Customer
   * @param market - MarketInfo
   * @param customerDraft - Draft for customerDraft to be created
   * @returns customerResponse
   */
  public async create(
    market: MarketInfo,
    customerDraft: CustomerDraft,
  ): Promise<Customer> {
    try {
      const country = market.country.toLocaleUpperCase();

      const response = await this.ctClient.getClient(country)
        .customers()
        .post({ body: customerDraft }).execute();
      return response.body.customer;
    } catch (err: any) { // NOSONAR
      logger.error(`from Commerce Tool, because:\n${err.stack}`);
      if (err.body?.statusCode) {
        throw new ApiError(err.body.statusCode, err.body.errors);
      }
      throw err;
    }
  }

  /** Forgot a Customer's password in CommerceTools
   * @param market - MarketInfo
   * @param email - email
   * @param Url - url
   */
  public async forgotCustomersPassword(
    market: MarketInfo,
    email: string,
  ): Promise<CustomerForgotPassword> {
    try {
      const forgotPasswordResult = await this.ctClient.getClient(market.country)
        .customers()
        .passwordToken()
        .post({ body: { email, ttlMinutes: Number(config.ttlMinutes) } })
        .execute();
      return forgotPasswordResult.body;
    } catch (e: any) { // NOSONAR
      logger.error(`Failed to update customer because:\n${e.stack}`);

      throw new ApiError(HttpStatusCodes.BAD_REQUEST, 'Invalid email id');
    }
  }

  /**
   * Update Customer Address Dao
   * @param market - MarketInfo
   * @param customerId - Customer Id
   * @param payload - Payload to be sent to Commerce Tool
   * @returns Updated Address response
   */
  public async updateCustomer(
    market: MarketInfo,
    customerId: string,
    payload: Update,
  ): Promise<Customer> {
    const response: ClientResponse<Customer> = await this.ctClient.getClient(market.country)
      .customers()
      .withId({ ID: customerId })
      .post({
        body: payload as CustomerUpdate,
      })
      .execute();
    return response.body;
  }

  /**
   * Update Customer Info
   * @param market - MarketInfo
   * @param authHeader - Bearer Token
   * @param payload - Payload to be sent to Commerce Tool
   * @returns Updated Customer response
   */
  public async updateMyCustomer(
    market: MarketInfo,
    authHeader: string,
    payload: MyCustomerUpdate,
  ): Promise<Customer> {
    try {
      const response: ClientResponse<Customer> = await this.ctClient.getClient(market.country)
        .me()
        .post({
          body: payload,
          headers: {
            Authorization: authHeader,
          },
        })
        .execute();
      return response.body;
    } catch (error : any) { // NOSONAR
      logger.error(`Failed to update customer because:\n${error.stack}`);
      throw new ApiError(HttpStatusCodes.FORBIDDEN, 'Invalid customer');
    }
  }

  /**
   * Reads a Customer from CommerceTools
   * @param market - MarketInfo
   * @param customerId - Id of Commerce Tool Customer to retrieve
   * @returns Fetched customerDao (or undefined if the Customer doesn't exist)
   */
  public async findOne(
    market: MarketInfo,
    customerId: string,
  ): Promise<Customer | undefined> {
    const country = market.country.toLocaleUpperCase();

    let customer: ClientResponse<Customer>;
    try {
      customer = await this.ctClient.getClient(country)
        .customers()
        .withId({ ID: customerId })
        .get()
        .execute();
    } catch (err: any) { // NOSONAR
      logger.error(`Failed to retrieve Customer id "${customerId}" from Commerce Tool, because:\n${err.stack}`);

      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        return undefined;
      }
      throw err;
    }
    return customer.body;
  }

  /**
 * Reads a Customer from CommerceTools
 * @param market - MarketInfo
 * @param customerId - Id of Commerce Tool Customer to retrieve
 * @returns Fetched customerDao (or undefined if the Customer doesn't exist)
 */
  public async findGraphQLOne(
    market: MarketInfo,
    customerId: string,
  ): Promise<GraphQLCustomerResponse | undefined> {
    const body = {
      query: await this.graphql.getCustomerById,
      variables: {
        id: customerId,
      },
    };
    const result: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
      .graphql()
      .post({ body })
      .execute();
    const { customer } = result.body.data;
    if (customer === null) {
      return undefined;
    }
    return customer;
  }

  /**
   * Update Customer Password Dao
   * @param market - MarketInfo
   * @param payload - Payload to be sent to commerce tool
   * @returns Updated Customer response
  */
  public async changePassword(
    market: MarketInfo,
    payload: CustomerChangePassword,
    authHeader: string,
  ): Promise<Customer> {
    let response: ClientResponse<Customer>;
    try {
      response = await this.ctClient.getClient(market.country)
        .me()
        .password()
        .post({
          body: payload,
          headers: {
            Authorization: authHeader,
          },
        })
        .execute();
      return response.body;
    } catch (error : any) { // NOSONAR
      logger.error(`Failed to reset customer password because:\n${error.stack}`);
      throw new ApiError(HttpStatusCodes.FORBIDDEN, 'Invalid password');
    }
  }

  /** Reset a Customer's password in CommerceTools
   * @param market - MarketInfo
   * @param tokenValue - Password reset token
   * @param newPassword - New password
   */
  public async resetCustomersPassword(
    market: MarketInfo,
    tokenValue: string,
    newPassword: string,
  ): Promise<boolean> {
    try {
      await this.ctClient.getClient(market.country)
        .customers()
        .passwordReset()
        .post({ body: { tokenValue, newPassword } })
        .execute();

      return true;
    } catch (err) { // NOSONAR
      logger.error(`Failed to reset customer password because:\n${err}`);
      return false;
    }
  }

  /**
   * Update Customer Password Dao
   * @param market - MarketInfo
   * @param payload - Payload to be sent to commerce tool
   * @returns Updated Customer response
  */
  public async setDefaultAddress(
    market: MarketInfo,
    payload: MyCustomerUpdate,
    authHeader: string,
  ): Promise<Customer> {
    let response: ClientResponse<Customer>;
    try {
      response = await this.ctClient.getClient(market.country)
        .me()
        .post({
          body: payload,
          headers: {
            Authorization: authHeader,
          },
        })
        .execute();
      return response.body;
    } catch (error : any) { // NOSONAR
      logger.error(`Failed to set default address because:\n${error.stack}`);
      throw new ApiError(HttpStatusCodes.FORBIDDEN, 'Invalid address id');
    }
  }

  /**
   * Reads a Customer from CommerceTools based on auth token
   * @param market - MarketInfo
   * @param authHeader - customer auth token
   * @returns Fetched customerDao (or undefined if the Customer doesn't exist)
   */
  public async getCustomerDetailsGraphQL(
    market: MarketInfo,
    authHeader: string,
  ): Promise<GraphQLCustomerResponse> {
    try {
      const body = {
        query: await this.graphql.getCustomerByToken,
      };
      const result: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          headers: {
            Authorization: authHeader,
          },
          body,
        })
        .execute();

      const { body: { data: { me: { customer } } } } = result;
      if (!customer) {
        throw new ApiError(
          HttpStatusCodes.NOT_FOUND,
          i18next.t('error.customerNotFound'),
        );
      }
      return customer;
    } catch (error: any) { // NOSONAR
      logger.error(`from Commerce tool, because:\n${error.stack}`);
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, (error?.messageArray) ? error.messageArray : error.message);
      }
      throw error;
    }
  }

  /**
   * Use to retrive customer's login reponse from commercetool.
   * @param market
   * @param CustomerSignin
   */
  public async login(
    market: MarketInfo,
    customerSignin: CustomerSignin,
  ): Promise<LoginCustomerDto> {
    try {
      return await this.ctClient.getAuthClient(market.country)
        .customerPasswordFlow({
          username: customerSignin.email,
          password: customerSignin.password,
        }, {
          disableRefreshToken: false,
        });
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to retrieve auth login info from CT because:\n${error.stack}`);
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, error.errors);
      }
      throw error;
    }
  }

  /**
   * Use to set customer id to anonymous cart.
   * @param market - MarketInfo
   * @param cartId - string Cart id
   * @param version - number Cart version
   * @param customerId - string Customer id
   * */
  public async setCustomerIdToCart(
    market: MarketInfo,
    cartId: string,
    version: number,
    customerId: string,
  ): Promise<void> {
    const body: CartUpdate = {
      version,
      actions: [{
        action: 'setCustomerId',
        customerId,
      }],
    };

    try {
      await this.ctClient.getClient(market.country)
        .carts()
        .withId({ ID: cartId })
        .post({ body })
        .execute();
    } catch (error: any) { // NOSONAR
      logger.error(`Failed to retrieve auth login info from CT because:\n${error.stack}`);
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, error.errors);
      }
      throw error;
    }
  }
}
