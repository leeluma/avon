import {
  CartDraft, CartUpdate, ClientResponse, GraphQLResponse,
} from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import { ApiError, CtClient, logger } from '../lib';
import { MarketInfo } from '../middlewares';
import { graphql } from '../graphql';
import { CartDto, CustomerActiveCartAndWishListDto, GraphQLCartResponseDto } from '../dtos';

export interface CartDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

enum CART_ACTIONS {
  addShoppingList = 'addShoppingList',
  addLineItem = 'addLineItem'
}

/**
 * `CartsDao` data access class for Carts
  Cart,
} from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';

import {
  CtClient, logger,
} from '../lib';

interface CartDaoConfig {
  ctClient: CtClient;
}

/**
 * `CtCartDao` data access class for CommerceTools `Cart`
 */
export class CartDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `CartsDao` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: CartDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
   * Get a Cart by customerId or anonymousId from CT
   * @param market - MarketInfo
   * @param customerId - Customer id
   * @param anonymousId - Anonymous id
   */
  public async getCartById(
    market: MarketInfo,
    cartId: string | undefined,
  ): Promise<GraphQLCartResponseDto | null> {
    const body = {
      query: await this.graphql.getCustomerCart,
      variables: {
        shippingCondition: 'isDefault in ("true")',
        cartId,
        locale: market.locale.toUpperCase(),
      },
    };

    let response: ClientResponse<GraphQLResponse>;
    try {
      response = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body })
        .execute();
    } catch (error: any) { // NOSONAR
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
        + ` GraphQL returned: ${JSON.stringify(error.body.errors)}.`);

      throw error;
    }
    // If the cart doesn't exist, we still get a valid response with a null item
    return response.body.data;
  }

  /**
   * Reads a Cart from CommerceTools
   * @param market - MarketInfo
   * @param cartId - Id of Cart to retrieve
   * @returns Fetched CartDto (or undefined if the Cart doesn't exist)
   */
  public async findOne(
    market: MarketInfo,
    cartId: string,
  ): Promise<CartDto | undefined> {
    try {
      const cart = await this.ctClient.getClient(market.country)
        .carts()
        .withId({ ID: cartId })
        .get()
        .execute();

      return cart.body;
    } catch (err: any) { // NOSONAR
      logger.error(`Failed to retrieve Cart id "${cartId}" from CT, because:\n${err.stack}`);

      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        return undefined;
      }

      throw err;
    }
  }

  /**
   * Creates a Cart in CommerceTools
   * @param market - MarketInfo
   * @param cartDraftDto - Cart to be created
   * @returns Fetched CartDto (or undefined if the Cart doesn't exist)
   */
  public async create(
    market: MarketInfo,
    cartDraftDto: CartDraft,
  ): Promise<CartDto> {
    const cart = await this.ctClient.getClient(market.country)
      .carts()
      .post({ body: cartDraftDto })
      .execute();

    return cart.body;
  }

  /** Adds all `LineItem`s from a `ShoppingList` to a `Cart` */
  public async addShoppingList(
    market: MarketInfo,
    cartId: string,
    cartVersion: number,
    shoppingListId: string,
  ): Promise<void> {
    const body: CartUpdate = {
      version: cartVersion,
      actions: [{
        action: CART_ACTIONS.addShoppingList,
        shoppingList: {
          typeId: 'shopping-list',
          id: shoppingListId,
        },
      }],
    };

    await this.ctClient.getClient(market.country)
      .carts()
      .withId({ ID: cartId })
      .post({ body })
      .execute();
  }

  /**
   * Adds a `LineItem` to a `Cart`
   * @param market - MarketInfo
   * @param cartId - Id of Cart
   * @param cartVersion - Version of Cart
   * @param productId - Id of Product
   * @param variantId - Variant Id
   */

  public async addLineItem(
    market: MarketInfo,
    cartId: string,
    cartVersion: number,
    productId: string,
    variantId: number,
  ): Promise<void> {
    const body : CartUpdate = {
      version: cartVersion,
      actions: [{
        action: CART_ACTIONS.addLineItem,
        productId,
        variantId,
      }],
    };

    await this.ctClient.getClient(market.country)
      .carts()
      .withId({ ID: cartId })
      .post({ body })
      .execute();
  }

  /**
   * Get Active cartId from CommerceTools
   * @param country - string
   * @param cartId - string
   * @returns cart from the commercetools
   */

  public async getCustomerWishlistAndCartId(
    customerId: string,
    authHeader: string,
    market: MarketInfo,
  ): Promise<CustomerActiveCartAndWishListDto> {
    const body = {
      query: await this.graphql.getActiveCartId,
      variables: {
        where: `customer(id="${customerId}")`,
        sort: ['lastModifiedAt Desc'],
        limit: 1,
      },
    };
    let ctResponse: ClientResponse<GraphQLResponse>;

    try {
      ctResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          headers: {
            Authorization: authHeader,
          },
          body,
        })
        .execute();
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`from Commerce tool, because:\n${err.stack}`);
      if (err.body?.statusCode) {
        throw new ApiError(err.body.statusCode, err.body.errors);
      }
      throw err;
    }
    return ctResponse?.body?.data;
  }
}
