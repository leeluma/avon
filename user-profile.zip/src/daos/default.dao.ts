import HttpStatusCodes from 'http-status-codes';
import axios from 'axios';
import { CommonResponse } from '../dtos';
import {
  ApiError, CtClient, logger, URI,
} from '../lib';
import { MarketInfo } from '../middlewares';
import { config } from '../config';
import { axiosOptions } from '../lib/axios-instance';

const {
  ctAuthEndpoint, ctRO: {
    clientId,
    clientSecret,
  },
} = config;

export interface DefaultDaoConfig {
  ctClient: CtClient;
}

/**
 * `defaultDao` data access class for Header
 */
export class DefaultDao {
  private readonly ctClient: CtClient;

  /**
   * Constructor for `DefaultDao` class
   * @param configuration - Injects dependencies into the object
   */
  constructor(configuration: DefaultDaoConfig) {
    this.ctClient = configuration.ctClient;
  }

  /**
   * Get result from Commerce Tool
   * @param market - MarketInfo
   * @param params - Params
   * @returns result
   */
  public async refreshToken(
    market: MarketInfo,
    params,
  ): Promise<CommonResponse> {
    try {
      return await this.ctClient.getAuthClient(market.country).refreshTokenFlow(params);
    } catch (error: any) { // NOSONAR
      logger.error(`Failed to generate refreshToken from Commerce Tool because:\n${error}`);
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, error.errors);
      }
      throw error;
    }
  }

  /**
   * Verify customer tokens from Commerce Tool
   * @param market - MarketInfo
   * @param params - Params
   * @returns result
   */
  public async verifyToken(
    market: MarketInfo,
    params,
  ): Promise<CommonResponse> {
    // eslint-disable-next-line max-len
    const msg = 'Unfortunately, the link you\'ve used has expired. To reset your password, enter your email below & click the link within [x minutes]';
    const message = msg.replace('[x minutes]', `${config.ttlMinutes} minutes`);
    try {
      const confirmToken = await this.ctClient.getClient(market.country)
        .customers()
        .withPasswordToken({ passwordToken: params })
        .get()
        .execute();
      return confirmToken.body;
    } catch (error: any) { // NOSONAR
      logger.error(`Failed to verify token from Commerce Tool because:\n${error}`);
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, message);
      }
      throw error;
    }
  }

  /**
   * logout current token
   * @param authorizeToken - Authorization Token
   * @returns result
   */
  public async logout(
    authorizeToken,
  ): Promise<boolean> {
    try {
      const apiUrl = `${ctAuthEndpoint}${URI.CommerceTool.authToken}${authorizeToken}${URI.CommerceTool.tokenHint}`;
      const token = `${clientId}:${clientSecret}`;

      const encodedToken = Buffer.from(token).toString('base64');
      const configuration = {
        ...axiosOptions,
        method: 'post' as const,
        url: apiUrl,
        headers: { Authorization: `Basic ${encodedToken}` },
      };
      const result = await axios(configuration);
      return result.status === HttpStatusCodes.OK;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to fetch commerce tool auth logout data, because: ${error.stack}`);
      throw error;
    }
  }
}
