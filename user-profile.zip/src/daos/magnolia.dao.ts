import axios, { Axios, AxiosResponse } from 'axios';
import { logger, MarketInfo } from '../lib';
import { MAGNOLIA_URI } from '../common/constants';
import { CommonResponse, MagnoliaDto, MagnoliaInfo } from '../dtos';
import { axiosOptions } from '../lib/axios-instance';

const country = '{{country}}';

interface MagnoliaDaoConfig {
  basePath: string;
  globalSettingUrl: string;
}

/**
 * `MagnoliaDao` data access object for Magnolia Requests`,
 * methods return response from magnolia
 */
export class MagnoliaDao {
  private readonly basePath: string;

  private readonly globalSettingUrl: string;

  constructor(configuration: MagnoliaDaoConfig) {
    this.basePath = configuration.basePath;
    this.globalSettingUrl = configuration.globalSettingUrl;
  }

  /**
   * Reads a Global Setting from Magnolia.
   * @param market - MarketInfo
   * @returns `Global Setting`
   */
  public async getGlobalSetting(
    market: MarketInfo,
    magnolia?: MagnoliaInfo,
  ): Promise<CommonResponse> {
    let response;
    if (!this.basePath) {
      throw new Error('The magnolia "basePath" field in config is missing!');
    }
    if (!this.globalSettingUrl) {
      throw new Error('The magnolia "globalSettingUrl" field in config is missing!');
    }
    const magnoliaPath = magnolia?.url || this.basePath;
    const url = `${magnoliaPath}${this.globalSettingUrl
      .replace(country, market.country.toLowerCase())
      .replace('{{locale}}', market.locale)}`;
    const configUrl = {
      ...axiosOptions,
      method: 'get' as const,
      url,
    };

    try {
      response = await axios(configUrl);
    } catch (error: any) { // NOSONAR
      logger.error(`Response body: ${error.response?.data}`);
      throw new Error(`Failed to fetch global settings, because: ${error.stack}`);
    }
    return response.data;
  }

  /**
   * Get address validation settings data from magnolia
   * @param market - MarketInfo
   */
  public async getAddressSettings(
    market: MarketInfo,
  ) : Promise<MagnoliaDto> {
    try {
      const queryParams = `lang=${market.locale}-${market.country}`;
      let priceFormatSettingsUrl = `${this.basePath}${MAGNOLIA_URI.AddressSettings}?${queryParams}`;
      priceFormatSettingsUrl = priceFormatSettingsUrl.replace(country, `${market.country.toLocaleLowerCase()}`);

      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: priceFormatSettingsUrl,
      };
      const result = await axios(config);

      return result.data;
    } catch (error: any) { // NOSONAR
      //  -- only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch address validation settings data from magnolia, because: ${error.stack}`);
    }
  }

  public async getAccountPageData(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ): Promise<AxiosResponse> {
    const page = (magnolia.isPreview === true && magnolia.marketPath !== market.country.toLocaleLowerCase())
      ? MAGNOLIA_URI.page : MAGNOLIA_URI.userprofilePage;

    const queryParam = `lang=${market.locale}-${market.country}`;
    let checkoutUrl = `${magnolia.url}${page}?${queryParam}`;
    checkoutUrl = checkoutUrl.replace(country, `${magnolia.marketPath}`);
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: checkoutUrl,
    };
    try {
      const pageData = await axios(config);
      return pageData.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch account data from Magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get template data from Magnolia
   * @param templateName magnolia template name
   * @param magnoliaBasePath - string Magnolia API URL base path
   * @returns return template data from Magnolia
   */
  public async getTemplateDataFromMagnolia(
    templateName: string,
    magnoliaBasePath: string,
  ): Promise<Axios> {
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: `${magnoliaBasePath}${MAGNOLIA_URI.template}${templateName}`,
    };
    try {
      const howToLook = await axios(config);
      return howToLook.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch template data from Magnolia, because: ${error.stack}`);
    }
  }
}
