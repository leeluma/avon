import {
  ShoppingList, ShoppingListUpdate,
  ClientResponse, ShoppingListPagedQueryResponse, GraphQLResponse,
} from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import axios from 'axios';
import { MarketInfo } from '../middlewares';
import { CtClient, logger, URI } from '../lib';
import { graphql } from '../graphql';
import { CommonResponse, GraphQLShoppingList, MagnoliaPriceFormatDto } from '../dtos';
import { stringLiteral } from '../config';
import { axiosOptions } from '../lib/axios-instance';

const countryStatic = '{{country}}';

export interface ShoppingListDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

enum SHOPPINGLIST_ACTIONS {
  removeLineItem = 'removeLineItem',
}

/**
 * `ShoppingListDao` data access class for CommerceTools `ShoppingList`
 */
export class ShoppingListDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
     * Constructor for `ShoppingListDao` class
     * @param config injects dependencies into the object
     */
  constructor(config: ShoppingListDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
   * Reads a ShoppingList from CommerceTools
   * @param market - MarketInfo
   * @param shoppingListId - Id of CT ShoppingList to retrieve
   * @returns Fetched CtShoppingListDao (or undefined if the ShoppingList doesn't exist)
   */
  public async findOne(
    market: MarketInfo,
    shoppingListId: string,
  ): Promise<ShoppingList | undefined> {
    const country = market.country.toLocaleUpperCase();

    let shoppingList: ClientResponse<ShoppingList>;
    try {
      shoppingList = await this.ctClient.getClient(country)
        .shoppingLists()
        .withId({ ID: shoppingListId })
        .get({
          queryArgs: { expand: [stringLiteral.graphQL.expand.variant, stringLiteral.graphQL.expand.productSlug] },
        })
        .execute();
    } catch (err: any) { // NOSONAR
      logger.error(`Failed to retrieve ShoppingList id "${shoppingListId}" from CT, because:\n${err.stack}`);

      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        return undefined;
      }

      throw err;
    }
    return shoppingList.body;
  }

  /**
 * Reads a Wishlist from CommerceTools
 * @param market - MarketInfo
 * @param wishListId - Id of CT Wishlist to retrieve
 * @returns Fetched wishlistDao (or undefined if the Wishlist doesn't exist)
 */
  public async findGraphQLOne(
    market: MarketInfo,
    wishListId: string,
  ): Promise<GraphQLShoppingList | undefined> {
    const body = {
      query: await this.graphql.getShoppingListById,
      variables: {
        id: wishListId,
        locale: market.locale,
      },
    };
    try {
      const result: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body })
        .execute();
      const { shoppingList } = result.body.data;
      if (shoppingList === null) {
        return undefined;
      }
      return shoppingList;
    } catch (err: any) { // NOSONAR
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
        + ` GraphQL returned: ${JSON.stringify(err.body.errors)}.`);

      throw err;
    }
  }

  /**
   * Reads a ShoppingList from CommerceTools
   * @param market - MarketInfo
   * @param condition - CT condition
   * @returns Fetched ShoppingListDao (or undefined if the ShoppingList doesn't exist)
   */
  public async findOneBy(
    market: MarketInfo,
    condition: string,
  ): Promise<ShoppingList | undefined> {
    const country = market.country.toLocaleUpperCase();

    let shoppingList: ClientResponse<ShoppingListPagedQueryResponse>;
    try {
      shoppingList = await this.ctClient.getClient(country)
        .shoppingLists()
        .get({
          queryArgs: {
            expand: [stringLiteral.graphQL.expand.variant, stringLiteral.graphQL.expand.productSlug],
            where: condition,
            limit: 1,
          },
        })
        .execute();
    } catch (err: any) { // NOSONAR
      logger.error(`Failed to retrieve ${condition} from CT, because:\n${err.stack}`);

      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        return undefined;
      }

      throw err;
    }

    if (!shoppingList.body) {
      return undefined;
    }

    return shoppingList.body.results[0];
  }

  /** Removes `LineItem`s from a `ShoppingList`
  * @param market - MarketInfo
  * @param shoppingListId - Id of the ShoppingList to be updated
  * @param shoppingListVersion - Version of the ShoppingList to be updated
  * @param lineItemIds - Id of the LineItem to be deleted from ShoppingList
  * @returns ShoppingListDao with Deleted LineItems
  */
  public async deleteLineItems(
    market: MarketInfo,
    shoppingListId: string,
    shoppingListVersion: number,
    lineItemIds: string[],
  ): Promise<ShoppingList> {
    const body: ShoppingListUpdate = {
      version: shoppingListVersion,
      actions: lineItemIds.map((lineItemId) => ({
        action: SHOPPINGLIST_ACTIONS.removeLineItem,
        lineItemId,
      })),
    };

    const result = await this.ctClient.getClient(market.country)
      .shoppingLists()
      .withId({ ID: shoppingListId })
      .post({
        body,
        queryArgs: { expand: [stringLiteral.graphQL.expand.variant, stringLiteral.graphQL.expand.productSlug] },
      })
      .execute();

    return result.body;
  }

  /**
   * Reads a price format page from Magnolia.
   * @param _market - MarketInfo
   * @returns Object of `MagnoliaPriceDto`
   */
  public async getPriceFormat(market: MarketInfo): Promise<MagnoliaPriceFormatDto> {
    const { locale, country } = market;
    const localeAndCountry = `${locale.toLocaleLowerCase()}-${country.toLocaleLowerCase()}`;
    const { MAGNOLIA_BASE_PATH } = process.env;
    const configUrl = {
      method: 'get' as const,
      url: `${MAGNOLIA_BASE_PATH}${URI.magnolia.priceFormatUrl.replace(countryStatic, country.toLocaleLowerCase())
        .replace('{{localeAndCountry}}', localeAndCountry.toLocaleLowerCase())}`,
    };
    try {
      const response = await axios(configUrl);
      logger.info(`Status ${response.status}`);
      return response.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Response body: ${error.response?.data}`);
      throw new Error(`Failed to fetch magnolia price format, because: ${error.stack}`);
    }
  }

  /**
   * Get offer from magnolia
   * @param market - MarketInfo
   * @param magnolia - MagnoliaInfo
   */
  public async getResult(
    url,
  ): Promise<CommonResponse> {
    const configuration = {
      ...axiosOptions,
      method: 'get' as const,
      url,
    };
    try {
      const result = await axios(configuration);
      return result.data;
    } catch (error: any) { // NOSONAR
      throw new Error(`Failed to fetch data , because: ${error.stack}`);
    }
  }
}
