import axios from 'axios';
import {
  NextFunction, Request, Response,
} from 'express';
import { logger, URI } from '../lib';
import { config } from '../config';

const magnoliaBasePath = config.uri.magnolia.basePath;
export enum LogStatus {
  NONE,
  TRACE,
  INFO,
  ERROR
}

export interface LogConfig{
  apptusLogStatus: LogStatus
}

export const apptusLogConfig = async (req: Request, res: Response, next: NextFunction): Promise<void> => {
  if (logger.isDebugEnabled()) {
    let url = `${magnoliaBasePath}${URI.magnolia.logSetting}`;
    url = `${url.replace('{{country}}', res.locals.market.country.toLowerCase())}`;
    url = `${url}?lang=${res.locals.market.localeAndCountry}`;

    axios(url).then((response) => {
      const { apptusLogStatus } = response?.data || LogStatus.NONE;
      res.locals.logConfig = {
        apptusLogStatus: Number(apptusLogStatus),
      };
      next();
    })
      .catch((err) => {
        logger.error(`Unable to fetch aptus log status from magnolia because: ${err.stack}`);
        res.locals.logConfig = {
          apptusLogStatus: LogStatus.NONE,
        };
        next();
      });
  } else {
    res.locals.logConfig = {
      apptusLogStatus: LogStatus.NONE,
    };
    next();
  }
};
