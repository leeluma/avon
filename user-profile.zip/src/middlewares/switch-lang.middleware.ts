import { NextFunction, Request, Response } from 'express';
import i18next from 'i18next';

export const switchLangMiddleware = (req: Request, res: Response, next: NextFunction): void => {
  const { locale } = req.params;
  i18next.changeLanguage(locale);
  next();
};
