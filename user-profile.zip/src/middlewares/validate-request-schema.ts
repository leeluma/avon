import { NextFunction, Request, Response } from 'express';
import { validationResult } from 'express-validator';
import { StatusCodes } from 'http-status-codes';
import i18next from 'i18next';
import { ApiError } from '../lib';

export function validateRequestSchema(
  request: Request,
  response: Response,
  next: NextFunction,
): void {
  const errors = validationResult(request);

  if (!errors.isEmpty()) {
    const err = errors.array().map((e) => {
      e.msg = i18next.t(e.msg);
      // eslint-disable-next-line no-param-reassign
      e.nestedErrors?.forEach((nestedError : any) => { nestedError.msg = i18next.t(nestedError.msg); });
      return e;
    });
    throw new ApiError(StatusCodes.BAD_REQUEST, err);
  } else {
    next();
  }
}
