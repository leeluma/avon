import { NextFunction, Request, Response } from 'express';
import { MEASUREMENT } from '../common/constants';
import { logger, MarketInfo } from '../lib';
import localValidationSettings from '../validators/local-validation-settings.json';

type SettingsReader = (market: MarketInfo) => Promise<any>;

/**
 * Simple object check.
 * @param item
 * @returns {boolean}
 */export function isObject(item) {
  return (item && typeof item === 'object' && !Array.isArray(item));
}

/**
 * Deep merge two objects.
 * @param target
 * @param ...sources
 */
export function mergeDeep(target, ...sources) {
  if (!sources.length) return target;
  const source = sources.shift();

  if (isObject(target) && isObject(source)) {
    Object.keys(source).forEach((key) => {
      if (isObject(source[key])) {
        if (!target[key]) Object.assign(target, { [key]: {} });
        mergeDeep(target[key], source[key]);
      } else {
        Object.assign(target, { [key]: source[key] });
      }
    });
  }

  return mergeDeep(target, ...sources);
}

export const makeValidationSettingsMiddleware = (settingsReader: SettingsReader) => {
  return async (
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> => {
    try {
      (req as any).validationSettings = mergeDeep({}, localValidationSettings, await settingsReader(res.locals.market));
    } catch (err) {
      logger.error(`Failed to retrieve validation settings from Magnolia, because: ${err}`);
      /* Do not re-throw the error! */
      logger.info('Using local settings as fallback');
      (req as any).validationSettings = localValidationSettings;
    }

    next();
  };
};

/**
 * maps validation fields
 * @param addressSettings address setting object from magnolia
 * @returns validation fields object
 */
function formatAddressSettingData(addressSettings) {
  const regex = 'regex';
  let addressValidationObj = {};
  let addressSettingIndex = 0;
  while (addressSettingIndex < addressSettings[MEASUREMENT.nodes].length) {
    const fieldName = addressSettings[MEASUREMENT.nodes][addressSettingIndex];
    let addressValidationsIndex = 0;
    while (addressValidationsIndex < addressSettings[fieldName][MEASUREMENT.nodes].length) {
      const validationKey = addressSettings[fieldName][MEASUREMENT.nodes][addressValidationsIndex];
      let validationsNameIndex = 0;
      while (validationsNameIndex < addressSettings[fieldName][validationKey][MEASUREMENT.nodes].length) {
        const validationName = addressSettings[fieldName][validationKey][MEASUREMENT.nodes][validationsNameIndex];
        const { name } = addressSettings[fieldName];
        const objectKey = addressSettings[fieldName][validationKey][validationName].name;
        const objectMessage = addressSettings[fieldName][validationKey][validationName].message;
        if (objectKey === regex) {
          const objectValue = addressSettings[fieldName][validationKey][validationName].value;
          const a = addressValidationObj?.[name] ?? null;
          addressValidationObj = { ...addressValidationObj, [name]: { ...a, [`${objectKey}`]: objectValue } };
        }

        const b = addressValidationObj?.[name] ?? null;
        addressValidationObj = {
          ...addressValidationObj,
          [name]: {
            ...b, [objectKey === regex ? `${objectKey}Msg` : objectKey]: objectMessage,
          },
        };

        validationsNameIndex += 1;
      }
      addressValidationsIndex += 1;
    }
    addressSettingIndex += 1;
  }
  return addressValidationObj;
}

/**
 * middleware for address validation fields
 * @param settingsReader
 */
export const makeAddressValidationSettingsMiddleware = (settingsReader: SettingsReader) => {
  return async (
    req: Request,
    res: Response,
    next: NextFunction,
  ): Promise<void> => {
    try {
      const addressSettingsData = await settingsReader(res.locals.market);
      const formattedAddressSetting = formatAddressSettingData(addressSettingsData);
      (req as any).validationSettings = mergeDeep({}, localValidationSettings, formattedAddressSetting);
    } catch (err) {
      logger.error(`Failed to retrieve validation settings from Magnolia, because: ${err}`);
      /* Do not re-throw the error! */
      logger.info('Using local settings as fallback');
      (req as any).validationSettings = localValidationSettings;
    }

    next();
  };
};
