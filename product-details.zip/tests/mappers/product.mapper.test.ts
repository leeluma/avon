import faker from '@faker-js/faker';
import ProductMapper from '../../src/mappers/product.mapper';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubCtProductDto, stubCategory, stubGlobalSettings,
} from '../__stubs__';
import { ProductDto, BadgeNode } from '../../src/dtos/product.dto';
import { Category } from '../../src/dtos/product';
import { Common } from '../../src/lib/common';
import { Product } from '../../src/lib/product';
import {
  ATTRIBUTE_NAMES, ATTRIBUTE_VALUES, BADGE_NAMES, BADGE_VALUES,
} from '../../src/common/constant';

describe('ProductMapper', () => {
  let productMapper: ProductMapper;
  let productDto: ProductDto;
  let stubCat: Category;
  let common: Common;
  let product: Product;
  /* Dependencies */

  let market: MarketInfo;
  const catId = faker.datatype.uuid();
  const parentCatId = faker.datatype.uuid();
  const nameValue = {
    name: faker.datatype.string(),
    value: faker.datatype.string(),
  };
  const attributesRaw = [
    {
      name: 'isDiscontinued',
      value: false,
    },
    {
      name: faker.datatype.string(),
      value: {
        key: faker.datatype.string(),
        label: faker.datatype.string(),
      },
    },
    nameValue,
    {
      name: 'startDate',
      value: faker.date.recent(),
    },
    {
      name: 'endDate',
      value: faker.date.future(),
    },
    nameValue,
    nameValue,
    {
      name: ATTRIBUTE_NAMES.contentFillMeasurement,
      value: {
        key: 'g',
        label: faker.datatype.string(),
      },
    },
    {
      name: ATTRIBUTE_NAMES.contentFill,
      value: faker.datatype.number(),
    },
    {
      name: 'excludeCountDown',
      value: false,
    },
    {
      name: ATTRIBUTE_NAMES.badges,
      value: [
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.typeNew,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: 'NOU',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topRight,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.9,
          },
        ],
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.discount,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: '20%',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topLeft,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.2,
          },
        ],
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.bestSeller,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: 'Best Seller',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topRight,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.1,
          },
        ],
      ],
    },
    {
      name: ATTRIBUTE_NAMES.config,
      value: [
        [
          {
            name: 'quantity',
            value: 1,
          },
          {
            name: 'setComponent',
            value: {
              typeId: 'product',
              id: faker.datatype.uuid(),
            },
          },
          {
            name: 'lineNumber',
            value: faker.datatype.number(),
          },
          {
            name: ATTRIBUTE_VALUES.availabilitySku,
            value: faker.datatype.uuid(),
          },
        ],
        [
          {
            name: 'quantity',
            value: 1,
          },
          {
            name: 'setComponent',
            value: {
              typeId: 'product',
              id: faker.datatype.uuid(),
            },
          },
          {
            name: 'lineNumber',
            value: faker.datatype.number(),
          },
          {
            name: ATTRIBUTE_VALUES.availabilitySku,
            value: faker.datatype.uuid(),
          },
        ],
      ],
    },
  ];

  const availability = {
    stockQty: faker.datatype.number(),
    isAvailable: faker.datatype.boolean(),
  };

  const masterVariant = {
    id: faker.datatype.number(),
    sku: faker.datatype.string(),
    key: faker.datatype.string(),
    sellPrice: faker.datatype.number(),
    listPrice: faker.datatype.number(),
    formattedListPrice: faker.datatype.string(),
    formattedSellPrice: faker.datatype.string(),
    vatMessage: faker.datatype.string(),
    availability: {
      channels: {
        results: [
          {
            channel: {
              key: faker.datatype.string(),
            },
            availability: {
              isOnStock: faker.datatype.boolean(),
              availability: faker.datatype.number(),
            },
          },
        ],
      },
      noChannel: {
        isOnStock: faker.datatype.boolean(),
        availability: faker.datatype.number(),
      },
    },
    assets: [{
      url: faker.datatype.string(),
      assetType: faker.datatype.string(),
      sequence: faker.datatype.number(),
    }],
    prices: [
      {
        value: {
          type: faker.datatype.string(),
          currencyCode: faker.datatype.string(),
          centAmount: faker.datatype.number(),
          fractionDigits: faker.datatype.number(2),
        },
        id: faker.datatype.uuid(),
        channel: {
          typeId: faker.datatype.string(),
          id: faker.datatype.uuid(),
        },
        discounted: {
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.string(),
            fractionDigits: faker.datatype.number(2),
          },
          discount: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
        },
      },
      {
        value: {
          type: faker.datatype.string(),
          currencyCode: faker.datatype.string(),
          centAmount: faker.datatype.number(),
          fractionDigits: faker.datatype.number(2),
        },
        id: faker.datatype.uuid(),
        discounted: {
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.string(),
            fractionDigits: faker.datatype.number(2),
          },
          discount: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
        },
      },
    ],
    images: [
      {
        url: faker.datatype.string(),
        label: faker.datatype.string(),
        dimensions: {
          w: faker.datatype.number(),
          h: faker.datatype.number(),
        },
      },
    ],
    attributesRaw,
  };

  const price = {
    sellPrice: faker.datatype.number(),
    listPrice: faker.datatype.number(),
  };

  const stock = {
    stockQty: 100,
    isAvailable: true,
  };

  const expectedCountDown = {
    message: 'Express delivery! Order within {remainingTime}, and choose next day!',
    cutOffTime: '22:55',
    days: [
      {
        '@name': 'hourRules',
        '@path': '/ro-ro/p/texts/timeUnits/hourRules',
        '@id': '3df1723a-9643-4815-8c1d-dcb1940a04a8',
        '@nodeType': 'mgnl:contentNode',
        'mgnl:lastModified': '2022-01-24T23:32:56.278+05:30',
        other: 'hrs',
        one: 'hr',
        'mgnl:created': '2022-01-24T21:41:32.099+05:30',
        '@nodes': [],
      },
      {
        '@name': 'minuteRules',
        '@path': '/ro-ro/p/texts/timeUnits/minuteRules',
        '@id': 'a3b0a8d6-aef9-4f73-a7f2-7918a481088c',
        '@nodeType': 'mgnl:contentNode',
        'mgnl:lastModified': '2022-01-24T23:32:56.278+05:30',
        other: 'mins',
        one: 'min',
        'mgnl:created': '2022-01-24T21:41:32.100+05:30',
        '@nodes': [],
      },
      {
        '@name': 'days',
        '@path': '/ro-ro/p/deliveryCutoffs/days',
        '@id': '12937ad1-ae75-4611-930b-3d9b33d3d04a',
        '@nodeType': 'mgnl:contentNode',
        fri: 'true',
        thu: 'true',
        sat: 'true',
        'mgnl:created': '2022-01-24T21:41:32.102+05:30',
        tue: 'true',
        sun: 'true',
        mon: 'true',
        'mgnl:lastModified': '2022-01-24T21:41:32.102+05:30',
        wed: 'true',
        '@nodes': [],
      },
    ],
  };
  const priceFormatterData = 'RON 3.54';
  let globalSettings;
  let maxPriority: BadgeNode;
  beforeEach(() => {
    market = stubMarket();
    productDto = stubCtProductDto(market);
    globalSettings = stubGlobalSettings();
    maxPriority = {
      priority: '0.7',
      type: BADGE_VALUES.discount,
      text: '- 16 %',
      side: BADGE_VALUES.topLeft,
    };
    product = {
      getPriceDiff: jest.fn().mockReturnValueOnce(price),
      priceConverter: jest.fn().mockReturnValueOnce(undefined),
      productAttributeToDTO: jest.fn().mockReturnValueOnce(undefined),
      getAllKeywords: jest.fn().mockReturnValueOnce(undefined),
      getUnitPrice: jest.fn().mockReturnValueOnce(undefined),
      getMaxPriority: jest.fn().mockReturnValueOnce(maxPriority),
      getBadgeDetails: jest.fn().mockReturnValueOnce({ topRight: '', topLeft: '' }),
      magnoliaPriceFormatter: jest.fn().mockReturnValueOnce(priceFormatterData),
    } as any;

    common = {
      getStockDetails: jest.fn().mockReturnValueOnce(stock),
      getDeliveryCountdown: jest.fn().mockReturnValueOnce(expectedCountDown),
    } as any;

    /* Dependencies */
    productMapper = new ProductMapper({ common, product });
  });

  test('variantsToDto', () => {
    /* Setup */
    const channelKey = faker.datatype.string();
    const variantExpected = [{
      id: Number(masterVariant.id),
      key: masterVariant.key,
      sku: masterVariant.sku,
    },
    {
      id: Number(masterVariant.id),
      key: masterVariant.key,
      sku: masterVariant.sku,
    }];
    const variantWithEmptycheck = masterVariant;
    globalSettings.priceFormat.isVatIncluded = false;
    const variantDetails = [masterVariant, variantWithEmptycheck];
    /* Execute */
    (common.getStockDetails) = jest.fn().mockReturnValueOnce(stock);
    (product.magnoliaPriceFormatter) = jest.fn().mockReturnValueOnce(priceFormatterData);
    const result = (productMapper as any).variantsToDto(
      variantDetails,
      market.locale,
      channelKey,
      globalSettings.priceFormat,
    );

    /* Verify */
    expect(result).toMatchObject(variantExpected);
  });

  test('variantsToDto with isDiscontinued false', () => {
    (product.productAttributeToDTO) = jest.fn().mockReturnValueOnce({ isDiscontinued: true });
    /* Execute */
    const result = (productMapper as any).variantsToDto([masterVariant], market.locale);

    /* Verify */
    expect(result).toEqual([]);
  });

  test('empty variant and mastervarint', () => {
    /* Setup */
    const productReq = {
      id: productDto.id,
      key: productDto.key,
      masterData: {
        current: {
          variants: [],
        },
      },
    };
    const inventoryData: any = [
      {
        id: faker.datatype.uuid(),
        sku: faker.datatype.string(),
        custom: {
          customFieldsRaw: [
            {
              value: true,
              name: 'isLowAvailability',
            },
          ],
        },
      },
      {
        id: faker.datatype.uuid(),
        sku: faker.datatype.string(),
        custom: null,
      },
    ];
    /* Execute */
    const result = productMapper.convert(
  productReq as any,
  market.locale,
  '',
  globalSettings.priceFormat,
  inventoryData,
    );

    /* Verify */
    expect(result).toEqual({
      msg: 'Variant details not found for this product',
      id:
     productReq.id,
      key: productReq.key,
    });
  });

  test('variantImageToDTO', () => {
    /* Setup */
    const shotClassification = faker.random.word();
    const title = faker.random.word();
    const format = faker.random.word();
    const url = faker.datatype.string();
    const label = `${shotClassification}|${title}|${format}`;
    const videLabel = 'Video Gallery';
    const attributStub = [
      {
        name: faker.datatype.string(),
        value: [
          faker.datatype.string(),
        ],
      },
      {
        name: 'galleryVideo',
        value: [
          url,
        ],
      },
    ];
    const variantImageStub = [{
      url,
      label,
      dimensions: {
        w: faker.datatype.number(),
        h: faker.datatype.number(),
      },
    }];
    const variantImageStubRes = [
      {
        url,
        assetType: label,
        sequence: 0,
        shotClassification,
        title,
        format,
      },
      {
        url,
        assetType: videLabel,
        sequence: 0,
      },
    ];

    /* Execute */
    const result = (productMapper as any).variantImageToDTO(variantImageStub, attributStub);
    /* Verify */
    expect(result).toEqual(variantImageStubRes);
  });

  test('variantImageToDTO without images', () => {
    /* Setup */
    const url = faker.datatype.string();
    const videLabel = 'Video Gallery';
    const attributStub = [
      {
        name: faker.datatype.string(),
        value: [
          faker.datatype.string(),
        ],
      },
      {
        name: 'galleryVideo',
        value: [
          url,
        ],
      },
    ];
    const variantImageStub = undefined;
    const variantImageStubRes = [
      {
        url,
        assetType: videLabel,
        sequence: 0,
      },
    ];

    /* Execute */
    const result = (productMapper as any).variantImageToDTO(variantImageStub, attributStub);
    /* Verify */
    expect(result).toEqual(variantImageStubRes);
  });

  test('getAllBreadcrumb', () => {
    /* Setup */
    const ancestor = {
      typeId: 'category',
      id: parentCatId,
      key: faker.datatype.string(),
      name: faker.datatype.string(),
      slug: faker.datatype.string(),
    };
    stubCat = stubCategory();
    stubCat.ancestors = [ancestor];
    const expectedBreadcrumb = [
      {
        key: ancestor.key,
        parentKey: 'root',
        displayName: ancestor.name,
        url: `/en/c/${ancestor.slug}`,
      }, {
        key: stubCat.key,
        parentKey: ancestor.key,
        displayName: stubCat.name,
        url: `/en/c/${stubCat.slug}`,
      },
    ];
      /* Execute */
    const result = (productMapper as any).getAllBreadcrumb([stubCat], 'en');

    /* Verify */
    expect(result).toMatchObject(expectedBreadcrumb);
  });

  test('getAllBreadcrumb with 2 parents', () => {
    /* Setup */
    const ancestor = {
      typeId: 'category',
      id: parentCatId,
      key: faker.datatype.string(),
      name: faker.datatype.string(),
      slug: faker.datatype.string(),
    };
    stubCat = stubCategory();
    stubCat.ancestors = [ancestor, ancestor];
    const expectedBreadcrumb = [
      {
        key: ancestor.key,
        parentKey: 'root',
        displayName: ancestor.name,
        url: `/en/c/${ancestor.slug}`,
      },
      {
        key: ancestor.key,
        parentKey: ancestor.key,
        displayName: ancestor.name,
        url: `/en/c/${ancestor.slug}`,
      },
      {
        key: stubCat.key,
        parentKey: ancestor.key,
        displayName: stubCat.name,
        url: `/en/c/${stubCat.slug}`,
      },
    ];
      /* Execute */
    const result = (productMapper as any).getAllBreadcrumb([stubCat], 'en');

    /* Verify */
    expect(result).toMatchObject(expectedBreadcrumb);
  });

  test('convert', () => {
    /* Setup */
    const catDetails = {
      typeId: 'category',
      id: catId,
      name: faker.datatype.string(),
      key: faker.datatype.string(),
      slug: faker.datatype.string(),
      description: faker.datatype.string(),
      ancestors: [
        {
          id: faker.datatype.string(),
          key: faker.datatype.string(),
        },
      ],
      metaKeywords: faker.lorem.words(),
    };
    const productReq = {
      id: productDto.id,
      key: productDto.key,
      masterData: {
        current: {
          name: faker.datatype.string(),
          description: faker.datatype.string(),
          masterVariant,
          variants: [masterVariant],
          categories: [catDetails],
          searchKeywords: {},
        },
      },
    };
    const inventoryData: any = [
      {
        id: faker.datatype.uuid(),
        sku: faker.datatype.string(),
        custom: {
          customFieldsRaw: [
            {
              value: true,
              name: 'isLowAvailability',
            },
          ],
        },
      },
      {
        id: faker.datatype.uuid(),
        sku: faker.datatype.string(),
        custom: null,
      },
    ];
      // (productMapper.convert as Mock) = jest.fn().mockResolvedValueOnce(productDto);
    common.getAllKeywords = jest.fn().mockResolvedValueOnce('test');
    common.getAllCategories = jest.fn().mockResolvedValueOnce([{
      slug: catDetails.slug,
      id: catDetails.id,
    }]);
    (common.getStockDetails) = jest.fn().mockReturnValueOnce(stock);
    (common.getDeliveryCountdown) = jest.fn().mockReturnValueOnce(expectedCountDown);
    (product.magnoliaPriceFormatter) = jest.fn().mockReturnValueOnce(priceFormatterData);
    /* Execute */
    const result = productMapper.convert(
  productReq as any,
  market.locale,
  '',
  globalSettings.priceFormat,
  inventoryData,
    );

    /* Verify */
    expect(result.id).toBe(productReq.id);
    expect(result.key).toBe(productReq.key);
  });

  describe('check for only channel price', () => {
    const channelKey = faker.datatype.string();
    const masterVariantonlyChannel = {
      id: faker.datatype.number(),
      sku: faker.datatype.string(),
      key: faker.datatype.string(),
      sellPrice: faker.datatype.number(),
      listPrice: faker.datatype.number(),
      formattedListPrice: faker.datatype.string(),
      formattedSellPrice: faker.datatype.string(),
      vatMessage: faker.datatype.string(),
      availability,
      assets: [{
        url: faker.datatype.string(),
        assetType: faker.datatype.string(),
        sequence: faker.datatype.number(),
      }],
      prices: [
        {
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.number(),
            fractionDigits: 2,
          },
          id: faker.datatype.uuid(),
          channel: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
          discounted: {
            value: {
              type: faker.datatype.string(),
              currencyCode: faker.datatype.string(),
              centAmount: faker.datatype.string(),
              fractionDigits: 2,
            },
            discount: {
              typeId: faker.datatype.string(),
              id: faker.datatype.uuid(),
            },
          },
        },
      ],
      images: [
        {
          url: faker.datatype.string(),
          label: faker.datatype.string(),
          dimensions: {
            w: faker.datatype.number(),
            h: faker.datatype.number(),
          },
        },
      ],
      attributesRaw,
    };
    test('variantsToDto with only channel price', () => {
      /* Setup */
      const variantExpected = [{
        id: Number(masterVariantonlyChannel.id),
        key: masterVariantonlyChannel.key,
        sku: masterVariantonlyChannel.sku,
      }];
      (common.getStockDetails) = jest.fn().mockReturnValueOnce(stock);
      (product.magnoliaPriceFormatter) = jest.fn().mockReturnValueOnce(priceFormatterData);
      /* Execute */
      const result = (productMapper as any).variantsToDto(
        [masterVariantonlyChannel],
        market.locale,
        channelKey,
        globalSettings.priceFormat,
      );

      /* Verify */
      expect(result).toMatchObject(variantExpected);
    });

    test('get offers', () => {
      /* Setup */
      const categories = [
        {
          typeId: 'category',
          id: faker.datatype.string(),
          key: faker.datatype.string(),
          name: faker.datatype.string(),
          slug: faker.datatype.string(),
          description: faker.datatype.string(),
          ancestors: [],
          parent: {
            typeId: 'category',
            id: faker.datatype.string(),
          },
        },
        {
          typeId: 'category',
          id: faker.datatype.string(),
          key: faker.datatype.string(),
          name: faker.datatype.string(),
          slug: faker.datatype.string(),
          description: faker.datatype.string(),
          ancestors: [],
          parent: {
            typeId: 'category',
            id: faker.datatype.string(),
          },
          custom: {
            customFieldsRaw: [
              {
                name: 'type',
                value: 'Offer',
              },
            ],
          },
        },
      ];
      const expectedCategories = [{
        key: categories[1].key,
        description: categories[1].description,
        displayName: categories[1].name,
        url: `/en/offers/${categories[1].slug}`,
      },
      ];
        /* Execute */
      const result = (productMapper as any).getAllOffers(categories, 'en');

      /* Verify */
      expect(result).toMatchObject(expectedCategories);
    });

    test('exclude count down', () => {
      const variantData = masterVariant.attributesRaw;

      /* Execute */
      const result = (common as any).getDeliveryCountdown(variantData);

      /* Verify */
      expect(result).toMatchObject(expectedCountDown);
    });

    test('variantsToDto with empty data', () => {
      attributesRaw[10] = {
        name: 'isDiscontinued',
        value: true,
      };
      /* Execute */
      const result = (productMapper as any).variantsToDto([], market.locale);

      /* Verify */
      expect(result).toStrictEqual([]);
    });
    test('checkDiscount with discounted', () => {
      /* Setup */
      const priceData = {
        validUntil: faker.datatype.datetime(),
        value: {
          type: faker.datatype.string(),
          currencyCode: faker.datatype.string(),
          centAmount: 1000,
          fractionDigits: 2,
        },
        discounted: {
          validUntil: faker.datatype.datetime(),
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: 1000,
            fractionDigits: 2,
          },
        },
      };
      const variantExpected = {
        sellPrice: (priceData.discounted.value.centAmount / (10 ** priceData.discounted.value.fractionDigits))
          .toFixed(2),
        listPrice: (priceData.value.centAmount / (10 ** priceData.value.fractionDigits)).toFixed(2),
        sellPriceCT: priceData.discounted.value.centAmount,
        listPriceCT: priceData.value.centAmount,
        isPromotionApplied: true,
        validUntil: priceData.validUntil,
      };
        /* Execute */
      const result = (productMapper as any).checkDiscount(priceData);

      /* Verify */
      expect(result).toMatchObject(variantExpected);
    });

    test('checkDiscount without discounted', () => {
      /* Setup */
      const priceData = {
        validUntil: faker.datatype.datetime(),
        value: {
          type: faker.datatype.string(),
          currencyCode: faker.datatype.string(),
          centAmount: 1000,
          fractionDigits: 2,
        },
      };
      const variantExpected = {
        sellPrice: (priceData.value.centAmount / (10 ** priceData.value.fractionDigits)).toFixed(2),
        listPrice: (priceData.value.centAmount / (10 ** priceData.value.fractionDigits)).toFixed(2),
        sellPriceCT: priceData.value.centAmount,
        listPriceCT: priceData.value.centAmount,
        isPromotionApplied: false,
        validUntil: priceData.validUntil,
      };
        /* Execute */
      const result = (productMapper as any).checkDiscount(priceData);

      /* Verify */
      expect(result).toMatchObject(variantExpected);
    });
  });

  test('getAllBreadcrumb with empty data', () => {
    /* Execute */
    const result = (productMapper as any).getAllBreadcrumb([], 'en');

    /* Verify */
    expect(result).toMatchObject([]);
  });

  test('variantsToDto with empty data', () => {
    attributesRaw[10] = {
      name: 'isDiscontinued',
      value: true,
    };
    /* Execute */
    const result = (productMapper as any).variantsToDto([], market.locale);

    /* Verify */
    expect(result).toStrictEqual([]);
  });

  test('get offers with false scenario', () => {
    /* Setup */
    const categories = [
      {
        key: '',
        custom: {
          customFieldsRaw: [
            {
              name: 'type',
              value: 'Offer',
            },
          ],
        },
      },
    ];
    const expectedCategories = [{
      key: '',
      description: '',
      displayName: '',
      url: '',
    },
    ];
    /* Execute */
    const result = (productMapper as any).getAllOffers(categories, 'en');

    /* Verify */
    expect(result).toMatchObject(expectedCategories);
  });
  test('breadcrumbMapper  with false scenario', () => {
    /* Setup */
    const expectedCategories = {
      key: '',
      parentKey: '',
      displayName: '',
      url: '',
    };
    /* Execute */
    const result = (productMapper as any).breadcrumbMapper({}, 'en');

    /* Verify */
    expect(result).toMatchObject(expectedCategories);
  });
  test('getAllBreadcrumb with empty key', () => {
    /* Setup */
    stubCat = stubCategory();
    stubCat.ancestors = [];
    const expectedCategories = {
      key: stubCat.key,
      parentKey: '',
      displayName: stubCat.name,
      url: `/en/c/${stubCat.slug}`,
    };
      /* Execute */
    const result = (productMapper as any).getAllBreadcrumb([stubCat], 'en');

    /* Verify */
    expect(result).toMatchObject([expectedCategories]);
  });
});
