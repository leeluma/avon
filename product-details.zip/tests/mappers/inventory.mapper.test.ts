import faker from '@faker-js/faker';
import { ProductgraphqlDto, ProductDto } from '../../src/dtos/product.dto';
import { MarketInfo } from '../../src/middlewares';
import { InventoryMapper } from '../../src/mappers/inventory.mapper';
import { stubMarket, stubCtProductDto } from '../__stubs__';
import {
  BADGE_NAMES, BADGE_VALUES, ATTRIBUTE_NAMES, ATTRIBUTE_VALUES,
} from '../../src/common/constant';

describe('inventoryMapper', () => {
  let productDto: ProductDto;
  /** start testing address mapper */
  let inventoryMapper: InventoryMapper;
  let market: MarketInfo;
  const nameValue = {
    name: faker.datatype.string(),
    value: faker.datatype.string(),
  };
  const url = faker.datatype.string();
  const label = faker.datatype.string();
  const attributesRaw = [
    {
      name: 'galleryVideo',
      value: [
        url,
      ],
    },
    {
      name: faker.datatype.string(),
      value: {
        key: faker.datatype.string(),
        label: faker.datatype.string(),
      },
    },
    nameValue,
    {
      name: 'startDate',
      value: faker.datatype.datetime(),
    },
    {
      name: 'endDate',
      value: faker.datatype.datetime(),
    },
    nameValue,
    nameValue,
    {
      name: ATTRIBUTE_NAMES.contentFillMeasurement,
      value: {
        key: 'g',
        label: faker.datatype.string(),
      },
    },
    {
      name: ATTRIBUTE_NAMES.contentFill,
      value: faker.datatype.number(),
    },
    {
      name: ATTRIBUTE_NAMES.badges,
      value: [
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.typeNew,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: 'NOU',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topRight,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.9,
          },
        ],
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.discount,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: '20%',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topLeft,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.2,
          },
        ],
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.bestSeller,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: 'Best Seller',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topRight,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.1,
          },
        ],
      ],
    },
    {
      name: ATTRIBUTE_NAMES.config,
      value: [
        [
          {
            name: 'quantity',
            value: 1,
          },
          {
            name: 'setComponent',
            value: {
              typeId: 'product',
              id: faker.datatype.uuid(),
            },
          },
          {
            name: 'lineNumber',
            value: faker.datatype.number(),
          },
          {
            name: ATTRIBUTE_VALUES.availabilitySku,
            value: faker.datatype.uuid(),
          },
        ],
        [
          {
            name: 'quantity',
            value: 1,
          },
          {
            name: 'setComponent',
            value: {
              typeId: 'product',
              id: faker.datatype.uuid(),
            },
          },
          {
            name: 'lineNumber',
            value: faker.datatype.number(),
          },
          {
            name: ATTRIBUTE_VALUES.availabilitySku,
            value: faker.datatype.uuid(),
          },
        ],
      ],
    },
    {
      name: faker.datatype.string(),
      value: faker.datatype.boolean(),
    },
    {
      key: faker.datatype.string(),
      value: faker.datatype.boolean(),
    },
  ];
  const channelKey = faker.datatype.string();
  const availability = {
    channels: {
      results: [
        {
          channel: {
            key: channelKey,
          },
          availability: {
            isOnStock: faker.datatype.boolean(),
            availableQuantity: faker.datatype.number(),
            id: faker.datatype.string(),
          },
        },
        {
          channel: {
            key: faker.datatype.string(),
          },
          availability: {
            isOnStock: faker.datatype.boolean(),
            availableQuantity: faker.datatype.number(),
            id: faker.datatype.string(),
          },
        },
      ],
    },
    noChannel: {
      isOnStock: faker.datatype.boolean(),
      availableQuantity: faker.datatype.number(),
      id: faker.datatype.string(),
    },
  };

  const masterVariant = {
    id: faker.datatype.string(),
    key: faker.datatype.string(),
    sku: faker.datatype.string(),
    availability,
    prices: [],
    images: [],
    attributesRaw: [],
  };
  beforeEach(() => {
    productDto = stubCtProductDto(market);
    market = stubMarket();
    inventoryMapper = new InventoryMapper();
  });

  describe('get product inventory details', () => {
    test('getProductInventoriesIds', () => {
      const product: any = {
        id: productDto.id,
        key: productDto.key,
        masterData: {
          current: {
            searchKeywords: {
              locale: faker.datatype.string(),
              searchKeywords: {
                text: faker.datatype.string(),
              },
            },
            slug: {
              [market.locale]: faker.datatype.string(),
            },
            name: {
              [market.locale]: faker.datatype.string(),
            },
            metaTitle: faker.datatype.string(),
            metaDescription: {
              [market.locale]: faker.datatype.string(),
            },
            description: faker.lorem.words(),
            categories: [],
            masterVariant,
            variants: [masterVariant],
          },
        },
      };

      const inventoryId = availability.channels.results[0].availability.id;
      const mappedInventoryId = `"${inventoryId}","${inventoryId}"`;
      const result = (inventoryMapper as any).getProductInventoriesIds(product, channelKey);
      expect(result).toEqual(mappedInventoryId);
    });

    test('getProductInventoriesIds with empty variant', () => {
      masterVariant.availability.channels.results = [];
      const product: any = {
        id: productDto.id,
        key: productDto.key,
        masterData: {
          current: {
            masterVariant,
            variants: [masterVariant],
          },
        },
      };
      const result = (inventoryMapper as any).getProductInventoriesIds(product, channelKey);
      expect(result).toEqual('');
    });
  });
});
