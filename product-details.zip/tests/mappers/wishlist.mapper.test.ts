import { ShoppingList } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import { WishlistDto } from '../../src/dtos/wishlist.dto';
import { LineItemMapper } from '../../src/mappers/line-item.mapper';
import { MagnoliaPriceFormatDto } from '../../src/dtos/line-item.dto';
import { ShoppingListMapper } from '../../src/mappers/wishlist.mapper';
import { MarketInfo } from '../../src/middlewares';

import {
  stubMarket, stubShoppingList, stubWishlistDto,
  stubLineItemDto,
} from '../__stubs__';
import { Common } from '../../src/lib/common';

describe('CtShoppingListMapper', () => {
  /** start testing address mapper */
  let shoppingListMapper: ShoppingListMapper;
  let lineItemMapper: LineItemMapper;
  let market: MarketInfo;
  let magPriceFormat: MagnoliaPriceFormatDto;

  let shoppingList: ShoppingList;
  let wishlistDto: WishlistDto;
  let common: Common;

  beforeEach(() => {
    market = stubMarket();

    lineItemMapper = new LineItemMapper({ common });
    shoppingList = stubShoppingList(market);
    magPriceFormat = {
      isVatIncluded: faker.datatype.boolean(),
      baseMeasure: { unitPriceBaseMeasure: faker.datatype.number() },
    } as any;

    wishlistDto = stubWishlistDto({
      id: shoppingList.id,
      name: shoppingList.name[market.locale],
      lineItems: shoppingList.lineItems?.map((ctLineItem) => stubLineItemDto(
        lineItemMapper.mapLineItemResponse(market, ctLineItem, magPriceFormat),
      )),
      customerId: undefined,
      anonymousId: undefined,
      version: shoppingList.version,
    });

    shoppingListMapper = new ShoppingListMapper({ lineItemsMapper: lineItemMapper });
  });

  describe('map_CtShoppingListDto_WishlistDto', () => {
    test('responds with CtShoppingListDto mapped to WishlistDto', () => {
      const result = shoppingListMapper.mapShoppingListResponse(market, shoppingList, magPriceFormat);
      expect(result).toEqual(wishlistDto);
    });
  });
});
