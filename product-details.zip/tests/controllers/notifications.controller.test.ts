import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';

import { NotificationsController } from '../../src/controllers/notifications.controller';
import { NotificationsService } from '../../src/services/notifications.service';

import Mock = jest.Mock;
import { stubMarket, stubExpressReq, stubExpressRes } from '../__stubs__';

describe('NotificationsController', () => {
  /* System Under Test */
  let notificationsController: NotificationsController;

  /* Dependencies */
  let notificationsService: NotificationsService;
  let market: MarketInfo;

  /* Stubs */
  let request: Request;
  let response: Response;
  let params;

  beforeEach(() => {
    market = stubMarket();
    /* Stubs */
    request = stubExpressReq();
    response = stubExpressRes(market);
    /* Dependencies */
    notificationsService = {} as any;

    notificationsController = new NotificationsController({ notificationsService });
  });

  describe('product()', () => {
    beforeEach(() => {
      notificationsService.addToCart = jest.fn();
      request.headers.sessionkey = faker.datatype.uuid();
      request.headers.customerkey = faker.datatype.uuid();

      request.body.ticket = faker.datatype.uuid();
      request.body.productKey = faker.datatype.uuid();
      request.body.variantKey = faker.datatype.uuid();

      params = {
        sessionKey: request.headers.sessionkey,
        customerKey: request.headers.customerkey,
        ticket: request.body.ticket,
        productKey: request.body.productKey,
        variantKey: request.body.variantKey,
      };
    });

    test('calls adding-to-cart with parameters', async () => {
      /* Prepare */
      (notificationsService.addToCart as Mock).mockReturnValueOnce(true);

      /* Execute */
      await notificationsController.addToCart(request, response);

      /* Verify */
      expect(notificationsService.addToCart).toHaveBeenCalledTimes(1);
      expect(notificationsService.addToCart).toHaveBeenNthCalledWith(
        1,
        market,
        params,
      );
    });
  });
});
