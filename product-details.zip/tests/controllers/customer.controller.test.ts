import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes,
  stubCustomerRequestDto, stubCustomerResponseDto,
} from '../__stubs__';
import { CustomerController } from '../../src/controllers';
import { CustomerService } from '../../src/services';

import Mock = jest.Mock;
import {
  CustomerRegistrationRequestDto,
  CustomerResponseDto,
} from '../../src/dtos';

describe('CustomerController', () => {
  /* System Under Test */
  let customerController: CustomerController;

  /* Dependencies */
  let customerService: CustomerService;
  let market: MarketInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    customerService = {} as any;

    /* SUT */
    customerController = new CustomerController({ customerService });
  });
  describe('customer method', () => {
    let customerRequestDto: CustomerRegistrationRequestDto;
    let customerResponseDto: CustomerResponseDto;
    let authHeader: string;
    beforeEach(() => {
      customerRequestDto = stubCustomerRequestDto();
      customerResponseDto = stubCustomerResponseDto();
      authHeader = `Bearer ${faker.datatype.uuid()}`;
    });
    describe('getCustomerByToken()', () => {
      beforeEach(() => {
        customerService.getCustomerDetailsByToken = jest.fn();
        req.headers.authorization = authHeader;
      });

      test('calls customerService with request parameters', async () => {
        /* Prepare */
        (customerService.getCustomerDetailsByToken as Mock).mockReturnValueOnce(customerResponseDto);

        /* Execute */
        await customerController.getCustomerByToken(req, res);

        /* Verify */
        expect(customerService.getCustomerDetailsByToken).toHaveBeenCalledTimes(1);
        expect(customerService.getCustomerDetailsByToken).toHaveBeenNthCalledWith(
          1,
          market,
          authHeader,
        );
      });

      test('returns customerResponseDto as JsonApiResponseEntity', async () => {
        /* Prepare */
        (customerService.getCustomerDetailsByToken as Mock).mockReturnValueOnce(customerResponseDto);

        /* Execute */
        const response = await customerController.getCustomerByToken(req, res);

        /* Verify */
        expect(response).toEqual({
          statusCode: 200,
          body: customerResponseDto,
        });
      });

      test('throws ApiError(NOT_FOUND) if customer does not exist', async () => {
        /* Prepare */
        (customerService.getCustomerDetailsByToken as Mock).mockReturnValueOnce(undefined);

        const result = expect(() => customerController.getCustomerByToken(req, res));

        /* Execute */
        await result.rejects.toThrowError();
      });
    });
  });
});
