import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubCtProductDto,
} from '../__stubs__';
import { ProductController } from '../../src/controllers/product.controller';
import ProductService from '../../src/services/product.service';

import Mock = jest.Mock;
import { ProductDto } from '../../src/dtos/product.dto';

import { ApiError } from '../../src/lib';

describe('LeapApp', () => {
  /* System Under Test */
  let productController: ProductController;

  /* Dependencies */
  let productService: ProductService;
  let market: MarketInfo;
  let magnolia : MagnoliaInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    productService = {} as any;

    /* SUT */
    productController = new ProductController({ productService });
  });

  describe('getByKey()', () => {
    let productDto: ProductDto;
    let productKey: string;

    beforeEach(() => {
      productService.getByKey = jest.fn();
      productDto = stubCtProductDto(market);
      productKey = faker.datatype.string();
      productDto.key = productKey;
      req.params.key = productKey;
    });

    test('fetches data from productService', async () => {
      /* Prepare */
      (productService.getByKey as Mock).mockReturnValueOnce(productDto);

      /* Execute */
      await productController.getByKey(req, res);

      /* Verify */
      expect(productService.getByKey).toHaveBeenCalledTimes(1);
      expect(productService.getByKey).toHaveBeenNthCalledWith(
        1,
        market,
        productKey,
        magnolia,
        undefined,
        undefined,
      );
    });

    test('returns productDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (productService.getByKey as Mock).mockReturnValueOnce(productDto);

      /* Execute */
      const response = await productController.getByKey(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: productDto,
      });
    });

    test('throws ApiError(NOT_FOUND) if product does not exist', async () => {
      /* Prepare */
      (productService.getByKey as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(404, `product with key "${productKey}" not found.`);

      /* Execute */
      await expect(() => productController.getByKey(req, res))
        .rejects.toThrow(expectedError);
    });
  });
});
