import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { stubMarket, stubExpressReq, stubExpressRes } from '../__stubs__';
import { NotifyController } from '../../src/controllers/notify.controller';
import { NotifyService } from '../../src/services/notify.service';
import Mock = jest.Mock;

describe('LeapNotifyController', () => {
  /* System Under Test */
  let notifyController: NotifyController;

  /* Dependencies */
  let notifyService: NotifyService;
  let market: MarketInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    notifyService = {} as any;

    /* SUT */
    notifyController = new NotifyController({ notifyService });
  });

  describe('create()', () => {
    let sku: string;
    let productKey: string;
    let productUrl: string;
    let email: string;
    let value;

    beforeEach(() => {
      sku = faker.datatype.uuid();
      req.body.sku = sku;
      productKey = faker.datatype.number().toString();
      req.body.productKey = productKey;
      productUrl = faker.internet.url();
      req.body.productUrl = productUrl;
      email = faker.internet.email();
      req.body.email = email;
      notifyService.create = jest.fn();
      value = {
        sku, productKey, productUrl, email,
      };
    });

    test('fetches data from notifyService', async () => {
      /* Prepare */
      (notifyService.create as Mock).mockReturnValueOnce(value);

      /* Execute */
      await notifyController.create(req, res);

      /* Verify */
      expect(notifyService.create).toHaveBeenCalledTimes(1);
      expect(notifyService.create).toHaveBeenNthCalledWith(
        1,
        market,
        sku,
        productKey,
        productUrl,
        email,
      );
    });

    test('returns notifyDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (notifyService.create as Mock).mockReturnValueOnce(value);

      /* Execute */
      const response = await notifyController.create(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 201,
        body: undefined,
      });
    });
  });
});
