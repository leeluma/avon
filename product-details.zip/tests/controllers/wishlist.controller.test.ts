import { Request, Response } from 'express';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes,
} from '../__stubs__';
import { ShoppingListController } from '../../src/controllers/wishlist.controller';
import { ShoppingListService } from '../../src/services/wishlist.service';
import { WishlistDto } from '../../src/dtos/wishlist.dto';
import Mock = jest.Mock;
import { stubWishlistDto } from '../__stubs__/wishlist.dto.stub';

describe('LeapBeWishlistController', () => {
  /* System Under Test */
  let shoppingListController: ShoppingListController;

  /* Dependencies */
  let shoppingListService: ShoppingListService;
  let market: MarketInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes(market);

    /* Dependencies */
    shoppingListService = {} as any;

    /* SUT */
    shoppingListController = new ShoppingListController({ shoppingListService });
  });

  describe('create()', () => {
    let isAnonymous: boolean;

    let customerId: string | undefined;
    let anonymousId: string | undefined;
    let sku: string;

    let wishlistDto: WishlistDto;

    beforeEach(() => {
      sku = faker.datatype.uuid();
      req.body.sku = sku;

      isAnonymous = faker.datatype.boolean();
      if (isAnonymous) {
        anonymousId = faker.datatype.uuid();
        req.body.anonymousId = anonymousId;
      } else {
        customerId = faker.datatype.uuid();
        req.body.customerId = customerId;
      }

      wishlistDto = stubWishlistDto();

      shoppingListService.create = jest.fn();
    });

    test('fetches data from shoppingListService', async () => {
      /* Prepare */
      (shoppingListService.create as Mock).mockReturnValueOnce(wishlistDto);

      /* Execute */
      await shoppingListController.create(req, res);

      /* Verify */
      expect(shoppingListService.create).toHaveBeenCalledTimes(1);
      expect(shoppingListService.create).toHaveBeenNthCalledWith(
        1,
        market,
        undefined,
        customerId,
        anonymousId,
        sku,
      );
    });

    test('returns wishlistDto as JsonApiResponseEntity', async () => {
      /* Prepare */
      (shoppingListService.create as Mock).mockReturnValueOnce(wishlistDto);

      /* Execute */
      const response = await shoppingListController.create(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 201,
        body: wishlistDto,
      });
    });
  });

  describe('deleteLineItem()', () => {
    let lineItemId: string;
    let wishlistDto: WishlistDto;

    beforeEach(() => {
      shoppingListService.deleteLineItem = jest.fn();
      wishlistDto = stubWishlistDto();
      req.params.id = wishlistDto.id;
      lineItemId = faker.datatype.uuid();
      req.params.lineItemId = lineItemId;
      res.locals.market = market;
    });

    test('fetches data from wishlistService', async () => {
      /* Prepare */
      (shoppingListService.deleteLineItem as Mock).mockReturnValueOnce(wishlistDto);

      /* Execute */
      await shoppingListController.deleteLineItem(req, res);

      /* Verify */
      expect(shoppingListService.deleteLineItem).toHaveBeenCalledTimes(1);
      expect(shoppingListService.deleteLineItem).toHaveBeenNthCalledWith(
        1,
        market,
        wishlistDto.id,
        lineItemId,
      );
    });

    test('returns result from wishlistService.deleteLineItemWishlist as JsonApiResponseEntity', async () => {
      /* Prepare */
      (shoppingListService.deleteLineItem as Mock).mockReturnValueOnce(wishlistDto);

      /* Execute */
      const response = await shoppingListController.deleteLineItem(req, res);

      /* Verify */
      expect(response).toEqual({
        statusCode: 200,
        body: wishlistDto,
      });
    });
  });
});
