import { LineItemDraft, ShoppingListDraft, ShoppingListLineItemDraft } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { ShoppingListService, ShoppingListLineItemDraftWritable } from '../../src/services/wishlist.service';
import Mock = jest.Mock;
import { ApiError } from '../../src/lib';
import { ShoppingListMapper } from '../../src/mappers/wishlist.mapper';
import { ShoppingListDao } from '../../src/daos/wishlist.dao';
import MagnoliaDao from '../../src/daos/magnolia.dao';
import { MagnoliaPriceFormatDto } from '../../src/dtos/line-item.dto';
import {
  stubLineItemDto,
  stubMarket, stubShoppingList, stubShoppingListDraft, stubShoppingListLineItemDraft, stubWishlistDto,
} from '../__stubs__';
import { stubShoppingListLineItem } from '../__stubs__/shoppingListLineItem.stub';

describe('LeapBeWishlistService', () => {
  /* System Under Test */
  let shoppingListService: ShoppingListService;

  /* Dependencies */
  let shoppingListDao: ShoppingListDao;
  let magnoliaDao: MagnoliaDao;
  let wishlistMapper: ShoppingListMapper;
  let market: MarketInfo;
  let magPriceFormat: MagnoliaPriceFormatDto;

  beforeEach(() => {
    market = stubMarket();

    /* Dependencies */
    shoppingListDao = {
      create: jest.fn(),
      findOneBy: jest.fn(),
      findOne: jest.fn(),
      updateLineItemQuantity: jest.fn(),
    } as any;

    wishlistMapper = {
      mapShoppingListResponse: jest.fn(),
    } as any;

    magPriceFormat = { isVatIncluded: faker.datatype.boolean() } as any;
    magnoliaDao = { getPriceFormat: () => magPriceFormat } as any;

    /* SUT */
    shoppingListService = new ShoppingListService({
      shoppingListDao,
      magnoliaDao,
      shoppingListMapper: wishlistMapper,
    });
  });

  describe('create()', () => {
    let shoppingListDraftDto: ShoppingListLineItemDraftWritable<ShoppingListDraft>;
    let lineItemDraft: ShoppingListLineItemDraft;
    let customerId;
    let anonymousId;
    let sku;
    let wishlistId;

    beforeEach(() => {
      sku = faker.datatype.uuid();

      lineItemDraft = stubShoppingListLineItemDraft(market, { sku });

      shoppingListDraftDto = stubShoppingListDraft(market, {
        name: { [market.locale]: 'DEFAULT' },
        lineItems: [lineItemDraft],
      });
    });

    test('create new wishlist if sku and anonymousId provided', async () => {
      anonymousId = faker.datatype.uuid();
      shoppingListDraftDto.anonymousId = anonymousId;
      const currentShoppingListDto = stubShoppingList(market);
      (shoppingListDao.create as Mock).mockReturnValueOnce(currentShoppingListDto);
      /* Execute */
      await shoppingListService.create(market, wishlistId, customerId, anonymousId, sku);

      /* Verify */
      expect(shoppingListDao.create).toHaveBeenCalledTimes(1);
      expect(shoppingListDao.create).toHaveBeenNthCalledWith(
        1,
        market,
        shoppingListDraftDto,
      );
    });

    test('creates new wishlist if sku and customerId provided', async () => {
      customerId = faker.datatype.uuid();
      anonymousId = undefined;
      shoppingListDraftDto.customer = { id: customerId, typeId: 'customer' };
      const currentShoppingListDto = stubShoppingList(market);
      (shoppingListDao.create as Mock).mockReturnValueOnce(currentShoppingListDto);

      /* Execute */
      await shoppingListService.create(market, wishlistId, customerId, anonymousId, sku);

      /* Verify */
      expect(shoppingListDao.create).toHaveBeenCalledTimes(1);
      expect(shoppingListDao.create).toHaveBeenNthCalledWith(
        1,
        market,
        shoppingListDraftDto,
      );
    });

    test('throws ApiError(CONFLICT) if both anonymousId and customerId are specified', async () => {
      /* Prepare */
      customerId = faker.datatype.uuid();
      anonymousId = faker.datatype.uuid();

      /* Execute */
      const result = expect(() => {
        return shoppingListService.create(
          market,
          wishlistId,
          customerId,
          anonymousId,
          sku,
        );
      });

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(409, 'Specify exactly one of customerId or anonymousId.'),
      );
    });

    test('throws ApiError(BAD_REQUEST) if none id,anonymousId and customerId are specified', async () => {
      /* Prepare */
      customerId = undefined;
      anonymousId = undefined;
      wishlistId = undefined;

      /* Execute */
      const result = expect(() => {
        return shoppingListService.create(
          market,
          wishlistId,
          customerId,
          anonymousId,
          sku,
        );
      });

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(400, 'one of id, anonymousId or customerId is required'),
      );
    });

    test('throws ApiError(CONFLICT) if product already exists in wishlist.', async () => {
      /* Prepare */
      const lineItem = stubShoppingListLineItem(market, { variant: { sku, id: faker.datatype.number() } });
      const currentShoppingListDto = stubShoppingList(market, { lineItems: [lineItem] });
      (shoppingListDao.findOneBy as Mock).mockReturnValueOnce(currentShoppingListDto);
      wishlistId = faker.datatype.uuid();

      /* Execute */
      const result = expect(() => {
        return shoppingListService.create(
          market,
          wishlistId,
          customerId,
          anonymousId,
          sku,
        );
      });

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(409, 'product already exists in wishlist.'),
      );
    });

    test('update wishlist if id exists', async () => {
      wishlistId = faker.datatype.uuid();
      customerId = undefined;
      anonymousId = undefined;
      const currentShoppingListDto = stubShoppingList(market);
      (shoppingListDao.findOneBy as Mock).mockReturnValueOnce(currentShoppingListDto);
      (shoppingListDao.updateLineItemQuantity as Mock).mockReturnValueOnce(currentShoppingListDto);

      /* Execute */
      await shoppingListService.create(market, wishlistId, customerId, anonymousId, sku);

      /* Verify */
      expect(shoppingListDao.updateLineItemQuantity).toHaveBeenCalledTimes(1);
      expect(shoppingListDao.updateLineItemQuantity).toHaveBeenNthCalledWith(
        1,
        market,
        currentShoppingListDto.id,
        currentShoppingListDto.version,
        sku,
      );
    });

    test('update wishlist if anonymousId exists', async () => {
      anonymousId = faker.datatype.uuid();
      customerId = undefined;
      wishlistId = undefined;
      const currentShoppingListDto = stubShoppingList(market);
      (shoppingListDao.findOneBy as Mock).mockReturnValueOnce(currentShoppingListDto);
      (shoppingListDao.updateLineItemQuantity as Mock).mockReturnValueOnce(currentShoppingListDto);

      /* Execute */
      await shoppingListService.create(market, wishlistId, customerId, anonymousId, sku);

      /* Verify */
      expect(shoppingListDao.updateLineItemQuantity).toHaveBeenCalledTimes(1);
      expect(shoppingListDao.updateLineItemQuantity).toHaveBeenNthCalledWith(
        1,
        market,
        currentShoppingListDto.id,
        currentShoppingListDto.version,
        sku,
      );
    });

    test('update wishlist if customerId exists', async () => {
      customerId = faker.datatype.uuid();
      anonymousId = undefined;
      wishlistId = undefined;
      const currentShoppingListDto = stubShoppingList(market);
      (shoppingListDao.findOneBy as Mock).mockReturnValueOnce(currentShoppingListDto);
      (shoppingListDao.updateLineItemQuantity as Mock).mockReturnValueOnce(currentShoppingListDto);

      /* Execute */
      await shoppingListService.create(market, wishlistId, customerId, anonymousId, sku);

      /* Verify */
      expect(shoppingListDao.updateLineItemQuantity).toHaveBeenCalledTimes(1);
      expect(shoppingListDao.updateLineItemQuantity).toHaveBeenNthCalledWith(
        1,
        market,
        currentShoppingListDto.id,
        currentShoppingListDto.version,
        sku,
      );
    });
  });

  describe('deleteLineItem()', () => {
    let wishlistId;
    let lineItemId;

    beforeEach(() => {
      wishlistId = faker.datatype.uuid();
      lineItemId = faker.datatype.uuid();
      shoppingListDao.deleteLineItems = jest.fn();
    });

    test('throw error if wishlistId is invalid', async () => {
      /* Execute */
      const result = expect(() => {
        return shoppingListService.deleteLineItem(market, wishlistId, lineItemId);
      });

      /* Verify */
      await result.rejects.toThrow(
        new ApiError(401, 'Invalid wishlistId.'),
      );
    });

    test('calls shoppingListDao.deleteLineItem()', async () => {
      /* prepare */
      const shoppingListDto = stubShoppingList(market);
      (shoppingListDao.findOne as Mock).mockReturnValueOnce(shoppingListDto);
      /* Execute */
      await shoppingListService.deleteLineItem(market, wishlistId, lineItemId);
      /* Verify */
      expect(shoppingListDao.deleteLineItems).toHaveBeenCalledTimes(1);
      expect(shoppingListDao.deleteLineItems).toHaveBeenNthCalledWith(
        1,
        market,
        wishlistId,
        shoppingListDto.version,
        [lineItemId],
      );
    });

    test('maps CT response to Dao', async () => {
      /* Prepare */
      const shoppingListDto = stubShoppingList(market);
      (shoppingListDao.findOne as Mock).mockReturnValueOnce(shoppingListDto);
      (shoppingListDao.deleteLineItems as Mock).mockReturnValueOnce(shoppingListDao);

      /* Execute */
      await shoppingListService.deleteLineItem(market, wishlistId, lineItemId);

      /* Verify */
      expect(wishlistMapper.mapShoppingListResponse).toHaveBeenCalledTimes(1);
      expect(wishlistMapper.mapShoppingListResponse).toHaveBeenNthCalledWith(
        1,
        market,
        shoppingListDao,
        magPriceFormat,
      );
    });

    test('returns result from mapper', async () => {
      /* Prepare */
      const shoppingListDto = stubShoppingList(market);
      (shoppingListDao.findOne as Mock).mockReturnValueOnce(shoppingListDto);
      const wishlistDto = stubWishlistDto();
      (wishlistMapper.mapShoppingListResponse as Mock).mockReturnValueOnce(wishlistDto);

      /* Execute */
      const response = await shoppingListService.deleteLineItem(market, wishlistId, lineItemId);

      /* Verify */
      expect(response).toEqual(wishlistDto);
    });
  });
});
