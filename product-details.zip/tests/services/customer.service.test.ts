import faker from '@faker-js/faker';
import { Customer } from '@commercetools/platform-sdk';
import { MarketInfo } from '../../src/middlewares';
import { CustomerDao } from '../../src/daos';
import {
  stubMarket, stubCustomerDto,
} from '../__stubs__';
import { CustomerService } from '../../src/services';
import Mock = jest.Mock;
import { CustomerMapper } from '../../src/mappers/customer.mapper';

type Writeable<T> = { -readonly [P in keyof T]: T[P] };

describe('CustomerService', () => {
  /* System Under Test */
  let customerService: CustomerService;

  /* Dependencies */
  let customerDao: CustomerDao;
  let customerMapper: CustomerMapper;
  let market: MarketInfo;

  beforeAll(() => {
    jest.useFakeTimers().setSystemTime(new Date());
  });

  afterAll(() => {
    jest.useRealTimers();
  });

  beforeEach(() => {
    market = stubMarket();
    customerMapper = {
      mapCustomerResponse: jest.fn(),
      mapGraphQLCustomerResponse: jest.fn(),
    } as any;
    customerDao = {} as any;

    /* SUT */
    customerService = new CustomerService({
      customerDao,
      customerMapper,
    });
  });
  describe('getCustomerDetailsByToken()', () => {
    let customerDto: Writeable<Customer>;
    let authHeader: string;

    beforeEach(() => {
      customerDao.getCustomerDetailsGraphQL = jest.fn();
      authHeader = faker.datatype.uuid();
      customerDto = stubCustomerDto();
    });

    test('reads the customerDto from customerDao', async () => {
      /* Prepare */
      (customerDao.getCustomerDetailsGraphQL as Mock).mockReturnValueOnce(customerDto);
      (customerMapper.mapCustomerResponse as Mock).mockReturnValueOnce(customerDto);

      /* Execute */
      await customerService.getCustomerDetailsByToken(market, authHeader);

      /* Verify */
      expect(customerDao.getCustomerDetailsGraphQL).toHaveBeenCalledTimes(1);
      expect(customerMapper.mapGraphQLCustomerResponse).toHaveBeenNthCalledWith(1, customerDto);
    });
  });
});
