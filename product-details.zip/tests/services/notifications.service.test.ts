import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import { NotificationsDao } from '../../src/daos/notifications.dao';
import { NotificationsService } from '../../src/services/notifications.service';
import Mock = jest.Mock;

import { stubMarket } from '../__stubs__';

describe('NotificationService', () => {
  /* System Under Test */
  let notificationsService: NotificationsService;

  /* Dependencies */
  let notificationsDao: NotificationsDao;
  let market: MarketInfo;
  let params;

  beforeEach(() => {
    market = stubMarket();
    notificationsDao = {
      cartNotifications: jest.fn(),
    } as any;
    notificationsService = new NotificationsService({ notificationsDao });
    params = {
      sessionKey: faker.datatype.uuid(),
      customerKey: faker.datatype.uuid(),
      ticket: faker.datatype.uuid(),
      productKey: undefined,
      variantKey: undefined,
    };
  });

  describe('addToCart()', () => {
    test('return true if notification updated in addding to cart', async () => {
      /* Prepare */
      (notificationsDao.cartNotifications as Mock).mockReturnValueOnce(true);

      /* Execute */
      await notificationsService.addToCart(market, params);

      /* Verify */
      expect(notificationsDao.cartNotifications).toHaveBeenCalledTimes(1);
    });
  });
});
