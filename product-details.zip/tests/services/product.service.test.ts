import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubCtProductDto, stubMagnoliaInfo, stubGlobalSettings,
} from '../__stubs__';
import ProductDao from '../../src/daos/product.dao';
import MagnoliaDao from '../../src/daos/magnolia.dao';
import { InventoryDao } from '../../src/daos/inventory.dao';
import ProductService from '../../src/services/product.service';
import ShippingService from '../../src/services/shipping.service';
import Mock = jest.Mock;
import { ProductDto } from '../../src/dtos/product.dto';
import ProductMapper from '../../src/mappers/product.mapper';
import { InventoryMapper } from '../../src/mappers/inventory.mapper';
import { Common } from '../../src/lib/common';
import {
  BADGE_NAMES, BADGE_VALUES, ATTRIBUTE_NAMES, ATTRIBUTE_VALUES,
} from '../../src/common/constant';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import { ShoppingListDao } from '../../src/daos';

describe('LeapApp', () => {
  /* System Under Test */
  let productService: ProductService;
  let shippingService: ShippingService;
  /* Dependencies */
  let productDao: ProductDao;
  let magnoliaDao: MagnoliaDao;
  let shoppingListDao: ShoppingListDao;
  let inventoryDao: InventoryDao;
  let productMapper: ProductMapper;
  let inventoryMapper: InventoryMapper;
  let market: MarketInfo;
  let magnoliaInfo: MagnoliaInfo;
  let common: Common;
  let magnoliaTemplateDefinition: {
    'mgnl:template': string;
  };
  let magnoliaBasePath: string;
  let globalSettings;
  const nameValue = {
    name: faker.datatype.string(),
    value: faker.datatype.string(),
  };
  const url = faker.datatype.string();
  const label = faker.datatype.string();
  const attributesRaw = [
    {
      name: 'galleryVideo',
      value: [
        url,
      ],
    },
    {
      name: faker.datatype.string(),
      value: {
        key: faker.datatype.string(),
        label: faker.datatype.string(),
      },
    },
    nameValue,
    {
      name: 'startDate',
      value: faker.datatype.datetime(),
    },
    {
      name: 'endDate',
      value: faker.datatype.datetime(),
    },
    nameValue,
    nameValue,
    {
      name: ATTRIBUTE_NAMES.contentFillMeasurement,
      value: {
        key: 'g',
        label: faker.datatype.string(),
      },
    },
    {
      name: ATTRIBUTE_NAMES.contentFill,
      value: faker.datatype.number(),
    },
    {
      name: ATTRIBUTE_NAMES.badges,
      value: [
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.typeNew,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: 'NOU',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topRight,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.9,
          },
        ],
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.discount,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: '20%',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topLeft,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.2,
          },
        ],
        [
          {
            name: BADGE_NAMES.type,
            value: {
              key: BADGE_VALUES.bestSeller,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.text,
            value: {
              ro: 'Best Seller',
            },
          },
          {
            name: BADGE_NAMES.side,
            value: {
              key: BADGE_VALUES.topRight,
              label: faker.datatype.string(),
            },
          },
          {
            name: BADGE_NAMES.priority,
            value: 0.1,
          },
        ],
      ],
    },
    {
      name: ATTRIBUTE_NAMES.config,
      value: [
        [
          {
            name: 'quantity',
            value: 1,
          },
          {
            name: 'setComponent',
            value: {
              typeId: 'product',
              id: faker.datatype.uuid(),
            },
          },
          {
            name: 'lineNumber',
            value: faker.datatype.number(),
          },
          {
            name: ATTRIBUTE_VALUES.availabilitySku,
            value: faker.datatype.uuid(),
          },
        ],
        [
          {
            name: 'quantity',
            value: 1,
          },
          {
            name: 'setComponent',
            value: {
              typeId: 'product',
              id: faker.datatype.uuid(),
            },
          },
          {
            name: 'lineNumber',
            value: faker.datatype.number(),
          },
          {
            name: ATTRIBUTE_VALUES.availabilitySku,
            value: faker.datatype.uuid(),
          },
        ],
      ],
    },
    {
      name: faker.datatype.string(),
      value: faker.datatype.boolean(),
    },
  ];

  const availability = {
    channels: {
      results: [
        {
          channel: {
            key: faker.datatype.string(),
          },
          availability: {
            isOnStock: faker.datatype.boolean(),
            availableQuantity: faker.datatype.number(),
          },
        },
        {
          channel: {
            key: faker.datatype.string(),
          },
          availability: {
            isOnStock: faker.datatype.boolean(),
            availableQuantity: faker.datatype.number(),
          },
        },
      ],
    },
    noChannel: {
      stockQty: faker.datatype.number(),
      isAvailable: faker.datatype.boolean(),
    },
  };
  const masterVariant = {
    id: faker.datatype.number(),
    sku: faker.datatype.string(),
    key: faker.datatype.string(),
    sellPrice: faker.datatype.number(),
    listPrice: faker.datatype.number(),
    formatedListPrice: faker.datatype.string(),
    formatedSellPrice: faker.datatype.string(),
    vatMessage: faker.datatype.string(),
    availability,
    assets: [{
      url: faker.datatype.string(),
      assetType: faker.datatype.string(),
      sequence: faker.datatype.number(),
    }],
    prices: [
      {
        value: {
          type: faker.datatype.string(),
          currencyCode: faker.datatype.string(),
          centAmount: faker.datatype.number(),
          fractionDigits: faker.datatype.number(2),
        },
        id: faker.datatype.uuid(),
        channel: {
          typeId: faker.datatype.string(),
          id: faker.datatype.uuid(),
        },
        discounted: {
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.string(),
            fractionDigits: faker.datatype.number(2),
          },
          discount: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
        },
      },
      {
        value: {
          type: faker.datatype.string(),
          currencyCode: faker.datatype.string(),
          centAmount: faker.datatype.number(),
          fractionDigits: faker.datatype.number(2),
        },
        id: faker.datatype.uuid(),
        discounted: {
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.string(),
            fractionDigits: faker.datatype.number(2),
          },
          discount: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
        },
      },
    ],
    images: [
      /* {
        url,
        label: label,
        dimensions: {
          w: faker.datatype.number(),
          h: faker.datatype.number(),
        },
      }, */
      {
        url,
        label,
        dimensions: {
          w: faker.datatype.number(),
          h: faker.datatype.number(),
        },
      },
    ],
    attributesRaw,
  };
  beforeEach(() => {
    inventoryMapper = {
      getProductInventoriesIds: jest.fn(),
    } as any;

    shippingService = {
      getShippingMethods: jest.fn(),
    } as any;

    inventoryDao = {} as any;
    market = stubMarket();
    magnoliaInfo = stubMagnoliaInfo();
    globalSettings = stubGlobalSettings();

    magnoliaTemplateDefinition = { 'mgnl:template': faker.datatype.string() };
    magnoliaBasePath = faker.internet.url();
    /* Dependencies */
    productDao = {} as any;
    magnoliaDao = {} as any;
    shoppingListDao = {} as any;
    common = {
      deliveryCountdownExists: jest.fn(),
      enableExcludeCount: jest.fn(),
    } as any;
    productMapper = {
      convert: jest.fn(),
      multiProductMap: jest.fn(),
      productMapping: jest.fn(),
    } as any;

    /* SUT */
    productService = new ProductService({
      productDao, magnoliaDao, shoppingListDao, productMapper, shippingService, common, inventoryMapper, inventoryDao,
    });
  });

  describe('getByKey()', () => {
    let productDto: ProductDto;
    const channelKey = faker.datatype.string();
    let wishlistId: string;
    const inventoryData = [
      {
        id: faker.datatype.uuid(),
        sku: faker.datatype.string(),
        custom: {
          customFieldsRaw: [
            {
              value: true,
              name: 'isLowAvailability',
            },
          ],
        },
      },
      {
        id: faker.datatype.uuid(),
        sku: faker.datatype.string(),
        custom: null,
      },
    ];
    beforeEach(() => {
      productDao.fetchProduct = jest.fn();
      magnoliaDao.getPdpDataFromMagnolia = jest.fn();
      magnoliaDao.getHowToLookFromMagnolia = jest.fn();
      magnoliaDao.getTemplateDataFromMagnolia = jest.fn();
      magnoliaDao.getGlobalSettings = jest.fn();
      shoppingListDao.findGraphQLOne = jest.fn();
      magnoliaDao.getDefaultWarehouse = jest.fn();
      productDto = stubCtProductDto(market);
      wishlistId = faker.datatype.uuid();
      inventoryDao.fetchInventoryDetail = jest.fn();
    });

    test('fetches data from productDao', async () => {
      /* Prepare */
      const product = {
        id: productDto.id,
        key: productDto.key,
        masterData: {
          current: {
            name: {
              [market.locale]: faker.datatype.string(),
            },
            description: {
              [market.locale]: faker.lorem.words(),
            },
            masterVariant,
            variants: [masterVariant],
          },
        },
      };
      (productDao.fetchProduct as Mock).mockReturnValueOnce(stubCtProductDto);
      (magnoliaDao.getPdpDataFromMagnolia as Mock).mockReturnValueOnce(magnoliaTemplateDefinition);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (magnoliaDao.getHowToLookFromMagnolia as Mock).mockReturnValueOnce(undefined);
      (common.deliveryCountdownExists as Mock).mockReturnValueOnce(productDto);
      (inventoryMapper.getProductInventoriesIds as Mock).mockReturnValueOnce(`"${faker.datatype.uuid()}"`);
      (inventoryDao.fetchInventoryDetail as Mock).mockReturnValueOnce(inventoryData);
      (productMapper.convert as Mock).mockReturnValueOnce(productDto);

      /* Execute */
      await productService.getByKey(market, productDto.key, magnoliaInfo, undefined, channelKey);

      /* Verify */
      expect(productDao.fetchProduct).toHaveBeenCalledTimes(1);
      expect(magnoliaDao.getPdpDataFromMagnolia).toHaveBeenCalledTimes(1);
      expect(magnoliaDao.getHowToLookFromMagnolia).toHaveBeenCalledTimes(1);
    });

    test('maps CtproductDto to productDto', async () => {
      /* Prepare */
      (productDao.fetchProduct as Mock).mockReturnValueOnce(productDto);
      (magnoliaDao.getDefaultWarehouse as Mock).mockReturnValueOnce({
        id: faker.datatype.uuid(),
        magnoliaBasePath,
      });
      (magnoliaDao.getPdpDataFromMagnolia as Mock).mockReturnValueOnce(magnoliaTemplateDefinition);
      (magnoliaDao.getHowToLookFromMagnolia as Mock).mockReturnValueOnce(undefined);
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (common.deliveryCountdownExists as Mock).mockReturnValueOnce(productDto);
      (inventoryMapper.getProductInventoriesIds as Mock).mockReturnValueOnce(`"${faker.datatype.uuid()}"`);
      (inventoryDao.fetchInventoryDetail as Mock).mockReturnValueOnce(inventoryData);
      (productMapper.convert as Mock).mockReturnValueOnce(productDto);
      (shoppingListDao.findGraphQLOne as Mock).mockReturnValueOnce({
        id: faker.datatype.uuid(),
        lineItems: [
          {
            id: faker.datatype.uuid(),
            productId: productDto.id,
          },
        ],
      });

      /* Execute */
      const result = await productService.getByKey(market, productDto.key, magnoliaInfo, wishlistId, undefined);
      /* Verify */
      expect(productMapper.convert).toHaveBeenCalledTimes(1);
      expect(shoppingListDao.findGraphQLOne).toHaveBeenCalledTimes(1);
      expect(magnoliaDao.getGlobalSettings).toHaveBeenCalledTimes(1);
      expect(result?.isWishlistHasItem).toBe(true);
    });

    test('returns the productDto from mapper', async () => {
      const hasPromotedShippingMethod = {
        hasPromotion: true,
      };
  
      /* Prepare */
      (productDao.fetchProduct as Mock).mockReturnValueOnce(stubCtProductDto);
      (common.deliveryCountdownExists as Mock).mockReturnValueOnce(true);
      (magnoliaDao.getPdpDataFromMagnolia as Mock).mockReturnValueOnce(magnoliaTemplateDefinition);
      (common.enableExcludeCount as Mock).mockReturnValueOnce({ ...productDto, ...hasPromotedShippingMethod });
      (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
      (inventoryMapper.getProductInventoriesIds as Mock).mockReturnValueOnce(`"${faker.datatype.uuid()}"`);
      (inventoryDao.fetchInventoryDetail as Mock).mockReturnValueOnce(inventoryData);
      (productMapper.convert as Mock).mockReturnValueOnce(productDto);

      /* Execute */
      const response:any = await productService.getByKey(market, productDto.key, magnoliaInfo, undefined, channelKey);

      /* Verify */
      expect(response?.pdpResponse).toBe(productDto);
    });

    test('returns undefined if the product does not exist', async () => {
      /* Prepare */
      (productDao.fetchProduct as Mock).mockReturnValueOnce(null);
      (common.deliveryCountdownExists as Mock).mockReturnValueOnce(productDto);
      (productMapper.convert as Mock).mockReturnValueOnce(productDto);
      /* Execute */
      const response = await productService.getByKey(market, productDto.key, magnoliaInfo, undefined, channelKey);

      /* Verify */
      expect(response).toBeUndefined();
      expect(productMapper.convert).not.toHaveBeenCalled();
    });
  });
});
describe('LeapApp bundle check', () => {
  /* System Under Test */
  let productService: ProductService;
  let shippingService: ShippingService;
  let common: Common;
  /* Dependencies */
  let productDao: ProductDao;
  let magnoliaDao: MagnoliaDao;
  let shoppingListDao: ShoppingListDao;
  let inventoryDao: InventoryDao;
  let productMapper: ProductMapper;
  let inventoryMapper: InventoryMapper;
  let market: any;
  const channelKey = faker.datatype.string();
  const attributesRaw = [
    {
      name: faker.datatype.string(),
      value: {
        key: faker.datatype.string(),
        label: faker.datatype.string(),
      },
    },
    {
      name: 'startDate',
      value: faker.date.recent(),
    },
    {
      name: 'endDate',
      value: faker.date.recent(),
    },
    {
      name: 'excludeCountDown',
      value: faker.datatype.boolean(),
    },
    {
      name: 'badges',
      value: [
        [
          {
            name: 'type',
            value: {
              key: BADGE_VALUES.typeNew,
              label: faker.datatype.string(),
            },
          },
          {
            name: 'text',
            value: {
              ro: 'NOU',
            },
          },
          {
            name: 'side',
            value: {
              key: BADGE_VALUES.topRight,
              label: faker.datatype.string(),
            },
          },
          {
            name: 'priority',
            value: 0.9,
          },
        ],
        [
          {
            name: 'type',
            value: {
              key: BADGE_VALUES.discount,
              label: faker.datatype.string(),
            },
          },
          {
            name: 'text',
            value: {
              ro: '20%',
            },
          },
          {
            name: 'side',
            value: {
              key: BADGE_VALUES.topLeft,
              label: faker.datatype.string(),
            },
          },
          {
            name: 'priority',
            value: 0.2,
          },
        ],
        [
          {
            name: 'type',
            value: {
              key: BADGE_VALUES.bestSeller,
              label: faker.datatype.string(),
            },
          },
          {
            name: 'text',
            value: {
              ro: 'Best Seller',
            },
          },
          {
            name: 'side',
            value: {
              key: BADGE_VALUES.topRight,
              label: faker.datatype.string(),
            },
          },
          {
            name: 'priority',
            value: 0.1,
          },
        ],
      ],
    },
    {
      name: 'config',
      value: [
        [
          {
            name: 'quantity',
            value: 1,
          },
          {
            name: 'setComponent',
            value: {
              typeId: 'product',
              id: faker.datatype.uuid(),
            },
          },
          {
            name: 'lineNumber',
            value: faker.datatype.number(),
          },
          {
            name: 'skuCode',
            value: faker.datatype.uuid(),
          },
        ],
        [
          {
            name: 'quantity',
            value: 1,
          },
          {
            name: 'setComponent',
            value: {
              typeId: 'product',
              id: faker.datatype.uuid(),
            },
          },
          {
            name: 'lineNumber',
            value: faker.datatype.number(),
          },
          {
            name: 'skuCode',
            value: faker.datatype.uuid(),
          },
        ],
      ],
    },
  ];
  const availability = {
    stockQty: faker.datatype.number(),
    isAvailable: faker.datatype.boolean(),
  };
  const masterVariant = {
    id: faker.datatype.number(),
    sku: faker.datatype.string(),
    key: faker.datatype.string(),
    sellPrice: faker.datatype.number(),
    listPrice: faker.datatype.number(),
    formattedListPrice: faker.datatype.string(),
    formattedSellPrice: faker.datatype.string(),
    vatMessage: faker.datatype.string(),
    availability,
    assets: [{
      url: faker.datatype.string(),
      assetType: faker.datatype.string(),
      sequence: faker.datatype.number(),
    }],
    prices: [
      {
        value: {
          type: faker.datatype.string(),
          currencyCode: faker.datatype.string(),
          centAmount: faker.datatype.number(),
          fractionDigits: faker.datatype.number(),
        },
        id: faker.datatype.uuid(),
        channel: {
          typeId: faker.datatype.string(),
          id: faker.datatype.uuid(),
        },
        discounted: {
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.string(),
            fractionDigits: faker.datatype.string(),
          },
          discount: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
        },
      },
      {
        value: {
          type: faker.datatype.string(),
          currencyCode: faker.datatype.string(),
          centAmount: faker.datatype.number(),
          fractionDigits: faker.datatype.number(),
        },
        id: faker.datatype.uuid(),
        discounted: {
          value: {
            type: faker.datatype.string(),
            currencyCode: faker.datatype.string(),
            centAmount: faker.datatype.string(),
            fractionDigits: faker.datatype.string(),
          },
          discount: {
            typeId: faker.datatype.string(),
            id: faker.datatype.uuid(),
          },
        },
      },
    ],
    images: [
      {
        url: faker.datatype.string(),
        label: faker.datatype.string(),
        dimensions: {
          w: faker.datatype.number(),
          h: faker.datatype.number(),
        },
      },
    ],
    attributesRaw,
  };
  const mockResponse = {
    id: 'a8b45c77-69fa-42ac-b92e-7547654d7b16',
    key: faker.datatype.string(),
    name: faker.datatype.string(),
    masterData: {
      current: {
        masterVariant,
      },
    },
  };
  const deliveryParam = {
    name: 'excludeCountDown',
    value: false,
  };
  let magnoliaInfo: MagnoliaInfo;
  let magnoliaTemplateDefinition: {
    'mgnl:template': string;
  };

  let globalSettings;
  beforeEach(() => {
    inventoryMapper = {
      getProductInventoriesIds: jest.fn(),
    } as any;
    market = { locale: 'ro', country: 'RO' };
    magnoliaInfo = stubMagnoliaInfo();
    globalSettings = stubGlobalSettings();
    magnoliaTemplateDefinition = { 'mgnl:template': faker.datatype.string() };

    /* Dependencies */
    productDao = {} as any;
    magnoliaDao = {} as any;
    shoppingListDao = {} as any;
    common = {
      deliveryCountdownExists: jest.fn(),
      enableExcludeCount: jest.fn(),
    } as any;
    productMapper = {
      convert: jest.fn(),
    } as any;
    productDao.fetchProduct = jest.fn();
    magnoliaDao.getPdpDataFromMagnolia = jest.fn();
    magnoliaDao.getGlobalSettings = jest.fn();
    magnoliaDao.getHowToLookFromMagnolia = jest.fn();
    magnoliaDao.getTemplateDataFromMagnolia = jest.fn();
    /* SUT */
    productService = new ProductService({
      productDao, magnoliaDao, shoppingListDao, productMapper, shippingService, common, inventoryMapper, inventoryDao,
    });
  });

  test('check inventory()', async () => {
    /* Prepare */
    (productDao.fetchProduct as Mock).mockReturnValueOnce(mockResponse);
    (magnoliaDao.getPdpDataFromMagnolia as Mock).mockReturnValueOnce(magnoliaTemplateDefinition);
    (magnoliaDao.getGlobalSettings as Mock).mockReturnValueOnce(globalSettings);
    (magnoliaDao.getHowToLookFromMagnolia as Mock).mockReturnValueOnce(undefined);
    (common.deliveryCountdownExists as Mock).mockReturnValueOnce(deliveryParam);
    (productMapper.convert as Mock).mockReturnValueOnce(mockResponse);
    /* Execute */
    await productService.getByKey(
      market,
      mockResponse.key,
      magnoliaInfo,
      undefined,
      channelKey,
    );
    /* Verify */
    expect(productDao.fetchProduct).toHaveBeenCalledTimes(1);
    expect(magnoliaDao.getPdpDataFromMagnolia).toHaveBeenCalledTimes(1);
    expect(magnoliaDao.getHowToLookFromMagnolia).toHaveBeenCalledTimes(1);
  });
});
