import faker from '@faker-js/faker';
import { CustomObjectDraft } from '@commercetools/platform-sdk';
import i18next from 'i18next';
import { MarketInfo } from '../../src/middlewares';
import { NotifyDao } from '../../src/daos/notify.dao';
import { NotifyService } from '../../src/services/notify.service';
import Mock = jest.Mock;

describe('LeapNotifyService', () => {
  /* System Under Test */
  let notifyService: NotifyService;

  /* Dependencies */
  let notifyDao: NotifyDao;
  let market: MarketInfo;

  beforeEach(() => {
    /* Dependencies */
    notifyDao = {} as any;

    /* SUT */
    notifyService = new NotifyService({ notifyDao });
  });

  describe('create()', () => {
    let customObjectDraft: CustomObjectDraft;
    let container;
    let key;
    let value;
    let productUrl;
    let sku;
    let productKey;
    let email;
    const mockData = {
      results: [{
        masterData: {
          current: {
            masterVariant: {
              sku: '42317-9161866660405742964',
            },
          },
        },
      }],
    };

    beforeEach(() => {
      sku = '42317-9161866660405742964';
      productKey = '42317';
      // || faker.datatype.number().toString();
      container = `notify-${sku}`;
      email = faker.internet.email();
      key = email.replace('@', '~~at~~');
      productUrl = faker.internet.url;
      value = {
        productUrl,
      };
      notifyDao.create = jest.fn();
      notifyDao.isProduct = jest.fn();

      customObjectDraft = ({
        container,
        key,
        value,
      });
    });

    test('creates the CtCustomObjectDraftDto using the ctNotifyDao', async () => {
      /* Prepare */
      (notifyDao.isProduct as Mock).mockResolvedValueOnce(true);
      (notifyDao.create as Mock).mockReturnValueOnce(customObjectDraft);

      /* Execute */
      await notifyService.create(market, sku, productKey, productUrl, email);

      /* Verify */
      expect(notifyDao.create).toHaveBeenCalledTimes(1);
      expect(notifyDao.create).toHaveBeenNthCalledWith(
        1,
        market,
        customObjectDraft,
      );
    });

    test('should through , if product not found', async () => {
      /* Prepare */
      (notifyDao.isProduct as Mock).mockResolvedValueOnce(false);
      (notifyDao.create as Mock).mockReturnValueOnce(customObjectDraft);

      /* Execute & Verify */
      await expect(notifyService.create(market, 'mismatch', productKey, productUrl, email))
        .rejects.toThrow(i18next.t('product.notFound'));
    });
  });
});
