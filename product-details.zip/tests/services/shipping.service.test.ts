import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubCtProductDto,
} from '../__stubs__';
import ShippingDao from '../../src/daos/shipping.dao';
import ShippingService from '../../src/services/shipping.service';
import Mock = jest.Mock;
import { ProductDto } from '../../src/dtos/product.dto';
import ShippingMapper from '../../src/mappers/shipping.mapper';

describe('LeapApp', () => {
  /* System Under Test */
  let shippingService: ShippingService;

  /* Dependencies */
  let shippingDao: ShippingDao;
  let shippingMapper: ShippingMapper;
  let market: MarketInfo;
  beforeEach(() => {
    market = stubMarket();

    /* Dependencies */
    shippingDao = {} as any;
    shippingMapper = {
      hasPromotedShippingMethod: jest.fn(),
    } as any;

    /* SUT */
    shippingService = new ShippingService({ shippingDao, shippingMapper });
  });

  describe('getShippingMethods()', () => {
    let productDto: ProductDto;

    beforeEach(() => {
      shippingDao.getShippingMethods = jest.fn();
      productDto = stubCtProductDto(market);
    });

    test('fetches data from shippingDao', async () => {
      /* Prepare */
      (shippingDao.getShippingMethods as Mock).mockReturnValueOnce(stubCtProductDto);
      (shippingMapper.hasPromotedShippingMethod as Mock).mockReturnValueOnce(productDto);

      /* Execute */
      await shippingService.getShippingMethods(market);

      /* Verify */
      expect(shippingDao.getShippingMethods).toHaveBeenCalledTimes(1);
    });
  });
});
