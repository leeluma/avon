import { ShippingMethodPagedQueryResponse } from '@commercetools/platform-sdk';
import { CtClient } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import { stubMarket, stubCtShippingDto } from '../__stubs__';
import Mock = jest.Mock;
import { stubCtClient } from '../__stubs__/ct-client.stub';
import { ShippingMethodDto } from '../../src/dtos/shipping.dto';
import ShippingDao from '../../src/daos/shipping.dao';
import { graphql } from '../../src/graphql';

describe('Shipping Dao testing Suit', () => {
  let shippingDao: ShippingDao;
  let shippingResponse: ShippingMethodPagedQueryResponse;
  let shippingMethodDto: ShippingMethodDto;

  let ctClient: CtClient;
  let market: MarketInfo;
  let post: Mock;
  let get: Mock;
  let execute: Mock;

  beforeEach(() => {
    market = stubMarket();

    shippingMethodDto = stubCtShippingDto(market);

    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    ctClient = stubCtClient(market.country, {
      shippingMethods: jest.fn().mockReturnValueOnce({ get }),
      graphql: jest.fn().mockReturnValueOnce({ get, post }),
    });

    shippingDao = new ShippingDao({ ctClient, graphql });
  });

  describe('getShippingMethods()', () => {
    let ctResponse: any;
    beforeEach(() => {
      shippingMethodDto = stubCtShippingDto(market);
      ctResponse = {
        body: {
          data: {
            shippingMethods: {
              results: [shippingResponse],
            },
          },
        },
      };
    });

    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      execute.mockReturnValueOnce(ctResponse);

      /* Execute */
      await shippingDao.getShippingMethods(market);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
    });
    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {};
      execute.mockRejectedValueOnce(err);

      const result = shippingDao.getShippingMethods(market);

      await expect(result).rejects.toThrow(err);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);
      /* Execute */
      const result = expect(() => shippingDao.getShippingMethods(market));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });
});
