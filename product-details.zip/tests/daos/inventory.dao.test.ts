import i18next from 'i18next';
import faker from '@faker-js/faker';
import { CtClient, ApiError } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import { graphql } from '../../src/graphql';
import { stubMarket, stubCtInventoryDto } from '../__stubs__';
import Mock = jest.Mock;
import { InventoryDao } from '../../src/daos';
import { stubCtClient } from '../__stubs__/ct-client.stub';

describe('Inventory Detail Dao testing Suit', () => {
  let inventoryDao: InventoryDao;
  let multiInventoryDto;
  let ctClient: CtClient;
  let gql: typeof graphql;
  let market: MarketInfo;
  let post: Mock;
  let execute: Mock;

  beforeEach(() => {
    market = stubMarket();

    multiInventoryDto = stubCtInventoryDto();

    execute = jest.fn();
    post = jest.fn().mockReturnValueOnce({ execute });
    ctClient = stubCtClient(market.country, {
      graphql: jest.fn().mockReturnValueOnce({ post }),
    });

    gql = {
      isProduct: Promise.resolve('query () { product {} }'),
      getProducts: Promise.resolve('query () { product {} }'),
      getInventory: Promise.resolve('query () { inventoryEntries {} }'),
      getShippingMethods: Promise.resolve('query () { shippingMethods {} }'),
      wishlistById: Promise.resolve('query () { shoppingList {} }'),
      getCustomerByToken: Promise.resolve('query () { customer {} }'),
    };

    inventoryDao = new InventoryDao({ ctClient, graphql: gql });
  });

  /**
   * Unit test case for fetchInventory function of inventory.dao
   */
  describe('fetchInventoryDetail()', () => {
    let condition;
    let ctResponse: any;
    beforeEach(() => {
      multiInventoryDto = stubCtInventoryDto({ id: faker.datatype.uuid() });
      condition = `id in ("${multiInventoryDto.id}")`;
      ctResponse = {
        body: {
          data: {
            inventoryEntries: {
              results: [multiInventoryDto],
            },
          },
        },
      };
    });

    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      const expectedBody = {
        query: 'query () { inventoryEntries {} }',
        variables: {
          where: condition,
          locale: market.locale,
        },
      };
      execute.mockReturnValueOnce(ctResponse);

      /* Execute */
      await inventoryDao.fetchInventoryDetail(market, `"${multiInventoryDto.id}"`);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: expectedBody },
      );
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await inventoryDao.fetchInventoryDetail(market, multiInventoryDto.id);

      expect(result).toBe(ctResponse.body.data.inventoryEntries.results);
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {
        data: null,
        errors: ['msg'],
      };
      execute.mockRejectedValueOnce(err);

      const result = inventoryDao.fetchInventoryDetail(market, multiInventoryDto.id);

      await expect(result).rejects.toThrow(err);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);
      /* Execute */
      const result = expect(() => inventoryDao.fetchInventoryDetail(market, multiInventoryDto.id));

      /* Verify */
      await result.rejects.toThrow(isError);
    });

    test('re-throws ApiError ctClient errors', async () => {
      /* Prepare */
      const errBody = {
        body: {
          data: null,
          errors: ['msg'],
        },
      };

      execute.mockReturnValueOnce(errBody);
      /* Execute */
      const call = () => inventoryDao.fetchInventoryDetail(market, multiInventoryDto.id);

      /* Verify */
      await expect(call).rejects.toThrow(
        new ApiError(400, i18next.t('error.inventoryInvalidUuid')),
      );
    });

    test('returns the result undefined', async () => {
      const errBody = {
        body: {
          data: null,
        },
      };
      execute.mockReturnValueOnce(errBody);

      const result = await inventoryDao.fetchInventoryDetail(market, multiInventoryDto.id);

      expect(result).toBe(undefined);
    });
  });
});
