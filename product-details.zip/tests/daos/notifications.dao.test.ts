import faker from '@faker-js/faker';
import axios from 'axios';
import { MarketInfo } from '../../src/middlewares';
import { stubMarket } from '../__stubs__';
import Mock = jest.Mock;
import { NotificationsDao } from '../../src/daos/notifications.dao';
import { Common } from '../../src/lib';

jest.mock('axios');

describe('NotificationsDao testing Suit', () => {
  let notificationsDao: NotificationsDao;
  let common: Common;
  let market: MarketInfo;
  let queryString: Mock;

  let apptusBaseUrl: string;
  let apptusClusterId: string;
  let apptusEsalesMarket: string;
  let params;

  beforeEach(() => {
    market = stubMarket();
    apptusBaseUrl = faker.internet.url();
    apptusClusterId = faker.datatype.uuid();
    apptusEsalesMarket = 'AVONSHOP_';

    queryString = jest.fn();

    common = {
      queryString,
    } as any;

    notificationsDao = new NotificationsDao({
      common,
      apptusBaseUrl,
      apptusClusterId,
      apptusEsalesMarket,
    });

    params = {
      sessionKey: faker.datatype.uuid(),
      customerKey: faker.datatype.uuid(),
      ticket: faker.datatype.uuid(),
      productKey: undefined,
      variantKey: undefined,
    };
  });

  describe('cartNotifications()', () => {
    const mockResponse = {
      data: true,
    };
    test('returns apptus response body', async () => {
      /* Prepare */
      (axios.post as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await notificationsDao.cartNotifications(market, params);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios.post).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia data', async () => {
      const error = new Error('Magnolia throw error');
      (axios.post as unknown as Mock).mockRejectedValueOnce(error);
      /* Execute */
      const response = expect(() => (notificationsDao).cartNotifications(market, params));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch notifications from Apps, because: ${error.stack}`),
      );
      expect(axios.post).toHaveBeenCalledTimes(1);
    });
  });
});
