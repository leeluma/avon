import faker from '@faker-js/faker';
import { CustomObjectDraft } from '@commercetools/platform-sdk';
import { graphql } from '../../src/graphql';
import { CtClient } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import { stubMarket } from '../__stubs__';
import Mock = jest.Mock;
import { NotifyDao } from '../../src/daos/notify.dao';
import { stubCtClient } from '../__stubs__/ct-client.stub';

describe('NotifyDao', () => {
  let notifyDao: NotifyDao;

  let customObjectDraft: CustomObjectDraft;

  let ctClient: CtClient;
  let gql: typeof graphql;
  let market: MarketInfo;
  let post: Mock;
  let withId: Mock;
  let get: Mock;
  let execute: Mock;

  beforeEach(() => {
    market = stubMarket();

    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get });
    post = jest.fn().mockReturnValueOnce({ execute });
    ctClient = stubCtClient(market.country, {
      customObjects: jest.fn().mockReturnValueOnce({ withId, post }),
      graphql: jest.fn().mockReturnValueOnce({ post }),
    });
    gql = {
      isProduct: Promise.resolve('query () { products {} }'),
      getProducts: Promise.resolve('query () { product {} }'),
      getInventory: Promise.resolve('query () { inventoryEntry {} }'),
      getShippingMethods: Promise.resolve('query () { inventoryEntry {} }'),
      wishlistById: Promise.resolve('query () { shoppingList {} }'),
      getCustomerByToken: Promise.resolve('query () { customer {} }'),
    };
    notifyDao = new NotifyDao({ ctClient, graphql: gql });
  });

  describe('create()', () => {
    test('queries ctClient with the CustomerDraft', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: { customObject: undefined } });

      /* Execute */
      await notifyDao.create(market, customObjectDraft);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: customObjectDraft },
      );
    });
  });

  describe('isProduct()', () => {
    let key: string;
    let sku: string;

    beforeEach(() => {
      key = faker.datatype.number().toString();
      sku = faker.datatype.uuid();
    });

    test('returns client response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            products: {
              exists: true,
            },
          },
        },
      });

      /* Execute */
      const result = await notifyDao.isProduct(market, key, [sku]);

      /* Verify */
      expect(result).toBe(true);
    });

    test('returns undefined response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            products: {
              exists: false,
            },
          },
        },
      });

      /* Execute */
      const result = await notifyDao.isProduct(market, key, [sku]);

      /* Verify */
      expect(result).toBe(false);
    });
  });
});
