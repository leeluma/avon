import faker from '@faker-js/faker';
import { CustomerDraft } from '@commercetools/platform-sdk';
import { CtClient } from '../../src/lib';
import { graphql } from '../../src/graphql';
import { MarketInfo } from '../../src/middlewares';
import { stubMarket, stubCustomerDraftDto, stubCtCustomerClient } from '../__stubs__';
import Mock = jest.Mock;
import { CustomerDao } from '../../src/daos';
import { GraphQLCustomerResponse } from '../../src/dtos';

describe('CustomerDao', () => {
  let customerDao: CustomerDao;

  let customerDraftDto: CustomerDraft;
  let ctClient: CtClient;
  let gql: typeof graphql;
  let market: MarketInfo;
  let execute: Mock;
  let get: Mock;
  let post: Mock;
  let withId: Mock;
  let password: Mock;
  let passwordReset: Mock;
  let passwordToken: Mock;
  let authHeader: string;
  let customerPasswordFlow: Mock;
  beforeEach(() => {
    market = stubMarket();
    customerDraftDto = stubCustomerDraftDto();

    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    password = jest.fn().mockReturnValueOnce({ post });
    passwordReset = jest.fn().mockReturnValueOnce({ post });
    passwordToken = jest.fn().mockReturnValueOnce({ post });
    customerPasswordFlow = jest.fn();
    authHeader = `Bearer ${faker.datatype.string()}`;
    ctClient = stubCtCustomerClient(market.country, {
      customers: jest.fn().mockReturnValueOnce({
        passwordToken, passwordReset, withId, post,
      }),
      carts: jest.fn().mockReturnValueOnce({ withId, post }),
      me: jest.fn().mockReturnValueOnce({ password, post }),
      graphql: jest.fn().mockReturnValueOnce({ post }),
      customerPasswordFlow,
    });
    gql = {
      isProduct: Promise.resolve('query () { product {} }'),
      getProducts: Promise.resolve('query () { product {} }'),
      getInventory: Promise.resolve('query () { inventoryEntries {} }'),
      getShippingMethods: Promise.resolve('query () { shippingMethods {} }'),
      wishlistById: Promise.resolve('query () { shoppingList {} }'),
      getCustomerByToken: Promise.resolve('query () { customer {} }'),
    };

    customerDao = new CustomerDao({ ctClient, graphql: gql });
  });
  describe('getCustomerDetailsGraphQL()', () => {
    let graphQLCustomerResponse: GraphQLCustomerResponse;
    test('returns client response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            me: {
              customer: {
                results: graphQLCustomerResponse,
              },
            },
          },
        },
      });

      /* Execute */
      const result = await customerDao.getCustomerDetailsGraphQL(market, authHeader);

      /* Verify */
      expect(result).toEqual({ results: graphQLCustomerResponse });
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader));

      /* Verify */
      await result.rejects.toThrowError();
    });

    test('re-throws non-404 ctClient errors if customer not found', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({
        body: {
          data: {
            me: {},
          },
        },
      });

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader));

      /* Verify */
      await result.rejects.toBeTruthy();
    });

    test('re-throws API-Error ctClient errors', async () => {
      /* Prepare */
      const err = {
        statusCode: 401,
        message: 'Unauthorized',
        messageArray: [],
        timestamp: faker.time.recent(),
        errors: [
          null,
        ],
      };
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader));
      /* Verify */
      await result.rejects.toBeTruthy();
    });

    test('re-throws API-Error ctClient errors if statusCode is not present in error', async () => {
      /* Prepare */
      const err = {
        message: 'Unauthorized',
        timestamp: faker.time.recent(),
        errors: [
          null,
        ],
      };
      execute.mockRejectedValueOnce(err);

      /* Execute */
      const result = expect(() => customerDao.getCustomerDetailsGraphQL(market, authHeader));
      /* Verify */
      await result.rejects.toBeTruthy();
    });
  });
});
