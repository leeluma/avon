import faker from '@faker-js/faker';
import { Product } from '@commercetools/platform-sdk';
import { readFile } from 'fs/promises';
import { CtClient } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';
import { stubCtProductDto, stubMarket } from '../__stubs__';
import Mock = jest.Mock;
import ProductDao from '../../src/daos/product.dao';
import { graphql } from '../../src/graphql';
import { stubCtClient } from '../__stubs__/ct-client.stub';
import { ProductDto } from '../../src/dtos/product.dto';

describe('Product Detail Dao testing Suit', () => {
  let productDao: ProductDao;

  let productDto: ProductDto;
  let product: Product;
  let ctClient: CtClient;
  let market: MarketInfo;
  let post: Mock;
  let withKey: Mock;
  let get: Mock;
  let execute: Mock;

  beforeEach(() => {
    market = stubMarket();

    productDto = stubCtProductDto(market);

    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withKey = jest.fn().mockReturnValueOnce({ get, post });
    ctClient = stubCtClient(market.country, {
      products: jest.fn().mockReturnValueOnce({ withKey, get }),
      inventory: jest.fn().mockReturnValueOnce({ get }),
      graphql: jest.fn().mockReturnValueOnce({ get, post }),
    });

    productDao = new ProductDao({ ctClient, graphql });
  });

  describe('fetchProduct()', () => {
    let ctResponse: any;
    beforeEach(() => {
      productDto = stubCtProductDto(market, { key: faker.datatype.string() });
      ctResponse = {
        body: {
          data: {
            product: {
              results: [product],
            },
          },
        },
      };
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: productDto });

      /* Execute */
      await productDao.fetchProduct(market, `"${productDto.key}"`);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {};
      execute.mockRejectedValueOnce(err);

      const result = productDao.fetchProduct(market, `"${productDto.key}"`);

      await expect(result).rejects.toThrow(err);
    });

    test('returns graphql response with inventory', async () => {
      execute.mockReturnValueOnce(ctResponse);

      await productDao.getInventoryBySku(market, `"${productDto?.masterVariant?.sku}"`);

      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);
      /* Execute */
      const result = expect(() => productDao.fetchProduct(market, productDto.key));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('re-throws non-404 ctClient errors for inventory', async () => {
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);
      const result = expect(() => productDao.getInventoryBySku(market, productDto?.masterVariant?.sku));

      await result.rejects.toThrow(iseError);
    });
  });
});
