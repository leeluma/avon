import faker from '@faker-js/faker';
import axios from 'axios';
import { Request } from 'express';
import { axiosOptions } from '../../src/lib/axios-options';
import { MarketInfo } from '../../src/middlewares';
import { stubMarket, stubExpressReq, stubMagnoliaInfo } from '../__stubs__';
import Mock = jest.Mock;
import MagnoliaDao from '../../src/daos/magnolia.dao';
import { MagnoliaInfo } from '../../src/dtos/common.dto';

jest.mock('axios');
// jest.mock('axios');

describe('Magnolia Dao testing Suit', () => {
  let magnoliaDao: MagnoliaDao;
  let market: MarketInfo;
  // let instanceAxios = axios;

  let req: Request;
  let magnoliaBasePath: string;
  let magnolia: MagnoliaInfo;
  const templateName = faker.datatype.string();

  const mockResponse = {
    data: {
      results: [
        {
          name: faker.datatype.string(),
          path: faker.datatype.string(),
          id: faker.datatype.uuid(),
          nodeType: faker.datatype.string(),
          title: faker.datatype.string(),
          facebook: {
            name: faker.datatype.string(),
            path: faker.datatype.string(),
          },
          twitter: {
            name: faker.datatype.string(),
            path: faker.datatype.string(),
          },
        },
      ],
    },
  };

  beforeEach(() => {
    magnolia = stubMagnoliaInfo();
    market = stubMarket();
    magnoliaBasePath = faker.internet.url();
    /* Stubs */
    req = stubExpressReq();

    magnoliaDao = new MagnoliaDao();
    /* instanceAxios = jest.fn(); */
  });

  // Unite test case for getPdpDataFromMagnolia() method
  describe('getPdpDataFromMagnolia()', () => {
    test('returns magnolia response body', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getPdpDataFromMagnolia(market, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getPdpDataFromMagnolia(market, magnolia));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch product data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  // Unit test case for getHowToLookFromMagnolia() method
  describe('getHowToLookFromMagnolia()', () => {
    let productKey:string;
    beforeEach(() => {
      productKey = faker.datatype.string();
    });

    test('How to and the Look response', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getHowToLookFromMagnolia(market, productKey, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch How to and the look data from magnolia', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getHowToLookFromMagnolia(market, productKey, magnolia));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch product How to and The Look data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getTemplateDataFromMagnolia()', () => {
    test('returns magnolia template response body', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getTemplateDataFromMagnolia(templateName, magnolia);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia template data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getTemplateDataFromMagnolia(templateName, magnolia));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch Product details template data from Magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getDefaultWarehouse()', () => {
    test('returns magnolia template response body', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getDefaultWarehouse(market, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch getDefaultWarehouse data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getDefaultWarehouse(market, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch warehouse data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getPriceFormat()', () => {
    test('Get price format from magnolia', async () => {
      (axios as unknown as Mock).mockResolvedValueOnce({ data: 'test' });
      /* Execute */
      const response = await magnoliaDao.getPriceFormat(market);
      /* Verify */
      expect(response).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch price format  from magnolia', async () => {
      const err = {
        stack: 'some error',
      };
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao as any).getPriceFormat(market));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch magnolia price format, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getGlobalSettings()', () => {
    test('returns magnolia global setting response body', async () => {
      /* Prepare */
      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getGlobalSettings(market, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledTimes(1);
    });

    test('Failed to fetch magnolia global setting data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      // (axios as unknown) = jest.fn().mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getGlobalSettings(market, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch global settings data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
});
