import faker from '@faker-js/faker';
import { MagnoliaInfo } from '../../src/dtos/common.dto';

export const stubMagnoliaInfo = (
  config: Partial<MagnoliaInfo> = {},
): MagnoliaInfo => {
  return {
    url: faker.internet.url(),
    isPreview: faker.datatype.boolean(),
    marketPath: faker.datatype.string(),
    ...config,
  };
};
