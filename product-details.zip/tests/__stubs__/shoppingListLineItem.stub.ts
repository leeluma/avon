import { ShoppingListLineItem } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';

export const stubShoppingListLineItem = (
  market: MarketInfo,
  config: Partial<ShoppingListLineItem> = {},
): ShoppingListLineItem => {
  return {
    variant: {
      id: faker.datatype.number(),
      sku: faker.datatype.uuid(),
    },
    addedAt: faker.date.recent().toISOString(),
    id: faker.datatype.uuid(),
    name: { [market.locale]: faker.random.word() },
    productId: faker.datatype.uuid(),
    productType: {
      typeId: 'product-type',
      id: faker.datatype.uuid(),
    },
    quantity: faker.datatype.number(),
    ...config,
  };
};
