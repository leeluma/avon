import faker from '@faker-js/faker';
import { ProductDto } from '../../src/dtos/product.dto';
import { MarketInfo } from '../../src/middlewares';
import { stubVariantFields, stubOffersDtoFields, stubDeliveryDtoFields } from '.';

export const stubCtProductDto = (
  market: MarketInfo,
  config: Partial<ProductDto> = {},
): ProductDto => {
  return {
    id: faker.datatype.string(),
    key: faker.datatype.string(),
    name: faker.random.word(),
    description: faker.commerce.productDescription(),
    metaDescription: faker.commerce.productDescription(),
    metaTitle: faker.random.words(),
    isLive: faker.datatype.boolean(),
    masterVariant: stubVariantFields(),
    variants: [],
    categories: [],
    breadcrumb: [],
    offers: [stubOffersDtoFields()],
    searchKeywords: faker.lorem.words(),
    deliveryCountdown: stubDeliveryDtoFields(),
    ...config,
  };
};
