import { ShoppingListLineItemDraft } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';

export const stubShoppingListLineItemDraft = (
  market: MarketInfo,
  config: Partial<ShoppingListLineItemDraft> = {},
): ShoppingListLineItemDraft => {
  return {
    sku: faker.datatype.uuid(),
    ...config,
  };
};
