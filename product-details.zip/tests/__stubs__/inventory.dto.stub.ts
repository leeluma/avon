import faker from '@faker-js/faker';
import { InventoryEntry } from '@commercetools/platform-sdk';

export const stubCtInventoryDto = (
  config: Partial<InventoryEntry> = {},
): any => {
  return {
    id: faker.datatype.uuid(),
    sku: faker.datatype.string(),
    custom: {
      customFieldsRaw: [
        {
          value: true,
          name: 'isLowAvailability',
        },
      ],
    },
    ...config,
  };
};
