import faker from '@faker-js/faker';
import { Category } from '../../src/dtos/product';

export const stubCategory = (
  config: Partial<Category> = {},
): Category => {
  return {
    typeId: 'category',
    id: faker.datatype.string(),
    key: faker.datatype.string(),
    name: faker.datatype.string(),
    slug: faker.datatype.string(),
    description: faker.datatype.string(),
    ancestors: [],
    parent: {
      typeId: 'category',
      id: faker.datatype.string(),
    },
    custom: {
      customFieldsRaw: {
        name: faker.datatype.string(),
        value: faker.datatype.string(),
      },
    },
    ...config,
  };
};
