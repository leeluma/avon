import faker from '@faker-js/faker';

export const stubProductVariant = (
  config = {},
) => {
  return {
    id: faker.datatype.uuid(),
    key: faker.datatype.uuid(),
    attributes: [],
    prices: [{
      value: {
        type: faker.random.word(),
        currencyCode: faker.finance.currencyCode(),
        centAmount: faker.datatype.number(),
        fractionDigits: faker.datatype.number(2),
      },
      id: faker.datatype.uuid(),
      channel: {
        typeId: faker.random.word(),
        id: faker.datatype.uuid(),
      },
      discounted: {
        value: {
          type: faker.random.word(),
          currencyCode: faker.finance.currencyCode(),
          centAmount: faker.datatype.number(),
          fractionDigits: faker.datatype.number(2),
        },
        discount: {
          typeId: faker.random.word(),
          id: faker.datatype.uuid(),
        },
      },
    }],
    images: [],
    assets: [],
    sku: faker.datatype.string(),
    isVatIncluded: faker.datatype.boolean(),
    vatIncludedMessage: faker.datatype.string(),
    ...config,
  };
};
