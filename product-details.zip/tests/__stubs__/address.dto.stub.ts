import { Address } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';

export const stubAddressDto = (
  config: Partial<Address> = {},
): Address => {
  return {
    id: faker.datatype.uuid(),
    custom: {
      type: {
        id: 'address-type',
        typeId: 'type',
      },
      fields: {
        Address1: faker.address.streetAddress(),
        Address2: faker.address.streetAddress(),
        Address3: faker.address.secondaryAddress(),
        Address4: faker.address.secondaryAddress(),
        Latitude: +faker.address.latitude(),
        Longitude: +faker.address.longitude(),
      },
    },
    city: faker.address.city(),
    region: faker.address.county(),
    country: faker.address.country(),
    state: faker.address.state(),
    phone: faker.phone.phoneNumber(),
    postalCode: faker.address.zipCode(),
    ...config,
  };
};
