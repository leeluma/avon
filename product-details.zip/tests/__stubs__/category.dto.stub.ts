import faker from '@faker-js/faker';
import { OffersDto } from '../../src/dtos/product.dto';

export const stubOffersDtoFields = (
  config: Partial<OffersDto> = {},
): OffersDto => {
  return {
    key: faker.datatype.string(),
    displayName: faker.datatype.string(),
    url: faker.datatype.string(),
    description: faker.datatype.string(),
    ...config,
  };
};
