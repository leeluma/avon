import faker from '@faker-js/faker';

export const stubSetAttributes = [
  {
    name: faker.datatype.string(),
    value: {
      key: faker.datatype.string(),
      label: faker.datatype.string(),
    },
  },
  {
    name: 'startDate',
    value: faker.date.recent(),
  },
  {
    name: 'endDate',
    value: faker.date.recent(),
  },
  {
    name: 'config',
    value: [
      [
        {
          name: 'quantity',
          value: 1,
        },
        {
          name: 'setComponent',
          value: {
            typeId: 'product',
            id: faker.datatype.uuid(),
          },
        },
        {
          name: 'lineNumber',
          value: faker.datatype.number(),
        },
        {
          name: 'skuCode',
          value: faker.datatype.uuid(),
        },
      ],
      [
        {
          name: 'quantity',
          value: 1,
        },
        {
          name: 'setComponent',
          value: {
            typeId: 'product',
            id: faker.datatype.uuid(),
          },
        },
        {
          name: 'lineNumber',
          value: faker.datatype.number(),
        },
        {
          name: 'skuCode',
          value: faker.datatype.uuid(),
        },
      ],
    ],
  },
];
