import faker from '@faker-js/faker';
import { DeliveryCountObject } from '../../src/dtos/product.dto';

export const stubDeliveryDtoFields = (
  config: Partial<DeliveryCountObject> = {},
): DeliveryCountObject => {
  return {
    message: faker.datatype.string(),
    cutOffTime: faker.datatype.string(),
    days: [],
    ...config,
  };
};
