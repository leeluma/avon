import { Customer, CustomerDraft } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import { stubAddressDto } from './address.dto.stub';
import { stubTrackingFields } from './trackingfields.stub';
import {
  CustomerResponseDto, CustomerRegistrationRequestDto,
} from '../../src/dtos';
import { stubAddressResponseDto } from './address-response.dto.stub';


export const stubCustomerDto = (
  config: Partial<Customer> = {},
): Customer => {
  return {
    id: faker.datatype.uuid(),
    version: faker.datatype.number(),
    isEmailVerified: faker.datatype.boolean(),
    email: faker.internet.email(),
    password: faker.internet.password(),
    addresses: [stubAddressDto(), stubAddressDto()],
    billingAddressIds: [faker.datatype.uuid(), faker.datatype.uuid()],
    shippingAddressIds: [faker.datatype.uuid(), faker.datatype.uuid()],
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName(),
    ...stubTrackingFields(),
    ...config,
  };
};

export const stubCustomerDraftDto = (
  config: Partial<CustomerDraft> = {},
): CustomerDraft => {
  return {
    isEmailVerified: faker.datatype.boolean(),
    email: faker.internet.email(),
    password: faker.internet.password(),
    addresses: [stubAddressDto(), stubAddressDto()],
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName(),
    ...config,
  };
};
export const stubCustomerRequestDto = (
  config: Partial<CustomerRegistrationRequestDto> = {},
): CustomerRegistrationRequestDto => {
  return {
    email: faker.internet.email(),
    password: faker.internet.password(),
    firstName: faker.name.firstName(),
    lastName: faker.name.lastName(),
    optIn: faker.datatype.boolean(),
    cartId: faker.datatype.uuid(),
    ...config,
  };
};

export const stubCustomerResponseDto = (
  config: Partial<CustomerResponseDto> = {},
): CustomerResponseDto => {
  return {
    id: faker.datatype.uuid(),
    email: faker.internet.email(),
    addresses: [stubAddressResponseDto(), stubAddressResponseDto()],
    ...config,
  };
};
