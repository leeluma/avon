import faker from '@faker-js/faker';
import { AvailabilityDto } from '../../src/dtos/product.dto';

export const stubAvailabilityFields = (
  config: Partial<AvailabilityDto> = {},
): AvailabilityDto => {
  return {
    stockQty: faker.datatype.number(),
    isAvailable: faker.datatype.boolean(),
    ...config,
  };
};
