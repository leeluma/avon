import faker from '@faker-js/faker';
import { VariantDto } from '../../src/dtos/product.dto';
import { stubAttributeFields, stubAvailabilityFields } from '.';
import { stubBadgesFields } from './productbadges.dto.stub';

export const stubVariantFields = (
  config: Partial<VariantDto> = {},
): VariantDto => {
  return {
    id: faker.datatype.number(),
    key: faker.datatype.uuid(),
    sku: faker.datatype.string(),
    listPrice: faker.datatype.number(),
    sellPrice: faker.datatype.number(),
    formattedListPrice: faker.datatype.string(),
    formattedSellPrice: faker.datatype.string(),
    vatMessage: faker.datatype.string(),
    unitPrice: faker.datatype.string(),
    attributes: stubAttributeFields(),
    badges: stubBadgesFields(),
    availability: stubAvailabilityFields(),
    currency: faker.datatype.string(),
    priceValidUntil: faker.datatype.string(),
    assets: [],
    ...config,
  };
};
