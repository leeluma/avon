import { ShoppingListDraft } from '@commercetools/platform-sdk';
import faker from '@faker-js/faker';
import { MarketInfo } from '../../src/middlewares';

export const stubShoppingListDraft = (
  market: MarketInfo,
  config: Partial<ShoppingListDraft> = {},
): ShoppingListDraft => {
  return {
    name: { [market.locale]: faker.random.word() },
    lineItems: [],
    ...config,
  };
};
