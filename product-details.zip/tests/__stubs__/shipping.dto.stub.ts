import faker from '@faker-js/faker';
import { ShippingMethodDto } from '../../src/dtos/shipping.dto';
import { MarketInfo } from '../../src/middlewares';

export const stubCtShippingDto = (
  market: MarketInfo,
  config: Partial<ShippingMethodDto> = {},
): ShippingMethodDto => {
  return {
    limit: faker.datatype.number(),
    offset: faker.datatype.number(),
    count: faker.datatype.number(),
    total: faker.datatype.number(),
    results: [
      {
        id: faker.datatype.string(),
        version: faker.datatype.string(),
        createdAt: faker.date.recent(),
        lastModifiedAt: faker.date.recent(),
        lastModifiedBy: {
          isPlatformClient: faker.datatype.boolean(),
          user: {
            typeId: faker.datatype.string(),
            id: faker.datatype.string(),
          },
        },
        createdBy: {
          clientId: faker.datatype.string(),
          isPlatformClient: faker.datatype.boolean(),
        },
        name: faker.datatype.string(),
        taxCategory: {},
        zoneRates: [],
        isDefault: faker.datatype.boolean(),
        key: faker.datatype.string(),
        custom: {
          customFieldsRaw: {
            value: faker.datatype.boolean(),
            name: faker.datatype.string(),
          },
        },
        references: [],
        attributeTypes: {},
        cartFieldTypes: {},
        lineItemFieldTypes: {},
        customLineItemFieldTypes: {},
        ...config,
      },
    ],
  };
};
