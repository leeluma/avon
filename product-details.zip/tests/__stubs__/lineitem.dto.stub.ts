import faker from '@faker-js/faker';
import { LineItemDto } from '../../src/dtos/line-item.dto';

export const stubLineItemDto = (
  config: Partial<LineItemDto> = {},
): LineItemDto => {
  return {
    id: faker.datatype.uuid(),
    quantity: faker.datatype.number(),
    images: [],
    listPrice: faker.datatype.number(),
    sellPrice: faker.datatype.number(),
    vatIncluded: faker.datatype.string(),
    productMassDetails: faker.datatype.string(),
    product: {},
    url: faker.internet.url(),
    name: faker.animal.dog(),
    ...config,
  };
};
