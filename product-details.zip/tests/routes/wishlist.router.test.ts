import { Router } from 'express';
import { param } from 'express-validator';
import { ShoppingListRouter } from '../../src/routes/wishlist.routes';
import { validateRequestSchema } from '../../src/middlewares';
import { ShoppingListController } from '../../src/controllers/wishlist.controller';
import { validateAddToWishlist, validateId } from '../../src/validators';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks/express-validator.mock').default);

describe('WishlistRouter', () => {
  let shoppingListController: ShoppingListController;
  let shoppingListRouter: ShoppingListRouter;
  let mockRouter: Router;

  beforeEach(() => {
    shoppingListController = {
      create: jest.fn(),
      deleteLineItem: jest.fn(),
    } as any;

    mockRouter = {
      post: jest.fn(() => mockRouter),
      delete: jest.fn(() => mockRouter),
    } as any;

    shoppingListRouter = new ShoppingListRouter({
      shoppingListController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = shoppingListRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      shoppingListRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenCalledTimes(1);
      expect(mockRouter.delete).toHaveBeenCalledTimes(1);
    });

    test('configures the POST / route', () => {
      shoppingListRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        1,
        '/',
        validateAddToWishlist,
        validateRequestSchema,
        expect.any(Function),
      );
    });

    test('configures the DELETE /:id/lineitems/:lineItemId route', () => {
      shoppingListRouter.buildExpressRouter();

      expect(mockRouter.delete).toHaveBeenNthCalledWith(
        1,
        '/:id/lineitems/:lineItemId',
        validateId,
        param('lineItemId').isUUID(),
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
