import { Router } from 'express';
import { ProductRouter } from '../../src/routes/product.routes';
import { ProductController } from '../../src/controllers/product.controller';
import { validateKey } from '../../src/validators';
import { validateRequestSchema } from '../../src/middlewares/validate-request-schema';
import { magnoliaUrlMiddleware } from '../../src/middlewares/magnolia-url.middleware';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks/express-validator.mock').default);

describe('ProductRouter', () => {
  let productController: ProductController;
  let productRouter: ProductRouter;
  let mockRouter: Router;

  beforeEach(() => {
    productController = {
      getByKey: jest.fn(),
    } as any;

    mockRouter = {
      get: jest.fn(() => mockRouter),
    } as any;

    productRouter = new ProductRouter({
      productController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = productRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      productRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenCalledTimes(1);
    });

    test('configures the GET /:key route', () => {
      productRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/:key',
        validateKey,
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function),
      );
    });
  });
});
