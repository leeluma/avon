import { Router } from 'express';
import { NotificationsRouter } from '../../src/routes/notifications.router';
import { NotificationsController } from '../../src/controllers/notifications.controller';
import { validateNotifications } from '../../src/validators';
import { validateRequestSchema } from '../../src/middlewares';

describe('notificationsRouter', () => {
  let notificationsController: NotificationsController;
  let notificationsRouter: NotificationsRouter;
  let mockRouter: Router;

  beforeEach(() => {
    notificationsController = {
      addToCart: jest.fn(),
    } as any;

    mockRouter = {
      post: jest.fn(() => mockRouter),
    } as any;

    notificationsRouter = new NotificationsRouter({
      notificationsController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter() for Notifications', () => {
    test('configures the POST /adding-to-cart route', () => {
      notificationsRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        1,
        '/adding-to-cart',
        validateNotifications,
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
