import { Router } from 'express';
import { body } from 'express-validator';
import { NotifyRouter } from '../../src/routes/notify.routes';
import { NotifyController } from '../../src/controllers/notify.controller';
import { validateRequestSchema } from '../../src/middlewares';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks/express-validator.mock').default);

describe('NotifyRouter', () => {
  let notifyController: NotifyController;
  let notifyRouter: NotifyRouter;
  let mockRouter: Router;

  beforeEach(() => {
    notifyController = {
      create: jest.fn(),
    } as any;

    mockRouter = {
      post: jest.fn(() => mockRouter),
    } as any;

    notifyRouter = new NotifyRouter({
      notifyController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = notifyRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      notifyRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenCalledTimes(1);
    });

    test('configures the POST / route', () => {
      notifyRouter.buildExpressRouter();

      expect(mockRouter.post).toHaveBeenNthCalledWith(
        1,
        '/',
        body('sku').notEmpty().withMessage('product.sku'),
        body('productKey').notEmpty().withMessage('product.key'),
        body('productUrl').notEmpty().isURL().withMessage('product.url'),
        body('email').isEmail().withMessage('customer.email'),
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
