import { Router, RequestHandler } from 'express';
import { CustomerRouter } from '../../src/routes';
import { CustomerController } from '../../src/controllers';
import { validateRequestSchema } from '../../src/middlewares';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks/express-validator.mock').default);

describe('CustomerRouter', () => {
  let customerController: CustomerController;
  let customerRouter: CustomerRouter;
  let mockRouter: Router;
  let mockValidationSettingsMiddleware: RequestHandler;
  let authMiddleware: RequestHandler;

  beforeEach(() => {
    customerController = {
      getById: jest.fn(),
      registration: jest.fn(),
      changePassword: jest.fn(),
      getAddress: jest.fn(),
      addAddress: jest.fn(),
      updateAddress: jest.fn(),
      getAddressesByCustomerId: jest.fn(),
      updateMyCustomer: jest.fn(),
      deleteAddress: jest.fn(),
      login: jest.fn(),
      resetCustomersPassword: jest.fn(),
      forgotCustomersPassword: jest.fn(),
      defaultAddress: jest.fn(),
      getCustomerByToken: jest.fn(),
      updateCustomerOptIn: jest.fn(),
    } as any;

    mockRouter = {
      get: jest.fn(() => mockRouter),
      post: jest.fn(() => mockRouter),
      put: jest.fn(() => mockRouter),
      delete: jest.fn(() => mockRouter),
    } as any;

    mockValidationSettingsMiddleware = jest.fn(() => mockRouter);
    authMiddleware = jest.fn().mockReturnValueOnce(mockRouter);

    customerRouter = new CustomerRouter({
      customerController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = customerRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      customerRouter.buildExpressRouter();
      expect(mockRouter.get).toHaveBeenCalledTimes(1);
    });

    test('configures the GET / route', () => {
      customerRouter.buildExpressRouter();

      expect(mockRouter.get).toHaveBeenNthCalledWith(
        1,
        '/',
        authMiddleware,
        validateRequestSchema,
        expect.any(Function),
      );
    });
  });
});
