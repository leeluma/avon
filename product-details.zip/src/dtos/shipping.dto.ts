export interface CustomFields{
  value: boolean;
  name: string;
}
export interface CustomDto {
  customFieldsRaw: CustomFields;
}

export interface User {
  typeId: string;
  id: string;
}

export interface LastModifiedBy {
  isPlatformClient: boolean;
  user: User;
}

export interface CreatedBy {
  clientId: string;
  isPlatformClient: boolean;
}

export interface LooseObject {
  [key: string]: string
}

export interface ShippingResponseDto{
  id: string,
  version: string
  createdAt: Date;
  lastModifiedAt: Date;
  lastModifiedBy: LastModifiedBy;
  createdBy: CreatedBy;
  name:string;
  taxCategory: LooseObject;
  zoneRates: [];
  isDefault: boolean;
  key: string,
  custom: CustomDto;
  references: [];
  attributeTypes: LooseObject;
  cartFieldTypes: LooseObject;
  lineItemFieldTypes: LooseObject;
  customLineItemFieldTypes: LooseObject;
}

export interface ShippingMethodDto{
  limit: number;
  offset: number;
  count: number;
  total: number;
  results: ShippingResponseDto[];
}

export interface ShippingMethodsResultDto {
  custom: CustomDto;
}
export interface ShippingMethodsResponseDto {
  results: ShippingMethodsResultDto[];
}
