export interface NotificationRequest {
  ticket?: string;
  productKey?: string;
  variantKey?: string;
}
