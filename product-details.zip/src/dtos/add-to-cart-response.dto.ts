import { Address, LineItem } from '@commercetools/platform-sdk';

export interface AddToCartResponseDto {
  id: string;
  version: number;
  totalRetailPriceAmount: string;
  totalTaxAmount: number;
  totalAdjustmentAmount: number;
  totalInvoicedAmount: string;
  customerId: string;
  anonymousId: string;
  lineItems: LineItem[];
  shippingAddress: Address;
}
