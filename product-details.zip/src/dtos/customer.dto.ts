import { Customer } from '@commercetools/platform-sdk';
import { AddressResponseDto, GraphQLAddress } from '.';
import { CommonResponse, GraphQLCustomFields } from './common.dto';

/** Used to accept customer info in registration API */
export interface CustomerRegistrationRequestDto {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    optIn?: boolean;
    cartId?: string;
    key?: string;
}
/**
 * Used to accept customer login request info
 */
export interface LoginReqDto {
    email: string,
    password: string
}

/** Used to return customer info in API response */
export interface CustomerResponseDto {
    id: string;
    email: string;
    firstName?: string;
    lastName?: string;
    optIn?: boolean;
    phoneNumber?: string;
    termsAndConditions?: boolean;
    addresses?: AddressResponseDto[];
}
export interface SetDefaultAddressPayload {
    version: string;
    actions : CommonResponse
}
/**
 * customer's login response Dto
 */
export interface CustomerLoginResDto{
    accessToken: string;
    tokenType: string;
    expiresIn: number;
    refreshToken: string;
}
/**
 *  Used to return cusrtomers response
 */
export interface CustomerAddressResponseDto {
    addresses?: AddressResponseDto[];
}

/** Used to accept customer info in change password API */
export interface ChangePasswordRequestDto {
    customerId: string;
    currentPassword: string;
    newPassword: string;
}

export interface CustomerForgotPassword {
    value: string,
    expiresAt: string,
    customerId: string,
}
export interface LoginDto {
    email: string,
    password: string,
    cartId?: string,
  }

export type GraphQLCustomerResponse = Omit<Customer, 'addresses'> & {
    custom?: GraphQLCustomFields;
    addresses: GraphQLAddress[] };

export interface SetDefaultAddressDto {
    isBilling: boolean,
    isDelivery: boolean,
    addressId: string,
    version: number,
}

export interface LoginCustomerDto{
    access_token: string;
    expires_in: number;
    token_type: string;
    refresh_token: string;
    scope: string;
    expires_at?: number;
}

export interface CustomerLoginResponseDto {
    accessToken: string;
    expiresIn: number;
    tokenType: string;
    scope?: string;
    refreshToken: string;
    expiresAt?: number;
    customerId: string | undefined;
    cartId?: string;
    wishlistId?: string;
  }
export interface LoginResponseDto {
    statusCode: number;
    body: CustomerLoginResponseDto;
  }

export interface CustomerActiveCartAndWishListDto {
    shoppingLists: {
        results: [
            {
                id: string;
            }
        ]
    };
    me: {
        activeCart:{
            id: string;
        }
    };
  }
