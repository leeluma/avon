import { FieldContainer } from '@commercetools/platform-sdk';

/** Generic response from CommerceTools */
export interface CtResponse<T> {
  statusCode: number;
  body: T;
}

export interface CtLocalizedStringDto {
  [locale: string]: string;
}

export interface CtId {
  id: string;
}

export interface CtTrackingClientDto {
  clientId: string;
  isPlatformClient: boolean;
}

/** Common interface to extend from in most other Ct* interfaces */
export interface CtTrackingFieldsDto {
  createdAt: string;
  createdBy: CtTrackingClientDto;
  lastModifiedAt: string;
  lastModifiedBy: CtTrackingClientDto;
}

export interface MagnoliaInfo {
  url: string;
  isPreview: boolean;
  marketPath: string;
}

export interface CtDto {
  [k: string]: string;
  }

export interface CommonResponse {
  [x: string]: any | unknown; // NOSONAR
}
export interface GraphQLTypeResourceIdentifier {
  typeId: 'type';
  id?: string;
  key?: string;
}

export interface GraphQLCustomFields {
    type: GraphQLTypeResourceIdentifier;
    customFieldsRaw: FieldContainer;
  }
