import { CtId } from './common.dto';

export interface User {
  typeId: string;
  id: string;
}

export interface LastModifiedBy {
  isPlatformClient: boolean;
  user: User;
}

export interface CreatedBy {
  clientId: string;
  isPlatformClient: boolean;
}

export interface ProductType {
  typeId: string;
  id: string;
}

export interface Name {
  en: string;
}

export interface Description {
  en: string;
}

export interface Slug {
  en: string;
}

export interface Ancestor {
  id: string;
  key: string;
}

export interface CategoryCustomDto {
  customFieldsRaw: {
    name: string;
    value: string;
  }
}
export interface Category {
  typeId: string;
  id: string;
  key: string;
  name: string;
  slug: string;
  description: string;
  ancestors: Ancestor[],
  parent:{
    typeId: string;
    id: string;
  }
  custom: CategoryCustomDto,
}
export interface MetaTitle {
  en: string;
}

export interface MetaDescription {
  en: string;
}

export interface Value {
  type: string;
  currencyCode: string;
  centAmount: number;
  fractionDigits: number;
}

/**
 * Discount interface
 */
export interface Discount {
  typeId: string;
  id: string;
}
export interface Discounted {
  value: Value;
  discount: Discount;
}

export interface Channel {
  typeId: string;
  id: string;
}

export interface Price {
  value: Value;
  id: string;
  channel: Channel;
  discounted: Discounted;
}

export interface Dimensions {
  w: number;
  h: number;
}

export interface Image {
  url: string;
  label: string;
  dimensions: Dimensions;
}
export interface Availability {
  isOnStock: boolean;
  availableQuantity: number;
  version: number;
  id: string;
}

export interface VariantValue {
  type: string;
  currencyCode: string;
  centAmount: number;
  fractionDigits: number;
}
export interface VariantChannel {
  typeId: string;
  id: string;
}
export interface VariantPrice {
  value: VariantValue;
  id: string;
  channel: VariantChannel;
}
export interface VariantDimensions {
  w: number;
  h: number;
}
export interface VariantImage {
  url: string;
  label: string;
  dimensions: VariantDimensions;
}

export interface StagedName {
  en: string;
}

export interface StagedDescription {
  en: string;
}

export interface StagedCategory {
  typeId: string;
  id: string;
}

export interface StagedSlug {
  en: string;
}

export interface StagedMetaTitle {
  en: string;
}

export interface StagedMetaDescription {
  en: string;
}

export interface TaxCategory {
  typeId: string;
  id: string;
}

export interface SearchText {
  text: string
}

export interface Locale {
    locale: SearchText[];
}

export interface SearchKeywords {
  searchKeywords: Locale;
}

export interface ProductVariantPriceDto extends CtId {
  value: {
      type: string;
      currencyCode: string;
      centAmount: number;
      fractionDigits: number;
  },
  channel: {
      typeId: string;
      id: string;
  }
  discounted: {
      value: {
         type: string;
         currencyCode: string;
         centAmount: number;
         fractionDigits: number;
      },
  discount: {
      typeId: string;
      id: string;
      }
  }
}
