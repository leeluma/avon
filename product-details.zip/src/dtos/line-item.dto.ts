import { LooseObject } from './product.dto';

export interface BaseMeasure{
  '@name':string,
  '@path':string,
  '@id':string,
  '@nodeType':string,
  'translation':string,
  'unitPriceBaseMeasure':string,
  'containerSizeLimit':string,
  'masterContentIdentifier':string,
  '@nodes':Array<string>
}
export interface MagnoliaPriceFormatDto{
  'isVatIncluded': string;
  'vatIncludedMessage': string;
  '@name': string,
  '@path':string,
  '@id':string,
  '@nodeType':string,
  'ccy':string,
  'showDecimalZero':string,
  'thousandSeperator':string,
  'noOfDigit':string,
  'masterContentIdentifier':string,
  'currencyPlacement':string,
  'mgnl:created':string,
  'decimalPoint':string,
  'mgnl:lastModified':string,
  'baseMeasure':BaseMeasure,
  '@nodes':Array<string>
}

export interface LineItemImageDto {
  url: string,
  assetType: string,
  sequence: number,
}

export interface LineItemDto {
  id: string;
  variantId?: number;
  quantity: number | undefined;
  url: string;
  name: string;
  product: LooseObject;
  listPrice: number,
  sellPrice: number,
  vatIncluded: string,
  productMassDetails: string;
  images: LineItemImageDto[]
}
