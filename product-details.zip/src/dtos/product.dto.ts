import {
  ProductVariantAvailability, InventoryEntry, LocalizedString, ProductCatalogData,
} from '@commercetools/platform-sdk';

export interface AttributesDto{
  variantType: string;
  variantValue: string;
  shortDescription: string;
  brandId: string;
  brandName: string;
  finishedStockCode: string;
  specialMessage: string;
  ContentFillMeasure: string;
  ContentFill: string;
  excludeCountDown: boolean;
  isDiscontinued: boolean;
  inStock: boolean;
  nonRepListPrice: string;
  nonRepSalePrice: string;
}
export interface LooseObject {
  [key: string]: string;
}
export interface AssetsDto{
  url: string;
  assetType?: string;
  sequence: number;
  shotClassification?: string,
  title?: string,
  format?: string,
}
export interface Channel{
  key: string;
}
export interface ChannelAvailability{
  channel: Channel;
  availability: ProductVariantAvailability;
  id?: string;
}

export interface AvailabilityDto{
  stockQty?: number;
  isAvailable?: boolean;
  limitedStock?: boolean;
}

export interface BadgesDto {
  topRight: string;
  topLeft: string;
}

export interface VariantDto{
  id: number;
  key?: string;
  sku?: string;
  listPrice: number,
  sellPrice: number,
  formattedListPrice: string,
  formattedSellPrice: string,
  vatMessage: string,
  unitPrice: string,
  attributes?: AttributesDto;
  badges: BadgesDto;
  availability: AvailabilityDto;
  assets?: AssetsDto[];
  currency: string,
  priceValidUntil: string | null,
}

export interface BreadcrumbDto {
  key?: string;
  parentKey?: string;
  displayName?: string | LocalizedString;
  url?: string;
}

export interface OffersDto {
  key?: string;
  displayName: string | LocalizedString;
  url: string;
  description: string | LocalizedString;
}
export interface AncestorsDto {
  id :string
  key : string
  metaKeywords : string | LocalizedString
  slug : string | LocalizedString
  name : string | LocalizedString
}

export interface CustomFieldsRawDto {
  name :string
  value : string | boolean
}
export interface CustomFields {
  customFieldsRaw: CustomFieldsRawDto[]
}
export interface CategoryResDto {
  id: string;
  slug: string | LocalizedString;
}
export interface CategoryDto {
  id: string;
  slug: string | LocalizedString;
  key?: string;
  description?: string | LocalizedString;
  name?: string | LocalizedString;
  parent?: string;
  ancestors?: AncestorsDto[];
  custom?: CustomFields;
}
export interface GraphQLInventoryEntry extends Omit<InventoryEntry, 'custom'> {
  custom: CustomFields;
}
export interface DeliveryCountObject{
  message: string;
  cutOffTime: string;
  days: (string | undefined)[];
}

export interface DeliverCountDownDto {
  deliveryCountDown: DeliveryCountObject | [];
}
export interface BadgeNode {
  priority?: string;
  type?: string;
  text?: string;
  side?: string;
}
export interface SearchKeywordsDataDto {
  text: string;
}
export interface SearchKeywordsDto {
  locale: string;
  searchKeywords: SearchKeywordsDataDto;
}
export interface MultiProductDto {
  id: string;
  key: string;
  name: string;
  description: string;
  metaDescription?: string;
  metaKeywords?: string;
  metaTitle?: string;
  isLive: boolean;
  masterVariant: VariantDto;
  variants: VariantDto[];
}
export interface VariantDimensions {
  w: number;
  h: number;
}
export interface ChannelavailabilityDto{
  isOnStock : boolean;
  availableQuantity: number;
  id: string;
}
export interface ChannelsresultsDto{
  key?: string;
}
export interface VariantchannelsresultsDto{
  channel: ChannelsresultsDto;
  availability: ChannelavailabilityDto;
}
export interface VariantchannelsDto{
  results: VariantchannelsresultsDto[];
}
export interface VariantavailabilityDto{
  channels: VariantchannelsDto;
  noChannel: ChannelavailabilityDto;
}
export interface PriceschannelDto{
  id: string;
}
export interface PricesValueDto{
  type: string;
  currencyCode: string;
  centAmount: number;
  fractionDigits: number;
}
export interface PricesdiscountedvalueDto{
  type: string;
  currencyCode: string;
  centAmount: number;
  fractionDigits: number;
}
export interface PricesdiscountedDto{
  value: PricesdiscountedvalueDto;
}
export interface PricesDto{
  id: VariantchannelsDto;
  validUntil: string;
  value: PricesValueDto;
  channel: PriceschannelDto;
  discounted: PricesdiscountedDto;
}
export interface ImagedimensionsDto{
  width: number;
  height: number;
}
export interface ImageDto{
  url: string;
  label: string;
  dimensions: ImagedimensionsDto
}
export interface AttributesRawValueDto{
  key: string;
  lable: string;
}
export interface AttributesRawBatchValueDto{
  key: string;
  lable: string;
}
export interface AttributesRawBatchDto{
  name: string;
  value: string | LooseObject | number | AttributesRawBatchValueDto;
}
export interface AttributesRawDto{
  name: string;
  value: AttributesRawValueDto[] | [AttributesRawBatchDto] | [];
}
export interface MastervariantDto{
  id: string;
  key?: string;
  sku?: string;
  availability: VariantavailabilityDto;
  prices?: PricesDto[];
  images?: ImageDto[];
  attributesRaw: AttributesRawDto[];
}
export interface CurrentDto{
  searchKeywords: SearchKeywordsDto
  slug: string | LocalizedString;
  name: string | LocalizedString;
  metaTitle?: string;
  metaDescription?: string | LocalizedString;
  description: string;
  categories: CategoryDto[];
  masterVariant: MastervariantDto;
  variants: MastervariantDto[];
}
export interface MasterdataDto{
  current: CurrentDto;
}
export interface ProductgraphqlDto{
  id: string
  key: string | LocalizedString;
  masterData: MasterdataDto;
}
export interface PdpNotFoundResponse{
  msg: string;
  id : string;
  key : string | LocalizedString;
}
export interface ProductDto {
  id: string;
  key: string | LooseObject;
  name: string | LooseObject;
  description: string;
  metaTitle?: string;
  metaDescription?: string | LooseObject;
  isLive: boolean;
  searchKeywords: string;
  offers: OffersDto[];
  breadcrumb: BreadcrumbDto[];
  categories: CategoryDto[];
  deliveryCountdown: DeliveryCountObject | [];
  masterVariant: VariantDto | undefined;
  variants: VariantDto[];
}
export interface ProductResponseDto {
  pdpResponse: ProductDto,
  productSetting: LooseObject,
  templateDefinition: LooseObject,
  isWishlistHasItem?: boolean,
}
export interface GraphQLVariant extends Omit<MastervariantDto,
  'availability' > {
  availability: VariantavailabilityDto;
  attributesRaw: AttributesRawDto[];
}
export interface GraphQLProductData extends Omit<ProductDto,
  'masterVariant' | 'variants' > {
  masterVariant: GraphQLVariant;
  variants: GraphQLVariant[];
}
export interface GraphQLProductCatalogData extends Omit<ProductCatalogData,
  'current' > {
  current: GraphQLProductData;
}
export interface GraphQLProduct extends Omit<ProductgraphqlDto,
  'masterData' > {
  masterData: GraphQLProductCatalogData;
}
export interface CommonResponse {
  [x: string]: any | unknown; // NOSONAR
}
