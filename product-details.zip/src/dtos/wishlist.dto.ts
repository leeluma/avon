import { ShoppingListLineItem, ShoppingList } from '@commercetools/platform-sdk';
import { LineItemDto } from './line-item.dto';

/**
 * @swagger
 * components:
 *   schemas:
 *     LineItemDto:
 *       additionalProperties: false
 *       properties:
 *         id:
 *           type: string
 *         name:
 *           type: string
 *         images:
 *           items: {}
 *           type: array
 *         listPrice:
 *           type: number
 *         sellPrice:
 *           type: number
 *         vatIncluded:
 *           type: string
 *         productMassDetail:
 *           type: string
 *         url:
 *           type: string
 *         product:
 *           $ref: '#/components/schemas/ProductsDto'
 *         quantity:
 *           type: number
 *         variantId:
 *           type: number
 *       required:
 *         - id
 *         - product
 *         - prices
 *         - images
 *         - name
 *         - url
 *         - listPrice
 *         - sellPrice
 *         - vatIncluded
 *         - productMassDetails
 *       type: object
 *     ProductsDto:
 *       additionalProperties: false
 *       properties:
 *         id:
 *           type: string
 *       required:
 *         - id
 *       type: object
 *     WishlistDto:
 *       additionalProperties: false
 *       properties:
 *         anonymousId:
 *           type: string
 *         customerId:
 *           type: string
 *         id:
 *           type: string
 *         key:
 *           type: string
 *         lineItems:
 *           items:
 *             $ref: '#/components/schemas/LineItemDto'
 *           type: array
 *         name:
 *           type: string
 *         version:
 *           type: number
 *       required:
 *         - id
 *         - name
 *         - lineItems
 *       type: object
 */
export interface WishlistDto {
  id: string;
  name: string;
  key?: string;
  lineItems: LineItemDto[];
  customerId?: string;
  anonymousId?: string;
  version?: number;
}

export interface GraphQLShoppingListLineItem extends Omit<ShoppingListLineItem, 'name' | 'productSlug' |
'addedAt' | 'productType'> {
  name: string;
  productSlug: string;
}

export interface GraphQLShoppingList extends Omit<ShoppingList, 'name' | 'lineItems' |
'createdAt' | 'lastModifiedAt'> {
  name: string;
  lineItems?: GraphQLShoppingListLineItem[],
}
