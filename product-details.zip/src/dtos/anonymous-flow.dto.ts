/** Used to accept anonymous session info in anonymous flow API */

export interface AnonymousFlowDto{
    access_token: string;
    expires_in: number;
    token_type: string;
    refresh_token: string;
    scope?: string;
}

export interface AnonymousFlowResponseDto {
  accessToken: string;
  expiresIn: number;
  refreshToken: string;
  anonymousId: string;
}

/**
 * @swagger
 * components:
 *   schemas:
 *     AnonymousFlowResponseDto:
 *       additionalProperties: false
 *       description: anonymous session flow response Dto
 *       properties:
 *         accessToken:
 *           type: string
 *         expiresIn:
 *           type: number
 *         refreshToken:
 *           type: string
 *         anonymousId:
 *           type: string
 *       required:
 *         - accessToken
 *         - anonymousId
 *         - expiresIn
 *         - refreshToken
 *       type: object
 */
