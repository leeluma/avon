import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { CustomObjectDraft } from '@commercetools/platform-sdk';
import { NotifyDao } from '../daos/notify.dao';
import { logger, ApiError } from '../lib';
import { MarketInfo } from '../middlewares';

/**
 * Notify Service constructor config
 * @param: notifyDao
 */

interface NotifyServiceConfig {
  notifyDao: NotifyDao;
}

/**
 * `NotifyService` for business logic `Notify`
 */
export class NotifyService {
  private readonly notifyDao: NotifyDao;

  /**
   * Constructor for `NotifyService` class
   * @param config injects dependencies into the object
   */
  constructor(config: NotifyServiceConfig) {
    this.notifyDao = config.notifyDao;
  }

  /**
   * Creates Custom Object for Notify
   * @param market - MarketInfo
   * @param sku - Valid Product SKU
   * @param productKey - Valid Product Key
   * @param productUrl - Valid Product Url
   * @param email - Valid Customer's Email
   * @returns HTTP code 201 in case of custom object successfully created.
   */
  public async create(
    market: MarketInfo,
    sku: string,
    productKey: string,
    productUrl: string,
    email: string,
  ): Promise<void> {
    logger.info(`Create Custom Notify Object for ${JSON.stringify({
      sku, productKey, productUrl, email,
    })}`);

    /**
     * Check if sku is availabe in CT or not
     */

    const product = await this.notifyDao.isProduct(market, productKey, [sku]);
    if (!product) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('product.notFound'));
    }

    const container = `notify-${sku}`;
    const key = email.replace('@', '~~at~~');
    const notifyDraft : CustomObjectDraft = {
      container,
      key,
      value: {
        productUrl,
      },
    };

    await this.notifyDao.create(market, notifyDraft);
  }
}
