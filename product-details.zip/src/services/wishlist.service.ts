import { ShoppingListDraft, ShoppingListLineItemDraft } from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import { ShoppingListMapper } from '../mappers/wishlist.mapper';
import { ApiError, logger } from '../lib';
import { MarketInfo } from '../middlewares';
import { ShoppingListDao } from '../daos/wishlist.dao';
import MagnoliaDao from '../daos/magnolia.dao';
import { WishlistDto } from '../dtos/wishlist.dto';

const DEFAULT_NAME = 'DEFAULT';

export interface ShoppingListServiceConfig {
  shoppingListDao: ShoppingListDao;
  magnoliaDao: MagnoliaDao;
  shoppingListMapper: ShoppingListMapper;
}

export type ShoppingListLineItemDraftWritable<T> = {
  -readonly [K in keyof T]: T[K];
};

/**
 * `WishlistService` for business logic `Wishlist`
 */
export class ShoppingListService {
  private readonly shoppingListDao: ShoppingListDao;

  private readonly magnoliaDao: MagnoliaDao;

  private readonly shoppingListMapper: ShoppingListMapper;

  /**
   * Constructor for `WishlistService` class
   * @param config injects dependencies into the object
   */
  constructor(config: ShoppingListServiceConfig) {
    this.shoppingListDao = config.shoppingListDao;
    this.magnoliaDao = config.magnoliaDao;
    this.shoppingListMapper = config.shoppingListMapper;
  }

  /**
   * Creates ShoppingList for Customer
   * @param market - MarketInfo
   * @param id - Wishlist Id
   * @param customerId - Valid UUID of the Customer
   * @param anonymousId - Valid Anonymous Id
   * @param sku - Product SKU to be added as the first product in the Wishlist
   * @returns Default Wishlist response i.e. minimal information required by Frontend
   */
  public async create(
    market: MarketInfo,
    id: string | undefined,
    customerId: string | undefined,
    anonymousId: string | undefined,
    sku: string,
  ): Promise<WishlistDto> {
    let shoppingListDto;
    let condition;

    const lineItemDraft: ShoppingListLineItemDraft = { sku };
    const shoppingListDraft: ShoppingListLineItemDraftWritable<ShoppingListDraft> = {
      name: { [market.locale]: DEFAULT_NAME },
      lineItems: [lineItemDraft],
    };

    if (customerId && anonymousId) {
      throw new ApiError(HttpStatusCodes.CONFLICT, 'Specify exactly one of customerId or anonymousId.');
    } else if (id) {
      condition = `id="${id}"`;
    } else if (customerId) {
      condition = `customer(id="${customerId}")`;
      shoppingListDraft.customer = { id: customerId, typeId: 'customer' };
    } else if (anonymousId) {
      condition = `anonymousId="${anonymousId}"`;
      shoppingListDraft.anonymousId = anonymousId;
    } else {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, 'one of id, anonymousId or customerId is required');
    }

    logger.info(`Add or update item to Wishlist for ${JSON.stringify({
      customerId, anonymousId, sku, lineItemDraft, shoppingListDraft,
    })}`);

    const wishlist = condition ? await this.shoppingListDao.findOneBy(market, condition) : undefined;
    const magnoliaPriceFormat = await this.magnoliaDao.getPriceFormat(market);

    if (wishlist) {
      const lineItemExists = wishlist.lineItems?.some((item) => item.variant?.sku === sku);
      if (lineItemExists) {
        throw new ApiError(HttpStatusCodes.CONFLICT, 'product already exists in wishlist.');
      }

      shoppingListDto = await this.shoppingListDao.updateLineItemQuantity(
        market,
        wishlist.id,
        wishlist.version,
        sku,
      );

      return this.shoppingListMapper.mapShoppingListResponse(market, shoppingListDto, magnoliaPriceFormat);
    }

    shoppingListDto = await this.shoppingListDao.create(market, shoppingListDraft);

    return this.shoppingListMapper.mapShoppingListResponse(market, shoppingListDto, magnoliaPriceFormat);
  }

  /**
   * Deletes a line item from the wishlist
   * @param market - Market Info
   * @param wishlistId - Wishlist Id
   * @param lineItemId - Line Item Id
   * @returns Wishlist Response
   */
  public async deleteLineItem(
    market: MarketInfo,
    wishlistId: string,
    lineItemId: string,
  ): Promise<WishlistDto> {
    const shoppingListDto = await this.shoppingListDao.findOne(market, wishlistId);

    if (!shoppingListDto) {
      throw new ApiError(HttpStatusCodes.BAD_REQUEST, 'Invalid wishlistId.');
    }
    const updatedWishlist = await this.shoppingListDao.deleteLineItems(
      market,
      wishlistId,
      shoppingListDto.version,
      [lineItemId],
    );
    const magnoliaPriceFormat = await this.magnoliaDao.getPriceFormat(market);
    return this.shoppingListMapper.mapShoppingListResponse(market, updatedWishlist, magnoliaPriceFormat);
  }
}
