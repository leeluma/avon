import { LocalizedString } from '@commercetools/platform-sdk';
import ProductDao from '../daos/product.dao';
import MagnoliaDao from '../daos/magnolia.dao';
import { ShoppingListDao, InventoryDao } from '../daos';
import ProductMapper from '../mappers/product.mapper';
import { InventoryMapper } from '../mappers/inventory.mapper';
import { MarketInfo } from '../middlewares';
import ShippingService from './shipping.service';
import { MagnoliaInfo } from '../dtos/common.dto';
import { CommonResponse } from '../dtos';
import { Common } from '../lib/common';

interface ProductServiceConfig {
  productDao: ProductDao;
  magnoliaDao: MagnoliaDao;
  shoppingListDao: ShoppingListDao;
  productMapper: ProductMapper;
  shippingService: ShippingService;
  common: Common;
  inventoryMapper: InventoryMapper;
  inventoryDao: InventoryDao;
}

/**
 * `ProductService` for business logic `Product Detail Page`
 */
export default class ProductService {
  private readonly productDao: ProductDao;

  private readonly common: Common;

  private readonly magnoliaDao: MagnoliaDao;

  private readonly shoppingListDao: ShoppingListDao;

  private readonly productMapper: ProductMapper;

  private readonly shippingService: ShippingService;

  private readonly inventoryMapper: InventoryMapper;

  private readonly inventoryDao: InventoryDao;

  /**
   * Constructor for `ProductService` class
   * @param config injects dependencies into the object
   */
  constructor(config: ProductServiceConfig) {
    this.productDao = config.productDao;
    this.magnoliaDao = config.magnoliaDao;
    this.shoppingListDao = config.shoppingListDao;
    this.productMapper = config.productMapper;
    this.shippingService = config.shippingService;
    this.common = config.common;
    this.inventoryMapper = config.inventoryMapper;
    this.inventoryDao = config.inventoryDao;
  }

  /**
   * PDP Get by Id implementation
   * @param market - MarketInfo
   * @param productKey - Product Key
   * @param magnolia - MagnoliaInfo
   * @param wishlistId - Wishlist id
   * @param channelKey - Channel key
   * @returns PDP Response
   */
  public async getByKey(
    market: MarketInfo,
    productKey: string | LocalizedString,
    magnolia : MagnoliaInfo,
    wishlistId: string | undefined,
    channelKey: string | undefined,
  ): Promise<CommonResponse | undefined> {
    // need add type as ProductgraphqlDto for result
    // Get PDP data from Magnolia
    // eslint-disable-next-line prefer-const
    let [result, magnoliaData, globalSettings, shoppingList] = await Promise.all([
      this.productDao.fetchProduct(market, productKey),
      this.magnoliaDao.getPdpDataFromMagnolia(market, magnolia),
      this.magnoliaDao.getGlobalSettings(market, magnolia.url),
      wishlistId ? this.shoppingListDao.findGraphQLOne(market, wishlistId)
        : Promise.resolve({ lineItems: [] }),
    ]);

    // if result is null then return undefined
    if (result === null) {
      return undefined;
    }

    let isWishlistHasItem;
    let warehouseKey;
    warehouseKey = channelKey;
    // if channelKey is undefined then getting default channelKey from magnolia global settings
    if (channelKey === undefined) {
      const warehouseResult = globalSettings.warehouseSettings;
      warehouseKey = warehouseResult?.defaultWarehouse;
    }

    const productDelivery = this.common.deliveryCountdownExists(result);
    const inventoriesIds = this.inventoryMapper.getProductInventoriesIds(result, warehouseKey);

    // getting inventories, howToLook, hasExpressDelivery and template data from CT and magnolia
    const [inventoryData, howToLookData, hasExpressDelivery, templateData] = await Promise.all([
      inventoriesIds !== undefined && inventoriesIds.length > 0
        ? this.inventoryDao.fetchInventoryDetail(market, inventoriesIds) : Promise.resolve([]),
      this.magnoliaDao.getHowToLookFromMagnolia(market, result?.id, magnolia),
      productDelivery === true ? this.shippingService.getShippingMethods(market) : Promise.resolve(false),
      magnolia.isPreview ? this.magnoliaDao.getTemplateDataFromMagnolia(magnoliaData['mgnl:template'], magnolia)
        : Promise.resolve({}),
    ]);

    if (productDelivery === true) {
      result = this.common.enableExcludeCount(
        result,
        hasExpressDelivery,
      );
    }
    // mapping CT data as per our format in mapper file
    const pdpCTResponse = this.productMapper.convert(
      result,
      market.locale,
      warehouseKey,
      globalSettings.priceFormat,
      inventoryData as any, // NOSONAR
    );

    // Check if wishlist exist in shoppingList
    if (wishlistId) {
      isWishlistHasItem = shoppingList?.lineItems?.some((item) => item.productId === pdpCTResponse.id);
    }
    // Delete fieldValidator and addressSetting property
    // delete globalSettings.fieldValidators;
    delete globalSettings.addressSettings;

    return {
      ...magnoliaData,
      pdpResponse: pdpCTResponse,
      productSetting: howToLookData,
      templateDefinition: templateData,
      isWishlistHasItem,
      globalSettings,
    };
  }
}
