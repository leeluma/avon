import ShippingDao from '../daos/shipping.dao';
import ShippingMapper from '../mappers/shipping.mapper';
import { logger } from '../lib';
import { MarketInfo } from '../middlewares';

interface ShippingServiceConfig {
  shippingDao: ShippingDao;
  shippingMapper: ShippingMapper;
}

/**
 * `ShippingService` for business logic `Product Detail Page`
 */
export default class ShippingService {
  private readonly shippingDao: ShippingDao;

  private readonly shippingMapper: ShippingMapper;

  /**
   * Constructor for `ShippingService` class
   * @param config injects dependencies into the object
   */
  constructor(config: ShippingServiceConfig) {
    this.shippingDao = config.shippingDao;
    this.shippingMapper = config.shippingMapper;
  }
  /**
   * Get by all shipping method implementation
   * @param market - MarketInfo
   * @returns PDP Response
   */

  // eslint-disable-next-line consistent-return
  public async getShippingMethods(market: MarketInfo): Promise<boolean> {
    logger.info('check all shipping methods for promotion');
    const result = await this.shippingDao.getShippingMethods(market);
    if (result === undefined) {
      return false;
    }
    return this.shippingMapper.hasPromotedShippingMethod(result?.data?.shippingMethods);
  }
}
