// NOSONAR
import { AddressDraft, CustomerDraft, UpdateAction } from '@commercetools/platform-sdk';
import { CustomerDao } from '../daos';
import { CustomerResponseDto } from '../dtos';
import { CustomerMapper } from '../mappers/customer.mapper';
import { MarketInfo } from '../middlewares';

export interface CustomerServiceConfig {
  customerDao: CustomerDao;
  customerMapper: CustomerMapper;
}

export interface AddressAction extends UpdateAction{
  address?: AddressDraft;
  addressKey?: string;
  addressId?:string;
}

export type CustomCustomerDraft = Omit<CustomerDraft, 'addresses'>;

/**
 * Customer Service class
 */
export class CustomerService {
  private readonly customerDao: CustomerDao;

  private readonly customerMapper: CustomerMapper;

  constructor(configuration: CustomerServiceConfig) {
    this.customerDao = configuration.customerDao;
    this.customerMapper = configuration.customerMapper;
  }

  /**
   * Get Customer details by Customer Token implementation
   * @param market - MarketInfo
   * @param authHeader - Customer Token
   * @returns Customer Response
   */
  public async getCustomerDetailsByToken(
    market: MarketInfo,
    authHeader: string,
  ): Promise<CustomerResponseDto | undefined> {
    const customer = await this.customerDao.getCustomerDetailsGraphQL(market, authHeader);
    return this.customerMapper.mapGraphQLCustomerResponse(customer);
  }
}
