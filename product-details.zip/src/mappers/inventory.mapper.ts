import { ProductgraphqlDto } from '../dtos/product.dto';

export class InventoryMapper {
  /**
   * Method to get product all inventories id
   * @param product
   * @param channelKey
   * @returns
   */
  public getProductInventoriesIds(product:ProductgraphqlDto, channelKey: string | undefined): string {
    const { masterVariant, variants } = product.masterData.current;
    const channels = masterVariant.availability.channels?.results;
    const stockDetail = channels?.find((channel) => channel.channel.key === channelKey);
    const inventoryIds: string[] = [];
    variants.forEach((variant) => {
      const invChannels = variant.availability.channels?.results;
      const stockDetails = invChannels?.find((channel) => channel.channel.key === channelKey);
      if (stockDetails?.availability.id) {
        inventoryIds.push(stockDetails.availability.id);
      }
    });
    if (stockDetail !== undefined) {
      inventoryIds.push(stockDetail.availability.id);
    }
    return (inventoryIds.length > 0 ? inventoryIds.map((id) => `"${id}"`).toString() : '');
  }
}
