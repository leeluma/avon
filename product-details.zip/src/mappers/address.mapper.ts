import { Address, Customer } from '@commercetools/platform-sdk';
import {
  AddressResponseDto,
  GraphQLAddress,
  GraphQLCustomerResponse,
} from '../dtos';

export class AddressMapper {
  public mapAddressResponse(
    addressDto: Address,
    customerDto?: Customer,
  ): AddressResponseDto {
    return {
      id: addressDto.id,
      customerId: customerDto?.id,
      firstName: addressDto?.firstName,
      lastName: addressDto?.lastName,
      address1: addressDto.custom?.fields.Address1,
      address2: addressDto.custom?.fields.Address2,
      address3: addressDto.custom?.fields.Address3,
      address4: addressDto.custom?.fields.Address4,
      recipientName: addressDto.custom?.fields.RecipientName,
      county: addressDto.custom?.fields.county,
      latitude: addressDto.custom?.fields.Latitude,
      longitude: addressDto.custom?.fields.Longitude,
      city: addressDto.city,
      region: addressDto.region,
      country: addressDto.country,
      state: addressDto.state,
      phoneNumber: addressDto.phone,
      zip: addressDto.postalCode,
      isShippingAddress: addressDto?.id ? customerDto?.shippingAddressIds?.includes(addressDto.id) : false,
      isBillingAddress: addressDto?.id ? customerDto?.billingAddressIds?.includes(addressDto.id) : false,
    };
  }

  public mapGraphQLAddressResponse(
    addressDto: GraphQLAddress,
    customerDto?: GraphQLCustomerResponse,
  ): AddressResponseDto {
    let customFieldsRaw;
    let isShippingAddress;
    let isBillingAddress;
    if (addressDto?.custom) {
      customFieldsRaw = addressDto.custom.customFieldsRaw.reduce((result, custom) => {
        // eslint-disable-next-line no-param-reassign
        result[custom.name] = custom.value;
        return result;
      }, {});
    }

    if (addressDto?.id) {
      isShippingAddress = addressDto.id ? customerDto?.shippingAddressIds?.includes(addressDto.id) : false;
      isBillingAddress = addressDto.id ? customerDto?.billingAddressIds?.includes(addressDto.id) : false;
    }

    return {
      id: addressDto?.id,
      customerId: customerDto?.id,
      firstName: addressDto?.firstName,
      lastName: addressDto?.lastName,
      recipientName: customFieldsRaw?.RecipientName,
      address1: customFieldsRaw?.Address1,
      address2: customFieldsRaw?.Address2,
      address3: customFieldsRaw?.Address3,
      address4: customFieldsRaw?.Address4,
      county: customFieldsRaw?.county,
      latitude: customFieldsRaw?.Latitude,
      longitude: customFieldsRaw?.Longitude,
      city: addressDto?.city,
      region: addressDto?.region,
      country: addressDto?.country,
      state: addressDto?.state,
      phoneNumber: addressDto?.phone,
      zip: addressDto?.postalCode,
      isShippingAddress,
      isBillingAddress,
    };
  }
}
