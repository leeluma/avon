import {
  AssetsDto, VariantDto, BreadcrumbDto,
  AvailabilityDto, CategoryDto, OffersDto, ProductgraphqlDto, MastervariantDto, PricesDto,
  ImageDto, AttributesRawDto, PdpNotFoundResponse, ProductDto, GraphQLInventoryEntry,
} from '../dtos/product.dto';
import { PriceFormat } from '../dtos/magnolia.dto';
import {
  ATTRIBUTE_NAMES, ATTRIBUTE_VALUES, CATEGORY_LEVEL,
} from '../common/constant';
import { Common } from '../lib/common';
import { Product } from '../lib/product';

export interface ProdutcMapperConfig {
  common: Common;
  product: Product;
}
export default class ProductMapper {
  private readonly common: Common;

  private readonly product: Product;

  constructor(config: ProdutcMapperConfig) {
    this.common = config.common;
    this.product = config.product;
  }

  /** Maps variant images to product DTO * @param images - variant images * @returns  */
  private readonly variantImageToDTO = (images: ImageDto[] | undefined, attribute:AttributesRawDto[] | undefined):
   AssetsDto[] | undefined => {
    let assetsDto: AssetsDto[] | undefined = images?.map((img, index) => {
      const assetDto: AssetsDto = {
        url: img.url,
        assetType: img.label,
        sequence: index,
        ...this.variantImageDetails(img.label),

      };
      return assetDto;
    });
    /** check for Gallery Video Attribute */
    const videoGallery = attribute?.find((value) => value.name === ATTRIBUTE_NAMES.galleryVideo);
    if ((typeof videoGallery !== 'undefined') && (videoGallery.value.length > 0)) {
      const videos: AssetsDto[] = videoGallery?.value?.map((video, index) => {
        return {
          url: video, assetType: ATTRIBUTE_VALUES.assetType, sequence: index,
        };
      });
      /** merging images and Video attributes */
      assetsDto = assetsDto ? [...assetsDto, ...videos] : videos;
    }
    return assetsDto;
  };

  /** Check variant prices have channel price * @param prices variants prices * @returns */
  private readonly checkChannel = (prices: PricesDto[]|[]) => {
    const priceWithoutChannel = prices?.find((attribute) => attribute.channel === null);
    const [firstPrice] = prices;
    return this.checkDiscount(priceWithoutChannel ?? firstPrice);
  };

  /** Check if product price have discount property then return sell price after applied promotion
   * if discount property not available then return empty object
   * @param price  - All price details including promotional prices * @returns - sellPrice and isPromotionApplied */
  private readonly checkDiscount = (price: PricesDto) => {
    const numberTen = 10;
    if (price?.discounted && price?.discounted !== null) {
      return {
        sellPrice: (price.discounted.value.centAmount / (numberTen ** price.discounted.value.fractionDigits)
        ).toFixed(price.discounted.value.fractionDigits),
        listPrice: (price.value.centAmount / (numberTen ** price.value.fractionDigits))
          .toFixed(price.value.fractionDigits),
        sellPriceCT: price.discounted.value.centAmount,
        listPriceCT: price.value.centAmount,
        isPromotionApplied: true,
        validUntil: price.validUntil,
      };
    }
    return {
      sellPrice: (price.value.centAmount / (numberTen ** price.value.fractionDigits)
      ).toFixed(price.value.fractionDigits),
      listPrice: (price.value.centAmount / (numberTen ** price.value.fractionDigits))
        .toFixed(price.value.fractionDigits),
      sellPriceCT: price.value.centAmount,
      listPriceCT: price.value.centAmount,
      isPromotionApplied: false,
      validUntil: price.validUntil,
    };
  };

  /** * Maps child variant fields to product DTO * @param variants - all variant details of other variants
   * @param locale * @returns - All child Variants DTO  */
  private readonly variantsToDto = (
    variants: MastervariantDto[],
    locale:string,
    channelKey: string,
    priceFormat: PriceFormat,
    inventoryData: GraphQLInventoryEntry[],
  ): VariantDto[] => {
    let variantDetails;
    if (variants.length !== 0) {
      variantDetails = variants.map((variant) => {
        const {
          sellPrice, listPrice, sellPriceCT, listPriceCT, validUntil,
        } = this.checkChannel(variant?.prices ?? []);
        const channels = variant?.availability.channels?.results;
        const availabilities:AvailabilityDto = this.common.getStockDetails(channels, channelKey, inventoryData);
        const productAttr = this.product.productAttributeToDTO(variant.attributesRaw, locale);
        if (!productAttr?.isDiscontinued) {
          const variantDto: VariantDto = {
            id: Number(variant.id),
            key: variant.key,
            sku: variant.sku,
            sellPrice: Number(sellPrice),
            listPrice: Number(listPrice),
            formattedListPrice: this.product.magnoliaPriceFormatter(listPriceCT, priceFormat),
            formattedSellPrice: this.product.magnoliaPriceFormatter(sellPriceCT, priceFormat),
            currency: priceFormat?.ccy,
            priceValidUntil: validUntil,
            vatMessage: (priceFormat.isVatIncluded === 'true') ? priceFormat.vatIncludedMessage : '',
            unitPrice: this.product.getUnitPrice(variant.attributesRaw, Number(sellPriceCT), priceFormat),
            availability: availabilities,
            assets: this.variantImageToDTO(variant.images, variant.attributesRaw),
            attributes: {
              ...productAttr,
              inStock: availabilities?.isAvailable ?? false,
              nonRepListPrice: listPrice,
              nonRepSalePrice: sellPrice,
            },
            badges: this.product.getBadgeDetails(variant.attributesRaw, sellPriceCT, listPriceCT, locale),
          };
          return variantDto;
        }
        return null;
      });
      variantDetails = variantDetails.filter((n) => n);
    }
    return variantDetails ?? [];
  };

  /** Maps product Data * @param product - main method to map product details * @param locale * @returns */
  public convert = (
    product: ProductgraphqlDto,
    locale:string,
    channelKey: string,
    priceFormat: PriceFormat,
    inventoryData: GraphQLInventoryEntry[],
  ):
  ProductDto | PdpNotFoundResponse => {
    const masterVariant = this.variantsToDto(
      product?.masterData?.current?.masterVariant ? [product?.masterData?.current?.masterVariant] : [],
      locale,
      channelKey,
      priceFormat,
      inventoryData,
    );
    const variants = this.variantsToDto(
      product?.masterData?.current?.variants,
      locale,
      channelKey,
      priceFormat,
      inventoryData,
    );
    if (variants?.length === 0 && masterVariant?.length === 0) {
      return { msg: 'Variant details not found for this product', id: product.id, key: product.key };
    }
    const ProductCat = product?.masterData?.current?.categories ?? [];
    return {
      id: product.id,
      key: product.key,
      name: product?.masterData?.current?.name,
      description: product?.masterData?.current?.description,
      metaTitle: product?.masterData?.current?.metaTitle ?? '',
      metaDescription: product?.masterData?.current?.metaDescription ?? '',
      isLive: true,
      searchKeywords: this.product.getAllKeywords(product.masterData.current.searchKeywords, locale),
      offers: this.getAllOffers(ProductCat, locale),
      breadcrumb: this.getAllBreadcrumb(ProductCat, locale),
      categories: this.common.getAllCategories(ProductCat),
      deliveryCountdown: this.common.getDeliveryCountdown(product?.masterData?.current?.masterVariant?.attributesRaw),
      variants,
      masterVariant: masterVariant.length > 0 ? masterVariant[0] : undefined,
    };
  };

  /** returns category index having maximum ancestors
   * @param categories category data * @param locale locale * @returns CategoryHavingMaxAncestor */
  private readonly getAllBreadcrumb = (categories: CategoryDto[], locale:string): BreadcrumbDto[] => {
    if (categories.length === 0) {
      return [];
    }
    const category = this.getCategoryHavingMaxAncestor(categories);
    const rootCat = CATEGORY_LEVEL.parent;
    // product category
    const ProductCat = this.breadcrumbMapper(category, locale);
    if (category?.parent && category?.ancestors !== undefined) {
      const parentCat = category.ancestors[category.ancestors.length - 1];
      ProductCat.parentKey = parentCat ? parentCat?.key : '';
    } else {
      ProductCat.parentKey = rootCat;
    }
    // parent categories
    const parentCatArr = this.getParentCatArr(category, rootCat, locale);
    return [...parentCatArr ?? [], ProductCat];
  };

  /** * returns category index having maximum ancestors
   * @param categories category data * @param locale locale * @returns CategoryHavingMaxAncestor */
  private readonly getCategoryHavingMaxAncestor = (categories: CategoryDto[])
 : CategoryDto => {
    let maxAnsIndex = 0;
    let maxAnsLength = 0;
    for (let index = 0; index < categories?.length; index += 1) {
      const totalAncestors = categories[index].ancestors
        ? categories[index].ancestors?.length : 0;
      if (totalAncestors !== undefined && totalAncestors > maxAnsLength) {
        maxAnsLength = totalAncestors;
        maxAnsIndex = index;
      }
    }
    return categories[maxAnsIndex];
  };

  /** parent category of category @param category category data @param rootCat string @param locale locale @returns breadcrumb array */
  private readonly getParentCatArr = (category, rootCat: string, locale:string)
  : BreadcrumbDto[] => {
    return category?.ancestors.map((value: CategoryDto, index: number) => {
      let parentCatKey;
      const ProductAnsCat = this.breadcrumbMapper(value, locale);
      if (index === 0) {
        parentCatKey = rootCat;
      } else {
        const ancestors = category?.ancestors[index - 1];
        parentCatKey = ancestors !== undefined ? ancestors.key : '';
      }
      return {
        key: ProductAnsCat?.key,
        parentKey: parentCatKey,
        displayName: ProductAnsCat?.displayName,
        url: ProductAnsCat?.url,
      };
    });
  };

  /** * map category to breadcrumb object * @param category category to map * @param locale locale string * @returns breadcrumb object */
  private readonly breadcrumbMapper = (category: CategoryDto, locale: string): BreadcrumbDto => {
    return {
      key: (category?.key ?? ''),
      parentKey: '',
      displayName: category?.name ?? '',
      url: (category?.slug ? `/${locale}/c/${category?.slug}` : ''),
    };
  };

  /** return array of objects of associated offer categories * @param categories: All associated categories
   * @param locale: locale of market * @returns: all associated offer categories Dto  */
  private readonly getAllOffers = (categories: CategoryDto[], locale:string): OffersDto[] => {
    const offerArray: OffersDto[] = [];
    if (categories.length > 0) {
      categories.forEach((category) => {
        if (category?.custom?.customFieldsRaw) {
          const offerDetails = category?.custom?.customFieldsRaw?.find((data) => data.value === 'Offer');
          if (offerDetails) {
            const offerObj: OffersDto = {
              key: category.key,
              displayName: category.name ?? '',
              url: category.slug ? `/${locale}/offers/${category.slug}` : '',
              description: category.description ?? '',
            };
            offerArray.push(offerObj);
          }
        }
      });
    }
    return offerArray;
  };

  private readonly variantImageDetails = (image: string) => {
    const [shotClassification, title, format] = image.split('|');
    return { shotClassification, title, format };
  };
}
