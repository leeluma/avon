import { ShippingMethodsResponseDto } from '../dtos';

export default class ShippingMapper {
  public hasPromotedShippingMethod = (shippingData:ShippingMethodsResponseDto): boolean => {
    let isPromoted = false;
    const shippingWithPromotion = shippingData.results
      .find((value) => value.custom?.customFieldsRaw?.value === true);
    if (shippingWithPromotion) {
      isPromoted = true;
    }
    return isPromoted;
  };
}
