import { ShoppingList } from '@commercetools/platform-sdk';
import { LineItemDto, MagnoliaPriceFormatDto } from '../dtos/line-item.dto';
import { WishlistDto } from '../dtos/wishlist.dto';
import { MarketInfo } from '../middlewares';
import { LineItemMapper } from './line-item.mapper';

export interface WishlistMapperConfig {
  lineItemsMapper: LineItemMapper;
}

/**
 * Maps ShoppingList Response
 */
export class ShoppingListMapper {
  private readonly lineItemsMapper: LineItemMapper;

  constructor(config: WishlistMapperConfig) {
    this.lineItemsMapper = config.lineItemsMapper;
  }

  public mapShoppingListResponse(
    market: MarketInfo,
    shoppingListDto: ShoppingList,
    magPriceFormat: MagnoliaPriceFormatDto,
  ): WishlistDto {
    const { locale } = market;
    return {
      id: shoppingListDto.id,
      name: shoppingListDto.name[locale],
      lineItems: shoppingListDto.lineItems?.map(
        (item) =>
          this.lineItemsMapper.mapLineItemResponse(market, item, magPriceFormat),
      ) as LineItemDto[],
      customerId: shoppingListDto.customer?.id,
      anonymousId: shoppingListDto.anonymousId,
      version: shoppingListDto.version,
    };
  }
}
