export const ATTRIBUTE_NAMES = {
  config: 'config',
  galleryVideo: 'galleryVideo',
  badges: 'badges',
  contentFillMeasurement: 'ContentFillMeasure',
  contentFill: 'ContentFill',
  availability: 'availability',
  excludeCountDown: 'excludeCountDown',
};

export const ATTRIBUTE_VALUES = {
  attributeValue: 'value',
  availabilitySku: 'skuCode',
  assetType: 'Video Gallery',
};

export const BADGE_NAMES = {
  type: 'type',
  text: 'text',
  side: 'side',
  priority: 'priority',
};

export const BADGE_VALUES = {
  discount: 'DISCOUNT',
  bestSeller: 'BESTSELLER',
  typeNew: 'NEW',
  topLeft: 'TOP-LEFT',
  topRight: 'TOP-RIGHT',
};

export const MEASUREMENT = {
  baseMeasure: 'baseMeasure',
  nodes: '@nodes',
};

export const DEFAULT_INVENTORY = {
  stockQty: 999,
  isAvailable: true,
};

export const ATTRIBUTE_TYPES = {
  boolean: 'boolean',
  string: 'string',
  number: 'number',
  date: 'date',
};

export const CATEGORY_LEVEL = {
  parent: 'root',
};

export const QUERY_EXPAND = {
  findOne: 'masterData.current.categories[*].ancestors[*]',
  findProducts: 'masterData.current.categories[*]',
};

export const SHIPPING_METHOD_TEXT = {
  textNode: 'texts',
  delivery: 'deliveryCutoffs',
  nodes: '@nodes',
  deliveryText: 'deliveryCountdown',
  time: 'time',
};

export const CATEGORY_TYPE = {
  category: 'category',
};

export enum MagnoliaUri {
    PDP = '.rest/delivery/pages/v1/',
    HOW_TO_LOOK = '.rest/delivery/product-setting/',
    TEMPLATE = '.rest/template-definitions/v1/',
    LOG_SETTINGS = '.rest/delivery/pages/v1/ro/apptusSetting',
    WARE_HOUSE_SETTINGS= '.rest/delivery/global-settings/{{country}}/settings/warehouseSettings',
    GLOBAL_SETTINGS= '.rest/delivery/global-settings/{{country}}/settings',
}

const NODE_TYPE_KEY = 'mgnl:contentNode';

export const MESSAGE_KEY = {
  datatypeUuid: 'datatype.uuid',
  commonNotEmpty: 'common.notEmpty',
  lineItemQuantity: 'lineItems.quantity',
};

export const CT_KEY = {
  lineItemVariant: 'lineItems[*].variant',
  lineItemProductSlug: 'lineItems[*].productSlug',
};

export const APPTUS_KEY = {
  clusterId: '{{CLUSTER_ID}}',
};

export const RESPONSE_KEY = {
  applicationJson: 'application/json',
};

export const NUMBER_KEY = {
  zero: 0,
  two: 2,
  ten: 10,
  hundred: 100,
};

export const MAGNOLIA_PRICE_FORMAT = {
  isVatIncluded: true,
  vatIncludedMessage: 'Vat Included',
  '@name': 'priceFormat',
  '@path': '/RO-RO/priceFormat',
  '@id': '679164d0-6c34-49b9-a213-254de265e290',
  '@nodeType': NODE_TYPE_KEY,
  ccy: 'RON',
  showDecimalZero: 'true',
  thousandSeperator: ',',
  noOfDigit: '2',
  masterContentIdentifier: '283ea6c8-d454-46ee-aa14-98a5358254f9',
  currencyPlacement: 'before',
  'mgnl:created': '2021-12-23T17:15:06.907+05:30',
  decimalPoint: '.',
  'mgnl:lastModified': '2021-12-23T17:15:06.907+05:31',
  baseMeasure: {
    '@name': 'baseMeasure',
    '@path': '/RO-RO/priceFormat/baseMeasure',
    '@id': '41a2366f-0854-43ac-94a7-940b8ae686bb',
    '@nodeType': NODE_TYPE_KEY,
    translation: 'mg',
    unitPriceBaseMeasure: '100 mg',
    containerSizeLimit: '10',
    masterContentIdentifier: '6068f45a-5caf-4317-bd13-0d0e50bb6930',
    '@nodes': [],
  },
  '@nodes': [
    'baseMeasure',
  ],
};

export const URI = {
  apptus: {
    esaleAddToCart: 'notifications/adding-to-cart',
    nonEsaleAddToCart: 'notifications/non-esales-adding-to-cart',
  },
  magnolia: {
    priceFormatUrl: '.rest/delivery/pages/v1/{{country}}/priceFormat?lang={{localeAndCountry}}',
  },
};
