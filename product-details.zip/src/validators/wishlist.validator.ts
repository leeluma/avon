import { body, oneOf } from 'express-validator';
import { MESSAGE_KEY } from '../common/constant';

export const validateAddToWishlist = [
  body('sku')
    .isString()
    .withMessage('product.sku')
    .notEmpty(),
  oneOf([
    body('customerId').notEmpty().withMessage(MESSAGE_KEY.commonNotEmpty).isUUID()
      .withMessage(MESSAGE_KEY.datatypeUuid),
    body('anonymousId').notEmpty().withMessage(MESSAGE_KEY.commonNotEmpty).isUUID()
      .withMessage(MESSAGE_KEY.datatypeUuid),
    body('id').notEmpty().withMessage(MESSAGE_KEY.commonNotEmpty).isUUID()
      .withMessage(MESSAGE_KEY.datatypeUuid),
  ]),
];
