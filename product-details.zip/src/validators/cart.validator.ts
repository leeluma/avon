import { body, oneOf } from 'express-validator';
import { MESSAGE_KEY } from '../common/constant';

export const validateAddToCart = [
  body('cartId')
    .optional({ checkFalsy: true })
    .isUUID()
    .withMessage('datatype.uuid'),

  body('lineItems.sku')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage(MESSAGE_KEY.commonNotEmpty),

  body(MESSAGE_KEY.lineItemQuantity)
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage(MESSAGE_KEY.commonNotEmpty),

  body(MESSAGE_KEY.lineItemQuantity)
    .if(body(MESSAGE_KEY.lineItemQuantity).notEmpty())
    .isInt({ min: 1, max: 2000 })
    .withMessage('common.integer'),
  oneOf([
    body('customerId').notEmpty().withMessage(MESSAGE_KEY.commonNotEmpty).isUUID()
      .withMessage(MESSAGE_KEY.datatypeUuid),
    body('anonymousId').notEmpty().withMessage(MESSAGE_KEY.commonNotEmpty).isUUID()
      .withMessage(MESSAGE_KEY.datatypeUuid),
  ]),
];
