import {
  param, body, header, oneOf,
} from 'express-validator';
import { MESSAGE_KEY } from '../common/constant';

export const validateBearerToken = header('Authorization').notEmpty().withMessage('common.notEmpty');

const validateId = [
  param('id')
    .exists({ checkNull: true, checkFalsy: true })
    .isUUID()
    .withMessage('id must exists and contain a valid uuid.'),
];

const validateKey = [
  param('key')
    .exists({ checkNull: true, checkFalsy: true })
    .isString()
    .withMessage('key must exists and contain a valid data.'),
];

const validateNotifications = [
  header('sessionKey').notEmpty().withMessage(MESSAGE_KEY.commonNotEmpty).isUUID()
    .withMessage(MESSAGE_KEY.datatypeUuid),
  header('customerKey').notEmpty().withMessage(MESSAGE_KEY.commonNotEmpty).isUUID()
    .withMessage(MESSAGE_KEY.datatypeUuid),
  oneOf([
    [
      body('productKey').notEmpty().withMessage(MESSAGE_KEY.commonNotEmpty),
      body('variantKey').notEmpty().withMessage(MESSAGE_KEY.commonNotEmpty),
    ],
    body('ticket').optional(),
  ]),
];

const validateRefreshToken = [
  header('refreshtoken').notEmpty().withMessage('common.notEmpty'),
];

export {
  validateId,
  validateKey,
  validateNotifications,
  validateRefreshToken,
};
