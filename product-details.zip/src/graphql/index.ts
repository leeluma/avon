import { readFile } from 'fs/promises';

const loadAsync = async (fileName: string | boolean): Promise<string> =>
  (await readFile(`${__dirname}/../graphql/${fileName}.graphql`, 'utf-8'))
    .toString();

export const graphql = {
  isProduct: loadAsync('is-product'),
  getProducts: loadAsync('get-products'),
  getInventory: loadAsync('get-inventory'),
  getShippingMethods: loadAsync('get-shippingmethods'),
  wishlistById: loadAsync('wishlist-by-id'),
  getCustomerByToken: loadAsync('get-customer-by-token'),
};
