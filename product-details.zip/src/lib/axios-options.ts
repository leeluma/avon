import Agent, { HttpsAgent } from 'agentkeepalive';

const keepAliveAgentHttps = new HttpsAgent({
  maxSockets: 50,
  maxFreeSockets: 10,
  timeout: 60000, // active socket keepalive for 60 seconds
  freeSocketTimeout: 30000, // free socket keepalive for 30 seconds
  keepAlive: true,
});

const keepAliveAgentHttp = new Agent({
  maxSockets: 50,
  maxFreeSockets: 10,
  timeout: 60000, // active socket keepalive for 60 seconds
  freeSocketTimeout: 30000, // free socket keepalive for 30 seconds
  keepAlive: true,
});

export const axiosOptions = {
  httpAgent: keepAliveAgentHttp,
  timeout: 60000,
  httpsAgent: keepAliveAgentHttps,
};
