/* eslint-disable no-unsafe-optional-chaining */
import { Attribute, Price, ShoppingListLineItem } from '@commercetools/platform-sdk';
import { ProductVariantPriceDto } from '../dtos/product';
import { MarketInfo } from '../middlewares';
import {
  NUMBER_KEY, ATTRIBUTE_NAMES, DEFAULT_INVENTORY, SHIPPING_METHOD_TEXT,
} from '../common/constant';
import {
  CategoryDto, CategoryResDto, SearchKeywordsDto, ProductgraphqlDto, VariantchannelsresultsDto, AvailabilityDto,
  GraphQLInventoryEntry, AttributesRawDto, DeliveryCountObject,
} from '../dtos/product.dto';
import shippingMethodJson from '../../tmp/shippingMethod.json';
import { Product } from './product';

export const CONTENT_FILL_MEASURE = 'ContentFillMeasure';
export const CONTENT_FILL = 'ContentFill';
export const CHANNEL = 'channel';

export interface ProdutcMapperConfig {
  product: Product;
}

export class Common {
  private readonly product: Product;

  constructor(config: ProdutcMapperConfig) {
    this.product = config.product;
  }

  /**
   * Generate URL from Product id and Slug
   * @param lineItemDraft - ShoppingListLineItem
   * @param market - Market
   * @returns URL
   */
  public getUrl(market: MarketInfo, lineItemDraft: ShoppingListLineItem): string {
    return `/p/${lineItemDraft.productSlug ? lineItemDraft.productSlug[market.locale] : ''}`;
  }

  /**
  * Get Attribute value by Attribute name
  * @param attributes - List of `AttributesDto`s
  * @param attrName - Attribute name
  * @returns attribute value
  */
  public getAttributeValue(attributes: Attribute[], attrName: string) {
    if (!attributes) {
      return '';
    }
    const attr = attributes.find((a) => a.name === attrName);
    if (typeof attr?.value === 'object') {
      return attr.value.key ?? attr.value;
    }
    return attr ? attr.value : '';
  }

  /**
  * Get non-representative price i.e. price which do not have
  * Channel ID associated with it.
  * @param prices - List of prices
  * @param channel - Channel
  * @returns non-representative price
  */
  public getNonRepPrice(prices: Price[], channel: string) {
    if (!prices) {
      return 0;
    }
    const nonRepPrice = prices.find((price) => !(channel in price));
    return nonRepPrice
      ? nonRepPrice.value.centAmount / (NUMBER_KEY.ten ** (nonRepPrice.value.fractionDigits || NUMBER_KEY.two))
      : 0;
  }

  /**
  * Get non-representative price with discount
  * @param prices - List of prices
  * @param channel - Channel
  * @returns non-representative price with discounts included
  */
  public getNonRepPriceWithDiscount(prices: Price[], channel: string) {
    if (!prices) {
      return 0;
    }
    const priceArr = prices.filter((price) => !(channel in price));
    let listPrice = 0;
    if (priceArr[0]?.value?.centAmount) {
      listPrice = priceArr[0]?.value?.centAmount
        / (NUMBER_KEY.ten ** (priceArr[0]?.value?.fractionDigits || NUMBER_KEY.two));
    }
    let discountedPrice = 0;
    if (priceArr[0]?.discounted?.value.centAmount) {
      discountedPrice = priceArr[0]?.discounted?.value.centAmount
        / (NUMBER_KEY.ten ** priceArr[0]?.discounted?.value.fractionDigits || NUMBER_KEY.two);
    }
    return discountedPrice !== 0 ? discountedPrice : listPrice;
  }

  /** * Get non-representative price with discount && wuthout discount
  * @param prices - List of prices * @param channel - Channel * @returns non-representative price with discounts included without dot
  */
  public getNonRepPriceCal(prices: ProductVariantPriceDto[], channel: string) {
    if (!prices) {
      return {
        withoutDiscount: 0,
        withDiscount: 0,
      };
    }
    const priceAttribute = prices?.filter((price) => !(channel in price));
    let listPrice = 0;
    if (priceAttribute[0]?.value?.centAmount) {
      listPrice = priceAttribute[0]?.value?.centAmount;
    }
    let discountedPrice = 0;
    if (priceAttribute[0]?.discounted?.value.centAmount) {
      discountedPrice = priceAttribute[0]?.discounted?.value.centAmount;
    }
    return {
      withoutDiscount: listPrice !== 0 ? listPrice : 0,
      withDiscount: discountedPrice !== 0 ? discountedPrice : listPrice,
    };
  }

  /** Get Product Mass Detail * @param attributes - list of `AttributesDto`s  * @param magnoliaObject Magnolia Price Format
  * @returns Product Mass Detail */
  public getproductMassDetail(
    attributes: Attribute[],
    magnoliaObject: any,
    prices: any[],
    channel: string,
  ) {
    let price: any;
    const contentFill = this.getAttributeValue(attributes, CONTENT_FILL);
    const contentFillMeasure = this.getAttributeValue(attributes, CONTENT_FILL_MEASURE);
    const { withDiscount } = this.getNonRepPriceCal(prices, channel);
    if (!Number.isNaN(withDiscount)) {
      price = this.product.magnoliaPriceFormatter(withDiscount, magnoliaObject);
      return `${contentFill} ${contentFillMeasure}(${price}/${magnoliaObject.baseMeasure.unitPriceBaseMeasure})`;
    }
    return '';
  }

  /** It used to convert object parameters to query string. * @param params * @returns  */
  public queryString(params): string {
    const removeUndefined = JSON.parse(JSON.stringify(params));
    return Object.entries(removeUndefined).map(
      ([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value as string)}`,
    ).join('&');
  }

  /** for getting comma separated Search Keywords string of products */
  public getAllKeywords = (searchKey: SearchKeywordsDto, locale: string): string => {
    return (typeof searchKey !== 'undefined' && locale in searchKey) ? searchKey[locale][0].text : '';
  };

  /** associates categories slug and id * @param catArray category of products
   * @param locale locale of the country * @returns Categories */
  public getAllCategories = (categoryArray: CategoryDto[]): CategoryResDto[] => {
    if (categoryArray.length === 0) {
      return [];
    }
    return categoryArray.map((value) => {
      return { slug: value.slug ?? '', id: value.id ?? '' };
    });
  };

  /**
   * This method modifies CT response if excludeCountDOwn attribute has false value but does not have any promotional shipping attached
   * @param attribute : Product attribute of Master variant * @param hasPromotion : Shipping method has any promotion
   * @returns modified excludeCountDown attribute in case of no promotion on shipping method
   */
  public enableExcludeCount = (masterData: ProductgraphqlDto, hasPromotion: boolean):ProductgraphqlDto => {
    let changeValue;
    if (hasPromotion === true) {
      changeValue = masterData.masterData.current.masterVariant.attributesRaw.map((value) => {
        let excludeCountDown = false;
        if (value.name === ATTRIBUTE_NAMES.excludeCountDown) {
          excludeCountDown = true;
        }
        return { ...value, value: (excludeCountDown === true ? excludeCountDown : value.value) };
      });
    }
    return changeValue ?? masterData;
  };

  /**
   * this method is validating product for excludeCountDown node and looks for shipping method with promotion
   * @param product : product response
   * @returns : returns true if excludeCountDown attribute exists with false value
   */
  public deliveryCountdownExists = (product: ProductgraphqlDto):boolean => {
    let hasExpressDelivery = false;
    let excludeCountDown;
    const attribute = ('masterData' in product && 'attributesRaw' in product.masterData.current.masterVariant)
      ? product.masterData.current.masterVariant.attributesRaw : [];
    if (attribute !== undefined && attribute.length > 0) {
      excludeCountDown = attribute.find((value) => value.name === ATTRIBUTE_NAMES.excludeCountDown);
      // eslint-disable-next-line no-unneeded-ternary
      hasExpressDelivery = (typeof excludeCountDown !== 'undefined'
          && excludeCountDown.length > 0 && excludeCountDown.value === false) ? true : false;
    }
    return hasExpressDelivery;
  };

  /** get product stock details */
  public getStockDetails = (
    channels: VariantchannelsresultsDto[],
    channelKey: string,
    inventoryData: GraphQLInventoryEntry[],
  ): AvailabilityDto => {
    if (channels?.length === 0) {
      return DEFAULT_INVENTORY;
    }
    const stockDetails = channels?.find((channel) => channel.channel.key === channelKey);
    const inventory = inventoryData?.find((inv) => inv.id === stockDetails?.availability.id);
    let limitedStock : string | boolean = false;
    if (inventory !== undefined && inventory.custom !== null) {
      inventory.custom.customFieldsRaw.forEach((field) => {
        if (field.name === 'isLowAvailability') {
          limitedStock = field?.value;
        }
      });
    }

    return {
      stockQty: stockDetails?.availability.availableQuantity,
      isAvailable: stockDetails?.availability.isOnStock,
      limitedStock,
    };
  };

  /** Fetching delivery details from magnolia * @param attribute : attribute with excludeCountDown Value
   * @returns Response of Delivery details from magnolia response */
  public getDeliveryCountdown = (attribute: AttributesRawDto[]): DeliveryCountObject | [] => {
    if (attribute.length === 0) {
      return [];
    }
    const allNodes: Array<string | undefined> = [];
    let allTextsNodes: Array<string | undefined>;
    let allDeliveryNodes: Array<string | undefined>;
    let deliverTextMessage = '';
    let deliveryTime = '';
    const excludeCountDown = attribute.find((value) => value.name === ATTRIBUTE_NAMES.excludeCountDown);
    if (typeof excludeCountDown !== 'undefined' && 'value' in excludeCountDown) {
      if (excludeCountDown.value) {
        return [];
      }
      // get delivery time Nodes
      if (SHIPPING_METHOD_TEXT.textNode in shippingMethodJson) {
        deliverTextMessage = shippingMethodJson[SHIPPING_METHOD_TEXT.textNode][SHIPPING_METHOD_TEXT.deliveryText];
        allTextsNodes = shippingMethodJson[SHIPPING_METHOD_TEXT.textNode][SHIPPING_METHOD_TEXT.nodes];
        allTextsNodes.forEach((value) => {
          const timeKeys = shippingMethodJson[SHIPPING_METHOD_TEXT.textNode][value][SHIPPING_METHOD_TEXT.nodes];
          timeKeys.forEach((element) => {
            allNodes.push(shippingMethodJson[SHIPPING_METHOD_TEXT.textNode][value][element]);
          });
          return allNodes;
        });
      }
      // get delivery Nodes
      if (SHIPPING_METHOD_TEXT.delivery in shippingMethodJson) {
        deliveryTime = shippingMethodJson[SHIPPING_METHOD_TEXT.delivery][SHIPPING_METHOD_TEXT.time];
        allDeliveryNodes = shippingMethodJson[SHIPPING_METHOD_TEXT.delivery][SHIPPING_METHOD_TEXT.nodes];
        allDeliveryNodes.forEach((value) => {
          allNodes.push(shippingMethodJson[SHIPPING_METHOD_TEXT.delivery][value]);
        });
      }
    } else {
      return [];
    }
    return {
      message: deliverTextMessage, cutOffTime: deliveryTime, days: allNodes,
    };
  };
}
