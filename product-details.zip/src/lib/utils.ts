/**
 * To get the market path for global cluster market.
 * LANG_COUNTRY_MAP='{"en-ro": "en-us"}'
 * [ 'Global', 'en-us', 'CEE' ]
 */
export const getMarketPath = (pathArray: Array<string>):string => {
  const path = pathArray.filter((i) => {
    return !i.includes('_');
  });
  return path.join('/'); // Global/CEE
};
