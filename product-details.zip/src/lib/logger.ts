/**
 * This is a wrapper for log4js
 */
import { inspect } from 'util';
import log4js from 'log4js';
import { config } from 'dotenv';

config();

const LOG_LEVEL = (process.env.LOG_LEVEL || 'off').toLowerCase();

log4js.configure({
  appenders: {
    console: { type: 'console' },
  },

  categories: {
    default: { appenders: ['console'], level: LOG_LEVEL },
  },
});

const logger = log4js.getLogger();

if (!process.env.LOG_LEVEL) {
  logger.warn('Missing LOG_LEVEL environment variable. Defaulting to "off". You will not see any logs.');
}

/**
 * Log a JavaScript Error object. This function sanitizes the Error a bit
 * before printing it (removes req/res in case the Error comes from axios)
 * and supports circular references.
 * @param source - string A keyword describing the context where the error happened (eg, PaymentService)
 * @param reason - string What happened (eg, failed to initiate payment)
 * @param error - any Should be an Error object
 */
export const logError = (
  source: string,
  reason: string,
  error: any,
): void => {
  if (process.env.LOG_LEVEL !== 'trace') {
    logger.error(`${source} ERROR: ${reason} because:\n${error}`);
    return;
  }

  const cleanError: any = {
    ...error,
    stack: error.stack,
    message: error.message,
  };

  /* Remove fields we don't care about, because many errors contain
     the HTTP request and response objects, but they are complicated,
     and we rarely care to see what's in them */
  delete cleanError.req;
  delete cleanError.res;
  delete cleanError.request;
  delete cleanError.response;

  const stringError = inspect(cleanError, { depth: 10 });

  logger.error(`${source} ERROR: ${reason} because:\n${stringError}`);
};

export { logger };
