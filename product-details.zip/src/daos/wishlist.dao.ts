import {
  ShoppingList, ShoppingListDraft, ShoppingListUpdate,
  ClientResponse, ShoppingListPagedQueryResponse,
  GraphQLResponse,
} from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import { MarketInfo } from '../middlewares';
import { ApiError, CtClient, logger } from '../lib';
import { CT_KEY } from '../common/constant';
import { graphql } from '../graphql';
import { GraphQLShoppingList } from '../dtos';

export interface ShoppingListDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

enum SHOPPINGLIST_ACTIONS {
  addLineItem = 'addLineItem',
  removeLineItem = 'removeLineItem',
  changeLineItemQuantity = 'changeLineItemQuantity',
}

/**
 * `ShoppingListDao` data access class for CommerceTools `ShoppingList`
 */
export class ShoppingListDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
     * Constructor for `ShoppingListDao` class
     * @param config injects dependencies into the object
     */
  constructor(config: ShoppingListDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
   * Creates a ShoppingList for Customer
   * @param market - MarketInfo
   * @param shoppingListDraft - Draft for ShoppingListDraft to be created
   * @returns ShoppingListDao with LineItems
   */
  public async create(
    market: MarketInfo,
    shoppingListDraft: ShoppingListDraft,
  ): Promise<ShoppingList> {
    let response: ClientResponse<ShoppingList>;
    const country = market.country.toLocaleUpperCase();
    try {
      response = await this.ctClient.getClient(country)
        .shoppingLists()
        .post({ body: shoppingListDraft, queryArgs: { expand: [CT_KEY.lineItemVariant, CT_KEY.lineItemProductSlug] } })
        .execute();
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to create wishlist, because:\n${err.stack}`);
      if (err.body?.statusCode) {
        throw new ApiError(err.body.statusCode, err.body.errors);
      }
      throw err;
    }

    return response.body;
  }

  /**
   * Reads a ShoppingList from CommerceTools
   * @param market - MarketInfo
   * @param shoppingListId - Id of CT ShoppingList to retrieve
   * @returns Fetched CtShoppingListDao (or undefined if the ShoppingList doesn't exist)
   */
  public async findOne(
    market: MarketInfo,
    shoppingListId: string,
  ): Promise<ShoppingList | undefined> {
    const country = market.country.toLocaleUpperCase();

    let shoppingList: ClientResponse<ShoppingList>;
    try {
      shoppingList = await this.ctClient.getClient(country)
        .shoppingLists()
        .withId({ ID: shoppingListId })
        .get({
          queryArgs: { expand: [CT_KEY.lineItemVariant, CT_KEY.lineItemProductSlug] },
        })
        .execute();
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to retrieve ShoppingList id "${shoppingListId}" from CT, because:\n${err.stack}`);

      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        return undefined;
      }

      throw err;
    }
    return shoppingList.body;
  }

  /**
   * Reads a ShoppingList from CommerceTools
   * @param market - MarketInfo
   * @param condition - CT condition
   * @returns Fetched ShoppingListDao (or undefined if the ShoppingList doesn't exist)
   */
  public async findOneBy(
    market: MarketInfo,
    condition: string,
  ): Promise<ShoppingList | undefined> {
    const country = market.country.toLocaleUpperCase();
    let shoppingList: ClientResponse<ShoppingListPagedQueryResponse>;
    try {
      shoppingList = await this.ctClient.getClient(country)
        .shoppingLists()
        .get({
          queryArgs: {
            expand: [CT_KEY.lineItemVariant, CT_KEY.lineItemProductSlug],
            where: condition,
            limit: 1,
          },
        })
        .execute();
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to retrieve ${condition} from CT, because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
        return undefined;
      }
      throw err;
    }
    if (!shoppingList.body) {
      return undefined;
    }
    return shoppingList.body.results[0];
  }

  /**
   * Adds a LineItem to an existing ShoppingList or updates its quantity
   * @param market - MarketInfo
   * @param shoppingListId - Id of the ShoppingList to be updated
   * @param shoppingListVersion - Version of the ShoppingList to be updated
   * @param sku - SKU identifier of the LineItem to be added to the ShoppingList
   * @returns ShoppingListDao with LineItems
   */
  public async updateLineItemQuantity(
    market: MarketInfo,
    shoppingListId: string,
    shoppingListVersion: number,
    sku: string,
  ): Promise<ShoppingList> {
    const country = market.country.toLocaleUpperCase();

    const body: ShoppingListUpdate = {
      version: shoppingListVersion,
      actions: [{
        action: SHOPPINGLIST_ACTIONS.addLineItem,
        sku,
      }],
    };
    let response: ClientResponse<ShoppingList>;
    try {
      response = await this.ctClient.getClient(country)
        .shoppingLists()
        .withId({ ID: shoppingListId })
        .post({ body, queryArgs: { expand: [CT_KEY.lineItemVariant, CT_KEY.lineItemProductSlug] } })
        .execute();
      return response.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to create wishlist, because:\n${err.stack}`);
      if (err.body?.statusCode) {
        throw new ApiError(err.body.statusCode, err.body.errors);
      }
      throw err;
    }
  }

  /** Removes `LineItem`s from a `ShoppingList`
  * @param market - MarketInfo
  * @param shoppingListId - Id of the ShoppingList to be updated
  * @param shoppingListVersion - Version of the ShoppingList to be updated
  * @param lineItemIds - Id of the LineItem to be deleted from ShoppingList
  * @returns ShoppingListDao with Deleted LineItems
  */
  public async deleteLineItems(
    market: MarketInfo,
    shoppingListId: string,
    shoppingListVersion: number,
    lineItemIds: string[],
  ): Promise<ShoppingList> {
    const body: ShoppingListUpdate = {
      version: shoppingListVersion,
      actions: lineItemIds.map((lineItemId) => ({
        action: SHOPPINGLIST_ACTIONS.removeLineItem,
        lineItemId,
      })),
    };

    const result = await this.ctClient.getClient(market.country)
      .shoppingLists()
      .withId({ ID: shoppingListId })
      .post({ body, queryArgs: { expand: [CT_KEY.lineItemVariant, CT_KEY.lineItemProductSlug] } })
      .execute();

    return result.body;
  }

  /**
 * Reads a Wishlist from CommerceTools
 * @param market - MarketInfo
 * @param wishListId - Id of CT Wishlist to retrieve
 * @returns Fetched wishlistDao (or undefined if the Wishlist doesn't exist)
 */
  public async findGraphQLOne(
    market: MarketInfo,
    wishListId: string,
  ): Promise<GraphQLShoppingList | undefined> {
    const body = {
      query: await this.graphql.wishlistById,
      variables: {
        id: wishListId,
        locale: market.locale,
      },
    };
    try {
      const result: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body })
        .execute();
      const { shoppingList } = result.body.data;
      if (shoppingList === null) {
        return undefined;
      }
      return shoppingList;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
        + ` GraphQL returned: ${JSON.stringify(err.body.errors)}.`);

      throw err;
    }
  }
}
