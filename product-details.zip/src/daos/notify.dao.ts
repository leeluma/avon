import { CustomObjectDraft, ClientResponse, GraphQLResponse } from '@commercetools/platform-sdk';
import { graphql } from '../graphql';
import { MarketInfo } from '../middlewares';
import { CtClient } from '../lib';

/**
 * Notify dao constructor config
 * @param: ctClient
 */
interface NotifyDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

/**
 * `NotifyDao` data access class for CommerceTools `Custom Object`
 */
export class NotifyDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `NotifyDao` class
   * @param config injects dependencies into the object
   */
  constructor(config: NotifyDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
   * Creates a Custom Object for Notify
   * @param market - MarketInfo
   * @param notifyDraft - Draft for Custom Object
   * @returns respone with status code.
   */
  public async create(
    market: MarketInfo,
    notifyDraft: CustomObjectDraft,
  ): Promise<void> {
    const country = market.country.toLocaleUpperCase();

    await this.ctClient.getClient(country)
      .customObjects()
      .post({ body: notifyDraft }).execute();
  }

  /**
   * Fetch Single Product by Key and skus
   * @param market - MarketInfo
   * @param productKey - Key of a Product to be Fetch
   * @returns - Response Body of Product
   */
  public async isProduct(
    market: MarketInfo,
    productKey: string,
    skus: string[],
  ): Promise<boolean> {
    const body = {
      query: await this.graphql.isProduct,
      variables: {
        skus,
        where: `key=${productKey}`,
      },
    };
    const result: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
      .graphql()
      .post({ body })
      .execute();
    return result.body.data.products.exists;
  }
}
