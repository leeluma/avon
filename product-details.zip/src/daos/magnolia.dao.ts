import { LocalizedString } from '@commercetools/platform-sdk';
import axios, { AxiosResponse } from 'axios';
import { axiosOptions } from '../lib/axios-options';
import { MarketInfo } from '../middlewares';
import { MagnoliaUri, URI } from '../common/constant';
import { MagnoliaPriceFormatDto } from '../dtos/line-item.dto';
import { LooseObject } from '../dtos/product.dto';
import { logger } from '../lib';
import { MagnoliaDto } from '../dtos/magnolia.dto';
import { CommonResponse } from '../dtos';
import { MagnoliaInfo } from '../dtos/common.dto';

const countryStatic = '{{country}}';

/**
 * `MagnoliaDao` data access class for Magnolia
 */
export default class MagnoliaDao {
  /**
   * Reads a price format page from Magnolia.
   * @param _market - MarketInfo
   * @returns Object of `MagnoliaPriceDto`
   */
  public async getPriceFormat(market: MarketInfo): Promise<MagnoliaPriceFormatDto> {
    const { locale, country } = market;
    const localeAndCountry = `${locale.toLocaleLowerCase()}-${country.toLocaleLowerCase()}`;
    const { MAGNOLIA_BASE_PATH } = process.env;
    const configUrl = {
      ...axiosOptions,
      method: 'get' as const,
      url: `${MAGNOLIA_BASE_PATH}${URI.magnolia.priceFormatUrl.replace(countryStatic, country.toLocaleLowerCase())
        .replace('{{localeAndCountry}}', localeAndCountry.toLocaleLowerCase())}`,
    };
    try {
      const response = await axios(configUrl);
      logger.info(`Status ${response.status}`);
      return response.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Response body: ${error.response?.data}`);
      throw new Error(`Failed to fetch magnolia price format, because: ${error.stack}`);
    }
  }

  /**
   * Get PDP data From Magnolia
   * @param market - MarketInfo
   * @returns Return pdp data from Magnolia
   */

  public async getPdpDataFromMagnolia(
    market: MarketInfo,
    magnolia: MagnoliaInfo,
  ) : Promise<AxiosResponse> {
    const queryParam = `lang=${market.locale}-${market.country}`;
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: `${magnolia.url}${MagnoliaUri.PDP}${magnolia.marketPath}/p?${queryParam}`,
    };
    try {
      const page = await axios(config);
      return page.data;
    } catch (error:any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch product data from Magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get How To and The Look data from Magnolia
   * @param market
   * @param productKey
   * @returns return How To and The Look data from Magnolia
   */
  public async getHowToLookFromMagnolia(
    market: MarketInfo,
    productKey: string | LocalizedString,
    magnolia: MagnoliaInfo,
  ) : Promise<LooseObject> {
    const magnoliaQuery = `@ancestor=/${market.country.toLocaleLowerCase()}&q=${productKey}
    &lang=${market.locale}-${market.country}`;
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: `${magnolia.url}${MagnoliaUri.HOW_TO_LOOK}?${magnoliaQuery}`,
    };
    try {
      const howToLook = await axios(config);
      return howToLook.data;
    } catch (error:any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch product How to and The Look data from Magnolia, because: ${error.stack}`);
    }
  }

  /**
    * Get Product details template data from Magnolia
    * @param templateName magnolia template name
    * @returns return Product details template data from Magnolia
    */
  public async getTemplateDataFromMagnolia(
    templateName: string,
    magnolia: MagnoliaInfo,
  ): Promise<AxiosResponse> {
    const config = {
      ...axiosOptions,
      method: 'get' as const,
      url: `${magnolia.url}${MagnoliaUri.TEMPLATE}${templateName}`,
    };
    try {
      const templateDefinition = await axios(config);
      return templateDefinition.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch Product details template data from Magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get warehouse data
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   */
  public async getDefaultWarehouse(
    market: MarketInfo,
    magnoliaBasePath: string,
  ) : Promise<MagnoliaDto> {
    try {
      let wareHouseSettingUrl = `${magnoliaBasePath}${MagnoliaUri.WARE_HOUSE_SETTINGS}?lang=${market.localeAndCountry}`;
      wareHouseSettingUrl = wareHouseSettingUrl.replace(countryStatic, `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: wareHouseSettingUrl,
      };
      const result = await axios(config);
      return result.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch warehouse data from magnolia, because: ${error.stack}`);
    }
  }

  /**
   * Get global settings data
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   */
  public async getGlobalSettings(
    market: MarketInfo,
    magnoliaBasePath: string,
  ) : Promise<CommonResponse> {
    try {
      let globalSettingsUrl = `${magnoliaBasePath}${MagnoliaUri.GLOBAL_SETTINGS}?lang=${market.localeAndCountry}`;
      globalSettingsUrl = globalSettingsUrl.replace(countryStatic, `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: globalSettingsUrl,
      };
      const result = await axios(config);
      return result.data;
    } catch (error: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      throw new Error(`Failed to fetch global settings data from magnolia, because: ${error.stack}`);
    }
  }
}
