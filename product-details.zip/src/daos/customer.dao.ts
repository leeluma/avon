import { ClientResponse, GraphQLResponse } from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { graphql } from '../graphql';
import { MarketInfo } from '../middlewares';
import { logger, CtClient, ApiError } from '../lib';
import { GraphQLCustomerResponse } from '../dtos';

export interface CustomerDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

/**
 * `CustomerDao` data access class for CommerceTools `customer`
 */
export class CustomerDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `customerDraftDto` class
   * @param configs injects dependencies into the object
   */
  constructor(configs: CustomerDaoConfig) {
    this.ctClient = configs.ctClient;
    this.graphql = configs.graphql;
  }

  /**
   * Reads a Customer from CommerceTools based on auth token
   * @param market - MarketInfo
   * @param authHeader - customer auth token
   * @returns Fetched customerDao (or undefined if the Customer doesn't exist)
   */
  public async getCustomerDetailsGraphQL(
    market: MarketInfo,
    authHeader: string,
  ): Promise<GraphQLCustomerResponse> {
    try {
      const body = {
        query: await this.graphql.getCustomerByToken,
      };
      const result: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          headers: {
            Authorization: authHeader,
          },
          body,
        })
        .execute();

      const { body: { data: { me: { customer } } } } = result;
      if (!customer) {
        throw new ApiError(
          HttpStatusCodes.NOT_FOUND,
          i18next.t('error.customerNotFound'),
        );
      }
      return customer;
    } catch (error: any) { // NOSONAR
      logger.error(`from Commerce tool, because:\n${error.stack}`);
      if (error?.statusCode) {
        throw new ApiError(error.statusCode, (error?.messageArray) ? error.messageArray : error.message);
      }
      throw error;
    }
  }
}
