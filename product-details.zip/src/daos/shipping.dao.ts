import {
  ClientResponse,
  GraphQLResponse,
} from '@commercetools/platform-sdk';
import { CtClient, logger } from '../lib';
import { MarketInfo } from '../middlewares';
import { graphql } from '../graphql';

interface CtShippingDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

/**
 * `CtShippingDao` data access class for CommerceTools `Shipping Methods`
 */
export default class ShippingDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `ShippingDao` class
   * @param config injects dependencies into the object
   */
  constructor(config: CtShippingDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
   * Fetch all the shipping methods using GraphQL
   * @param market - Market info
   * @returns - product details
   */
  public async getShippingMethods(
    market: MarketInfo,
  ): Promise<GraphQLResponse> {
    const body = {
      query: await this.graphql.getShippingMethods,
      variables: {
        locale: market.locale,
      },
    };
    let ctResponse: ClientResponse<GraphQLResponse>;

    try {
      ctResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body })
        .execute();
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
          + ` GraphQL returned: ${JSON.stringify(err.body?.errors)}.`);
      throw err;
    }
    return ctResponse.body?.data?.shippingMethods;
  }
}
