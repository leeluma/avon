import { ClientResponse, GraphQLResponse, LocalizedString } from '@commercetools/platform-sdk';
import { CtClient, logger } from '../lib';
import { MarketInfo } from '../middlewares';
import { graphql } from '../graphql';
import { ProductgraphqlDto } from '../dtos/product.dto';

interface CtProductDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

/**
 * `CtProductDao` data access class for CommerceTools `Product`
 */
export default class ProductDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `ProductDao` class
   * @param config injects dependencies into the object
   */
  constructor(config: CtProductDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
   * Fetch products data based on provided ids using GraphQL
   * @param market - Market info
   * @param productIds - multiple product ids as comma separated
   * @returns - product details
   */
  public async fetchProduct(
    market: MarketInfo,
    productIds: string | LocalizedString,
  ): Promise<ProductgraphqlDto> {
    const body = {
      query: await this.graphql.getProducts,
      variables: {
        key: productIds,
        locale: market.locale,
      },
    };
    let ctResponse: ClientResponse<GraphQLResponse>;

    try {
      ctResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body })
        .execute();
      // logging the x-correlation-id
      logger.info(`x-correlation-id: ${ctResponse.headers?.['x-correlation-id']}`);
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
          + ` GraphQL returned: ${JSON.stringify(err.body?.errors)}.`);
      throw err;
    }
    return ctResponse?.body?.data?.product;
  }

  /**
   * Fetch inventory data based on provided sku using GraphQL
   * @param market - Market info
   * @param productIds - sku ids as comma separated
   * @returns - product details
   */
  public async getInventoryBySku(
    market: MarketInfo,
    skuIds: string | undefined,
  ): Promise<GraphQLResponse> {
    const body = {
      query: await this.graphql.getInventory,
      variables: {
        where: `sku in (${skuIds})`,
      },
    };
    let ctResponse: ClientResponse<GraphQLResponse>;
    try {
      ctResponse = await this.ctClient.getClient(market.country)
        .graphql()
        .post({ body })
        .execute();
      return ctResponse.body?.data?.inventoryEntries;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Error querying CT GraphQL with body ${JSON.stringify(body)}.`
          + ` GraphQL returned: ${JSON.stringify(err.body?.errors)}.`);
      throw err;
    }
  }
}
