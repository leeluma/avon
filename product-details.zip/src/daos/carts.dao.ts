import axios, { AxiosRequestConfig } from 'axios';
import { ApiError, logger } from '../lib';
import { MarketInfo } from '../middlewares';
import { AddToCartResponseDto } from '../dtos/add-to-cart-response.dto';
import { RESPONSE_KEY } from '../common/constant';

export interface CartsDaoConfig {
  beOrderUrl: string;
}

/**
 * `CartsDao` data access class for Carts
 */
export class CartsDao {
  private readonly beOrderUrl: string;

  /**
   * Constructor for `CartsDao` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: CartsDaoConfig) {
    this.beOrderUrl = config.beOrderUrl;
  }

  public async addProductToCart(
    market: MarketInfo,
    channelKey:string| undefined,
    requestParam,
  ): Promise<AddToCartResponseDto> {
    const cartId = requestParam?.cartId;
    const customerId = requestParam?.customerId;
    const lineItems = requestParam?.lineItems;
    const anonymousId = requestParam?.anonymousId;
    const axiosConfig: AxiosRequestConfig = {
      method: 'post' as const,
      url: `${this.beOrderUrl.replace('{{MARKET}}', market.localeAndCountry)}/carts`,
      headers: {
        'Content-Type': RESPONSE_KEY.applicationJson,
        Accepts: RESPONSE_KEY.applicationJson,
      },
      data: {
        customerId,
        anonymousId,
        channelKey,
        cartId,
        lineItems: { sku: lineItems?.sku, quantity: lineItems?.quantity, productKey: lineItems?.productKey },
      },
    };

    try {
      const response = await axios(axiosConfig);

      return response.data.data;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`LEAP BE ORDER returned error: ${err}`);

      if (!err.response) {
        throw err;
      }

      throw new ApiError(err.response.status, err.response.data?.errors);
    }
  }
}
