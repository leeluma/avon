import { Router } from 'express';
import { validateKey } from '../validators';
import { validateRequestSchema } from '../middlewares/validate-request-schema';
import { ProductController } from '../controllers/product.controller';
import { wrapJsonApiController } from '../lib';
import { magnoliaUrlMiddleware } from '../middlewares/magnolia-url.middleware';

interface ProductRouterConfig {
    productController: ProductController;
  Router: typeof Router;
}

/**
 * `ProductRouter` for all the routes related to `/product`
 */
export class ProductRouter {
  private readonly productController: ProductController;

  private readonly Router: typeof Router;

  constructor(config: ProductRouterConfig) {
    this.productController = config.productController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
    * @swagger
    * components:
    *   schemas:
    *     HttpResponseEntityProductDto:
    *      type: object
    *      properties:
    *        status:
    *          $ref: '#/components/schemas/Status'
    *        data:
    *          $ref: '#/components/schemas/ProductDto'
    *     Status:
    *      type: object
    *      properties:
    *        statusCode:
    *          type: integer
    *          format: int32
    *          example: 200
    *        msg:
    *          type: string
    *          example: OK
    *        timestamp:
    *          type: string
    *          example: 2022-01-24T08:15:49.618Z
    *     VariantsDto:
    *      type: object
    *      properties:
    *        id:
    *          type: integer
    *          format: int32
    *          example: 1
    *        key:
    *          type: string
    *          example: 85089-9161866660405716787
    *        sku:
    *          type: string
    *          example: 85089-9161866660405716787
    *        sellPrice:
    *          type: number
    *          example: 22.95
    *        listPrice:
    *          type: number
    *          example: 26.99
    *        formattedListPrice:
    *          type: string
    *          example: 26.99 RON
    *        formattedSellPrice:
    *          type: string
    *          example: 22.95 RON
    *        vatMessage:
    *          type: string
    *          example: Vat Included
    *        unitPrice:
    *          type: string
    *          example: 33 RON per 100g
    *        availability:
    *          $ref: '#/components/schemas/AvailabilityDto'
    *        assets:
    *          type: array
    *          items:
    *            $ref: '#/components/schemas/AssetDto'
    *        attributes:
    *            $ref: '#/components/schemas/AttributesDto'
    *        badges:
    *            $ref: '#/components/schemas/BadgesDto'
    *     deliveryCountdownDto:
    *       type: object
    *       properties:
    *         message:
    *           type: string
    *           example: Express delivery! Order within remainingTime and choose next day!
    *         cutOffTime:
    *           type: string
    *           example: 22:55
    *         days:
    *           type: array
    *           items:
    *             type: object
    *             properties:
    *               name:
    *                 type: string
    *                 example: hourRules
    *               path:
    *                 type: string
    *                 example: /ro-ro/p/texts/timeUnits/hourRules
    *               id:
    *                 type: string
    *                 example: 3df1723a-9643-4815-8c1d-dcb1940a04a8
    *               nodeType:
    *                 type: string
    *                 example: mgnl:contentNode
    *               lastModified:
    *                 type: string
    *                 example: 2022-01-24T23:32:56.278+05:30
    *               other:
    *                 type: string
    *                 example: hrs
    *               one:
    *                 type: string
    *                 example: hr
    *               created:
    *                 type: string
    *                 example: 2022-01-24T21:41:32.099+05:30
    *               nodes:
    *                 type: array
    *                 items:
    *     CategoriesDto:
    *       type: array
    *       items:
    *         type: object
    *         properties:
    *           slug:
    *             type: string
    *             example: 302-314-398_produce-make-up_ten_corrector
    *           id:
    *             type: string
    *             example: ab1ae49d-6059-4594-a585-315b854d72df
    *     BreadcrumbDto:
    *       type: array
    *       items:
    *         type: object
    *         properties:
    *           key:
    *             type: string
    *             example: 302
    *           parentKey:
    *             type: string
    *             example: root
    *           displayName:
    *             type: string
    *             example: PRODUCE MAKE-UP
    *           url:
    *             type: string
    *             example: /c/302_produce-make-up
    *     OffersDto:
    *       type: array
    *       items:
    *         type: object
    *         properties:
    *           key:
    *             type: string
    *             example: Any-3-with-3150-RON
    *           displayName:
    *             type: string
    *             example: Any 3 with 31.50 RON!
    *           url:
    *             type: string
    *             example: /c/any-3-with-3150-ron
    *           description:
    *             type: string
    *             example: Any 3 with 31.50 RON!
    *     SearchKeywordsDto:
    *       type: string
    *       example: Naturals
    *     AssetDto:
    *      type: object
    *      properties:
    *        url:
    *          type: string
    *          example: https://www.avon.com/assets/en-gb/images/pro prod_1221999_1_613x613.jpg
    *        assetType:
    *          type: string
    *          enum:
    *           - Gallery
    *           - Thumbnail
    *           - Variant
    *          example: Gallery
    *        sequence:
    *          type: integer
    *          format: int64
    *          example: 1
    *     AvailabilityDto:
    *      type: object
    *      properties:
    *        stockQty:
    *          type: integer
    *          format: int64
    *          example: 10
    *        isAvailable:
    *          type: boolean
    *     AttributesDto:
    *       type: object
    *       properties:
    *        variantType:
    *          type: string
    *          example: Shade
    *        brandId:
    *          type: string
    *          example: 2556
    *        brandName:
    *          type: string
    *          example: Avon True
    *        variantValue:
    *          type: string
    *          example: Pink Fair
    *        finishedStockCode:
    *          type: string
    *          example: 1317765
    *        ingredients:
    *          type: string
    *          example: We inform you
    *        hexCode:
    *          type: string
    *          example: #ff8da1
    *        maxPurchasableQty:
    *          type: integer
    *          format: int32
    *          example: 10
    *        specialMessage:
    *          type: string
    *          example: NOU
    *        ContentFillMeasure:
    *          type: string
    *          example: g
    *        ContentFill:
    *          type: integer
    *          format: int32
    *          example: 70
    *     BadgesDto:
    *       type: object
    *       properties:
    *         topRight:
    *           type: string
    *           example: New
    *         topLeft:
    *           type: string
    *           example: -16 %
    *     ProductDto:
    *        type: object
    *        required:
    *          - id
    *          - key
    *          - name
    *          - description
    *          - masterVariant
    *        properties:
    *          id:
    *            type: string
    *            example: 1b318b22-b439-43ca-8bf8-fac91c688ad8
    *          key:
    *            type: string
    *            example: 85089
    *          name:
    *            type: string
    *            example: Corrector Power stay
    *          description:
    *            type: string
    *            example: Corrector Power stay.
    *          metaTitle:
    *            type: string
    *            example: Looking for Corrector.
    *          metaDescription:
    *            type: string
    *            example: Looking for Corrector.
    *          isLive:
    *             type: boolean
    *          masterVariant:
    *            $ref: '#/components/schemas/VariantsDto'
    *            description: master variant of the product
    *          variants:
    *           description: array of variants
    *           type: array
    *           items:
    *             $ref: '#/components/schemas/VariantsDto'
    *          deliveryCountdown:
    *            $ref: '#/components/schemas/deliveryCountdownDto'
    *          categories:
    *            $ref: '#/components/schemas/CategoriesDto'
    *          breadcrumb:
    *            $ref: '#/components/schemas/BreadcrumbDto'
    *          offers:
    *            $ref: '#/components/schemas/OffersDto'
    *          searchKeywords:
    *           $ref: '#/components/schemas/SearchKeywordsDto'
    */

    /**
     * @swagger
     * /product-details/v1/{language}-{market}/products/{id}:
     *   get:
     *     summary: Get the product by id for particular language and market
     *     operationId: getProductById
     *     tags: [Product]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *           type: string
     *         required: true
     *         description: The language
     *         example: ro
     *       - in: path
     *         name: market
     *         schema:
     *           type: string
     *         required: true
     *         description: The market
     *         example: ro
     *       - in: header
     *         name: channelkey
     *         schema:
     *           type: string
     *         required: false
     *         description: The channelkey
     *         example: DC-RO
     *       - in: path
     *         name: key
     *         schema:
     *           type: string
     *         required: true
     *         description: The product key
     *         example: 85089
     *       - in: header
     *         name: wishlistId
     *         schema:
     *           type: string
     *         description: The wishlist id to check if product belong to wishlist or not.
     *         example: uuid
     *     responses:
     *       200:
     *         description: default response
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/HttpResponseEntityProductDto'
     *       404:
     *         description: The product was not found
     */

    router.get(
      '/:key',
      validateKey,
      validateRequestSchema,
      magnoliaUrlMiddleware,
      wrapJsonApiController(
        this.productController.getByKey.bind(this.productController),
      ),
    );

    return router;
  }
}
