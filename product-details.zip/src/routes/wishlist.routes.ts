import { Router } from 'express';
import { param } from 'express-validator';
import { ShoppingListController } from '../controllers/wishlist.controller';
import { wrapJsonApiController } from '../lib';
import { validateRequestSchema } from '../middlewares';
import { validateId } from '../validators/common.validator';
import { validateAddToWishlist } from '../validators';

/**
 * Shopping List Router constructor config
 * @param: shoppingListController
 */

interface ShoppingListRouterConfig {
  shoppingListController: ShoppingListController;
  Router: typeof Router;
}

/**
 * `WishlistRouter` for all the routes related to `/wishlists`
 */
export class ShoppingListRouter {
  private readonly shoppingListController: ShoppingListController;

  private readonly Router: typeof Router;

  constructor(config: ShoppingListRouterConfig) {
    this.shoppingListController = config.shoppingListController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
 * @swagger
 * components:
 *   schemas:
 *     WishlistRequestDto:
 *       additionalProperties: false
 *       properties:
 *         anonymousId:
 *           type: string
 *         customerId:
 *           type: string
 *         id:
 *           type: string
 *         sku:
 *           type: string
 *       required:
 *         - sku
 *       type: object
 */

    /**
     * @swagger
     * /product-details/v1/{language}-{market}/wishlists:
     *   post:
     *     summary: Add or update wishlist lineitem.
     *     tags: [Wishlists]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: market
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *      description: Valid fields
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/WishlistRequestDto'
     *     responses:
     *       200:
     *         description: Add or update wishlist items.
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/WishlistDto'
     *       404:
     *         description: Something went wrong.
     */
    router.post(
      '/',
      validateAddToWishlist,
      validateRequestSchema,
      wrapJsonApiController(
        this.shoppingListController.create.bind(this.shoppingListController),
      ),
    );

    /**
     * @swagger
     * /product-details/v1/{language}-{market}/wishlists/{id}/lineitems/{lineItemId}:
     *   delete:
     *     summary: Delete Line Item from Wishlist
     *     tags: [Wishlists]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: market
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: path
     *         name: id
     *         schema:
     *            type: string
     *         required: true
     *       - in: path
     *         name: lineItemId
     *         schema:
     *            type: string
     *         required: true
     *     responses:
     *       200:
     *         description: Deletes a LineItem from Wishlist
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/WishlistDto'
     *       404:
     *         description: Wishlist not found.
     */
    router.delete(
      '/:id/lineitems/:lineItemId',
      validateId,
      param('lineItemId').isUUID(),
      validateRequestSchema,
      wrapJsonApiController(
        this.shoppingListController.deleteLineItem.bind(this.shoppingListController),
      ),
    );

    return router;
  }
}
