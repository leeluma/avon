import { Router } from 'express';
import { validateRequestSchema } from '../middlewares';
import { DefaultController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import { validateRefreshToken } from '../validators';

export interface DefaultRouterConfig {
  defaultController: DefaultController;
  Router: typeof Router;
}

/**
 * `DefaultRouter` for all the routes related to `/`
 */

export class DefaultRouter {
  private readonly defaultController: DefaultController;

  private readonly Router: typeof Router;

  /**
   * Constructor for `DefaultRouter` class
   * @param config injects dependencies into the object
   */

  constructor(config: DefaultRouterConfig) {
    this.defaultController = config.defaultController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /** @swagger
     * /product-details/v1/{locale}-{country}/anonymous:
     *   post:
     *     summary: create anonymous session
     *     tags: [Customers]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     responses:
     *       200:
     *         description: Anonymous session created successfully
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/AnonymousFlowResponseDto'
     *       500:
     *         description: Something went wrong.
     */
    router
      .post(
        '/anonymous',
        validateRequestSchema,
        wrapJsonApiController(
          this.defaultController.createAnonymousSession.bind(this.defaultController),
        ),
      );
    /**
     * @swagger
     * /product-details/v1/{locale}-{country}/refresh-token:
     *   post:
     *     summary: Fetch refresh token
     *     tags: [Default]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: headers
     *         name: refreshToken
     *         schema:
     *            type: string
     *            default: '*****'
     *            required: true
     *     responses:
     *       200:
     *         description: Get refresh token
     *       404:
     *         description: refresh token not found
     */

    router.post(
      '/refresh-token',
      validateRefreshToken,
      validateRequestSchema,
      wrapJsonApiController(
        this.defaultController.refreshToken.bind(this.defaultController),
      ),
    );
    return router;
  }
}
