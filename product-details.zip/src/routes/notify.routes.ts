import { Router } from 'express';
import { body } from 'express-validator';
import { validateRequestSchema } from '../middlewares';
import { NotifyController } from '../controllers/notify.controller';
import { wrapJsonApiController } from '../lib';

/**
 * Notify Router constructor config
 * @param: notifyController
 */

interface NotifyRouterConfig {
  notifyController: NotifyController;
  Router: typeof Router;
}

/**
 * `NotifyRouter` for all the routes related to `/notify`
 */
export class NotifyRouter {
  private readonly notifyController: NotifyController;

  private readonly Router: typeof Router;

  constructor(config: NotifyRouterConfig) {
    this.notifyController = config.notifyController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * components:
     *   schemas:
     *     customObject:
     *       type: object
     *       required:
     *         - sku
     *         - productUrl
     *         - email
     *         - productKey
     *       properties:
     *         sku:
     *           type: string
     *           description: The sku of the product
     *         productUrl:
     *           type: string
     *           description: The url of a product
     *         email:
     *           type: string
     *           description: Email of the customer
     *         productKey:
     *            type: string
     *            description: Product Key
     *       example:
     *         sku: "35697"
     *         productUrl: "http://avon.com/xyz"
     *         email: "hcl@avon.com"
     *         productKey: "47865"
     */

    /**
     * @swagger
     * /product-details/v1/{language}-{market}/notify:
     *   post:
     *     summary: Create Custom Object for Notify
     *     tags: [Notify]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: market
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     requestBody:
     *       required: true
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/customObject'
     *     responses:
     *       201:
     *         description: Creates a Custom Object for Notify
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/customObject'
     *       404:
     *         description: Something went wrong.
     */
    router.post(
      '/',
      body('sku').notEmpty().withMessage('product.sku'),
      body('productKey').notEmpty().withMessage('product.key'),
      body('productUrl').notEmpty().isURL().withMessage('product.url'),
      body('email').isEmail().withMessage('internet.email'),
      validateRequestSchema,
      wrapJsonApiController(
        this.notifyController.create.bind(this.notifyController),
      ),
    );

    return router;
  }
}
