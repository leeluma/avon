import { Router } from 'express';
import { validateRequestSchema } from '../middlewares';
import { NotificationsController } from '../controllers/notifications.controller';
import { wrapJsonApiController } from '../lib';
import { validateNotifications } from '../validators';

export interface NotificationsRouterConfig {
  notificationsController: NotificationsController;
  Router: typeof Router;
}

/**
 * `NotificationsRouter` for all the routes related to `/notifications`
 */
export class NotificationsRouter {
  private readonly notificationsController: NotificationsController;

  private readonly Router: typeof Router;

  constructor(config: NotificationsRouterConfig) {
    this.notificationsController = config.notificationsController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router {
    const router = this.Router();

    /**
     * @swagger
     * components:
     *   schemas:
     *     NotificationRequest:
     *       additionalProperties: false
     *       properties:
     *         ticket:
     *           type: string
     *         productKey:
     *           type: string
     *         variantKey:
     *           type: string
     *       type: object
     */

    /**
     * @swagger
     * /product-details/v1/{language}-{market}/notifications/adding-to-cart:
     *   post:
     *     summary: Add apptus notification for cart esale and cart non-esale products
     *     tags: [Notifications]
     *     parameters:
     *       - in: path
     *         name: language
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: market
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *       - in: header
     *         name: sessionkey
     *         schema:
     *            type: string
     *            default: uuid
     *         required: true
     *       - in: header
     *         name: customerKey
     *         schema:
     *            type: string
     *            default: uuid
     *         required: true
     *     requestBody:
     *      description: if token is available then other are optional else required.
     *      required: true
     *      content:
     *        application/json:
     *          schema:
     *            $ref: '#/components/schemas/NotificationRequest'
     *     responses:
     *       200:
     *         description: The notifications response
     *         content:
     *           application/json:
     *             schema:
     *               type: object
     *               properties:
     *                 status:
     *                  type: object
     *                  properties:
     *                    statusCode:
     *                      type: integer
     *                      format: int32
     *                      example: 200
     *                    msg:
     *                      type: string
     *                      example: OK
     *                    timestamp:
     *                      type: string
     *                      example: '2022-03-06T10:27:41.207Z'
     *                 data:
     *                  type: boolean
     *       400:
     *         description: Bad request
     */
    router.post(
      '/adding-to-cart',
      validateNotifications,
      validateRequestSchema,
      wrapJsonApiController(
        this.notificationsController.addToCart.bind(this.notificationsController),
      ),
    );

    return router;
  }
}
