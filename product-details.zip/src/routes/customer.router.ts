import { Router } from 'express';
import { validateRequestSchema } from '../middlewares';
import { CustomerController } from '../controllers';
import { wrapJsonApiController } from '../lib';
import { validateBearerToken } from '../validators';

export interface CustomerRouterConfig {
  customerController: CustomerController;
  Router: typeof Router;
}

/**
 * `CustomerRouter` for all the routes related to `/customer`
 */
export class CustomerRouter {
  private readonly customerController: CustomerController;

  private readonly Router: typeof Router;

  constructor(config: CustomerRouterConfig) {
    this.customerController = config.customerController;
    this.Router = config.Router;
  }

  public buildExpressRouter(): Router { // NOSONAR
    const router = this.Router();
    /*
  * @swagger
  * components:
  *   securitySchemes:
  *     bearerAuth:
  *       type: http
  *       scheme: bearer
  */
    /**
     * @swagger
     * /user-profile/v1/{locale}-{country}/customers:
     *   get:
     *     summary: Get customer based on token
     *     tags: [Customer Details]
     *     parameters:
     *       - in: path
     *         name: locale
     *         schema:
     *            type: string
     *            default: ro
     *         required: true
     *       - in: path
     *         name: country
     *         schema:
     *            type: string
     *            default: RO
     *         required: true
     *     security:
     *      - bearerAuth: []
     *     responses:
     *       200:
     *         description: Get a customer details based on token
     *         content:
     *           application/json:
     *             schema:
     *               $ref: '#/components/schemas/CustomerAddressRequestDto'
     *       500:
     *         description: Something went wrong.
     */
    router.get(
      '/',
      validateBearerToken,
      validateRequestSchema,
      wrapJsonApiController(
        this.customerController.getCustomerByToken.bind(this.customerController),
      ),
    );
    return router;
  }
}
