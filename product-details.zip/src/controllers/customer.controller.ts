import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { MarketInfo } from '../middlewares';
import { ApiError, JsonApiResponseEntity } from '../lib';
import { CustomerService } from '../services';
import { CustomerResponseDto } from '../dtos';

export interface CustomerControllerConfig {
  customerService: CustomerService;
}

export class CustomerController {
  private readonly customerService: CustomerService;

  constructor(config: CustomerControllerConfig) {
    this.customerService = config.customerService;
  }

  /**
   * Get customer details based on token from Commerce Tool
   * @param request - Express request object
   * @param response - Express response object
   * @returns Customer details
   * @throws ApiError 404 if Customer id was not found
   */
  public async getCustomerByToken(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<CustomerResponseDto>> {
    const market = response.locals.market as MarketInfo;
    const authHeader: string = request.headers.authorization!;
    const customer = await this.customerService.getCustomerDetailsByToken(market, authHeader);
    if (!customer) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.customerNotFound'));
    }

    return {
      statusCode: HttpStatusCodes.OK,
      body: customer,
    };
  }
}
