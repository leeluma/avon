import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { NotifyService } from '../services/notify.service';
import { MarketInfo } from '../middlewares';
import { JsonApiResponseEntity } from '../lib';

/**
 * Notify Controller constructor config
 * @param: notifyService
 */
interface NotifyControllerConfig {
  notifyService: NotifyService;
}

/**
 * `NotifyController` representing `Notify`
 */
export class NotifyController {
  private readonly notifyService: NotifyService;

  /**
   * Constructor for `NotifyController` class
   * @param config injects dependencies into the object
   */
  constructor(config: NotifyControllerConfig) {
    this.notifyService = config.notifyService;
  }

  /**
   * Create Notify Object
   * @param req - Express request object
   * @param res - Express response object
   * @returns Created Notify Object
   */
  public async create(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<undefined>> {
    /* Parse request */
    const market = res.locals.market as MarketInfo;

    const {
      sku, productKey, productUrl, email,
    } = req.body;

    /* Call service */
    await this.notifyService.create(
      market,
      sku,
      productKey,
      productUrl,
      email,
    );

    return {
      statusCode: HttpStatusCodes.CREATED,
      body: undefined,
    };
  }
}
