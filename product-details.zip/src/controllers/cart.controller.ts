import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { CartsService } from '../services/carts.service';
import { MarketInfo } from '../middlewares';
import { JsonApiResponseEntity } from '../lib';
import { AddToCartResponseDto } from '../dtos/add-to-cart-response.dto';

export interface CartsControllerConfig {
  cartsService: CartsService;
}

/**
 * Service for managing Carts
 */
export class CartsController {
  private readonly cartsService: CartsService;

  /**
   * Constructor for `CartsController` class
   * @param config - Injects dependencies into the object
   */
  constructor(config: CartsControllerConfig) {
    this.cartsService = config.cartsService;
  }

  public async addProductToCart(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<AddToCartResponseDto>> {
    const market = res.locals.market as MarketInfo;
    const channelKey = req.headers.channelkey ?? undefined;
    const cart = await this.cartsService.addProductToCart(
      market,
      channelKey as string | undefined,
      req.body,
    );

    return {
      statusCode: HttpStatusCodes.OK,
      body: cart,
    };
  }
}
