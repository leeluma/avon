import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { NotificationsService } from '../services/notifications.service';
import { MarketInfo } from '../middlewares';
import { JsonApiResponseEntity } from '../lib';

export interface NotificationsControllerConfig {
  notificationsService: NotificationsService;
}

export class NotificationsController {
  private readonly notificationsService: NotificationsService;

  constructor(config: NotificationsControllerConfig) {
    this.notificationsService = config.notificationsService;
  }

  /**
   * create a eSale and non-eSale notifications in Apptus add to cart API
   * @param request - Express request object
   * @param response - Express response object
   * @returns Product if it was found
   */
  public async addToCart(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<boolean>> {
    const market = response.locals.market as MarketInfo;

    const {
      sessionkey,
      customerkey,
    } = request.headers;
    const {
      ticket,
      productKey,
      variantKey,
    } = request.body;

    const params = {
      sessionKey: sessionkey,
      customerKey: customerkey,
      ticket,
      productKey,
      variantKey,
    };
    const result = await this.notificationsService.addToCart(market, params);
    return {
      statusCode: HttpStatusCodes.OK,
      body: result,
    };
  }
}
