import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { DefaultService } from '../services';
import { MarketInfo } from '../middlewares';
import {
  AnonymousFlowResponseDto, CommonResponse,
} from '../dtos';
import { JsonApiResponseEntity } from '../lib';

export interface DefaultControllerConfig {
  defaultService: DefaultService;
}

export class DefaultController {
  private readonly defaultService: DefaultService;

  constructor(config: DefaultControllerConfig) {
    this.defaultService = config.defaultService;
  }

  /**
   * Create Anonymous session
   * @param request - Express request object
   * @param response - Express response object
   */
  public async createAnonymousSession(
    request: Request,
    response: Response,
  ): Promise<JsonApiResponseEntity<AnonymousFlowResponseDto>> {
    const market = response.locals.market as MarketInfo;

    const result = await this.defaultService.createAnonymousSession(market);
    return {
      statusCode: HttpStatusCodes.OK,
      body: result,
    };
  }

  /**
   * Refresh token
   * @param request - Express request object
   * @param response - Express response object
   */
  public async refreshToken(
    request: Request,
    response: Response,
  ):Promise<JsonApiResponseEntity<CommonResponse>> {
    const market = response.locals.market as MarketInfo;
    const { refreshtoken } = request.headers;
    const refreshTokenResult = await this.defaultService.refreshToken(market, refreshtoken);
    return {
      statusCode: HttpStatusCodes.OK,
      body: refreshTokenResult,
    };
  }
}
