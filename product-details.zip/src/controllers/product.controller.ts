import { LocalizedString } from '@commercetools/platform-sdk';
import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import ProductService from '../services/product.service';
import { MarketInfo } from '../middlewares';
import { ProductResponseDto } from '../dtos/product.dto';
import { ApiError, JsonApiResponseEntity } from '../lib';
import { MagnoliaInfo } from '../dtos/common.dto';
import { CommonResponse } from '../dtos';

interface ProductControllerConfig {
  productService: ProductService;
}

/**
 * `ProductController` representing `product`
 */
export class ProductController {
  private readonly productService: ProductService;

  /**
   * Constructor for `ProductController` class
   * @param config injects dependencies into the object
   */
  constructor(config: ProductControllerConfig) {
    this.productService = config.productService;
  }

  /**
   * Gets a Product by Product Id
   * @param req - Express request object
   * @param res - Express response object
   * @returns Promise
   */
  public async getByKey(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<ProductResponseDto | CommonResponse>> {
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;
    const productKey: string | LocalizedString = req.params.key;
    const channelKey = req.headers.channelkey ?? undefined;
    const wishlistId = req.headers.wishlistid ?? undefined;
    const product = await this.productService.getByKey(
      market,
      productKey,
      magnolia,
      wishlistId as string | undefined,
      channelKey as string | undefined,
    );
    if (product === undefined) {
      throw new ApiError(
        HttpStatusCodes.NOT_FOUND,
        `product with key "${productKey}" not found.`,
      );
    }

    return {
      statusCode: HttpStatusCodes.OK,
      body: product,
    };
  }
}
