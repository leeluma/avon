import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { ShoppingListService } from '../services/wishlist.service';
import { MarketInfo } from '../middlewares';
import { JsonApiResponseEntity } from '../lib';
import { WishlistDto } from '../dtos/wishlist.dto';

export interface ShoppingListControllerConfig {
    shoppingListService: ShoppingListService;
}

/**
 * `ShoppingListController` representing `Shopping List`
 */
export class ShoppingListController {
  private readonly shoppingListService: ShoppingListService;

  /**
   * Constructor for `ShoppingListController` class
   * @param config injects dependencies into the object
   */
  constructor(config: ShoppingListControllerConfig) {
    this.shoppingListService = config.shoppingListService;
  }

  /**
   * Create Default Shopping List
   * @param req - Express request object
   * @param res - Express response object
   * @returns Created Shopping List
   */
  public async create(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<WishlistDto>> {
    /* Parse request */
    const market = res.locals.market as MarketInfo;

    const {
      customerId, anonymousId, id, sku,
    } = req.body;

    /* Call service */
    const wishlist = await this.shoppingListService.create(market, id, customerId, anonymousId, sku);

    return {
      statusCode: HttpStatusCodes.CREATED,
      body: wishlist,
    };
  }

  /**
   * Deletes Line Item from Wishlist
   * @param req - Express request object
   * @param res - Express response object
   * @returns Promise
   */
  public async deleteLineItem(
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<WishlistDto>> {
    /* Parse request */
    const market = res.locals.market as MarketInfo;

    const { id, lineItemId } = req.params;

    /* Call service */
    const wishlist = await this.shoppingListService.deleteLineItem(market, id, lineItemId);

    /* Respond */
    return {
      statusCode: HttpStatusCodes.OK,
      body: wishlist,
    };
  }
}
