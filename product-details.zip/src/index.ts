import { Router } from 'express';
import { CtClient } from './lib';
import { LeapApp, LeapAppConfig } from './app/leap.app';
import ProductDao from './daos/product.dao';
import MagnoliaDao from './daos/magnolia.dao';
import { NotifyDao } from './daos/notify.dao';
import { ShoppingListDao } from './daos/wishlist.dao';
import { NotificationsDao } from './daos/notifications.dao';
import { InventoryDao } from './daos/inventory.dao';

import { ProductController } from './controllers/product.controller';
import { NotifyController } from './controllers/notify.controller';
import { ShoppingListController } from './controllers/wishlist.controller';
import { NotificationsController } from './controllers/notifications.controller';

import ProductService from './services/product.service';
import ShippingService from './services/shipping.service';
import { NotifyService } from './services/notify.service';
import { ShoppingListService } from './services/wishlist.service';
import { NotificationsService } from './services/notifications.service';

import ShippingDao from './daos/shipping.dao';
import ShippingMapper from './mappers/shipping.mapper';
import { ShoppingListMapper } from './mappers/wishlist.mapper';
import { ProductRouter } from './routes/product.routes';
import { NotifyRouter } from './routes/notify.routes';
import { NotificationsRouter } from './routes/notifications.router';

import { ShoppingListRouter } from './routes/wishlist.routes';
import ProductMapper from './mappers/product.mapper';
import { InventoryMapper } from './mappers/inventory.mapper';
import { CustomerMapper } from './mappers/customer.mapper';

import { AddressMapper } from './mappers/address.mapper';

import { config } from './config/config';
import { LineItemMapper } from './mappers/line-item.mapper';
import { CartsRouter } from './routes/carts.router';
import { CartsController } from './controllers/cart.controller';
import { CartsService } from './services/carts.service';
import { CartsDao } from './daos/carts.dao';

import { graphql } from './graphql';
import { Common } from './lib/common';
import { CtDto } from './dtos';
import { DefaultDao, CustomerDao } from './daos';
import { DefaultService, CustomerService } from './services';
import { DefaultController, CustomerController } from './controllers';
import { DefaultRouter, CustomerRouter } from './routes';
import { Product } from './lib/product';

/* Build configuration */
const {
  projectName, projectVersion, apiContextPath, apiVersion, port, magnoliaBasePath, previewMagnoliaBasePath,
  beOrderUrl, apptusBaseUrl, apptusClusterId, apptusEsalesMarket,
} = config;
if (!projectName) {
  throw new Error('The "name" field in package.json is mandatory!');
}

if (!projectVersion) {
  throw new Error('The "version" field in package.json is mandatory!');
}

if (!apiContextPath) {
  throw new Error('The "API_CONTEXT_PATH" environment variable is mandatory! (suggested value: api)');
}
if (!apiVersion) {
  throw new Error('The "API_VERSION" environment variable is mandatory! (suggested value: v1)');
}
if (!port) {
  throw new Error('The "API_PORT" environment variable is missing or not a valid number! (suggested value: 3000)');
}
if (!magnoliaBasePath) {
  throw new Error('The "MAGNOLIA_BASE_PATH" environment variable is mandatory!');
}
if (!previewMagnoliaBasePath) {
  throw new Error('The "PREVIEW_MAGNOLIA_BASE_PATH" environment variable is mandatory!');
}
if (!beOrderUrl) {
  throw new Error('The "LEAP_BE_ORDER" environment variable is mandatory!');
}

if (!apptusClusterId) {
  throw new Error('The "APPTUS_CLUSTER_ID" environment variable is missing');
}

if (!apptusBaseUrl) {
  throw new Error('The "APPTUS_BASE_URL" environment variable is missing');
}

if (!apptusEsalesMarket) {
  throw new Error('The "APPTUS_ESALES_MARKET" environment variable is missing');
}

const appConfig: LeapAppConfig = {
  projectName,
  projectVersion,
  apiContextPath,
  apiVersion,
  port,
};

/* Initialize dependencies */

const ctClient = new CtClient(process.env as CtDto);

const productDao = new ProductDao({ ctClient, graphql });

const cartsDao = new CartsDao({ beOrderUrl });

const magnoliaDao = new MagnoliaDao();

const shippingDao = new ShippingDao({ ctClient, graphql });

const notifyDao = new NotifyDao({ ctClient, graphql });

const shoppingListDao = new ShoppingListDao({ ctClient, graphql });

const inventoryDao = new InventoryDao({ ctClient, graphql });

const product = new Product();
const common = new Common({ product });
const notificationsDao = new NotificationsDao({
  common,
  apptusBaseUrl,
  apptusClusterId,
  apptusEsalesMarket,
});

const addressMapper = new AddressMapper();

const customerDao = new CustomerDao({ ctClient, graphql });
const customerMapper = new CustomerMapper({ addressMapper });

const customerService = new CustomerService({
  customerDao,
  customerMapper,
});
const customerController = new CustomerController({ customerService });

const customerRouter = new CustomerRouter({
  customerController,
  Router,
});

const defaultDao = new DefaultDao({ ctClient });
const shippingMapper = new ShippingMapper();
const inventoryMapper = new InventoryMapper();
const shippingService = new ShippingService({ shippingDao, shippingMapper });

const productMapper = new ProductMapper({ common, product });

const lineItemsMapper = new LineItemMapper({ common });

const shoppingListMapper = new ShoppingListMapper({ lineItemsMapper });

const defaultService = new DefaultService({ defaultDao });
const productService = new ProductService({
  productDao, magnoliaDao, shoppingListDao, productMapper, shippingService, common, inventoryMapper, inventoryDao,
});

const notifyService = new NotifyService({ notifyDao });

const shoppingListService = new ShoppingListService({ shoppingListDao, magnoliaDao, shoppingListMapper });

const cartsService = new CartsService({ cartsDao });

const notificationsService = new NotificationsService({ notificationsDao });

const defaultController = new DefaultController({ defaultService });

const productController = new ProductController({ productService });

const notifyController = new NotifyController({ notifyService });

const shoppingListController = new ShoppingListController({ shoppingListService });

const cartsController = new CartsController({ cartsService });

const notificationsController = new NotificationsController({ notificationsService });

const defaultRouter = new DefaultRouter({ defaultController, Router });

const productRouter = new ProductRouter({ productController, Router });

const notifyRouter = new NotifyRouter({ notifyController, Router });

const shoppingListRouter = new ShoppingListRouter({ shoppingListController, Router });

const cartsRouter = new CartsRouter({ Router, cartsController });

const notificationsRouter = new NotificationsRouter({ Router, notificationsController });

/* Start app */

const leapApp = new LeapApp(appConfig);
leapApp.bootstrap();
leapApp.mount('/', defaultRouter.buildExpressRouter());
leapApp.mount('/products', productRouter.buildExpressRouter());
leapApp.mount('/notify', notifyRouter.buildExpressRouter());
leapApp.mount('/wishlists', shoppingListRouter.buildExpressRouter());
leapApp.mount('/carts', cartsRouter.buildExpressRouter());
leapApp.mount('/notifications', notificationsRouter.buildExpressRouter());
leapApp.mount('/customers', customerRouter.buildExpressRouter());
leapApp.listen();
