const filecopy = require('filecopy');
const fs = require('fs');
const path = require('path');
/**
 * Deep copy directory. Can copy files. Supports only exact directory or file names, no * matching.
 * @param src - Source directory or file
 * @param dist
 * @param log
 * @return {Promise<void>}
 */
const deepCopy = async (src, dist, log = false) => {
  console.log(`Copying ${path.relative(`${__dirname}/..`, src)}`);
  const lstat = fs.lstatSync(src);
  if (lstat.isDirectory()) {
    fs.mkdirSync(dist, { recursive: true });
  } else if (lstat.isFile()) {
    return filecopy(src, dist);
  } else {
    throw new Error(`copy-files.js can't handle node "${src}" with lstat: ${JSON.stringify(lstat)}`);
  }

  return Promise.all(
    fs.readdirSync(src).map((dir) =>
      deepCopy(`${src}/${dir}`, `${dist}/${dir}`)),
  );
};
Promise
  .all([
    deepCopy(`${__dirname}/../src/graphql`, `${__dirname}/../dist/src/graphql`, true),
    deepCopy(`${__dirname}/../src/locale`, `${__dirname}/../dist/src/locale`, true),
  ])
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });
