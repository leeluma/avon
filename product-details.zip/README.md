# leap-bff-product-details

This service implements APIs for to Product detail component.

# Repo Owner

HCL

# Installation

```shell
npm install
npm run build
```

Configure the `.env` file according to the sample below in this readme.

```shell
npm start
```

# Sample .env file

```
NODE_ENV=development
LOG_LEVEL=trace

CT_ACTIVE_MARKETS=["RO"]

CT_PROJECT_KEY_RO=avon-ro-v1
CT_CLIENT_ID_RO=<CT client id>
CT_CLIENT_SECRET_RO=<CT client secret>

CT_MAX_RETRIES=2
CT_RETRY_DELAY=300
CT_RETRY_MAX_DELAY=1000
CT_RETRY_ON_ABORT=true
CT_TIMEOUT=2000
CT_CONCURRENCY=20

CT_API_ENDPOINT=https://api.europe-west1.gcp.commercetools.com
CT_AUTH_ENDPOINT=https://auth.europe-west1.gcp.commercetools.com

MAGNOLIA_BASE_PATH=https://f376475d-0e63-4d20-8685-4afc8aa752a5.mock.pstmn.io/
PREVIEW_MAGNOLIA_BASE_PATH=https://f376475d-0e63-4d20-8685-4afc8aa752a5.mock.pstmn.io/
```

## Development Checklist

1. Update Swagger specs
2. Update Postman collection
3. Write Unit Test cases
4. Run stryker mutation testing
5. Write required validation
6. Run npm audit and see no security issues
7. All eslint issue mitigated
8. Write jsdoc comments on each method, class, constant etc.
9. API should not take more than 1.5 second
