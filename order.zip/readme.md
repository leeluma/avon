# leap-be-order

This service is used by other BFFs to provide add to cart feature. Home,PLP, Product Details and Cart BFF would be using this for add to cart.

# Repo Owner

HCL

# Installation

```shell
npm install
npm run build
```

Configure the `.env` file according to the sample below in this readme.

```shell
npm start
```

# Sample .env file

```
API_CONTEXT_PATH="order"
API_VERSION="v1"
API_PORT=3001

NODE_ENV=development
LOG_LEVEL=trace

CT_ACTIVE_MARKETS=["RO"]

CT_PROJECT_KEY_RO=avonshop-ct-ro-dev
CT_CLIENT_ID_RO=<CT client id>
CT_CLIENT_SECRET_RO=<CT client secret>

CT_MAX_RETRIES=2
CT_RETRY_DELAY=300
CT_RETRY_MAX_DELAY=1000
CT_RETRY_ON_ABORT=true
CT_TIMEOUT=2000
CT_CONCURRENCY=20

CT_API_ENDPOINT=https://api.europe-west1.gcp.commercetools.com
CT_AUTH_ENDPOINT=https://auth.europe-west1.gcp.commercetools.com
```

# Error handling

The `api-error` and `error-handler.middleware` will do most of the heavy lifting for you.

If a technical error happens (something that the client should not know about),
just throw an `Error(...)` in your controller/service/dao.

If there is an error that should inform the client about what went wrong,
then throw an `ApiError(...)`. The `ApiError` class requires two parameters.
The first parameter is the HTTP status code and the second parameter can be
an array of errors, or a single error (which will be automatically converted
into an array with a single element).

The `Error` will be converted into a generic 500 error and the message will be hidden from the client.

The `ApiError` will be forwarded to the client,
so **be careful what information you send to the client**.

`express-validator` errors are handled automatically.

### Error handling examples

- If anything goes wrong, this will be turned into a generic 500 error.

DAO code:

```typescript
db.query({ });
```

Output:

```json
{
    "statusCode": 500,
    "message": "Internal Server Error",
    "timestamp": "2021-12-21T08:35:14.697Z",
    "errors": [
        "Internal Server Error"
    ]
}
```

- If there is a validation error, it will be forwarded to the client.

Router code:

```typescript
express.Router()
  .post('/',
    validateAddToCart,
    validateRequestSchema,
    wrapJsonApiController(
        this.cartController.addProductToCart.bind(this.cartController),
    ))
```

Request:

```json
{
    "cartId":"",
    "lineItems": 
    {
        "productKey":"",
        "sku": "",
        "quantity":""
    }
}
```

Output:

```json
{
    "statusCode": 400,
    "message": "Bad Request",
    "timestamp": "2022-01-10T11:26:17.934Z",
    "errors": [
        {
            "value": "",
            "msg": "SKU code is mandatory",
            "param": "lineItems.sku",
            "location": "body"
        },
        {
            "value": "",
            "msg": "Line Item quantity is mandatory.",
            "param": "lineItems.quantity",
            "location": "body"
        }
    ]
}
```

- If an `ApiError` is thrown, it will be forwarded to the client.

Service code:

```typescript
if (lineItem.quantity > maxPurchasableQty) {
    throw new ApiError(
        HttpStatusCodes.NOT_FOUND,
        'Unable to add. Item per user restriction (maxPurchasableQty)',
    );
}
```

Output:

```json
{
    "statusCode": 404,
    "message": "Not Found",
    "timestamp": "2022-01-10T11:29:01.761Z",
    "errors": [
        {
            "message": "Unable to add. Item per user restriction (maxPurchasableQty)"
        }
    ]
}
```
