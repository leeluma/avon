import faker from '@faker-js/faker';

export const stubPriceFormatSettings = (
  config: Partial<any> = {},
): any => {
  return {
    ccy: 'RON',
    showDecimalZero: 'true',
    thousandSeperator: ',',
    noOfDigit: '2',
    currencyPlacement: 'before',
    decimalPoint: '.',
    isVatIncluded: 'true',
    vatIncludedMessage: 'Vat Included',
    baseMeasure: {
      '@name': faker.datatype.string(),
      '@path': faker.datatype.string(),
      '@id': faker.datatype.uuid(),
      '@nodeType': faker.datatype.string(),
      translation: 'mg',
      unitPriceBaseMeasure: '100 mg',
      containerSizeLimit: '10',
      '@nodes': [],
    },
    ...config,
  };
};
