import { Request, Response } from 'express';

export const stubExpressReq = (
  config: Partial<Request> = {},
): Request => {
  return {
    headers: {},
    body: {},
    params: {},
    query: {},
    ...config,
  } as any;
};

export const stubExpressRes = (
  config: Partial<Response> = {},
): Response => {
  const res: any = {
    statusCode: 999,
    headers: {},
    body: undefined,
    locals: {},

    status: (statusCode: number) => {
      res.statusCode = statusCode;
    },
    send: (body: any) => {
      res.body = body;
    },
  } as any;

  return { ...res, ...config };
};
