import faker from '@faker-js/faker';

export const stubCtProductGraphqlDto = (
  config = {},
): any => {
  return [
    {
      id: faker.datatype.uuid(),
      key: faker.datatype.string(),
      masterData: {
        current: {
          allVariants: [
            {
              sku: '1381950',
              attributesRaw: [
                {
                  name: 'maxPurchasableQty',
                  value: 10,
                },
                {
                  name: 'discontinued',
                  value: true,
                },
              ],
              availability: {
                channels: {
                  results: [
                    {
                      availability: {
                        availableQuantity: 5,
                        isOnStock: true,
                      },
                    },
                  ],
                },
              },
            },
          ],
        },
      },
    },
  ];
};
