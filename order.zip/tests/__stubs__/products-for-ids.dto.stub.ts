import faker from '@faker-js/faker';
import { Product } from '@commercetools/platform-sdk';

export const stubCtProductDto = (
  config: Partial<Product> = {},
): any => {
  return {
    id: faker.datatype.uuid(),
    key: faker.datatype.string(),
    masterData: {
      current: {
        categories: [
          {
            slug: faker.datatype.string(),
            name: faker.datatype.string(),
            key: faker.datatype.string(),
            description: faker.datatype.string(),
            custom: {
              customFieldsRaw: [
                {
                  name: faker.datatype.string(),
                  value: faker.datatype.string(),
                },
              ],
            },
          },
        ],
      },
    },
    ...config,
  };
};
