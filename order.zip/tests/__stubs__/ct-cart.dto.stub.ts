import faker from '@faker-js/faker';
import {
  ShippingInfo, ShippingAddressDto,
} from '../../src/dtos';

export const stubCtCartShippingInfo = (
  config: Partial<ShippingInfo> = {},
): ShippingInfo => {
  return {
    shippingMethodName: faker.datatype.string(),
    price: {
      type: faker.datatype.string(),
      currencyCode: faker.finance.currencyCode(),
      centAmount: faker.datatype.number(),
      fractionDigits: faker.datatype.number({
        min: 0,
        max: 2,
      }),
    },
    ...config,
  };
};

export const shippingAddressDto = (): ShippingAddressDto => {
  return {
    address1: faker.datatype.string(),
    address2: faker.datatype.string(),
    postalCode: faker.datatype.string(),
    city: faker.datatype.string(),
    county: faker.datatype.string(),
    phoneNumber: faker.datatype.string(),
  };
};

export const shippingAddressCtRes = () => {
  return {
    postalCode: faker.datatype.string(),
    city: faker.datatype.string(),
    phone: faker.datatype.string(),
    county: faker.datatype.string(),
    custom: {
      fields: {
        Address1: faker.datatype.string(),
        Address2: faker.datatype.string(),
        county: faker.datatype.string(),
      },
    },
  };
};
