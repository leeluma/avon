import { Request, Response } from 'express';
import { MarketInfo } from '../../src/middlewares';
import {
  stubMarket, stubExpressReq, stubExpressRes, stubCtCartDto, stubCartAddProductToCartDto, stubMagnoliaInfo,
} from '../__stubs__';
import { CartController } from '../../src/controllers';
import { CartService } from '../../src/services';

import Mock = jest.Mock;
import { CartDto, CartAddProductToCartDto } from '../../src/dtos';

describe('LeapApp', () => {
  /* System Under Test */
  let cartController: CartController;

  /* Dependencies */
  let cartService: CartService;
  let market: MarketInfo;

  /* Stubs */
  let req: Request;
  let res: Response;

  beforeEach(() => {
    market = stubMarket();

    /* Stubs */
    req = stubExpressReq();
    res = stubExpressRes({ locals: { market } });

    /* Dependencies */
    cartService = {} as any;

    /* SUT */
    cartController = new CartController({ cartService });
  });

  describe('addProductToCart()', () => {
    let cartAddProductToCartDto: CartAddProductToCartDto;
    let cartDto: CartDto;
    beforeEach(() => {
      cartService.addProductToCartBySku = jest.fn();
      cartAddProductToCartDto = stubCartAddProductToCartDto();
      cartDto = stubCtCartDto();
      const { customerId, cartId, lineItems } = cartAddProductToCartDto;
      req.body.customerId = customerId;
      req.body.cartId = cartId;
      req.body.lineItems = lineItems;
    });
    test('reads all the data from the request body', async () => {
      /* Prepare */
      (cartService.addProductToCartBySku as Mock).mockReturnValueOnce(cartDto);
      /* Execute */
      await cartController.addProductToCart(req, res);

      /* Verify */
      expect(cartService.addProductToCartBySku).toHaveBeenCalledTimes(1);
    });

    test('returns result from cartService.addProductToCartBySku in JsonResponseEntity format', async () => {
      /* Prepare */
      (cartService as any).addProductToCartBySku = jest.fn().mockReturnValueOnce(cartDto);
      /* Execute */
      const result = await cartController.addProductToCart(req, res);

      /* Verify */
      expect(result).toEqual({
        statusCode: 200,
        body: cartDto,
      });
    });
  });
});
