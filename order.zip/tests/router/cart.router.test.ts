import { Router } from 'express';
import { CartRouter } from '../../src/routers';
import { CartController } from '../../src/controllers';
import { validateAddToCart } from '../../src/validators';
import { validateRequestSchema } from '../../src/middlewares';
import { magnoliaUrlMiddleware } from '../../src/middlewares/magnolia-url.middleware';

jest.mock('express-validator', () =>
  jest.requireActual('../__mocks__/express-validator.mock').default);

describe('CartRouter', () => {
  let cartController: CartController;
  let cartRouter: CartRouter;
  let mockRouter: Router;

  beforeEach(() => {
    cartController = {
      addProductToCart: jest.fn(),
    } as any;

    mockRouter = {
      post: jest.fn(() => mockRouter),
    } as any;

    cartRouter = new CartRouter({
      cartController,
      Router: () => mockRouter,
    });
  });

  describe('buildExpressRouter()', () => {
    test('returns the express router', () => {
      const response = cartRouter.buildExpressRouter();
      expect(response).toBe(mockRouter);
    });

    test('mounts the expected number of routes', () => {
      cartRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenCalledTimes(1);
    });

    test('configures the POST / route', () => {
      cartRouter.buildExpressRouter();
      expect(mockRouter.post).toHaveBeenNthCalledWith(1,
        '/',
        validateAddToCart,
        validateRequestSchema,
        magnoliaUrlMiddleware,
        expect.any(Function));
    });
  });
});
