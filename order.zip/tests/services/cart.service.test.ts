import faker from '@faker-js/faker';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import currencyCode from '../../src/common/currency';
import { MarketInfo } from '../../src/middlewares';
import { CartMapper } from '../../src/mappers';
import MagnoliaDao from '../../src/daos/magnolia.dao';
import {
  stubMarket, stubCartFoundDto,
  stubCartFoundDto3,
  stubCtProductGraphqlDto,
  stubMagnoliaInfo,
  stubCtCartDto,
} from '../__stubs__';
import { CartDao, ProductDao } from '../../src/daos';
import { MagnoliaInfo } from '../../src/dtos/common.dto';
import { CartService } from '../../src/services';
import Mock = jest.Mock;
import {
  CartFoundDto,
} from '../../src/dtos';
import { ApiError } from '../../src/lib';
import { stubPriceFormatSettings } from '../__stubs__/magnolia-settings.stub';

describe('LeapApp', () => {
  /* System Under Test */
  let cartService: CartService;

  /* Dependencies */
  let cartDao: CartDao;
  let cartMapper: CartMapper;
  let market: MarketInfo;
  let magnoliaInfo: MagnoliaInfo;
  let productDao: ProductDao;
  let variantAttributes: any;
  let magnoliaResponse: any;
  let magnoliaDao: MagnoliaDao;
  beforeEach(() => {
    market = stubMarket();
    magnoliaInfo = stubMagnoliaInfo();
    magnoliaDao = {} as any;
    variantAttributes = {
      maxPurchasableQty: faker.datatype.number(),
      discontinued: false,
    };
    magnoliaResponse = {
      '@name': magnoliaDao,
      '@path': '/ro/settings/warehouseSettings',
      '@id': 'ad6c21e6-d8d3-46c8-8435-8c5cf45c7f0c',
      '@nodeType': 'mgnl:contentNode',
      isSingleWarehouse: 'true',
      defaultWarehouse: 'DC-RO',
      '@nodes': [],
    };
    /* Dependencies */
    cartDao = { getCartPaymentInfo: jest.fn(), getCartProductIds: jest.fn() } as any;
    productDao = { getProductBySKU: jest.fn(), fetchProductsDetail: jest.fn() } as any;
    cartMapper = { cartToDto: jest.fn(), getProductAttributes: jest.fn() } as any;
    magnoliaDao.getDefaultWarehouse = jest.fn();
    magnoliaDao.getPriceFormatSettings = jest.fn();
    /* SUT */
    cartService = new CartService({
      cartMapper, cartDao, productDao, magnoliaDao,
    });
  });

  // TODO
  describe('addProductToCartBySku()', () => {
    let customerId : string;
    let anonymousId : string;
    let cartId : string;
    let sku: string;
    let quantity:number;
    let productKey: string;
    let lineItems : any;
    let cartFoundDto: CartFoundDto;
    let cartFoundDto3: CartFoundDto;
    let createCartDto: any;
    let skuFoundStub;
    beforeEach(() => {
      cartDao.getCartById = jest.fn();
      cartDao.addProductToCartBySku = jest.fn();
      cartMapper.cartToDto = jest.fn();
      cartDao.createCart = jest.fn();
      cartFoundDto = stubCartFoundDto();
      cartFoundDto3 = stubCartFoundDto3();
      skuFoundStub = stubCtProductGraphqlDto();
      createCartDto = {
        body: { cartFoundDto },
        statusCode: 201,
      };
    });

    test('adds the product to cart', async () => {
      /* Prepare */
      let currency;
      const channelKey = faker.datatype.string();
      if (market.country in currencyCode) {
        currency = currencyCode[market.country];
      }
      (cartDao.getCartPaymentInfo as Mock).mockReturnValue({});
      (cartDao.getCartById as Mock).mockReturnValue(cartFoundDto);
      (cartMapper.getProductAttributes as Mock).mockReturnValueOnce(variantAttributes);
      (cartDao.addProductToCartBySku as Mock).mockReturnValue(createCartDto);
      (magnoliaDao.getPriceFormatSettings as Mock).mockReturnValueOnce(stubPriceFormatSettings);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartFoundDto);
      cartId = '1fc2b587-eec7-4228-9575-fd30d8907d49';
      sku = '106826-9161866660405752377';
      quantity = 1;
      productKey = '106826';
      lineItems = { sku, quantity };
      /* Execute */
      const response = await cartService.addProductToCartBySku(
        market,
        customerId,
        anonymousId,
        cartId,
        lineItems,
        magnoliaInfo,
        channelKey,
      );

      /* Verify */
      expect(response).toBe(cartFoundDto);
    });

    test('adds the product to cart (maxpurchasable and available quantiy 0)', async () => {
      const channelKey = faker.datatype.string();
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValue({});
      (cartDao.getCartById as Mock).mockReturnValue(cartFoundDto3);
      (cartMapper.getProductAttributes as Mock).mockReturnValueOnce(variantAttributes);
      (cartDao.addProductToCartBySku as Mock).mockReturnValue(createCartDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartFoundDto3);
      cartId = '1fc2b587-eec7-4228-9575-fd30d8907d49';
      sku = '106826-9161866660405752377';
      quantity = 1;
      productKey = '106826';
      lineItems = { sku, quantity };
      /* Execute */
      const response = await cartService.addProductToCartBySku(
        market,
        customerId,
        anonymousId,
        cartId,
        lineItems,
        magnoliaInfo,
        channelKey,
      );

      /* Verify */
      expect(response).toBe(cartFoundDto3);
    });

    test('creates a new cart if cart id is not provided', async () => {
      /* Prepare */
      (productDao.getProductBySKU as Mock).mockReturnValue(skuFoundStub);
      (cartMapper.getProductAttributes as Mock).mockReturnValueOnce(variantAttributes);
      (cartDao.createCart as Mock).mockReturnValue(createCartDto);
      (cartMapper.cartToDto as Mock).mockReturnValueOnce(cartFoundDto);
      (magnoliaDao.getDefaultWarehouse as Mock).mockReturnValueOnce(magnoliaResponse);
      cartId = '';
      quantity = 1;
      sku = faker.datatype.string();
      lineItems = { sku, quantity };
      /* Execute */
      const response = await cartService.addProductToCartBySku(
        market,
        customerId,
        anonymousId,
        cartId,
        lineItems,
        magnoliaInfo,
        undefined,
      );

      /* Verify */
      expect(magnoliaDao.getDefaultWarehouse).toHaveBeenCalledTimes(1);
      expect(response).toBe(cartFoundDto);
    });

    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      cartId = faker.datatype.uuid();
      const channelKey = faker.datatype.string();
      (cartDao.getCartPaymentInfo as Mock).mockReturnValue({ isPaymentInitiated: false, cart: undefined });
      (cartDao.addProductToCartBySku as Mock).mockReturnValueOnce(undefined);
      (cartDao.getCartById as Mock).mockReturnValueOnce(undefined);

      const expectedError = new ApiError(
        HttpStatusCodes.NOT_FOUND,
        i18next.t('error.cartNotFound'),
      );

      /* Execute */
      await expect(() => cartService.addProductToCartBySku(
        market,
        customerId,
        anonymousId,
        cartId,
        lineItems,
        magnoliaInfo,
        channelKey,
      ))
        .rejects.toThrow(expectedError);

      /* Verify */
      expect(cartDao.addProductToCartBySku).not.toHaveBeenCalled();
      expect(cartMapper.cartToDto).not.toHaveBeenCalled();
    });

    test('returns undefined for discontinued', async () => {
      /* Prepare */
      cartId = '';
      const channelKey = faker.datatype.string();
      (productDao.getProductBySKU as Mock).mockReturnValue(skuFoundStub);
      (cartDao.addProductToCartBySku as Mock).mockReturnValueOnce(undefined);
      variantAttributes.discontinued = true;
      lineItems.sku = skuFoundStub[0].masterData.current.allVariants[0].sku;
      (cartMapper.getProductAttributes as Mock).mockReturnValueOnce(variantAttributes);

      const expectedError = new ApiError(
        HttpStatusCodes.BAD_REQUEST,
        i18next.t('error.productDiscontinued'),
      );

      /* Execute */
      await expect(() => cartService.addProductToCartBySku(
        market,
        customerId,
        anonymousId,
        cartId,
        lineItems,
        magnoliaInfo,
        channelKey,
      ))
        .rejects.toThrow(expectedError);
    });

    test('returns undefined for isOnStock', async () => {
      /* Prepare */
      cartId = '';
      const channelKey = faker.datatype.string();
      (productDao.getProductBySKU as Mock).mockReturnValue(skuFoundStub);
      (cartDao.addProductToCartBySku as Mock).mockReturnValueOnce(undefined);
      lineItems.sku = skuFoundStub[0].masterData.current.allVariants[0].sku;
      skuFoundStub[0].masterData.current.allVariants[0].availability.channels.results[0].availability.isOnStock = false;
      (cartMapper.getProductAttributes as Mock).mockReturnValueOnce(variantAttributes);

      const expectedError = new ApiError(
        HttpStatusCodes.BAD_REQUEST,
        i18next.t('error.outOfStock'),
      );

      /* Execute */
      await expect(() => cartService.addProductToCartBySku(
        market,
        customerId,
        anonymousId,
        cartId,
        lineItems,
        magnoliaInfo,
        channelKey,
      ))
        .rejects.toThrow(expectedError);
    });

    test('check greaterThanMaxPurchasableQtyAndAvailableQuantity', async () => {
      /* Prepare */
      cartId = '';
      const channelKey = faker.datatype.string();
      (productDao.getProductBySKU as Mock).mockReturnValue(skuFoundStub);
      (cartDao.addProductToCartBySku as Mock).mockReturnValueOnce(undefined);
      lineItems.sku = skuFoundStub[0].masterData.current.allVariants[0].sku;
      lineItems.quantity = 10;
      variantAttributes.maxPurchasableQty = 2;
      (cartMapper.getProductAttributes as Mock).mockReturnValueOnce(variantAttributes);

      const expectedError = new ApiError(
        HttpStatusCodes.BAD_REQUEST,
        i18next.t('error.greaterThanMaxPurchasableQtyAndAvailableQuantity'),
      );

      /* Execute */
      await expect(() => cartService.addProductToCartBySku(
        market,
        customerId,
        anonymousId,
        cartId,
        lineItems,
        magnoliaInfo,
        channelKey,
      ))
        .rejects.toThrow(expectedError);
    });

    test('check greaterThanMaxPurchasableQty', async () => {
      /* Prepare */
      cartId = '';
      const channelKey = faker.datatype.string();
      (productDao.getProductBySKU as Mock).mockReturnValue(skuFoundStub);
      (cartDao.addProductToCartBySku as Mock).mockReturnValueOnce(undefined);
      lineItems.sku = skuFoundStub[0].masterData.current.allVariants[0].sku;
      lineItems.quantity = 4;
      variantAttributes.maxPurchasableQty = 2;
      (cartMapper.getProductAttributes as Mock).mockReturnValueOnce(variantAttributes);

      const expectedError = new ApiError(
        HttpStatusCodes.BAD_REQUEST,
        i18next.t('error.greaterThanMaxPurchasableQty'),
      );

      /* Execute */
      await expect(() => cartService.addProductToCartBySku(
        market,
        customerId,
        anonymousId,
        cartId,
        lineItems,
        magnoliaInfo,
        channelKey,
      ))
        .rejects.toThrow(expectedError);
    });

    test('skuNotFound', async () => {
      /* Prepare */
      cartId = '';
      const channelKey = faker.datatype.string();
      (productDao.getProductBySKU as Mock).mockReturnValue([]);
      (cartDao.addProductToCartBySku as Mock).mockReturnValueOnce(undefined);
      lineItems.sku = skuFoundStub[0].masterData.current.allVariants[0].sku;
      lineItems.quantity = 4;
      variantAttributes.maxPurchasableQty = 2;
      (cartMapper.getProductAttributes as Mock).mockReturnValueOnce(variantAttributes);

      const expectedError = new ApiError(
        HttpStatusCodes.NOT_FOUND,
        i18next.t('error.skuNotFound'),
      );

      /* Execute */
      await expect(() => cartService.addProductToCartBySku(
        market,
        customerId,
        anonymousId,
        cartId,
        lineItems,
        magnoliaInfo,
        channelKey,
      ))
        .rejects.toThrow(expectedError);
    });
  });

  test('checkProductDetails', () => {
    /* Prepare */
    const lineItemAvailability = { availableQuantity: 3 };
    const quantity = 5;
    const quantityAlreadyInCart = 0;
    /* Verify */
    const expectedError = new ApiError(
      HttpStatusCodes.BAD_REQUEST,
      i18next.t('error.addedGreaterThanAvailability'),
    );

    /* Execute */
    expect(() => (cartService as any).checkProductDetails(
      lineItemAvailability,
      variantAttributes,
      quantity,
      quantityAlreadyInCart,
    ))
      .toThrow(expectedError);
  });

  test('checkProductDetails for discontinued true', () => {
    /* Prepare */
    const lineItemAvailability = { availableQuantity: 3 };
    const quantity = 5;
    const quantityAlreadyInCart = 0;
    const tempVariantAttributes = {
      discontinued: null,
      maxPurchasableQty: null,
    };
    /* Verify */
    const expectedError = new ApiError(
      HttpStatusCodes.BAD_REQUEST,
      i18next.t('error.productDiscontinued'),
    );

    /* Execute */
    expect(() => (cartService as any).checkProductDetails(
      lineItemAvailability,
      tempVariantAttributes,
      quantity,
      quantityAlreadyInCart,
    ))
      .toThrow(expectedError);
  });

  describe('getCartPaymentInfo()', () => {
    let cartDto;
    let cartId: string;
    let stubCartWithPaymentInfo;
    let paymentInfo;

    beforeEach(() => {
      cartId = faker.datatype.uuid();
      cartDao.getCartPaymentInfo = jest.fn();
      cartDao.replicateCartById = jest.fn();
      cartDto = stubCtCartDto();
      paymentInfo = {
        paymentInfo: {
          payments: [{
            paymentStatus: {
              state: {
                name: 'Initial',
              },
            },
          }],
        },
      };
      stubCartWithPaymentInfo = {
        ...cartDto,
        paymentInfo,
      };
    });

    test('fetches data from cartDao', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(paymentInfo);
      (cartDao.replicateCartById as Mock).mockReturnValueOnce(stubCartWithPaymentInfo);

      /* Execute */
      const result = await cartService.checkCartPaymentInfo(market, cartId);

      /* Verify */
      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(cartDao.getCartPaymentInfo).toHaveBeenNthCalledWith(
        1,
        market,
        cartId,
      );
      expect(cartDao.replicateCartById).toHaveBeenCalledTimes(1);
      expect(result.isPaymentInitiated).toBe(true);
      expect(result.cart).toBe(stubCartWithPaymentInfo);
    });

    test('returns isPaymentInitiated false', async () => {
      /* Prepare */
      const cartPaymentInfo = {
        paymentInfo: {
          payments: [{
            paymentStatus: {
              state: {
                name: null,
              },
            },
          }],
        },
      };
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfo);

      /* Execute */
      const result = await cartService.checkCartPaymentInfo(market, cartId);

      /* Verify */
      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(result.isPaymentInitiated).toBe(false);
      expect(cartDao.replicateCartById).not.toHaveBeenCalled();
    });

    test('returns isPaymentInitiated false if does not match payments', async () => {
      /* Prepare */
      const cartPaymentInfo = {
        paymentInfo: {
          payments: [],
        },
      };
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(cartPaymentInfo);

      /* Execute */
      const result = await cartService.checkCartPaymentInfo(market, cartId);

      /* Verify */
      expect(cartDao.getCartPaymentInfo).toHaveBeenCalledTimes(1);
      expect(result.isPaymentInitiated).toBe(false);
      expect(cartDao.replicateCartById).not.toHaveBeenCalled();
    });

    test('returns undefined if the cart does not exist', async () => {
      /* Prepare */
      (cartDao.getCartPaymentInfo as Mock).mockReturnValueOnce(undefined);
      const expectedError = new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartIdNotFound', { cartId }));
      /* Execute */
      await expect(() => cartService.checkCartPaymentInfo(market, cartId))
        .rejects.toThrow(expectedError);

      /* Verify */
      expect(cartDao.replicateCartById).not.toHaveBeenCalled();
    });
  });
});
