import currency from 'currency.js';
import faker from '@faker-js/faker';
import i18next from 'i18next';
import { CartMapper } from '../../src/mappers/cart.mapper';
import {
  stubCartServiceToMapper,
  stubCartMapperResult,
  stubCartServiceToMapper1,
  stubCartServiceToMapper2,
  stubCartServiceToMapper8,
  stubCartServiceToMapper9,
  stubCtCartShippingInfo,
  shippingAddressCtRes,
  stubPriceFormatSettings,
  stubMarket,
} from '../__stubs__';
import { CartDto, ShippingInfo } from '../../src/dtos/cart.dto';
import { ApiError } from '../../src/lib';
import { MarketInfo } from '../../src/middlewares';

describe('CartMapper', () => {
  let cartMapper: CartMapper;
  let cart:any;
  let cartExpected:CartDto;
  let cart1:any;
  let cart2:any;
  let market: MarketInfo;

  beforeEach(() => {
    cartMapper = new CartMapper();
    cart = stubCartServiceToMapper();
    cartExpected = stubCartMapperResult();
    cart1 = stubCartServiceToMapper1();
    cart2 = stubCartServiceToMapper2();
    market = stubMarket();
  });

  test('cartToDto', () => {
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart, 'ro', stubPriceFormatSettings(), undefined);

    /* Verify */
    expect(result).toMatchObject(cartExpected);
  });

  test('cartToDto with empty shipping address', () => {
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart, 'ro', stubPriceFormatSettings(), undefined);

    /* Verify */
    expect(result).toMatchObject(cartExpected);
  });

  test('getProductAttributes()', () => {
    /* Execute */
    const result = (cartMapper as CartMapper).getProductAttributes([
      { name: 'maxPurchasableQty', value: 1 },
      { name: 'discontinued', value: true }]);
    const result1 = (cartMapper as CartMapper).getProductAttributes([
      { name: 'maxPurchasableQty', value: { key: true, label: 1 } },
      { name: 'discontinued', value: { key: true, label: true } },
    ]);
    const result2 = (cartMapper as CartMapper).getProductAttributes([{
      name: 'brandId',
      value: '535',
    }]);
    /* Verify */
    expect(result).toMatchObject({ maxPurchasableQty: 1, discontinued: true });
    expect(result1).toMatchObject({ maxPurchasableQty: 1, discontinued: true });
    expect(result2).toStrictEqual({});
  });

  test('cartToDto for maxPurchasableQty undefined', () => {
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart1, 'ro', stubPriceFormatSettings());

    /* Verify */
    expect(result.lineItems[0].maxPurchasableQty).toBe(9999999);
  });

  test('cartToDto for availableQuantity undefined', () => {
    /* Execute */

    const result = (cartMapper as CartMapper).cartToDto(cart2, 'ro', stubPriceFormatSettings());

    /* Verify */
    expect(result.lineItems[0].availableQuantity).toBe(9999999);
  });

  test('cart mapper with no lineItems', () => {
    const cart8 = stubCartServiceToMapper8();
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart8, 'ro', stubPriceFormatSettings());

    /* Verify */
    expect(result.lineItems.length).toBe(0);
  });

  test('cart mapper discount DoesNotMatchCart', () => {
    const cart9 = stubCartServiceToMapper9();
    /* Execute */
    const result = (cartMapper as CartMapper).cartToDto(cart9, 'ro', stubPriceFormatSettings());

    /* Verify */
    expect(result.promotion?.promotionState).toBe('DoesNotMatchCart');
  });

  test('getCartProductId mapper', () => {
    /* Prepare */
    const cartData = {
      id: faker.datatype.uuid(),
      lineItems: [{
        lineItemId: faker.datatype.string(),
        productId: faker.datatype.string(),
      }],
    };
    const productIdExpected = `"${cartData.lineItems[0].productId}"`;
    /* Execute */
    const result = cartMapper.getCartProductId(cartData.lineItems as any);

    /* Verify */
    expect(result).toBe(productIdExpected);
  });

  test('checkDiscount mapper', () => {
    /* Setup */
    const price = {
      id: faker.datatype.uuid(),
      value: {
        type: 'centPrecision',
        currencyCode: 'RON',
        centAmount: faker.datatype.number(),
        fractionDigits: 2,
      },
      discounted: {
        value: {
          type: 'centPrecision',
          currencyCode: 'RON',
          centAmount: faker.datatype.number(),
          fractionDigits: 2,
        },
        discount: {
          typeId: faker.datatype.string(),
          id: faker.datatype.uuid(),
        },
      },
    };
    const expectedRes = true;
    /* Execute */
    const result = (cartMapper as any).checkDiscount(price);

    /* Verify */
    expect(result.isPromotionApplied).toBe(expectedRes);
  });
  test('shippingAddressToDto mapper', () => {
    /* Prepare */
    const shippingAddressRes = shippingAddressCtRes();
    const shippingAddressExpected = {
      address1: shippingAddressRes.custom.fields.Address1,
      address2: shippingAddressRes.custom.fields.Address2,
      county: shippingAddressRes.custom.fields.county,
      city: shippingAddressRes.city,
      phoneNumber: shippingAddressRes.phone,
      postalCode: shippingAddressRes.postalCode,
    };
    /* Execute */
    const result = (cartMapper as any).shippingAddressToDto(shippingAddressRes);

    /* Verify */
    expect(result).toMatchObject(shippingAddressExpected);
  });

  test('shippingAddressToDto mapper having no address details', () => {
    /* Prepare */
    const shippingAddressDetails = {};
    const shippingAddressExpected = {
      address1: '',
      address2: '',
      postalCode: '',
      city: '',
      county: '',
      phoneNumber: '',
    };
    /* Execute */
    const result = (cartMapper as any).shippingAddressToDto(shippingAddressDetails);

    /* Verify */
    expect(result).toMatchObject(shippingAddressExpected);
  });

  test('lineItemsToDto lineItemVariantAttributesNotDefined', () => {
    /* Prepare */
    const cartData = {
      id: faker.datatype.uuid(),
      lineItems: [{
        lineItemId: faker.datatype.string(),
        productId: faker.datatype.string(),
      }],
    };
    /* Verify */
    const expectedError = new ApiError(400, i18next.t('error.lineItemVariantAttributesNotDefined'));

    /* Execute */
    expect(() => (cartMapper as any).lineItemsToDto(cartData.lineItems as any, market.locale, {}))
      .toThrow(expectedError);
  });

  test('getVatText()', () => {
    /* Prepare */
    const priceFormat = {
      vatIncludedMessage: 'test',
      isVatIncluded: 'true',
    };
    /* Execute */
    const result = (cartMapper as any).getVatText(priceFormat);

    /* Verify */
    expect(result).toEqual('test');
  });

  test('getVatText() for false scenario', () => {
    /* Execute */
    const result = (cartMapper as any).getVatText({});

    /* Verify */
    expect(result).toEqual('');
  });
});
