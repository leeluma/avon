import i18next from 'i18next';
import faker from 'faker';
import { MarketInfo } from '../../src/middlewares';
import { stubMarket, stubCtProductDto } from '../__stubs__';
import Mock = jest.Mock;
import { ProductDao } from '../../src/daos';
import { stubCtClient } from '../__stubs__/ct-client.stub';
import { ApiError, CtClient } from '../../src/lib';
import { GRAPHQL_QUERY } from '../../src/common/constants';
import { graphql } from '../../src/graphql';

describe('ProductDao', () => {
  let productDao: ProductDao;
  let ctClient: CtClient;
  let market: MarketInfo;
  let post: Mock;
  let withId: Mock;
  let get: Mock;
  let execute: Mock;
  let sku;
  let multiProductDto;

  beforeEach(() => {
    market = stubMarket();
    sku = faker.datatype.string();
    multiProductDto = stubCtProductDto();
    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    ctClient = stubCtClient(market.country, {
      carts: jest.fn().mockReturnValueOnce({ withId, post }),
      graphql: jest.fn().mockReturnValueOnce({ get, post }),
    });

    productDao = new ProductDao({ ctClient, graphql });
  });

  // TODO
  describe('getProductBySKU()', () => {
    test('get data from shipping method by graphql query', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });
      /* Execute */
      await productDao.getProductBySKU(market, sku);
      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        {
          body: {
            query: GRAPHQL_QUERY.getProduct.replace('{{sku}}', sku),
          },
        },
      );
    });
    test('getProductBySKU() re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);
      /* Execute */
      const result = expect(() => productDao.getProductBySKU(market, sku));
      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  /**
   * Unit test case for fetchProduct function of product.dao
   */
  describe('fetchProductsDetail()', () => {
    let condition;
    let ctResponse: any;
    beforeEach(() => {
      multiProductDto = stubCtProductDto({ id: faker.datatype.uuid() });
      condition = `id in ("${multiProductDto.id}")`;
      ctResponse = {
        body: {
          data: {
            products: {
              results: [multiProductDto],
            },
          },
        },
      };
    });

    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      const expectedBody = {
        query: await graphql.getProducts,
        variables: {
          where: condition,
          locale: market.locale,
        },
      };
      execute.mockReturnValueOnce(ctResponse);

      /* Execute */
      await productDao.fetchProductsDetail(market, `"${multiProductDto.id}"`);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: expectedBody },
      );
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await productDao.fetchProductsDetail(market, multiProductDto.id);

      expect(result).toBe(ctResponse.body.data.products.results);
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {
        data: null,
        errors: ['msg'],
      };
      execute.mockRejectedValueOnce(err);

      const result = productDao.fetchProductsDetail(market, multiProductDto.id);

      await expect(result).rejects.toThrow(err);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);
      /* Execute */
      const result = expect(() => productDao.fetchProductsDetail(market, multiProductDto.id));

      /* Verify */
      await result.rejects.toThrow(isError);
    });

    test('re-throws ApiError ctClient errors', async () => {
      /* Prepare */
      const errBody = {
        body: {
          data: null,
          errors: ['msg'],
        },
      };

      execute.mockReturnValueOnce(errBody);
      /* Execute */
      const call = () => productDao.fetchProductsDetail(market, multiProductDto.id);

      /* Verify */
      await expect(call).rejects.toThrow(
        new ApiError(400, i18next.t('error.inventoryInvalidUuid')),
      );
    });

    test('returns the result undefined', async () => {
      const errBody = {
        body: {
          data: null,
        },
      };
      execute.mockReturnValueOnce(errBody);

      const result = await productDao.fetchProductsDetail(market, multiProductDto.id);

      expect(result).toBe(undefined);
    });
  });
});
