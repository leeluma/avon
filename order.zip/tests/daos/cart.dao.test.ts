import faker from 'faker';
import i18next from 'i18next';
import { MarketInfo } from '../../src/middlewares';
import { graphql } from '../../src/graphql';
import { stubCtCartDto, stubMarket } from '../__stubs__';
import Mock = jest.Mock;
import { CartDao, createCartDraft } from '../../src/daos';
import { stubCtClient } from '../__stubs__/ct-client.stub';
import { CartDto } from '../../src/dtos';
import { CtClient, ApiError } from '../../src/lib';
import { GRAPHQL_QUERY } from '../../src/common/constants';

describe('CartDao', () => {
  let cartDao: CartDao;
  let cartDto: CartDto;
  let ctClient: CtClient;
  let market: MarketInfo;
  let post: Mock;
  let withId: Mock;
  let get: Mock;
  let execute: Mock;
  let replicate: Mock;
  let gql: typeof graphql;

  beforeEach(() => {
    market = stubMarket();

    cartDto = stubCtCartDto();

    execute = jest.fn();
    get = jest.fn().mockReturnValueOnce({ execute });
    post = jest.fn().mockReturnValueOnce({ execute });
    withId = jest.fn().mockReturnValueOnce({ get, post });
    replicate = jest.fn().mockReturnValueOnce({ post });
    ctClient = stubCtClient(market.country, {
      carts: jest.fn().mockReturnValueOnce({ withId, post, replicate }),
      graphql: jest.fn().mockReturnValueOnce({ get, post }),
    });

    gql = {
      getCartDetails: Promise.resolve('query () { cart {} }'),
      getProducts: Promise.resolve('query () { products {} }'),
    };
    cartDao = new CartDao({ ctClient, graphql: gql });
  });

  describe('createCart()', () => {
    test('queries CommerceTools Client with the cartDraft', async () => {
      /* Prepare */
      const { anonymousId, customerId, lineItems } = cartDto;
      const currency = 'RON';
      const { country } = market;
      const cartData = {
        customerId,
        lineItems,
      };
      const cartDraft = createCartDraft(currency, cartData as any);
      execute.mockReturnValueOnce({ body: undefined });
      /* Execute */
      await cartDao.createCart(market.country, currency, lineItems as any, customerId);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1,
        {
          body: cartDraft,
          queryArgs: {
            expand: ['lineItems[*].discountedPricePerQuantity[*].discountedPrice.includedDiscounts[*].discount',
              'discountCodes[*].discountCode.id'],
          },

        });
    });

    test('Cart with the cartDraft for anonymousId', async () => {
      /* Prepare */
      const { anonymousId, customerId, lineItems } = cartDto;
      const currency = 'RON';
      const { country } = market;
      const cartData = {
        country,
        currency,
        anonymousId,
        lineItems,
      };
      const cartDraft = createCartDraft(currency, cartData as any);
      execute.mockReturnValueOnce({ body: undefined });
      /* Execute */
      await cartDao.createCart(market.country, currency, lineItems as any, undefined, anonymousId);

      /* Verify */
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1,
        {
          body: cartDraft,
          queryArgs: {
            expand: ['lineItems[*].discountedPricePerQuantity[*].discountedPrice.includedDiscounts[*].discount',
              'discountCodes[*].discountCode.id'],
          },
        });
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      const { anonymousId, customerId, lineItems } = cartDto;
      const currency = 'RON';
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.createCart(market.country, currency, lineItems as any, customerId);
      /* Verify */
      expect(result).toBe(cartDto);
    });
  });

  describe('getCartById()', () => {
    let ctResponse: any;
    const cartId = faker.datatype.uuid();
    beforeEach(() => {
      ctResponse = {
        body: {
          data: {
            cart: {
              ...cartDto,
            },
          },
        },
      };
    });

    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      const locale = market.locale.toLocaleUpperCase();
      const expectedBody = {
        query: 'query () { cart {} }',
        variables: {
          cartId,
          locale,
        },
      };
      execute.mockReturnValueOnce(ctResponse);

      /* Execute */
      await cartDao.getCartById(market, cartId);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        { body: expectedBody },
      );
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await cartDao.getCartById(market, cartId);

      expect(result).toBe(ctResponse.body.data.cart);
    });

    test('returns the result data NULL from the GraphQL server', async () => {
      const ctResponses = {
        body: {
          data: null,
          errors: {
            error: 'Malformed parameter: UUID string is invalid',
          },
        },
      };
      execute.mockReturnValueOnce(ctResponses);

      const result = await cartDao.getCartById(market, cartId);

      expect(result).toBeUndefined();
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {};
      execute.mockRejectedValueOnce(err);

      const result = cartDao.getCartById(market, cartId);

      await expect(result).rejects.toThrow(err);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);
      /* Execute */
      const result = expect(() => cartDao.getCartById(market, cartId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });

    test('returns 404 if CtClient throws 404 for getCartById', async () => {
      /* Prepare */
      const isError = new ApiError(404, `Cart with CartId "${cartId}" not found.`);
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.getCartById(market, cartId));

      /* Verify */
      await result.rejects.toThrow(isError);
    });
  });

  describe('addProductToCartBySku()', () => {
    let country: string;
    // let cartId: string;
    let ID: string;
    let cartVersion: number;
    let sku: string;
    let quantity: number;
    let addLineItemBody: any;
    const channelKey = faker.datatype.string();
    beforeEach(() => {
      country = market.country;
      // cartId = 'cbbf6415-090c-4eb6-90b1-5733db440d16';
      ID = 'cbbf6415-090c-4eb6-90b1-5733db440d16';
      cartVersion = 1;
      sku = '106826-9161866660405752377';
      quantity = 3;
      addLineItemBody = {
        version: cartVersion,
        actions: [{
          action: 'addLineItem',
          sku,
          quantity,
          supplyChannel: {
            key: channelKey,
            typeId: 'channel',
          },
        }],
      };
    });

    test('queries ctClient with cart id', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.addProductToCartBySku(country, ID, cartVersion, sku, quantity, channelKey);

      /* Verify */
      expect(withId).toHaveBeenCalledTimes(1);
      expect(withId).toHaveBeenNthCalledWith(1, {
        ID,
      });
      expect(post).toHaveBeenNthCalledWith(1,
        {
          body: addLineItemBody,
          queryArgs: {
            expand: ['lineItems[*].discountedPricePerQuantity[*].discountedPrice.includedDiscounts[*].discount',
              'discountCodes[*].discountCode.id'],
          },
        });
    });

    test('returns ctClient response body', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.addProductToCartBySku(country, ID, cartVersion, sku, quantity, channelKey);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('returns undefined if CtClient throws 404', async () => {
      /* Prepare */
      const notFoundError = new Error('Not Found');
      (notFoundError as any).statusCode = 404;
      execute.mockRejectedValueOnce(notFoundError);

      /* Execute */
      const result = await cartDao.addProductToCartBySku(country, ID, cartVersion, sku, quantity, channelKey);

      /* Verify */
      expect(result).toBe(undefined);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const isError = new Error('Internal Server Error');
      (isError as any).statusCode = 500;
      execute.mockRejectedValueOnce(isError);

      /* Execute */
      const result = expect(() => cartDao.addProductToCartBySku(country, ID, cartVersion, sku, quantity, channelKey));

      /* Verify */
      await result.rejects.toThrow(isError);
    });
  });

  describe('getCartPaymentInfo()', () => {
    let ctResponse: any;
    const cartId = faker.datatype.uuid();
    beforeEach(() => {
      ctResponse = {
        body: {
          data: {
            cart: {
              ...cartDto,
            },
          },
        },
      };
    });

    test('queries ctClient with get query arg', async () => {
      /* Prepare */
      execute.mockReturnValueOnce(ctResponse);

      /* Execute */
      await cartDao.getCartPaymentInfo(market, cartId);

      /* Verify */
      expect(execute).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(
        1,
        {
          body: {
            query: GRAPHQL_QUERY.getCartPaymentInfo.replace('{{cartId}}', cartId)
              .replace('{{locale}}', market.locale),
          },
        },
      );
    });

    test('returns the result from the GraphQL server', async () => {
      execute.mockReturnValueOnce(ctResponse);

      const result = await cartDao.getCartPaymentInfo(market, cartId);

      expect(result).toBe(ctResponse.body.data.cart);
    });

    test('returns the result data NULL from the GraphQL server', async () => {
      const ctResponses = {
        body: {
          statusCode: 500,
          data: null,
          errors: {
            error: 'Malformed parameter: UUID string is invalid',
          },
        },
      };
      execute.mockReturnValueOnce(ctResponses);

      const result = await cartDao.getCartPaymentInfo(market, cartId);

      expect(result).toBeUndefined();
    });

    test('rethrows HTTP errors', async () => {
      const err = new Error('Something went wrong');
      (err as any).body = {};
      execute.mockRejectedValueOnce(err);

      const result = cartDao.getCartPaymentInfo(market, cartId);

      await expect(result).rejects.toThrow(err);
    });

    test('re-throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);
      /* Execute */
      const result = expect(() => cartDao.getCartPaymentInfo(market, cartId));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('returns 400 if CtClient throws 400 for replicate cart', async () => {
      /* Prepare */
      const iseError = new ApiError(400, i18next.t('error.cartIdNotFound', { cartId }));
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.getCartPaymentInfo(market, cartId));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });

  describe('replicateCartById()', () => {
    const cartId = faker.datatype.uuid();
    let cart: any;
    let cartReference: any;
    beforeEach(() => {
      cart = stubCtCartDto();
      cartReference = {
        reference: {
          typeId: 'cart',
          id: cartId,
        },
      };
    });

    test('post cart reference to replicate', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: undefined });

      /* Execute */
      await cartDao.replicateCartById(market.country, cartId);

      /* Verify */
      expect(replicate).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenCalledTimes(1);
      expect(post).toHaveBeenNthCalledWith(1,
        {
          body: cartReference,
        });
    });

    test('returns ctClient response body for replicate cart', async () => {
      /* Prepare */
      execute.mockReturnValueOnce({ body: cartDto });

      /* Execute */
      const result = await cartDao.replicateCartById(market.country, cartId);

      /* Verify */
      expect(result).toBe(cartDto);
    });

    test('throws non-404 ctClient errors', async () => {
      /* Prepare */
      const iseError = new Error('Internal Server Error');
      (iseError as any).statusCode = 500;
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.replicateCartById(market.country, cartId));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });

    test('returns 400 if CtClient throws 400 for replicate cart', async () => {
      /* Prepare */
      const iseError = new ApiError(400, i18next.t('error.cartIdNotFound', { cartId: cart.id }));
      execute.mockRejectedValueOnce(iseError);

      /* Execute */
      const result = expect(() => cartDao.replicateCartById(market.country, cartId));

      /* Verify */
      await result.rejects.toThrow(iseError);
    });
  });
});
