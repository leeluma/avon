import faker from '@faker-js/faker';
import axios from 'axios';
import { MarketInfo } from '../../src/middlewares';
import { stubMarket } from '../__stubs__';
import Mock = jest.Mock;
import MagnoliaDao from '../../src/daos/magnolia.dao';
import { MAGNOLIAURI } from '../../src/common/constants';
import { axiosOptions } from '../../src/lib/axios-options';

jest.mock('axios');

describe('Magnolia Dao testing Suit', () => {
  let magnoliaDao: MagnoliaDao;
  let market: MarketInfo;
  let wareHouseSettingUrl: string;
  let priceFormatSettingsUrl: string;
  let magnoliaBasePath: string;
  const mockResponse = {
    data: {
      name: faker.datatype.string(),
      path: faker.datatype.string(),
      id: faker.datatype.uuid(),
      nodeType: faker.datatype.string(),
      title: faker.datatype.string(),
      facebook: {
        name: faker.datatype.string(),
        path: faker.datatype.string(),
      },
      twitter: {
        name: faker.datatype.string(),
        path: faker.datatype.string(),
      },
    },
  };

  beforeEach(() => {
    market = stubMarket();
    magnoliaBasePath = faker.internet.url();
    /* Stubs */
    magnoliaDao = new MagnoliaDao();
  });

  // Unite test case for getDefaultWarehouse() method
  describe('getDefaultWarehouse()', () => {
    test('returns magnolia default warehouse response body', async () => {
      /* Prepare */
      wareHouseSettingUrl = `${magnoliaBasePath}${MAGNOLIAURI.WARE_HOUSE_SETTINGS}?lang=${market.localeAndCountry}`;
      wareHouseSettingUrl = wareHouseSettingUrl.replace('{{country}}', `${market.country.toLocaleLowerCase()}`);

      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getDefaultWarehouse(market, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledWith({ ...axiosOptions, method: 'get' as const, url: wareHouseSettingUrl });
    });

    test('Failed to fetch magnolia default warehouse data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getDefaultWarehouse(market, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch warehouse data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });

  describe('getPriceFormat()', () => {
    test('returns magnolia price format response body', async () => {
      /* Prepare */
      priceFormatSettingsUrl = `${magnoliaBasePath}${MAGNOLIAURI.PRICE_FORMAT}?lang=${market.localeAndCountry}`;
      priceFormatSettingsUrl = priceFormatSettingsUrl.replace('{{country}}', `${market.country.toLocaleLowerCase()}`);

      (axios as unknown as Mock).mockResolvedValueOnce(mockResponse);

      /* Execute */
      const result = await magnoliaDao.getPriceFormatSettings(market, magnoliaBasePath);

      /* Verify */
      expect(result).toBeTruthy();
      expect(axios).toHaveBeenCalledWith({ ...axiosOptions, method: 'get' as const, url: priceFormatSettingsUrl });
    });

    test('Failed to fetch magnolia price format data', async () => {
      const err = new Error('Magnolia throw error');
      (axios as unknown as Mock).mockRejectedValueOnce(err);
      /* Execute */
      const response = expect(() => (magnoliaDao).getPriceFormatSettings(market, magnoliaBasePath));
      /* Verify */
      await response.rejects.toThrow(
        new Error(`Failed to fetch price format settings data from magnolia, because: ${err.stack}`),
      );
      expect(axios).toHaveBeenCalledTimes(1);
    });
  });
});
