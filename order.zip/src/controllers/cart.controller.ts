import { Request, Response } from 'express';
import HttpStatusCodes from 'http-status-codes';
import { CartService } from '../services';
import { MarketInfo } from '../middlewares';
import { CartDto } from '../dtos';
import { JsonApiResponseEntity } from '../lib';
import { MagnoliaInfo } from '../dtos/common.dto';

interface CartControllerConfig {
  cartService: CartService;
}

export class CartController {
  private readonly cartService: CartService;

  constructor(config: CartControllerConfig) {
    this.cartService = config.cartService;
  }

  public addProductToCart = async (
    req: Request,
    res: Response,
  ): Promise<JsonApiResponseEntity<CartDto>> => {
    const market = res.locals.market as MarketInfo;
    const magnolia = res.locals.magnolia as MagnoliaInfo;

    const {
      customerId, anonymousId, cartId, channelKey,
    } = req.body;
    const { lineItems } = req.body;
    /* Call service */
    const cart = await this.cartService.addProductToCartBySku(
      market,
      customerId,
      anonymousId,
      cartId,
      lineItems,
      magnolia,
      channelKey as string | undefined,
    );
    return {
      statusCode: HttpStatusCodes.OK,
      body: cart,
    };
  };
}
