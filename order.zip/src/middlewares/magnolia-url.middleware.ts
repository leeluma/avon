import { NextFunction, Request, Response } from 'express';
import { config } from '../config/config';
import { MagnoliaInfo } from '../dtos/common.dto';

export const magnoliaUrlMiddleware = (req: Request, res: Response, next: NextFunction): void => {
  const magnolia: MagnoliaInfo = {
    url: config.magnoliaBasePath as string,
    isPreview: false,
  };

  const previewValue = req.query.isPreview ? (req.query.isPreview as string).toLowerCase() : false;
  if (previewValue === 'true') {
    magnolia.url = config.previewMagnoliaBasePath as string;
    magnolia.isPreview = true;
  }
  res.locals.magnolia = magnolia;
  next();
};
