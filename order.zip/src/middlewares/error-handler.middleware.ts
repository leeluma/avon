import { NextFunction, Request, Response } from 'express';
import HttpStatusCodes, { getReasonPhrase, ReasonPhrases } from 'http-status-codes';
import { ApiError, logger } from '../lib';

export const errorHandlerMiddleware = async (
  err: any,
  req: Request,
  res: Response,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  next: NextFunction,
): Promise<void> => {
  logger.error(`errorHandlerMiddleware caught the following error:\n${err.stack}`);

  let statusCode: number;
  let errors: any[];
  if (err instanceof ApiError) {
    statusCode = err.statusCode;
    errors = err.messageArray;
  } else
  if (err.name === 'BadRequest') {
    statusCode = 404;
    errors = ['404 error'];
    if (err.body.errors[0].code === 'InvalidInput') {
      statusCode = 404;
      errors = ['SKU code is invalid.'];
    }
  } else {
    statusCode = HttpStatusCodes.INTERNAL_SERVER_ERROR;
    errors = [ReasonPhrases.INTERNAL_SERVER_ERROR];
  }

  res.status(statusCode).send({
    statusCode,
    message: getReasonPhrase(statusCode),
    timestamp: new Date().toISOString(),
    errors,
  });
};
