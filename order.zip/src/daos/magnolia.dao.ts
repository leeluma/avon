import axios from 'axios';
import { axiosOptions } from '../lib/axios-options';
import { MarketInfo } from '../middlewares';
import { MAGNOLIAURI } from '../common/constants';
import { MagnoliaDto, PriceFormat } from '../dtos/magnolia.dto';

const country = '{{country}}';

/**
 * `MagnoliaDao` data access class for Magnolia
 */
export default class MagnoliaDao {
  /**
   * Get warehouse data
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   */
  public async getDefaultWarehouse(
    market: MarketInfo,
    magnoliaBasePath: string,
  ) : Promise<MagnoliaDto> {
    try {
      let wareHouseSettingUrl = `${magnoliaBasePath}${MAGNOLIAURI.WARE_HOUSE_SETTINGS}?lang=${market.localeAndCountry}`;
      wareHouseSettingUrl = wareHouseSettingUrl.replace(country, `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: wareHouseSettingUrl,
      };
      const result = await axios(config);
      return result.data;
    } catch (error) {
      throw new Error(`Failed to fetch warehouse data from magnolia, because: ${(error as Error).stack}`);
    }
  }

  /**
   * Get price format settings data from magnolia
   * @param market - MarketInfo
   * @param magnoliaBasePath - Magnolia base path url
   */
  public async getPriceFormatSettings(
    market: MarketInfo,
    magnoliaBasePath: string,
  ) : Promise<PriceFormat> {
    try {
      let priceFormatSettingsUrl = `${magnoliaBasePath}${MAGNOLIAURI.PRICE_FORMAT}?lang=${market.localeAndCountry}`;
      priceFormatSettingsUrl = priceFormatSettingsUrl.replace(country, `${market.country.toLocaleLowerCase()}`);
      const config = {
        ...axiosOptions,
        method: 'get' as const,
        url: priceFormatSettingsUrl,
      };
      const result = await axios(config);
      return result.data;
    } catch (error) {
      throw new Error(`Failed to fetch price format settings data from magnolia, because: ${(error as Error).stack}`);
    }
  }
}
