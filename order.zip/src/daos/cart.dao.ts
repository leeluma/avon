import {
  Cart, ClientResponse, GraphQLResponse, LineItemDraft, CartDraft,
} from '@commercetools/platform-sdk';
import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import { GRAPHQL_QUERY } from '../common/constants';
import { ApiError, CtClient, logger } from '../lib';
import { MarketInfo } from '../middlewares';
import { graphql } from '../graphql';

const cartNotFound = 'error.cartIdNotFound';
const queryCondition = ['lineItems[*].discountedPricePerQuantity[*].discountedPrice.includedDiscounts[*].discount',
  'discountCodes[*].discountCode.id'];

interface CartData {
  lineItems: LineItemDraft,
  customerId?: string,
  anonymousId?: string
}

export const createCartDraft = (currency: string, cartData: CartData): CartDraft => {
  const { customerId, anonymousId, lineItems: lineItemDraft } = cartData;
  return {
    currency,
    anonymousId,
    customerId,
    taxMode: 'Disabled',
    lineItems: [lineItemDraft],
  };
};

interface CartDaoConfig {
  ctClient: CtClient;
  graphql: typeof graphql;
}

/**
 * `CtCartDao` data access class for CommerceTools `Cart`
 */
export class CartDao {
  private readonly ctClient: CtClient;

  private readonly graphql: typeof graphql;

  /**
   * Constructor for `CartDao` class
   * @param config injects dependencies into the object
   */
  constructor(config: CartDaoConfig) {
    this.ctClient = config.ctClient;
    this.graphql = config.graphql;
  }

  /**
   * Creates a cart in CommerceTools
   * @param country - Country
   * @param currency - Currency
   * @param customerId - string
   * @param lineItems - string
   * @returns created cart
   */
   public createCart = async (
     country:string,
     currency:string,
     lineItems: LineItemDraft,
     customerId?:string,
     anonymousId?: string,
   ): Promise<Cart> => {
     const cartData = customerId
       ? {
         country,
         currency,
         customerId,
         lineItems,
       }
       : {
         country,
         currency,
         anonymousId,
         lineItems,
       };
     const cartDraft = createCartDraft(currency, cartData);
     const cart = this.ctClient.getClient(country).carts().post({
       body: cartDraft,
       queryArgs: { expand: queryCondition },
     }).execute();
     return (await cart).body;
   };

   /**
   * Get cart by Id from CommerceTools
   * @param country - string
   * @param cartId - string
   * @returns cart from the commercetools
   */
   public getCartById = async (market: MarketInfo, cartId: string): Promise<Cart | undefined> => {
     try {
       const locale = market.locale.toLocaleUpperCase();
       const body = {
         query: await this.graphql.getCartDetails,
         variables: {
           cartId,
           locale,
         },
       };
       const cart: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
         .graphql().post({ body }).execute();
       return cart.body.data?.cart;
     } catch (err: any) { // NOSONAR
       // --As per typescript documentation only two possiblities of types in case of error i.e. any|unknown
       logger.error(`from Commerce tool, because:\n${err.stack}`);
       if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
         throw new ApiError(HttpStatusCodes.NOT_FOUND, `Cart with CartId "${cartId}" not found.`);
       }
       throw err;
     }
   };

   /**
   * Add product to cart in CommerceTools
   * @param country - string
   * @param cartId - string
   * @param cartVersion - number
   * @param sku - string
   * @param quantity - number
   * @returns Updated cart after adding the product in cart
   */
   public addProductToCartBySku = async (
     country:string,
     cartId:string,
     cartVersion:number,
     sku:string,
     quantity:number,
     channelKey: string,
   ): Promise<Cart | undefined> => {
     try {
       const updatedCart = await this.ctClient.getClient(country)
         .carts()
         .withId({ ID: cartId })
         .post({
           body: {
             version: cartVersion,
             actions: [{
               action: 'addLineItem',
               sku,
               quantity,
               supplyChannel: {
                 typeId: 'channel',
                 key: channelKey,
               },
             }],
           },
           queryArgs: { expand: queryCondition },
         })
         .execute();
       return updatedCart.body;
     } catch (err: any) { // NOSONAR
       // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
       logger.error(` Failed, because:\n${err.stack}`);
       if (err.statusCode === HttpStatusCodes.NOT_FOUND) {
         return undefined;
       }
       throw err;
     }
   };

   /**
   * replicate cart by cart id
   * @param country - string
   * @param cartId - cartId
   * @returns replicated new cart using old cart id
   */
  public replicateCartById = async (
    country: string,
    cartId: string,
  ): Promise<Cart> => {
    try {
      const updatedCart = await this
        .ctClient.getClient(country).carts().replicate()
        .post({
          body: {
            reference: {
              typeId: 'cart',
              id: cartId,
            },
          },
        })
        .execute();
      return updatedCart.body;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`Failed to replicate cart because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.BAD_REQUEST) {
        throw new ApiError(
          HttpStatusCodes.BAD_REQUEST,
          i18next.t(cartNotFound, { cartId }),
        );
      }
      throw err;
    }
  };

  /**
   * Get cart by id from CommerceTools using graphql
   * @param market - MarketInfo
   * @param cartId - Id of Commerce tool cart to retrieve
   * @returns Fetched cartDao (or undefined if the cart don't exist)
   */
  public async getCartPaymentInfo(
    market: MarketInfo,
    cartId: string,
  ) {
    try {
      const query = GRAPHQL_QUERY.getCartPaymentInfo.replace('{{cartId}}', cartId)
        .replace('{{locale}}', market.locale);
      const cart: ClientResponse<GraphQLResponse> = await this.ctClient.getClient(market.country)
        .graphql()
        .post({
          body: { query },
        })
        .execute();
      return cart.body.data?.cart;
    } catch (err: any) { // NOSONAR
      // --As per typescript documentation only two possibilities of types in case of error i.e. any|unknown
      logger.error(`from Commerce tool, because:\n${err.stack}`);
      if (err.statusCode === HttpStatusCodes.BAD_REQUEST) {
        throw new ApiError(
          HttpStatusCodes.BAD_REQUEST,
          i18next.t(cartNotFound, { cartId }),
        );
      }
      throw err;
    }
  }
}
