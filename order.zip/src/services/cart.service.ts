/* eslint-disable prefer-const */
import HttpStatusCodes from 'http-status-codes';
import {
  Cart, LineItem, LineItemDraft, ProductVariantChannelAvailability,
} from '@commercetools/platform-sdk';
import i18next from 'i18next';
import { CartDao, ProductDao } from '../daos';
import { CartDto, CartPaymentInfo, CreateCartArgs } from '../dtos';
import { CartMapper } from '../mappers';
import currencyCode from '../common/currency';
import { ApiError } from '../lib';
import { MarketInfo } from '../middlewares';
import { DEFAULT_QUANTITY } from '../common/constants';
import MagnoliaDao from '../daos/magnolia.dao';
import { MagnoliaInfo } from '../dtos/common.dto';

interface CartServiceConfig {
  cartMapper: CartMapper;
  cartDao: CartDao;
  productDao: ProductDao;
  magnoliaDao: MagnoliaDao;
}

/**
 * `CartService` for business logic `CartService`
 */
export class CartService {
  private readonly cartDao: CartDao;

  private readonly cartMapper: CartMapper;

  private readonly productDao: ProductDao;

  private readonly magnoliaDao: MagnoliaDao;

  private readonly cartNotFound = 'error.cartNotFound';

  /**
   * Constructor for `CartService` class
   * @param config injects dependencies into the object
   */
  constructor(config: CartServiceConfig) {
    this.cartMapper = config.cartMapper;
    this.cartDao = config.cartDao;
    this.productDao = config.productDao;
    this.magnoliaDao = config.magnoliaDao;
  }

  /**
   * check product basic validation
   * @param lineItemAvailability
   * @param variantAttributes
   * @param quantity
   * @param quantityAlreadyInCart
   */
  private readonly checkProductDetails = (
    lineItemAvailability,
    variantAttributes,
    quantity: number,
    quantityAlreadyInCart = 0,
  ) => {
    const availableQuantity = lineItemAvailability?.availableQuantity ?? DEFAULT_QUANTITY.DEFAULT_MAX_AVAILABLE_QUANTITY;
    const isOnStock = lineItemAvailability?.isOnStock ?? true;
    const maxPurchasableQty = variantAttributes?.maxPurchasableQty ?? DEFAULT_QUANTITY.DEFAULT_MAX_PURCHASABLE_QUANTITY;
    const discontinued = variantAttributes?.discontinued ?? false;

    if (discontinued) {
      throw new ApiError(
        HttpStatusCodes.BAD_REQUEST,
        i18next.t('error.productDiscontinued'),
      );
    }
    if (!isOnStock) {
      throw new ApiError(
        HttpStatusCodes.BAD_REQUEST,
        i18next.t('error.outOfStock'),
      );
    }
    if ((quantity + quantityAlreadyInCart) > maxPurchasableQty) {
      if ((quantity + quantityAlreadyInCart) > availableQuantity) {
        throw new ApiError(
          HttpStatusCodes.BAD_REQUEST,
          i18next.t('error.greaterThanMaxPurchasableQtyAndAvailableQuantity'),
        );
      }
      throw new ApiError(
        HttpStatusCodes.BAD_REQUEST,
        i18next.t('error.greaterThanMaxPurchasableQty'),
      );
    }

    if ((quantity + quantityAlreadyInCart) > availableQuantity) {
      throw new ApiError(
        HttpStatusCodes.BAD_REQUEST,
        i18next.t('error.addedGreaterThanAvailability'),
      );
    }
  };

  /**
   * add product or create cart
   * if cartId then add in old cart else create new cart
   * @param cartId - cart Id
   * @param market - market info
   * @param cartVersion - cart version
   * @param lineItems - line item
   * @param customerId - customer id
   * @returns Cart Response
   */
  private readonly createCart = async (createCartArgs: CreateCartArgs) => {
    const {
      cartId, market, cartVersion, lineItems, magnoliaURL, customerId, anonymousId, warehouseKey,
      productsIds,
    } = createCartArgs;
    const { country } = market;
    const currency = currencyCode[country];
    let addedProductInCart: Cart | undefined;
    let priceFormatSettings;
    let productDetails;
    if (cartId) {
      [addedProductInCart, priceFormatSettings, productDetails] = await Promise.all([
        this.cartDao.addProductToCartBySku(
          country,
          cartId,
          cartVersion,
          lineItems.sku as string,
          lineItems.quantity as number,
          warehouseKey || '',
        ),
        this.magnoliaDao.getPriceFormatSettings(market, magnoliaURL),
        this.productDao.fetchProductsDetail(market, productsIds)]);
    } else {
      const lineItemDraft: LineItemDraft = {
        sku: lineItems.sku,
        quantity: lineItems.quantity,
        supplyChannel: {
          typeId: 'channel',
          key: warehouseKey,
        },
      };
      [addedProductInCart, priceFormatSettings, productDetails] = await Promise.all([
        this.cartDao.createCart(country, currency, lineItemDraft, customerId, anonymousId),
        this.magnoliaDao.getPriceFormatSettings(market, magnoliaURL),
        this.productDao.fetchProductsDetail(market, productsIds)]);
    }
    return this.cartMapper.cartToDto(addedProductInCart as Cart, market.locale, priceFormatSettings, productDetails);
  };

  /**
   * Cart Add Product implementation
   * @param market - MarketInfo
   * @param customerId - String
   * @param cartId - String
   * @param lineItems - String
   * @returns Cart Response
   */
  public addProductToCartBySku = async (
    market: MarketInfo,
    customerId: string,
    anonymousId: string,
    cartId: string,
    lineItems: LineItemDraft,
    magnolia : MagnoliaInfo,
    channelKey: string | undefined,
  ): Promise<CartDto> => {
    const { sku, quantity } = lineItems;
    let lineItemFoundWithSku;
    let quantityAlreadyInCart;
    let lineItemAvailability: ProductVariantChannelAvailability = {};
    let variantAttributes;
    let cart: Cart | undefined;
    let cartVersion;
    let createCartArgs;
    let warehouseKey;
    let productsIds = '';
    warehouseKey = channelKey;
    if (channelKey === undefined) {
      const warehouseResult = await this.magnoliaDao.getDefaultWarehouse(market, magnolia.url);
      warehouseKey = warehouseResult.defaultWarehouse;
    }
    if (cartId) {
      const cartPaymentInfo = await this.checkCartPaymentInfo(market, cartId);
      cart = cartPaymentInfo.cart as Cart;
      if (cartPaymentInfo.isPaymentInitiated === false && cartPaymentInfo.cart === undefined) {
        // get cart if cart Id
        cart = await this.cartDao.getCartById(market, cartId);
        if (!cart) {
          throw new ApiError(
            HttpStatusCodes.NOT_FOUND,
            i18next.t(this.cartNotFound),
          );
        }
      }

      if (cart.lineItems.length) {
        productsIds = this.getCartProductIds(cart.lineItems);
      }

      cartVersion = cart.version;
      // check if sku is in cart using sku, if found perform basic validation
      lineItemFoundWithSku = cart.lineItems.find((lineItem) => lineItem.variant.sku === sku);
      if (lineItemFoundWithSku) {
        quantityAlreadyInCart = lineItemFoundWithSku.quantity;
        const channelAvailable = lineItemFoundWithSku.variant.availability?.channels ?? undefined;
        if (channelAvailable) {
          const availableChannelKey = Object.keys(channelAvailable);
          lineItemAvailability = channelAvailable[availableChannelKey[0]];
        }
        variantAttributes = this.cartMapper.getProductAttributes(lineItemFoundWithSku.variant.attributesRaw);

        this.checkProductDetails(
          lineItemAvailability, variantAttributes, quantity as number, quantityAlreadyInCart,
        );
        createCartArgs = {
          cartId: cart.id,
          market,
          cartVersion,
          lineItems,
          magnoliaURL: magnolia.url,
          customerId,
          anonymousId,
          warehouseKey,
          productsIds,
        };

        return this.createCart(createCartArgs);
      }
    }
    // if no cart Id or sku in cart(line item), make graphql call to validate sku and do basic validation
    const productDetails = await this.productDao.getProductBySKU(market, sku as string);
    const productLineItemDetails = this.getProductLineItemDetails(productDetails, sku);
    lineItemAvailability = (await productLineItemDetails).lineItemAvailability;
    variantAttributes = (await productLineItemDetails).variantAttributes;
    productsIds = cart?.lineItems.length ? `${productsIds}, "${productDetails[0].id}"` : `"${productDetails[0].id}"`;
    this.checkProductDetails(
      lineItemAvailability, variantAttributes, quantity as number, quantityAlreadyInCart,
    );
    const lineItemDraft:LineItemDraft = {
      sku: lineItems.sku,
      quantity: lineItems.quantity,
      supplyChannel: {
        typeId: 'channel',
        key: channelKey,
      },
    };
    return this.createCart({
      cartId,
      market,
      cartVersion,
      lineItems: lineItemDraft,
      magnoliaURL: magnolia.url,
      customerId,
      anonymousId,
      warehouseKey,
      productsIds,
    });
  };

  /**
   * Check cart payment info and status
   * if payment initiated then Replicate the cart and return new cart data
   * @param market - MarketInfo
   * @param cartId - cartId
   * @returns payment info and cart Response
   */
  public async checkCartPaymentInfo(
    market: MarketInfo,
    cartId: string,
  ): Promise<CartPaymentInfo> {
    const { country } = market;
    const cart = await this.cartDao.getCartPaymentInfo(market, cartId);
    if (!cart) {
      throw new ApiError(HttpStatusCodes.NOT_FOUND, i18next.t('error.cartIdNotFound', { cartId }));
    }
    if (!cart.paymentInfo || cart.paymentInfo.payments.length === 0) {
      return { isPaymentInitiated: false };
    }
    const { payments } = cart.paymentInfo;
    const isPaymentPendingOrInitiated = payments.every((payment) => payment?.paymentStatus.state !== null
      && (payment?.paymentStatus.state?.name === 'Initial'
      || payment?.paymentStatus.state?.name === 'Pending'));

    if (isPaymentPendingOrInitiated) {
      const replicatedCart = await this.cartDao.replicateCartById(country, cartId);
      return { isPaymentInitiated: true, cart: replicatedCart };
    }
    return { isPaymentInitiated: false };
  }

  /**
   * get line item availability and attributes
   * @param productDetails - productDetails
   * @param sku - SKU
   * @returns line item availability and attributes data
   */
  public async getProductLineItemDetails(
    productDetails,
    sku: string | undefined,
  ) {
    if (!productDetails || productDetails.length === 0) {
      throw new ApiError(
        HttpStatusCodes.NOT_FOUND,
        i18next.t('error.skuNotFound'),
      );
    }
    const lineItemFoundWithSku = productDetails[0]?.masterData.current?.allVariants.find((variant) => variant.sku === sku);
    const lineItemAvailability = (lineItemFoundWithSku?.availability?.channels?.results.length > 0)
      ? lineItemFoundWithSku?.availability?.channels?.results[0]?.availability : {};
    const variantAttributes = this.cartMapper.getProductAttributes(lineItemFoundWithSku?.attributesRaw);
    return { lineItemAvailability, variantAttributes };
  }

  /** * Function to return cart product id */
  private readonly getCartProductIds = (lineItems: LineItem[]): string => {
    return lineItems
      .map((lineItem) => {
        return `"${lineItem.productId}"`;
      })
      .join(', ');
  };
}
