import { createClient } from '@commercetools/sdk-client';
import { createHttpMiddleware } from '@commercetools/sdk-middleware-http';
import { createAuthMiddlewareForClientCredentialsFlow } from '@commercetools/sdk-middleware-auth';
import { createApiBuilderFromCtpClient } from '@commercetools/platform-sdk';
import { createQueueMiddleware } from '@commercetools/sdk-middleware-queue';
import fetch from 'node-fetch';
import {
  ByProjectKeyRequestBuilder,
// eslint-disable-next-line import/no-unresolved
} from '@commercetools/platform-sdk/dist/declarations/src/generated/client/by-project-key-request-builder';

interface CtClientConfig {
  [k: string]: string;
}

interface MarketConfig {
  projectKey: string;
  apiEndpoint: string;
  authEndpoint: string;
  clientId: string;
  clientSecret: string;
}

export class CtClient {
  private readonly config: CtClientConfig;

  private clientPool: { [country: string]: ByProjectKeyRequestBuilder } = {};

  /**
   * @example
   *    const ctClient = new CtClient(process.env);
   *    const firstPageProducts = ctClient.getClient('RO').products().get().execute();
   * @param config Configuration variables. You probably want to pass `process.env` here.
   */
  constructor(config: CtClientConfig) {
    this.config = config;

    let countries: string[];
    try {
      countries = JSON.parse(config.CT_ACTIVE_MARKETS)
        .map((country) => country.toLocaleUpperCase());
    } catch (err) {
      throw new Error('Failed to parse commercetools-client ACTIVE_MARKETS config as JSON.');
    }

    countries.forEach((country) => {
      this.clientPool[country] = this.buildClient(country);
    });
  }

  public getClient(country: string): ByProjectKeyRequestBuilder {
    const client = this.clientPool[country];

    if (!client) {
      throw new Error(`No CtClient found for country "${country}".`);
    }

    return client;
  }

  private buildClient(country: string): ByProjectKeyRequestBuilder {
    const countryConfig = this.getConfigForCountry(country);

    const client = createClient({
      middlewares: [
        createAuthMiddlewareForClientCredentialsFlow({
          host: countryConfig.authEndpoint,
          projectKey: countryConfig.projectKey,
          credentials: {
            clientId: countryConfig.clientId,
            clientSecret: countryConfig.clientSecret,
          },
          fetch,
        }),
        createHttpMiddleware({
          host: countryConfig.apiEndpoint,
          includeResponseHeaders: true,
          includeOriginalRequest: true,
          maskSensitiveHeaderData: true,
          enableRetry: true,
          retryConfig: {
            maxRetries: this.config.CT_MAX_RETRIES || 2,
            retryDelay: this.config.CT_RETRY_DELAY || 300, // milliseconds
            maxDelay: this.config.CT_RETRY_MAX_DELAY || 1000, // milliseconds
            retryOnAbort: this.config.CT_RETRY_ON_ABORT || true,
          },
          // Optional if not globally available
          timeout: this.config.CT_TIMEOUT || 2000,
          fetch,
        }),
        createQueueMiddleware({
          concurrency: this.config.CT_CONCURRENCY || 20,
        }),
      ],
    });

    return createApiBuilderFromCtpClient(client)
      .withProjectKey({ projectKey: countryConfig.projectKey });
  }

  protected getConfigForCountry(country: string): MarketConfig {
    const countryUC = country.toUpperCase();

    const countryConfig = {
      projectKey: this.config[`CT_PROJECT_KEY_${countryUC}`],
      clientId: this.config[`CT_CLIENT_ID_${countryUC}`],
      clientSecret: this.config[`CT_CLIENT_SECRET_${countryUC}`],
      apiEndpoint: this.config.CT_API_ENDPOINT,
      authEndpoint: this.config.CT_AUTH_ENDPOINT,
    };

    Object.keys(countryConfig).forEach((key) => {
      if (!countryConfig[key]) {
        throw new Error(`Missing environment variable for CtClient country "${country}" config option "${key}".`);
      }
    });

    return countryConfig;
  }
}
