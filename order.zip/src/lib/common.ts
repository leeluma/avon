import currency from 'currency.js';
import { Cart, Product } from '@commercetools/platform-sdk';
import { PriceFormat } from '../dtos/magnolia.dto';
import {
  VariantAttribute, PromotionDto, PriceCurrencyDto, PriceDto,
} from '../dtos/cart.dto';
import {
  ATTRIBUTE_NAMES, ATTRIBUTE_VALUES, MEASUREMENT, DEFAULT_QUANTITY, CATEGORY_TYPE, VARIANT_ATTRIBUTES,
} from '../common/constants';
import {
  ImageDto, ShippingInfoDto, ShippingInfo, OffersDto,
} from '../dtos';

/**
 * function to convert number to decimal in given fraction
 * @param amount - Given amount
 * @param fraction - Given fraction
 * @returns
 */
export const priceConverter = (amount:number, fraction:number) => {
  const denominator = DEFAULT_QUANTITY.BASE_NUMBER ** fraction; // Ma th.pow(10, fraction);
  return (amount / denominator).toFixed(fraction);
};

/**
  * Get Formatted Magnolia Price
  * @param price - List of prices
  * @param priceFormat - Magnolia Price Format
  * @returns Magnolia Formatted Price
  */
export const magnoliaPriceFormatter = (price: number, priceFormat: PriceFormat): string => {
  let calculatedPrice = '';
  const numberTen = 10;
  const currencies: string = priceFormat.ccy;
  const showDecimalZero = Boolean(priceFormat.showDecimalZero ?? false);
  const noOfDigitAtLast = Number(priceFormat.noOfDigit ?? 0);
  const decimalPoint: string = priceFormat.decimalPoint ?? '.';
  const thousandSeparator: string = priceFormat.thousandSeperator ?? '';
  const currencyPlacement: string = priceFormat.currencyPlacement ?? 'after';
  const lastDigitNo: number = numberTen ** noOfDigitAtLast;
  const sellPrice = (price / lastDigitNo).toFixed(noOfDigitAtLast);
  const parts = sellPrice.toString().split('.');
  const calculation = parts[1] ? decimalPoint + parts[1] : '';
  const returnPrice = showDecimalZero === true ? (parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator)
    + calculation) : parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousandSeparator);
  calculatedPrice = (currencyPlacement === 'before')
    ? `${currencies} ${returnPrice}` : `${returnPrice} ${currencies}`;
  return calculatedPrice;
};

/**
   * @param attributes all variant attributes
   * @param sellPrice : variant sell price after discount
   * @param locale : market locale
   * @returns : string with unit price measurement
   */
export const getUnitPrice = (
  attributes:VariantAttribute[],
  sellPrice:number,
  priceFormat: PriceFormat,
):string => {
  let allBaseNodes: any[];
  let measuredValue;
  let result = '';
  let formattedPrice;
  const unitFillMeasureObj = attributes.find((value) => value.name === ATTRIBUTE_NAMES.contentFillMeasurement);
  const unitFillValueObj = attributes.find((value) => value.name === ATTRIBUTE_NAMES.contentFill);
  const unitFillMeasure = ((typeof unitFillMeasureObj !== 'undefined')
      && (ATTRIBUTE_VALUES.attributeValue in unitFillMeasureObj)) ? unitFillMeasureObj.value.key : '';
  const unitFillValue = ((typeof unitFillValueObj !== 'undefined')
      && (ATTRIBUTE_VALUES.attributeValue in unitFillValueObj)) ? unitFillValueObj.value : '';
  const allNodes: any = {};
  /* istanbul ignore else */
  if (Object.keys(priceFormat).length > 0 && (unitFillMeasure !== '') && (unitFillValue !== '')) {
    // normalizing unit price json response
    if (MEASUREMENT.baseMeasure in priceFormat) {
      if (MEASUREMENT.nodes in priceFormat.baseMeasure) {
        allBaseNodes = priceFormat.baseMeasure[MEASUREMENT.nodes];
        allBaseNodes.forEach((key) => {
          allNodes[priceFormat.baseMeasure[key].unitType] = priceFormat.baseMeasure[key];
          return allNodes;
        });
      }
    }
    // get Unit Price Measurement details
    if (unitFillMeasure in allNodes) {
      if (unitFillValue > allNodes[unitFillMeasure].containerSizeLimit) {
        measuredValue = sellPrice * (allNodes[unitFillMeasure].unitPriceBaseMeasure / unitFillValue);
        formattedPrice = magnoliaPriceFormatter(Math.round(measuredValue), priceFormat);
        result = `${formattedPrice} per ${allNodes[unitFillMeasure].unitPriceBaseMeasure}`
            + `${allNodes[unitFillMeasure].translation}`;
      }
    }
  }
  return result;
};

/**
 * Maps cart promotion
 * @param cart - any
 * @returns
 */
export const promotionToDto = (
  cart: Cart,
  priceFormat: PriceFormat,
  discountCodeId: string,
  isFormattedAmount = true,
): PromotionDto | undefined | number => {
  let promotionId = '';
  const promotionCode = '';
  let promotionState: string | undefined;
  let totalPromotionAmount = 0.0;
  let promotionApplied = false;
  /* istanbul ignore else */
  if (Array.isArray(cart.discountCodes) && cart.discountCodes[0]) {
    promotionState = cart.discountCodes[0].state;
    promotionId = cart.discountCodes[0].discountCode.id;
    if (cart.discountCodes[0].state === 'MatchesCart') {
      cart.lineItems.forEach((lineItem) => {
      /* istanbul ignore else */
        if (Array.isArray(lineItem.discountedPricePerQuantity) && lineItem.discountedPricePerQuantity.length) {
          lineItem.discountedPricePerQuantity.forEach((discount) => {
            discount.discountedPrice.includedDiscounts.forEach((element) => {
              // Comparing cart-discount id at line item level with cart-discount in discount code
              // As this code is supposed to tally savings through discount codes.
              if (element.discount.id === discountCodeId) {
                promotionApplied = true;
                totalPromotionAmount += element.discountedAmount.centAmount * discount.quantity;
              }
            });
          });
        }
      });
    }
  }
  if (!isFormattedAmount) {
    return totalPromotionAmount;
  }
  const promotionDto: PromotionDto = {
    promotionId,
    promotionCode,
    promotionAmount: Number(priceConverter(totalPromotionAmount, cart.totalPrice.fractionDigits)),
    formattedPromotionAmount: magnoliaPriceFormatter(totalPromotionAmount, priceFormat),
    promotionState,
    promotionApplied,
  };
  return promotionDto;
};

/**
   * Maps Line Item to Image DTO
   * @param lineItem - any
   * @returns
   */
export const imageToDto = (lineItem): ImageDto[] => lineItem.variant.images.map((image) => {
  const imageDto: ImageDto = {
    label: image.label,
    url: image.url,
    width: image.dimensions.w,
    height: image.dimensions.h,
  };
  return imageDto;
});

/**
   * Maps shipping method info
   * @param shippingInfo - shippingInfo
   * @returns Shipping method info
   */
export const shippingInfoToDto = (
  shippingInfo: ShippingInfo,
  priceFormat: PriceFormat,
): ShippingInfoDto => {
  const shippingMethodName = shippingInfo.shippingMethodName ? shippingInfo.shippingMethodName : '';
  const shippingMethodPrice = (shippingInfo.price && shippingInfo.price.centAmount)
    ? magnoliaPriceFormatter(shippingInfo?.price?.centAmount, priceFormat) : '0';
  return { shippingMethodName, shippingMethodPrice };
};

/**
   * Maps missing offer info
   * @param productDetails - productDetails
   * @param productId - productId
   * @returns missing offer details
   */
export const getProductOffer = (productDetails: Product[], productId: string, fulfilledOfferCategoryId: string): OffersDto[] => {
  const offerArray: OffersDto[] = [];

  // missed offer details
  /* istanbul ignore else */
  if (productDetails && productDetails.length > 0) {
    for (let index = 0; index < productDetails.length; index += 1) {
      /* istanbul ignore else */
      if (productDetails[index].id === productId) {
        let offerObj: OffersDto;
        productDetails[index].masterData.current.categories.forEach((category: any) => {
          /* istanbul ignore else */
          if (category?.custom && category?.custom.customFieldsRaw[0].value === CATEGORY_TYPE.offer) {
            offerObj = {
              key: category.key,
              displayName: category.name ? category.name : '',
              url: category.slug ? `/c/${category.slug}` : '',
              description: category.description
                ? category.description : '',
              fulfilled: category.id === fulfilledOfferCategoryId,
            };
            offerArray.push(offerObj);
          }
        });
      }
    }
  }
  return offerArray;
};

/**
   * maps attributes
   * @param attributes
   */
export const getProductAttributes = (attributes) => {
  const variantArr = attributes.map((attribute) => {
    if (attribute.name === VARIANT_ATTRIBUTES.variantType
        || attribute.name === VARIANT_ATTRIBUTES.variantValue
        || attribute.name === VARIANT_ATTRIBUTES.hexCode
        || attribute.name === VARIANT_ATTRIBUTES.maxPurchasableQty
        || attribute.name === VARIANT_ATTRIBUTES.discontinued) {
      return { [attribute.name]: attribute?.value?.key ? attribute?.value?.label : attribute?.value };
    }
    return undefined;
  });
  return Object.assign({}, ...variantArr);
};

/**
   * Get shipping info data
   * @param shippingInfo ShippingInfo
   * @returns ShippingInfoDto
   */
export const getShippingInfo = (
  shippingInfo: ShippingInfo | undefined,
  priceFormat: PriceFormat,
): ShippingInfoDto | undefined => {
  if (shippingInfo === undefined || shippingInfo === null) {
    return undefined;
  }
  return {
    shippingMethodName: shippingInfo.shippingMethodName,
    shippingMethodPrice: magnoliaPriceFormatter(shippingInfo.price.centAmount, priceFormat),
    shippingPrice: shippingInfo.price.centAmount,
  };
};

/**
 * Function to return specific field value
 */
export const getCustomFieldData = (
  custom,
  fieldName: string,
): string | undefined => {
  if (custom === undefined || custom === null) {
    return undefined;
  }
  let fieldValue;
  custom.customFieldsRaw.forEach((field) => {
    if (field.name === fieldName) {
      fieldValue = field.value;
    }
  });
  return fieldValue;
};

/**
 * Maps price and currency
 * @param price - number
 * @param currencyCode - string
 * @param priceFormat - PriceFormat
 * @returns
 */
export const getPriceWithCurrency = (price: number, currencyCode: string, priceFormat: PriceFormat): string => {
  const currencyPlacement: string = priceFormat.currencyPlacement ?? 'after';
  return (currencyPlacement === 'before') ? `${currencyCode} ${price}` : `${price} ${currencyCode}`;
};

/**
 * Maps monetaryAmount to price
 * @param price - any
 * @returns
 */
export const getTotalPriceAndCurrencyCode = (price: PriceDto): PriceCurrencyDto => {
  const totalPrice = currency(price.centAmount, {
    fromCents: true,
    precision: price.fractionDigits,
  });
  const currencyCode = price?.currencyCode;
  return {
    totalPrice: totalPrice.value,
    currencyCode,
  };
};
