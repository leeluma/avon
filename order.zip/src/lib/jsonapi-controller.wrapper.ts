import { NextFunction, Request, Response } from 'express';
import { getReasonPhrase } from 'http-status-codes';

type JsonApiAttributes<T> = {
  [k in keyof Omit<T, 'id'>]: any;
};

interface JsonApiObject<T> {
  data: JsonApiAttributes<T>;
}

export type JsonApiData<T> = JsonApiObject<T> | JsonApiObject<T>[] | null;

/**
 * To be returned from `JsonApiController`.
 */
export interface JsonApiResponseEntity<T> {
  statusCode: number;
  headers?: { [headerName: string]: string };
  body: T | T[];
}

/**
 * A controller that returns a `JsonApiResponseEntity` entity.
 */
export type JsonApiController<T> = (
  req: Request,
  res: Response,
) => Promise<JsonApiResponseEntity<T | undefined>>;

interface Serializable {
  id: string; // Force id to be string, hoping that developers will use UUIDs instead of incremental numbers
}

export const toJsonApiData = <T extends Serializable>(
  obj: T | T[],
): JsonApiData<T> | null => {
  if (obj === undefined) {
    throw new Error('Cannot serialize "undefined" to JsonApi.');
  }

  if (obj === null) {
    return null;
  }

  if (Array.isArray(obj)) {
    return obj.map((item) => toJsonApiData(item) as any);
  }

  if (typeof obj !== 'object') {
    throw new Error(`toJsonApiData() only supports null, objects and arrays. Type "${typeof obj}" is not supported.`);
  }

  if (!('id' in obj)) {
    throw new Error('Missing "id" property in JsonApi object.'
      + ' If you are absolutely sure you know what you are doing, assign it the value "undefined".');
  }

  const data: JsonApiData<T> = {
    data: { ...obj },
  };

  return data;
};

export const wrapJsonApiController = <T extends Serializable>(jsonApiController: JsonApiController<T>) => {
  return (
    req: Request,
    res: Response,
    next: NextFunction,
  ): void => {
    const jsonApiControllerAsync = async () => jsonApiController(req, res);

    jsonApiControllerAsync()
      .then((response: unknown) => {
        /* Don't do anything if the controller returns undefined
        because we assume the controller handled the response its self */

        if (response === undefined) {
          return;
        }

        /* Validate controller response */

        if (typeof response !== 'object' || !response) {
          throw new Error('Controller response must be a JsonApiResponseEntity object.');
        }

        const {
          statusCode, headers, body,
        } = response as JsonApiResponseEntity<T>;

        if (!('body' in response)) {
          throw new Error('Missing "body" in controller response.');
        }

        if (!statusCode) {
          throw new Error('Missing "statusCode" in controller response.'
            + ' This is required to ensure developers think well about the statusCode they return.');
        }

        if (headers && typeof headers !== 'object') {
          throw new Error('The "headers" field in controller response must be an object.');
        }

        /* Forward response to express */

        if (headers) {
          Object.keys(headers).forEach((k) => res.header(k, headers[k]));
        }

        res.status(statusCode);

        res.send({
          status: {
            statusCode,
            message: getReasonPhrase(statusCode),
            timestamp: new Date().toISOString(),
          },
          ...toJsonApiData(body),
        });
      })
      .catch(next);
  };
};
