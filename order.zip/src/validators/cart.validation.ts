import { body } from 'express-validator';

export const validateAddToCart = [
  body('cartId')
    .optional({ checkFalsy: true })
    .isUUID()
    .withMessage('validationError.cartInvalid'),
  body('lineItems.sku')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.skuMandatory'),
  body('lineItems.quantity')
    .exists({ checkNull: true, checkFalsy: true })
    .withMessage('validationError.lineItemQuantityMandatory'),
];
