import dotenv from 'dotenv';

dotenv.config();
export const config = {
  env: process.env.NODE_ENV,
  apiUrl: process.env.API_CONTEXT_PATH,
  port: parseInt(process.env.API_PORT || '0', 10),
  projectName: process.env.npm_package_name,
  projectVersion: process.env.npm_package_version,
  apiContextPath: process.env.API_CONTEXT_PATH,
  apiVersion: process.env.API_VERSION,
  magnoliaBasePath: process.env.MAGNOLIA_BASE_PATH,
  previewMagnoliaBasePath: process.env.PREVIEW_MAGNOLIA_BASE_PATH,
};
