import { Cart, LineItemDraft } from '@commercetools/platform-sdk';
import { MarketInfo } from '../middlewares';

export interface VariantAttribute {
  name: string;
  value: any; // NOSONAR
}

export interface ImageDto {
  url: string;
  label: string;
  width: number;
  height: number;
}

export interface OffersDto {
  key: string;
  displayName: string;
  url: string;
  description: string;
  fulfilled: boolean;
}

export interface LineItemDto {
  lineItemId: string;
  productId: string;
  productKey?: string;
  name: string;
  skuCode?: string;
  images: ImageDto[];
  listPrice: number,
  sellPrice: number,
  formattedListPrice: string,
  formattedSellPrice: string,
  vatMessage: string,
  unitPrice: string,
  quantity: number;
  modifiedTimeStamp?: string;
  sequenceNumber: number;
  maxPurchasableQty: number;
  availableQuantity:number;
  isAvailable: boolean;
  hexCode: string;
  variantKey?: string;
  variantType: string;
  variantValue: string;
  discontinued: boolean;
  offers: OffersDto[];
}
export interface ShippingAddressDto {
  address1?: string;
  address2?: string;
  postalCode?: string;
  city?: string;
  county?: string;
  phoneNumber?: string;
}

export interface PromotionDto {
  promotionId: string;
  promotionCode: string;
  promotionAmount: number;
  formattedPromotionAmount: string;
  promotionState?:string;
  promotionApplied: boolean;
}

export interface ShippingInfo {
  shippingMethodName: string;
  price: {
    type: string;
    currencyCode: string;
    centAmount: number;
    fractionDigits: number;
  }
}
export interface ShippingInfoDto {
  shippingMethodName: string;
  shippingMethodPrice: string;
  shippingPrice?: number;
}

export interface CartDto {
  id: string;
  version: number;
  totalRetailPriceAmount: string;
  totalInvoiceAmount: string;
  totalAmount: number;
  currencyCode: string;
  customerId?: string;
  anonymousId?: string;
  promotion?: PromotionDto;
  lineItems: LineItemDto[];
  shippingAddress: ShippingAddressDto;
  shippingInfo?: ShippingInfoDto;
}

export interface LineItemsAddProductDto {
  productKey : string,
  sku : string,
  quantity : number,
}

export interface CartAddProductToCartDto {
  cartId: string;
  customerId: string;
  lineItems: LineItemsAddProductDto;
}

export interface ShippingMethodsByCartArray {
  id: string;
  name: string;
  zoneRates: [
    {
      shippingRates: [
        {
          price: {
            centAmount: number;
            currencyCode: string;
            fractionDigits: number;
          },
          freeAbove: {
            centAmount: number;
            currencyCode: string;
            fractionDigits: number;
          }
        }
      ]
    }
  ]
}

export interface PriceCurrencyDto {
  totalPrice: number;
  currencyCode: string;
}

export interface CartPaymentInfo {
  isPaymentInitiated: boolean;
  cart?: Cart;
}

export interface PriceDto {
  centAmount: number;
  currencyCode: string;
  fractionDigits: number;
}

export interface CreateCartArgs {
  cartId: string,
    market: MarketInfo,
    cartVersion: number,
    lineItems: LineItemDraft,
    magnoliaURL: string,
    customerId?: string,
    anonymousId?: string,
    warehouseKey?: string,
    productsIds: string
}
