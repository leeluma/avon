export interface CtId {
  id: string;
}

/** See https://docs.commercetools.com/api/types#references */
export interface CtRef<T> extends CtId {
  typeId: string;
  obj?: T;
}

export interface CtTrackingClientDto {
  clientId: string;
  isPlatformClient: boolean;
}

/** Common interface to extend from in most other Ct* interfaces */
export interface CtTrackingFieldsDto {
  createdAt: string;
  createdBy: CtTrackingClientDto;
  lastModifiedAt: string;
  lastModifiedBy: CtTrackingClientDto;
}

export interface CtCustomFieldsDraftDto {
  [k: string]: string;
}

/** Generic response from CommerceTools */
export interface CtResponse<T> {
  statusCode: number;
  body: T;
}

export interface MagnoliaInfo {
  url: string;
  isPreview: boolean;
}

export interface CartFoundDto {
  type: 'Cart',
  id: string,
  version: number,
  lastMessageSequenceNumber: number,
  createdAt: string,
  lastModifiedAt: string,
  lastModifiedBy: {
    clientId: string,
    isPlatformClient: false,
  },
  createdBy: {
    clientId: string,
    isPlatformClient: false,
  },
  anonymousId: string,
  lineItems: [{
    id: string,
    productId: string,
    productKey: string,
    name: {
      ro: string,
    },
    productType: {
      typeId: 'product-type',
      id: string,
      version: number,
    },
    productSlug: {
      ro: string,
    },
    variant: {
      id: number,
      sku: string,
      key: string,
      prices: [{
        value: {
          type: 'centPrecision',
          currencyCode: 'RON',
          centAmount: number,
          fractionDigits: number,
        },
        id: string,
        channel: {
          typeId: 'channel',
          id: string,
        }
      }, {
        value: {
          type: 'centPrecision',
          currencyCode: 'RON',
          centAmount: number,
          fractionDigits: number,
        },
        id: string,
      }],
      images: [{
        url: string,
        label: 'Gallery',
        dimensions: {
          w: number,
          h: number
        }
      }, {
        url: string,
        label: 'Thumbnail',
        dimensions: {
          w: number,
          h: number
        }
      }],
      attributes: [{
        name: 'startDate',
        value: string,
      }, {
        name: 'endDate',
        value: string,
      }, {
        name: 'finishedStockCode',
        value: number,
      }, {
        name: 'maxPurchasableQty',
        value: number,
      }, {
        name: 'variantType',
        value: {
          key: 'Version',
          label: string,
        }
      }, {
        name: 'ratingCount',
        value: number,
      }],
      assets: [],
      availability: {
        isOnStock: boolean,
        availableQuantity: number,
        version: number,
        id: string,
      }
    },
    price: {
      value: {
        type: 'centPrecision',
        currencyCode: 'RON',
        centAmount: number,
        fractionDigits: number,
      },
      id: string,
    },
    quantity: number,
    discountedPricePerQuantity: [],
    addedAt: string,
    lastModifiedAt : string,
    state: [{
      quantity: number,
      state: {
        typeId: 'state',
        id: string,
      }
    }],
    priceMode: 'Platform',
    totalPrice: {
      type: 'centPrecision',
      currencyCode: 'RON',
      centAmount: number,
      fractionDigits: number,
    },
    lineItemMode: 'Standard'
  }],
  cartState: 'Active',
  totalPrice: {
    type: 'centPrecision',
    currencyCode: 'RON',
    centAmount: number,
    fractionDigits: number,
  },
  customLineItems: [],
  discountCodes: [],
  inventoryMode: 'None',
  taxMode: 'Disabled',
  taxRoundingMode: 'HalfEven',
  taxCalculationMode: 'LineItemLevel',
  refusedGifts: [],
  origin: 'Customer',
  itemShippingAddresses: []
}
