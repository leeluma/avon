import { Router } from 'express';
import { CtClient } from './lib';
import { LeapApp, LeapAppConfig } from './leap-app';
import { CartDao, ProductDao } from './daos';
import { CartController } from './controllers';
import { CartService } from './services';
import { CartRouter } from './routers';
import { CartMapper } from './mappers';
import { graphql } from './graphql';
import MagnoliaDao from './daos/magnolia.dao';

/* Build configuration */

const projectName = process.env.npm_package_name;
if (!projectName) {
  throw new Error('The "name" field in package.json is mandatory!');
}

const projectVersion = process.env.npm_package_version;
if (!projectVersion) {
  throw new Error('The "version" field in package.json is mandatory!');
}

const apiContextPath = process.env.API_CONTEXT_PATH;
if (!apiContextPath) {
  throw new Error('The "API_CONTEXT_PATH" environment variable is mandatory! (suggested value: api)');
}
const apiVersion = process.env.API_VERSION;
if (!apiVersion) {
  throw new Error('The "API_VERSION" environment variable is mandatory! (suggested value: v1)');
}
const port = parseInt(process.env.API_PORT || '0', 10);
if (!port) {
  throw new Error('The "API_PORT" environment variable is missing or not a valid number! (suggested value: 3000)');
}

const appConfig: LeapAppConfig = {
  projectName,
  projectVersion,
  apiContextPath,
  apiVersion,
  port,
};

/* Initialize dependencies */

const ctClient = new CtClient(process.env as any);
const cartDao = new CartDao({ ctClient, graphql });
const productDao = new ProductDao({ ctClient, graphql });
const cartMapper = new CartMapper();
const magnoliaDao = new MagnoliaDao();
const cartService = new CartService({
  cartMapper, cartDao, productDao, magnoliaDao,
});
const cartController = new CartController({ cartService });
const cartRouter = new CartRouter({ cartController, Router });

/* Start app */

const leapApp = new LeapApp(appConfig);
leapApp.bootstrap().then(() => {
  leapApp.mount('/carts', cartRouter.buildExpressRouter());
  leapApp.listen();
});
