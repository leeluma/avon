import HttpStatusCodes from 'http-status-codes';
import i18next from 'i18next';
import {
  Cart, LineItem, Product, Price, AddressDraft,
} from '@commercetools/platform-sdk';
import { ApiError } from '../lib';
import {
  magnoliaPriceFormatter, priceConverter, getUnitPrice, promotionToDto, getShippingInfo,
  imageToDto, getProductOffer, getPriceWithCurrency, getTotalPriceAndCurrencyCode,
} from '../lib/common';
import {
  CartDto, LineItemDto, ShippingAddressDto, PromotionDto, VariantAttribute,
} from '../dtos/cart.dto';
import { DEFAULT_QUANTITY, VARIANT_ATTRIBUTES } from '../common/constants';
import { PriceFormat } from '../dtos/magnolia.dto';

/**
   * Maps attribute to cart DTO
   * @param res - any
   * @param locale - locale of market
   * @returns
   */
export class CartMapper {
    public cartToDto = (
      cart: Cart, locale: string, priceFormat: PriceFormat, productDetails?: Product[],
    ): CartDto => {
      const totalInvoiceAmount = Number(priceConverter(cart.totalPrice.centAmount, cart.totalPrice.fractionDigits));
      const totalPriceAndCurrencyCode = getTotalPriceAndCurrencyCode(cart.totalPrice);
      let totalRetailPriceAmount = totalInvoiceAmount;
      let promotion : PromotionDto | undefined;
      if (Array.isArray(cart.discountCodes) && cart.discountCodes.length) {
        const discountCode = cart?.discountCodes[0].discountCode.obj ? cart?.discountCodes[0].discountCode.obj : undefined;
        const discountCodeId = (discountCode && discountCode?.cartDiscounts[0]?.id)
          ? discountCode?.cartDiscounts[0]?.id : '';
        promotion = promotionToDto(cart, priceFormat, discountCodeId) as PromotionDto;
        if (promotion) {
          totalRetailPriceAmount += promotion.promotionAmount;
          promotion.promotionCode = (discountCode && discountCode?.code) ? discountCode?.code : '';
        }
      }

      const cartDto: CartDto = {
        id: cart.id,
        version: cart.version,
        totalRetailPriceAmount: getPriceWithCurrency(
          totalRetailPriceAmount, totalPriceAndCurrencyCode.currencyCode, priceFormat,
        ),
        totalInvoiceAmount: getPriceWithCurrency(
          totalInvoiceAmount, totalPriceAndCurrencyCode.currencyCode, priceFormat,
        ),
        totalAmount: totalInvoiceAmount,
        currencyCode: totalPriceAndCurrencyCode.currencyCode,
        promotion,
        customerId: cart.customerId,
        anonymousId: cart.anonymousId,
        lineItems: this.lineItemsToDto(cart.lineItems, locale, priceFormat, productDetails),
        shippingAddress: cart.shippingAddress ? this.shippingAddressToDto(cart.shippingAddress) : {} as ShippingAddressDto,
        shippingInfo: getShippingInfo(cart.shippingInfo, priceFormat),
      };
      return cartDto;
    };

    /**
     *
     * @param priceFormat priceFormat
     * @returns Vat message if applicable on a market
     */
    private readonly getVatText = (priceFormat: PriceFormat): string => {
      const vatMessage = priceFormat.vatIncludedMessage ?? '';
      const isVatIncluded = priceFormat.isVatIncluded ?? false;
      return isVatIncluded === 'true' ? vatMessage : '';
    };

  /**
   * Maps shipping Address
   * @param shippingAddress - ShippingAddressDto
   * @returns ShippingAddressDto
   */
  private readonly shippingAddressToDto = (
    shippingAddress: AddressDraft,
  ): ShippingAddressDto => {
    return {
      address1: shippingAddress?.custom?.fields?.Address1 || '',
      address2: shippingAddress?.custom?.fields?.Address2 || '',
      postalCode: shippingAddress.postalCode || '',
      city: shippingAddress.city || '',
      county: shippingAddress?.custom?.fields?.county || '',
      phoneNumber: shippingAddress.phone || '',
    };
  };

  /**
   * Check variant prices have channel price
   * @param prices variants prices
   * @returns
   */
    private readonly checkChannel = (prices: Price) => {
      return (this.checkDiscount(prices));
    };

    /**
   * Check if product price have discount property then return sell price after applied promotion
   * if discount property not available then return empty object
   * @param price  - All price details including promotional prices
   * @returns - sellPrice and isPromotionApplied
   */
     private readonly checkDiscount = (price: Price) => {
       if (Object.prototype.hasOwnProperty.call(price, 'discounted') && price.discounted) {
         return {
           sellPrice: priceConverter(price.discounted.value.centAmount, price.discounted.value.fractionDigits),
           listPrice: priceConverter(price.value.centAmount, price.value.fractionDigits),
           sellPriceCT: price.discounted.value.centAmount,
           listPriceCT: price.value.centAmount,
           isPromotionApplied: true,
         };
       }
       return {
         sellPrice: priceConverter(price.value.centAmount, price.value.fractionDigits),
         listPrice: priceConverter(price.value.centAmount, price.value.fractionDigits),
         sellPriceCT: price.value.centAmount,
         listPriceCT: price.value.centAmount,
         isPromotionApplied: false,
       };
     };

/**
 * Maps line Item to Attribute
 * @param attributes - VariantAttribute
 * @returns
 */
private readonly mapVariantAttribute = (
  attributes: VariantAttribute[],
) => {
  const variantArr = attributes.map((attribute) => {
    const conditionsForAttributes1 = (attribute.name === VARIANT_ATTRIBUTES.variantType
    || attribute.name === VARIANT_ATTRIBUTES.variantValue
    || attribute.name === VARIANT_ATTRIBUTES.hexCode);

    const conditionsForAttributes2 = (attribute.name === VARIANT_ATTRIBUTES.maxPurchasableQty
      || attribute.name === VARIANT_ATTRIBUTES.discontinued);
    if (conditionsForAttributes1 || conditionsForAttributes2) {
      return {
        [attribute.name]: attribute.value.key
          ? attribute.value.label
          : attribute.value,
      };
    }
    return undefined;
  });
  return Object.assign({}, ...variantArr);
};

/**
 * set variant attribute in key
 * @param variantAttributes- variantAttributes
 * @returns setVariantAttribute
 */
private readonly setVariantAttribute = (
  variantAttributes,
) => {
  return {
    maxPurchasableQty: variantAttributes.maxPurchasableQty
    ?? DEFAULT_QUANTITY.DEFAULT_MAX_PURCHASABLE_QUANTITY,
    variantType: variantAttributes.variantType,
    variantValue: variantAttributes.variantValue ?? '',
    hexCode: variantAttributes.hexCode ?? '',
    discontinued: variantAttributes.discontinued ?? false,
  };
};

    /**
   * Maps line Item to Line Item DTO
   * @param lineItems - any
   * @param locale - string
   * @returns
   */
    private readonly lineItemsToDto = (
      lineItems: LineItem[], locale: string, priceFormat: PriceFormat, productDetails?: Product[],
    ): LineItemDto[] => {
      let availableQuantity: number;
      let variantAttributes: {
        maxPurchasableQty: number;
        variantType: string;
        variantValue: string;
        hexCode: string;
        discontinued: boolean;
      };
      let fulfilledOfferCategoryId: string;
      if (lineItems.length !== 0) {
        return lineItems.map((lineItem) => {
          if (lineItem?.variant && lineItem?.variant?.attributes) {
            variantAttributes = this.mapVariantAttribute(lineItem.variant.attributes);
          } else {
            throw new ApiError(
              HttpStatusCodes.BAD_REQUEST,
              i18next.t('error.lineItemVariantAttributesNotDefined'),
            );
          }
          availableQuantity = lineItem?.variant?.availability?.availableQuantity
          ?? DEFAULT_QUANTITY.DEFAULT_MAX_AVAILABLE_QUANTITY;
          const isAvailable = availableQuantity !== 0;
          const {
            sellPrice,
            listPrice,
            sellPriceCT,
            listPriceCT,
          } = this.checkChannel(lineItem.price ?? []);
          variantAttributes = this.setVariantAttribute(variantAttributes);
          // set category id of fulfilled offer
          if (lineItem?.discountedPricePerQuantity.length > 0) {
            lineItem?.discountedPricePerQuantity.forEach((discountedPricePerQuantity) => {
              discountedPricePerQuantity.discountedPrice.includedDiscounts.forEach((includedDiscount) => {
                fulfilledOfferCategoryId = includedDiscount.discount.obj?.custom
                && includedDiscount.discount.obj?.custom.fields['offer-category'].id;
              });
            });
          }

          const lineItemDto: LineItemDto = {
            lineItemId: lineItem.id,
            variantKey: lineItem.variant.key,
            productId: lineItem.productId,
            productKey: lineItem.productKey,
            name: lineItem.name[locale],
            skuCode: lineItem.variant.sku,
            images: imageToDto(lineItem),
            sellPrice: Number(sellPrice),
            listPrice: Number(listPrice),
            formattedListPrice: magnoliaPriceFormatter(listPriceCT, priceFormat),
            formattedSellPrice: magnoliaPriceFormatter(sellPriceCT, priceFormat),
            vatMessage: this.getVatText(priceFormat),
            unitPrice: getUnitPrice(lineItem.variant.attributes, Number(sellPriceCT), priceFormat),
            quantity: lineItem.quantity,
            modifiedTimeStamp: lineItem.lastModifiedAt,
            sequenceNumber: 0,
            maxPurchasableQty: variantAttributes.maxPurchasableQty,
            availableQuantity,
            isAvailable,
            variantType: variantAttributes.variantType,
            variantValue: variantAttributes.variantValue,
            hexCode: variantAttributes.hexCode,
            discontinued: variantAttributes.discontinued,
            offers: getProductOffer(
                productDetails as Product[],
                lineItem.productId,
                fulfilledOfferCategoryId,
            ),
          };
          return lineItemDto;
        });
      }
      return [];
    };

  /**
   * Map cart line item product ids in string
   * @param lineItems cart line item
   * @returns string of all product ids
   */
  public getCartProductId = (lineItems: LineItem[]): string => {
    return lineItems.map((lineItem) => {
      return `"${lineItem.productId}"`;
    }).join(', ');
  };

  /**
   * maps attributes
   * @param attributes
   */
  public getProductAttributes(attributes) {
    const variantArr = attributes.map((attribute) => {
      if (attribute.name === VARIANT_ATTRIBUTES.maxPurchasableQty
        || attribute.name === VARIANT_ATTRIBUTES.discontinued) {
        return { [attribute.name]: attribute?.value?.key ? attribute?.value?.label : attribute?.value };
      }
      return undefined;
    });
    return Object.assign({}, ...variantArr);
  }
}
