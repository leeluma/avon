export const DEFAULT_QUANTITY = {
  DEFAULT_MAX_PURCHASABLE_QUANTITY: 9999999,
  DEFAULT_MAX_AVAILABLE_QUANTITY: 9999999,
  DEFAULT_CENT_AMOUNT: 9999,
  BASE_NUMBER: 10,
};

export const VARIANT_ATTRIBUTES = {
  variantType: 'variantType',
  variantValue: 'variantValue',
  hexCode: 'hexCode',
  maxPurchasableQty: 'maxPurchasableQty',
  discontinued: 'discontinued',
};

export const CATEGORY_TYPE = {
  offer: 'Offer',
};

export const ATTRIBUTE_NAMES = {
  config: 'config',
  galleryVideo: 'galleryVideo',
  badges: 'badges',
  contentFillMeasurement: 'ContentFillMeasure',
  contentFill: 'ContentFill',
  availability: 'availability',
  excludeCountDown: 'excludeCountDown',
};

export const ATTRIBUTE_VALUES = {
  attributeValue: 'value',
  availabilitySku: 'skuCode',
  assetType: 'Video Gallery',
};

export const MEASUREMENT = {
  baseMeasure: 'baseMeasure',
  nodes: '@nodes',
};

export const MAGNOLIAURI = {
  WARE_HOUSE_SETTINGS: '.rest/delivery/global-settings/{{country}}/settings/warehouseSettings',
  PRICE_FORMAT: '.rest/delivery/global-settings/{{country}}/settings/priceFormat',
};

export const GRAPHQL_QUERY = {
  getProduct: `query { products(skus: "{{sku}}")
  { results { id key masterData { current { allVariants { sku
    attributesRaw{ name value }
    availability { channels { results { availability 
    {
    availableQuantity isOnStock
    }
    } } }
    } } } } }
  }`,
  getCartPaymentInfo: `query { cart(id: "{{cartId}}")
  {  
    paymentInfo {
      payments {
        paymentStatus {
          state {
            name(locale: "{{locale}}")
          }
        }
      }
    }
  }
  }`,
};
