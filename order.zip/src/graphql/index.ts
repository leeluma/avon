import { readFile } from 'fs/promises';

const loadAsync = async (fileName: string): Promise<string> =>
  (await readFile(`${__dirname}/../graphql/${fileName}.graphql`, 'utf-8'))
    .toString();

export const graphql = {
  getCartDetails: loadAsync('get-cart-details'),
  getProducts: loadAsync('get-products'),
};
